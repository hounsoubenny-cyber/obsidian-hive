// ============================================================================
// Enums et mappings — Obsidian Hive
// ============================================================================

import { ScanArgs, ScanInstanceArgs } from "../scanner/types";

export type AssetType = "web_site" | "web_app" | "network" | "server";
export type AssetStatus = "active" | "suppressed" | "inactive";

export const AssetTypeMapping: Record<AssetType, string> = {
  web_site: "🌐 Site web",
  web_app: "🧩 Application web",
  network: "📡 Réseau",
  server: "🖥️ Serveur distant",
};

export enum AssetStatutEnum {
  ACTIVE = "active",
  SUPPRESSED = "suppressed",
  INACTIVE = "inactive",
}

export const AssetStatusMapping: Record<AssetStatus, string> = {
  active: "✅ Actif",
  suppressed: "⏸️ Suspendu",
  inactive: "❌ Inactif",
};

export type Priority = 1 | 2 | 3 | 4;

export const PRIORITY_MAPPING: Record<Priority, string> = {
  1: "🟢 Basse",
  2: "🟡 Moyenne",
  3: "🟠 Haute",
  4: "🔴 Critique",
};

export enum PriorityEnum {
  LOW = 1,
  MEDIUM = 2,
  HIGH = 3,
  CRITICAL = 4,
}

export type NetworkDeploymentMode = "gateway" | "span_mirror" | "bridge";

export enum NetworkDeploymentModeEnum {
  GATEWAY = "gateway",
  SPAN_MIRROR = "span_mirror",
  BRIDGE = "bridge",
}

export const NetworkDeploymentModeMapping: Record<NetworkDeploymentMode, string> = {
  gateway: "🌐 Gateway (routeur)",
  span_mirror: "🔀 SPAN / Mirroring",
  bridge: "🌉 Bridge transparent",
};

// ── Types Spécifiques ServerAsset & Agent ────────────────────────────────────

export type AgentStatus = "pending_install" | "connected" | "offline" | "revoked";

export const AgentStatusMapping: Record<AgentStatus, string> = {
  pending_install: "⏳ En attente d'installation",
  connected: "🟢 Connecté (En ligne)",
  offline: "⚪ Hors ligne",
  revoked: "⛔ Révoqué",
};

export type AgentCapabilities = 
  | "scanner_web" 
  | "anti_phishing" 
  | "sandbox" 
  | "ids_ips" 
  | "simulator";

export const AgentCapabilitiesMapping: Record<AgentCapabilities, string> = {
  scanner_web: "🌐 Scan de vulnérabilités Web",
  anti_phishing: "🎣 Détection Anti-Phishing",
  sandbox: "📦 Sandbox d'exécution sécurisée",
  ids_ips: "🛡️ Détection d'intrusions (IDS/IPS)",
  simulator: "⚔️ Simulation d'attaques (MITRE)",
};

export interface ServerToolInfo {
  name: string;
  description: string;
  module: string;
  args: Record<string, any>;
}

export type Severity = "low" | "medium" | "high" | "critical";

export const SeverityMapping: Record<Severity, string> = {
  low: "🟢 Basse",
  medium: "🟡 Moyenne",
  high: "🟠 Haute",
  critical: "🔴 Critique",
};

export type Source = 
  | "scanner_web"
  | "ids_ips"
  | "sandbox"
  | "test"
  | "manual"
  | "server"
  | "email"
  | "code";

// ============================================================================
// Modèle de Base
// ============================================================================

export interface AddAssetResult {
  asset_id?: string;
  asset_data?: Asset;
  install_command?: string;
  error: string | null;
  status: string;
}

export interface AssetItem {
  id?: string;
  item_db_id?: number | null;
  name: string | null;
  type: AssetType;
  status: AssetStatus;
  priority: Priority;
  tags: string[];
  auto_fix?: boolean;
  created_at?: string;
  updated_at?: string;
  timestamp?: number;
  metadata_: Record<string, any>;
  every?: number;
  run_every?: boolean;
  already_exec_for_first_time?: boolean;
  last_rest_exec_time?: number | null;
  every_task_id?: string | null;
  workflow_task_id?: string | null;

  // Champs optionnels transverses
  deployment_mode?: NetworkDeploymentMode | null;
  config_path?: string | null;
  init_config?: Record<string, any> | null;
  run_config?: Record<string, any> | null;
  conf_content?: string | null;
  
  // Champs ServerAsset
  install_token?: string | null;
  install_token_expires_at?: string | null;
  agent_status?: AgentStatus;
  last_heartbeat?: string | null;
  capabilities?: AgentCapabilities[];
  installed_modules?: AgentCapabilities[];
  system_info?: Record<string, any>;
  allowed_tools?: string[];
  pending_deletion?: boolean;
}

// ============================================================================
// Sous-Types d'Actifs Spécialisés
// ============================================================================

export interface WebAsset extends AssetItem {
  type: "web_site" | "web_app";
  url: string;
  init_config: Record<string, any> | null;
  run_config: Record<string, any> | null;
  fix_allowed: boolean;
  source_code_dir: string | null;
}

export interface NetworkAsset extends AssetItem {
  type: "network";
  deployment_mode: NetworkDeploymentMode;
  config_path: string;
  every: 0;
  run_every?: false;
}

export interface ServerAsset extends AssetItem {
  type: "server";
  agent_status: AgentStatus;
  last_heartbeat?: string | null;
  capabilities: AgentCapabilities[];
  installed_modules: AgentCapabilities[];
  system_info: Record<string, any>;
  allowed_tools: string[];
  every: 0;
  run_every?: false;
}

// ── Modèles de création ──────────────────────────────────────────────────────

export interface WebAssetModel extends Omit<WebAsset, "init_config" | "run_config" | "url"> {
  scan_args: ScanArgs;
  scan_instance_args: ScanInstanceArgs;
  manage_immediatly?: boolean;
  init_config?: Record<string, unknown> | null;
  run_config?: Record<string, unknown> | null;
  url?: string | null;
}

export interface NetworkAssetModel extends Omit<NetworkAsset, "config_path"> {
  conf_content: string;
  manage_immediatly?: boolean;
  config_path?: string;
}

export interface ServerAssetModel extends AssetItem {
  type: "server";
}

export type Asset = WebAsset | NetworkAsset | ServerAsset;

// ============================================================================
// Requêtes et Réponses API
// ============================================================================

export interface ListAssetDataRequest {
  status?: AssetStatus | null;
  type_?: AssetType | null;
  priority?: Priority | null;
  tags?: string[] | null;
}

export interface GetAssetDataRequest {
  identifier: string;
  include_name?: boolean;
  first?: boolean;
}

export interface ManageAssetDataRequest {
  asset_id: string;
}

export interface RemoveAssetDataRequest extends ManageAssetDataRequest {}
export interface ResumeAssetDataRequest extends ManageAssetDataRequest {}
export interface PauseAssetDataRequest extends ManageAssetDataRequest {}

export interface UpdateAssetDataRequest extends ManageAssetDataRequest {
  attrs: Record<string, any>;
  restart_workflow?: boolean;
}

export interface SyncSourceCodeDataRequest extends ManageAssetDataRequest {
  admin_source_code_dir: string;
}

// ── Requêtes Spécifiques ServerAsset ──────────────────────────────────────────

export interface ServerAgentRevokeRequest {
  asset_id: string;
}

export interface RotateSecretRequest {
  asset_id: string;
}

export interface ReactivateServerAssetRequest {
  asset_id: string;
}

export interface ServerCapabilitiesRequest {
  asset_id: string;
  capabilities: AgentCapabilities[];
}

export interface ServerToolsRequest {
  asset_id: string;
  tools: string[];
}

// ── Actions Collectives (Bulk) ──────────────────────────────────────────────

export interface PauseAssetsDataRequest {
  asset_type?: AssetType | null;
  asset_ids?: string[] | null;
  priority?: Priority | null;
  tags?: string[] | null;
}

export interface ResumeAssetsDataRequest {
  asset_type?: AssetType | null;
  asset_ids?: string[] | null;
  priority?: Priority | null;
  tags?: string[] | null;
}

export interface BulkAssetActionResponse {
  status: "success" | "error" | "ok";
  results?: Record<string, any>;
  error?: string | null;
}

// ── Réponses API ────────────────────────────────────────────────────────────

export interface ListAssetResponse {
  assets: Asset[];
}

export interface GetAssetResponse {
  assets: Asset[] | null;
}

export interface ManageAssetResponse {
  status: "success" | "error" | "ok";
  asset_id?: string;
  error?: string | null;
}

export interface RemoveAssetResponse {
  status: string;
  asset_id: string | number;
}

export interface RotateSecretResponse {
  status: "success" | "error";
  secret?: string;
  error?: string;
}

export interface ReactivateServerAssetResponse {
  status: "success" | "error";
  install_token?: string;
  install_command?: string;
  error?: string;
}

// ============================================================================
// Recherche Unifiée
// ============================================================================

export interface SearchAssetDataRequest {
  query: string;
  include_name?: boolean;      
  case_sensitive?: boolean;    
  partial?: boolean;           
  first?: boolean;             
  limit?: number;              
}

export interface SearchAssetResponse {
  assets: Asset[] | null;
  total: number;
  query: string;
  params: {
    include_name: boolean;
    case_sensitive: boolean;
    partial: boolean;
    first: boolean;
    limit: number;
  };
}