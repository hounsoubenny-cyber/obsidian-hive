// ============================================================================
// Types & Interfaces — Simulateur d'Attaque IA (simulateur_attaque)
// ============================================================================

export type SimMode = "auto" | "interactive";

export type SimStatus = 
  | "starting" 
  | "running" 
  | "waiting" 
  | "completed" 
  | "stopped" 
  | "failed";

export type ListMergeMode = "replace" | "add" | "keep";

export type SimulateurAttaqueTabType = 
  | "launcher" 
  | "live" 
  | "containers" 
  | "networks" 
  | "reports" 
  | "health";

// ─────────────────────────────────────────────────────────────────────────────
// 1. CONFIGURATIONS DES 9 TACTIQUES MITRE ATT&CK
// ─────────────────────────────────────────────────────────────────────────────

export interface ReconConfig {
  port_range?: number[];
  timeout_socket?: number;
}

export interface SSHConfig {
  timeout?: number;
  total_timeout?: number | null;
  delay?: number;
  max_attempts?: number;
  add_common?: boolean;
  usernames?: string[];
  passwords?: string[];
}

export interface FTPConfig {
  timeout?: number;
  total_timeout?: number | null;
  max_attempts?: number;
  add_common?: boolean;
  usernames?: string[];
  passwords?: string[];
}

export interface HTTPConfig {
  timeout?: number;
  preference?: string;
  add_common?: boolean;
  paths?: string[];
}

export interface ExecConfig {
  timeout?: number;
  exec_timeout?: number;
  commands?: string[];
  add_common?: boolean;
  quick?: boolean;
}

export interface ReverseShellConfig {
  attaquant_ip?: string;
  attaquant_port?: number;
  timeout?: number;
  exec_timeout?: number;
  listener_timeout?: number;
  total_timeout?: number;
  commands?: string[];
}

export interface PersistenceConfig {
  ssh_key_timeout?: number;
  ssh_key_exec_timeout?: number;
  ssh_key_algo?: "Ed25519" | "RSA" | "ECDSA" | string;
  cron_script_path?: string;
  cron_expression?: string;
  cron_level?: "simple" | "intermediate" | "silent" | string;
}

export interface PrivescConfig {
  timeout?: number;
  exec_timeout?: number;
}

export interface CredAccessConfig {
  timeout?: number;
  exec_timeout?: number;
}

export interface LateralMovConfig {
  max_depth?: number;
  max_workers?: number;
  join_timeout?: number;
}

export interface ExfilConfig {
  c2_url?: string;
  timeout?: number;
}

export interface DefEvasionConfig {
  timeout?: number;
  exec_timeout?: number;
}

export interface SimConfig {
  recon?: ReconConfig;
  ssh?: SSHConfig;
  ftp?: FTPConfig;
  http?: HTTPConfig;
  execution?: ExecConfig;
  python_execution?: ExecConfig;
  reverse_shell?: ReverseShellConfig;
  persistence?: PersistenceConfig;
  privesc?: PrivescConfig;
  credential_access?: CredAccessConfig;
  lateral_movement?: LateralMovConfig;
  exfiltration?: ExfilConfig;
  defense_evasion?: DefEvasionConfig;
}

// ─────────────────────────────────────────────────────────────────────────────
// 2. REQUÊTES & RÉPONSES DE SIMULATION
// ─────────────────────────────────────────────────────────────────────────────

export interface StartSimRequest {
  image: string;
  mode?: SimMode;
  services?: Record<string, any> | null;
  use_llm?: boolean;
  llm_config?: Record<string, any> | null;
  sim_config?: SimConfig | null;
  container_name?: string | null;
  authorize_network?: boolean;
  network_caps?: boolean;
  default_services?: Record<string, number[]> | null;
  only_listening?: boolean;
  use_default_excludes?: boolean;
  capture_excluded_names?: string[] | null;
  capture_excluded_ports?: number[] | null;
  capture_excluded_pids?: number[] | null;
  auto_capture?: boolean;
}

export interface StartSimResponse {
  session_id: string;
  status: SimStatus;
  message: string;
}

export interface StopSimResponse {
  session_id: string;
  status: "stopped";
  message: string;
}

export interface SimStatusResponse {
  session_id: string;
  mode: SimMode;
  image: string;
  status: SimStatus;
  started_at: string;
  ended_at?: string | null;
  current_step?: string | null;
  progress: number;
  error?: string | null;
  actions_done: string[];
}

export interface ActionDetailInfo {
  available: boolean;
  reason: string;
  prereq: string;
}

export interface AvailableActionsResponse {
  session_id: string;
  actions_available: string[];
  actions_available_with_details?: Record<string, ActionDetailInfo> | null;
  actions_done: string[];
}

// ─────────────────────────────────────────────────────────────────────────────
// 3. STRUCTURE DU RAPPORT D'AUDIT CONSOLIDÉ
// ─────────────────────────────────────────────────────────────────────────────

export interface MitreTechniqueStatus {
  status: "SUCCÈS" | "ÉCHEC";
  errors?: string[];
}

export interface ExecutiveSummary {
  compromised: boolean;
  root_access: boolean;
  credentials_harvested_count: number;
  lateral_movement_hosts_count: number;
  persistence_installed_count: number;
  criticality_level: "CRITIQUE" | "ÉLEVÉ" | "MOYEN" | "FAIBLE";
}

export interface RemediationItem {
  vulnerability: string;
  impact: string;
  mitigation: string;
}

export interface CompromisedCredential {
  service: string;
  port: string | number;
  username: string;
  password: string;
}

export interface CompromisedShadowHash {
  user: string;
  algo: string;
  hash: string;
}

export interface StolenSshKey {
  name: string;
  source: string;
  type: string;
  usable: boolean;
}

export interface KnownHostItem {
  host: string;
  port: number;
}

export interface LateralHostCompromised {
  target: string;
  user: string;
  auth_method: string;
}

export interface SimulationReport {
  metadata?: {
    target_ip?: string;
    generated_at?: string;
    status?: string;
    simulator_version?: string;
  };
  executive_summary?: ExecutiveSummary;
  mitre_attack_matrix?: Record<string, Record<string, MitreTechniqueStatus>>;
  compromised_data?: {
    ports_discovered?: number[];
    credentials?: CompromisedCredential[];
    system_hashes?: CompromisedShadowHash[];
    stolen_ssh_keys?: StolenSshKey[];
    known_hosts_discovered?: KnownHostItem[];
    lateral_hosts_compromised?: LateralHostCompromised[];
    exfiltrated_payloads_count?: number;
    created_files_on_target?: string[];
  };
  technical_timeline?: Array<{ tactic: string; technique: string; success: boolean }>;
  remediation_plan?: RemediationItem[];
  // Structure spécifique au mode interactif (raw report)
  ip?: string;
  started_at?: string;
  ended_at?: string;
  done_steps?: string[];
  steps_results?: Record<string, any[]>;
  logs?: any[];
  state?: Record<string, any>;
  report?: SimulationReport; // Cas où le rapport est imbriqué
}

// ─────────────────────────────────────────────────────────────────────────────
// 4. MODÈLES DOCKER & CONTENEURS
// ─────────────────────────────────────────────────────────────────────────────

export interface DockerImageInfo {
  id: string;
  short_id: string;
  tags: string[];
  labels: Record<string, string>;
  size: number;
  size_human: string;
  created: string;
}

export type ContainerStatusType = 
  | "created" 
  | "running" 
  | "exited" 
  | "paused" 
  | "restarting" 
  | "removing" 
  | "dead" 
  | "stopped" 
  | "unknown";

export interface ContainerInfo {
  id: string;
  short_id: string;
  name: string;
  image: string;
  status: ContainerStatusType;
  ip?: string | null;
  created: string;
  size: number;
  size_human: string;
  labels: Record<string, string>;
  is_simatk: boolean;
}

export interface ContainerCreateRequest {
  image: string;
  name?: string | null;
  network?: string;
  cap_add?: string[] | null;
  labels?: Record<string, string> | null;
  environment?: Record<string, string> | null;
  ports?: Record<number, number> | null;
  command?: string;
}

export interface ContainerExecRequest {
  command: string | string[];
}

export interface ContainerExecResponse {
  success: boolean;
  container: string;
  command: string | string[];
  exit_code: number;
  stdout?: string | null;
  stderr?: string | null;
  message?: string | null;
}

// ─────────────────────────────────────────────────────────────────────────────
// 5. MODÈLES RÉSEAUX DOCKER (LAB & TOPOLOGIE)
// ─────────────────────────────────────────────────────────────────────────────

export interface NetworkInfo {
  name: string;
  id: string;
  short_id: string;
  driver: string;
  subnet?: string | null;
  internal: boolean;
  containers_count: number;
  labels: Record<string, string>;
  created: string;
}

export interface NetworkCreateRequest {
  name: string;
  driver?: "bridge" | "overlay";
  internal?: boolean;
  labels?: Record<string, string> | null;
}

export interface NetworkConnectRequest {
  container_name: string;
  ip?: string | null;
  aliases?: string[] | null;
}

export interface NetworkMoveRequest {
  container_name: string;
  source_network: string;
  destination_network: string;
  force?: boolean;
  ip?: string | null;
  aliases?: string[] | null;
}

export interface NetworkContainerInfo {
  id: string;
  name: string;
  status: string;
  image: string;
  ip?: string | null;
  labels: Record<string, string>;
  created: string;
  is_simatk: boolean;
  message?: string | null;
}

// ─────────────────────────────────────────────────────────────────────────────
// 6. CLONAGE DE SYSTÈME & SERVICES
// ─────────────────────────────────────────────────────────────────────────────

export interface CloneRequest {
  src?: string | null;
  dest?: string | null;
  archive_path?: string | null;
  remove_back_up?: boolean;
  container_name?: string | null;
  network_caps?: boolean;
  authorize_network?: boolean;
}

export interface CloneStatusResponse {
  clone_id: string;
  status: "running" | "completed" | "failed" | "stopped" | "not_found";
  image?: string | null;
  services?: Record<string, any> | null;
  error?: string | null;
  started_at?: string | null;
  ended_at?: string | null;
  message?: string | null;
}

export interface ValidateServicesResponse {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

// ─────────────────────────────────────────────────────────────────────────────
// 7. MESSAGES WEBSOCKET SERVEUR <-> CLIENT
// ─────────────────────────────────────────────────────────────────────────────

export interface WSSimMessage {
  type: 
    | "connected"
    | "replay_start"
    | "replay_end"
    | "sim_status"
    | "sim_ready"
    | "step_start"
    | "step_progress"
    | "step_success"
    | "step_result"
    | "step_end"
    | "step_error"
    | "step_cancelled"
    | "llm_suggest"
    | "llm_review"
    | "sim_state"
    | "sim_finished"
    | "finish"
    | "error"
    | "pong";

  session_id?: string;
  status?: SimStatus;
  mode?: SimMode;
  message?: string;
  current_step?: string | null; 
  step?: string;
  progress?: number;
  ip?: string;
  data?: any;
  result?: any;
  actions_available?: string[];
  actions_details?: Record<string, ActionDetailInfo>;
  actions_available_with_details?: Record<string, ActionDetailInfo>;
  actions_done?: string[];
  state_summary?: Record<string, any>;
  state?: Record<string, any>;
  suggestion?: any;
  review?: any;
  action?: string;
  report?: SimulationReport | Record<string, any>;
  error?: string;
  trace?: string;
  traceback?: string;
  timestamp?: string;
}