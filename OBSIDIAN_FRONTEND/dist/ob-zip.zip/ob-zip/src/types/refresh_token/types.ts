export interface RefreshTokenData {
    token: string;
    username: string
}