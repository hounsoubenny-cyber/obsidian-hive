// ============================================================================
// Enums et Mappings — Sandbox 
// ============================================================================

export type ThreatLevel = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

export enum ThreatLevelEnum {
  LOW = "LOW",
  MEDIUM = "MEDIUM",
  HIGH = "HIGH",
  CRITICAL = "CRITICAL",
}

export const ThreatLevelMapping: Record<ThreatLevel, string> = {
  LOW: "🟢 Faible (Bénin)",
  MEDIUM: "🟡 Moyen (Suspect)",
  HIGH: "🟠 Élevé (Dangereux)",
  CRITICAL: "🔴 Critique (Malveillant)",
};

export type SupportedLanguage =
  | "python"
  | "javascript"
  | "php"
  | "ruby"
  | "perl"
  | "java"
  | "go"
  | "rust"
  | "lua"
  | "r"
  | "powershell"
  | "c"
  | "cpp"
  | "bash";

export const LanguageMapping: Record<SupportedLanguage, string> = {
  python: "🐍 Python",
  javascript: "🟨 JavaScript (Node.js)",
  php: "🐘 PHP",
  ruby: "💎 Ruby",
  perl: "🐪 Perl",
  java: "☕ Java",
  go: "🐹 Go",
  rust: "🦀 Rust",
  lua: "🌙 Lua",
  r: "📊 R",
  powershell: "💙 PowerShell",
  c: "⚙️ C",
  cpp: "⚙️ C++",
  bash: "🐚 Bash / Shell",
};


export type SyscallFamily = "network" | "file" | "process" | "memory" | "system" | "unknown";

export const SyscallFamilyMapping: Record<SyscallFamily, string> = {
  network: "🌐 Réseau",
  file: "📁 Fichier",
  process: "⚡ Processus",
  memory: "🧠 Mémoire",
  system: "⚙️ Système",
  unknown: "❓ Inconnu",
};

// ============================================================================
// Types de Base & Sous-structures du Sandbox
// ============================================================================

/** Configuration de détonation dans le container Docker */
export interface SandboxConfigOverrides {
  network_disabled?: boolean;   // default: true
  mem_limit?: string;           // default: "256m"
  cpu_quota?: number;           // default: 50000 (50% core)
  cpu_period?: number;          // default: 100000
  pids_limit?: number;          // default: 64 (anti-fork bomb)
  read_only?: boolean;          // default: false
  user?: string;                // default: "sandbox"
  workdir?: string;             // default: "/sandbox/work"
  extra_env?: Record<string, string> | null;
  exec_timeout?: number;        // default: 30.0s
  enable_strace?: boolean;      // default: true
  enable_fs_monitor?: boolean;  // default: true
  alert_threshold?: number;     // default: 60
  decay_interval?: number;      // default: 10.0s
  decay_amount?: number;        // default: 5
}

/** Alerte de menace déclenchée en temps réel par le BehaviorScorer */
export interface ThreatAlertReport {
  timestamp: string;            // ISO datetime
  threat_score: number;         // 0 à 100
  threat_level: ThreatLevel;
  trigger_event?: string;       // Événement déclencheur résumé
  pattern_detected: string | null; // Ex: "reverse_shell", "shadow_read", "fileless_exec"
  canary_triggered: boolean;    // True si un honeypot (.env, id_rsa, /etc/shadow) a été touché
  session_duration: number;     // Seconde exacte du déclenchement
  mitre?: string | null;        // Identifiant MITRE ATT&CK (ex: "T1059.004")
  description?: string | null;  // Description de la technique d'attaque
}

/** Résultat brut de l'exécution dans le container */
export interface ExecutionResultSummary {
  success: boolean;
  exit_code: number | null;
  stdout: string;
  stderr: string;
  stdout_length?: number;
  stderr_length?: number;
  language: string;
  filename: string;
  code_filename?: string | null;
  command: string;
  duration: number;             // Durée en secondes
  timestamp: string;
  timeout_passed: boolean;
  summary?: {
    status: string;
    exit: number | string;
    duration: string;
    timeout: string;
  };
}

/** Rapport complet retourné après analyse dynamique */
export interface SandboxReport {
  session_id: string;
  config: SandboxConfigOverrides | Record<string, any>;
  exec_result: ExecutionResultSummary | null;
  final_score: number;          // 0 à 100
  final_level: ThreatLevel;
  alerts: ThreatAlertReport[];
  session_duration: number;
  timestamp: string;
  killed: boolean;              // True si le container a été stoppé d'urgence (SIGKILL)
  stats?: {
    container_pid?: number | null;
    fs_root?: string | null;
    events_processed?: number;
    syscall_stats?: {
      total_lines: number;
      total_events: number;
      parse_rate: number;
      running: boolean;
    } | null;
    error?: string;
  };
}

// ============================================================================
// 1. ROUTE : POST /api/analyse_code (Détonation Complète)
// ============================================================================

export interface AnalyzeCodeFormDataRequest {
  code?: string;                // Code source brut
  file?: File;                  // Fichier source uploadé (.py, .sh, .c...)
  language?: SupportedLanguage | string; // Langage (optionnel si auto-détecté)
  config_str?: string;          // JSON stringifié de SandboxConfigOverrides
  use_cache?: number;           // 1 = activé (défaut), 0 = désactivé
}

export type AnalyzeCodeResponse = SandboxReport;

// ============================================================================
// 2. ROUTE : POST /api/estimate_risk (Estimation Statique Rapide < 1s)
// ============================================================================

export interface EstimateRiskFormDataRequest {
  code?: string;
  file?: File;
}

export interface EstimateRiskResponse {
  risk_level: ThreatLevel;
  risk_score: number;           // 0 à 100
  flags: string[];              // Ex: ["Pattern reverse shell (+70)", "Lecture /etc/shadow (+40)"]
  recommend_sandbox: boolean;   // True si le score statique justifie une détonation
  language_detected: string | null;
}

// ============================================================================
// 3. ROUTE : GET /api/languages (Langages Supportés)
// ============================================================================

export interface SupportedLanguagesResponse {
  languages: SupportedLanguage[];
  count: number;
  timestamp: string;
}

// ============================================================================
// 4. ROUTE : GET /api/config (Configuration par Défaut)
// ============================================================================

export interface SandboxDefaultConfigResponse {
  image_name: string;
  mem_limit: string;
  cpu_quota: number;
  pids_limit: number;
  exec_timeout: number;
  alert_threshold: number;
  network_disabled: boolean;
  supported_languages: SupportedLanguage[];
  timestamp: string;
}

// ============================================================================
// 5. ROUTE : GET /api/status/containers (Monitoring des Containers Actifs)
// ============================================================================

export interface ContainerStatusItem {
  status: "running" | "exited" | "paused" | "error" | string;
  pid: number | null;
  healthy: boolean;
  session_id: string;
  container_name: string | null;
  image_name: string;
  timestamp: string;
  error: string | null;
}

export type ContainerStatusResponse = ContainerStatusItem[];

// ============================================================================
// 6. ROUTE : GET /api/status/health (Santé du Serveur Sandbox)
// ============================================================================

export interface SandboxHealthResponse {
  status: "healthy" | "unhealthy" | string;
  timestamp: string;
  active_sessions: string[];    // IDs des sessions de détonation en cours
  error: string | null;
}

// ============================================================================
// 7. ROUTE : GET /api/rate-limit-status & GET /api/close
// ============================================================================

export interface RateLimitStatusResponse {
  ip: string;
  limit: string;                // Ex: "10/minute"
}

export interface CloseApiResponse {
  message: string;
}