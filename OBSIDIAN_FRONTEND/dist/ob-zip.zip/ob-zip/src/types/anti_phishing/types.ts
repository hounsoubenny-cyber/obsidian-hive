// ============================================================================
// Enums et Mappings (Anti-Phishing ShieldAI)
// ============================================================================

export type DecisionType = "safe" | "suspicious" | "phishing" | "error";

export enum DecisionEnum {
  SAFE = "safe",
  SUSPICIOUS = "suspicious",
  PHISHING = "phishing",
  ERROR = "error",
}

export const DecisionMapping: Record<DecisionType, string> = {
  safe: "🟢 Sûr / Légitime",
  suspicious: "🟡 Suspect",
  phishing: "🔴 Phishing / Malveillant",
  error: "❌ Erreur d'analyse",
};

export type SpfStatus = "pass" | "fail" | "neutral" | "absent";
export enum SpfStatusEnum {
  PASS = "pass",
  FAIL = "fail",
  NEUTRAL = "neutral",
  ABSENT = "absent",
}
export const SpfStatusMapping: Record<SpfStatus, string> = {
  pass: "✅ Pass (Valide)",
  fail: "❌ Fail (Échec)",
  neutral: "⚪ Neutral",
  absent: "⚠️ Absent",
};

export type DkimStatus = "present" | "absent";
export enum DkimStatusEnum {
  PRESENT = "present",
  ABSENT = "absent",
}
export const DkimStatusMapping: Record<DkimStatus, string> = {
  present: "✅ Signé (Présent)",
  absent: "❌ Non signé (Absent)",
};

export type PassiveRiskLevel =
  | "✅ NÉGLIGEABLE"
  | "📊 FAIBLE"
  | "📊 MOYEN"
  | "⚠️ ÉLEVÉ"
  | "🚨 CRITIQUE"
  | "✅ DOMAINE VÉRIFIÉ"
  | "❌ ERREUR";

export type HistoryMode = "all" | "json" | "txt";

// ============================================================================
// Types de Base & Sous-structures
// ============================================================================

/** Prédiction brute retournée par le modèle IA tabulaire (PhishingIA) */
export interface IaPredictionBreakdown {
  predict_proba?: Record<string, { phishing: number; safe: number }>;
  predict?: Record<string, string>;
  true_labels?: Record<string, string>;
}

/** Flag unitaire levé lors de l'analyse heuristique/passive */
export interface PassiveFlag {
  message: string;
  points: number;
}

/** Résultat de l'analyse passive (18 critères) */
export interface PassivePredictionBreakdown {
  risk_level: PassiveRiskLevel | string;
  risk_score: number;
  is_phishing: boolean;
  flags?: PassiveFlag[] | [string, number][];
  flag?: string;
}

/** Détails techniques d'une analyse d'URL */
export interface UrlAnalysisBreakdown {
  ia_pred_proba?: number | null;
  ia_pred_proba_phishing?: number | null;
  ia_pred_proba_safe?: number | null;
  ia_pred?: string | null;
  passive_analyze?: null;
  passive_analyze_prob?: number;
  passive_analyze_level?: string;
}

/** Résumé de l'analyse d'une URL contenue dans un email */
export interface MailUrlSummary {
  url: string;
  decision: DecisionType | string;
  confidence: number;
}

/** Détails et métadonnées d'analyse d'email */
export interface MailAnalysisBreakdown {
  bert_prob: {
    phishing: number;
    safe: number;
  } | null;
  mail_passive_score: number;
  ratio_urls_phishing: number;
  max_url_score: number;
  header_risk: number;
  urls_summary: MailUrlSummary[];
  nb_urls_total: number;
  nb_urls_phishing: number;
  headers: {
    spf?: string;
    dkim?: string;
    from?: string;
    reply_to?: string;
  };
  critical_url?: string;
}

// ============================================================================
// 1. ROUTE : POST /api/analyze (Analyse d'URL)
// ============================================================================

export interface AnalyzeUrlRequest {
  url: string;
  check_blacklist?: boolean;    // default: false (Interroge PhishDestroy)
  check_right_click?: boolean;  // default: false (Détecte blocage clic droit)
  explain?: boolean;            // default: true  (Retourne les flags détaillés)
}

export interface AnalyzeUrlResponse {
  url: string;
  final_decision: DecisionType;
  confidence: number;           // 0.0 à 1.0
  source: string;               // "whitelist" | "ia_prediction(haut confiance)" | "url_critique" | ...
  date: string;                 // Format: "DD/MM/YYYY à HH:MM:SS"
  elapsed: number;              // Temps en secondes
  advice?: string;              // Conseil de sécurité si applicable
  breakdown?: UrlAnalysisBreakdown;
  ia_pred?: IaPredictionBreakdown;
  passive_pred?: PassivePredictionBreakdown;
  error?: string;
}

// ============================================================================
// 2. ROUTE : POST /api/analyze_mail (Analyse d'Emails)
// ============================================================================

/**
 * Payload envoyé sous forme de FormData (multipart/form-data)
 */
export interface AnalyzeMailFormDataRequest {
  files?: File[];               // Fichiers .eml
  mails?: string[];             // Contenus texte brut d'emails
  check_blacklist?: boolean;    // default: false
}

/** Résultat de l'analyse d'un email unitaire */
export interface AnalyzeMailItemResult {
  final_decision: DecisionType;
  confidence: number;
  source: string;
  date: string;
  elapsed: number;
  sender: string;
  subject: string;
  nb_urls_total: number;
  nb_urls_phishing: number;
  spf: SpfStatus | string;
  dkim: DkimStatus | string;
  bert_available?: boolean;
  advice?: string;
  breakdown?: MailAnalysisBreakdown;
  history?: {
    json: string;
    txt: string;
  };
  error?: string;
}

export interface AnalyzeMailResponse {
  results: AnalyzeMailItemResult[];
  total: number;
  phishing_count: number;
  safe_count: number;
  suspicious_count: number;
}

// ============================================================================
// 3. ROUTE : POST & GET /api/settings (Configuration)
// ============================================================================

export interface UserSettings {
  check_blacklist: boolean;
  explain: boolean;
  check_right_click: boolean;
}

export interface UpdateSettingsRequest extends Partial<UserSettings> {}

export interface UpdateSettingsResponse {
  message: string;
  status: "Succès" | "Erreur";
  settings: UserSettings;
  errors: any[];
}

export interface FullAppConfig extends UserSettings {
  model_dir: string;
  model_path: string;
  features_name: string[];
  n_features: number;
  refit_time: number;
  refit: boolean;
  backup_models: boolean;
  comparison_threshold: number;
  _all_: boolean;
  path_to_original_dataset: string;
  mail_model_dir: string;
  mail_model_type: "fast" | "full" | string;
}

// ============================================================================
// 4. ROUTES : GET /api/history & GET /api/history_mail (Historique)
// ============================================================================

export interface HistoryItemUrl {
  url: string;
  final_decision: DecisionType;
  confidence: number;
  source: string;
  date: string;
  elapsed: number;
  breakdown?: UrlAnalysisBreakdown;
}

export interface HistoryItemMail {
  date: string;
  final_decision: DecisionType;
  confidence: number;
  source: string;
  elapsed: number;
  sender: string;
  subject: string;
  nb_urls_total: number;
  nb_urls_phishing: number;
  spf: string;
  dkim: string;
}

export interface GetHistoryRequest {
  mode?: HistoryMode; // default: "all"
}

export interface HistoryUrlResponse {
  json: HistoryItemUrl[];
  txt: string;
  mode: string;
  error: any[];
}

export interface HistoryMailResponse {
  json: HistoryItemMail[];
  txt: string;
  mode: string;
  errors: any[];
}

// ============================================================================
// 5. ROUTES SYSTÈME : Health, Rate-Limit, Close
// ============================================================================

export interface HealthResponse {
  status: "healthy" | string;
  date: string;                 // ISO string
  ml_available: boolean;
  react: boolean;
  rate_limit: number;           // Ex: 30
  current_request_number: number;
  month_request_number: number;
  all_request_number: number;
}

export interface RateLimitStatusResponse {
  ip: string;
  limit: string;                // Ex: "30/minute"
}

export interface CloseApiResponse {
  "message ": string;
}