// ============================================================================
// Types & Interfaces — Module IDS/IPS (ids_ips)
// Obsidian Hive / ShieldAI
// ============================================================================

export type IdsTabType = 
  | "config"   
  | "health"
  | "bokeh"
  | "dashboard"
  | "health"
  | "login"
  | "help";

// ─────────────────────────────────────────────────────────────────────────────
// 1. GESTION DES SONDES RÉSEAU (FLEET & PROBES DISCOVERY)
// ─────────────────────────────────────────────────────────────────────────────

export type NetworkDeploymentMode = "gateway" | "span_mirror" | "bridge";

export interface NetworkProbeEndpoint {
  host: string;
  port: number;
  is_open: boolean;
}

/** Mapping retourné par /api/core/assets/list_network_endpoints */
export type NetworkEndpointsMap = Record<string, NetworkProbeEndpoint>;

export interface NetworkProbeInfo {
  asset_id: string;
  name?: string | null;
  host: string;
  port: number;
  is_open: boolean;
  deployment_mode?: NetworkDeploymentMode;
  interfaces?: string[];
  status?: "active" | "inactive" | "suppressed";
}

// ─────────────────────────────────────────────────────────────────────────────
// 2. MODES & DÉCISIONS DE THREAT LEVEL
// ─────────────────────────────────────────────────────────────────────────────

export type IdsMode = "ids" | "ips";

export type ThreatActionType = 
  | "log_only" 
  | "rate_limit_data" 
  | "rate_limit" 
  | "block_temp" 
  | "block_perm";

export interface ThreatDecision {
  level: ThreatActionType | string | null;
  action: ThreatActionType | string | null;
  duration?: number | null; // secondes (null = permanent / infini)
  score?: number;
}

export type NftRuleType = "drop" | "rate_limit" | "rate_limit_data";

export interface BlockedIpDetails {
  ip: string;
  rule: NftRuleType | string;
  set_name: string;
  duration?: number | null;
  input: boolean; // true = entrant (bloque source), false = sortant (bloque destination)
}

export interface IpScoreData {
  ip: string;
  score: number; // 0 à 300
  anomaly_count: number;
  blocked_count: number;
  geoloc: string; // Code pays ISO (ex: "RU", "CN", "FR", "XX")
  last_update: string;
  last_update_timestamp?: number;
  first_seen?: string;
  fisrt_seen?: string; // rétro-compatibilité avec typo backend
  resolution?: string | null; // Nom de domaine résolu (DNS PTR)
  input: boolean;
  port?: number | null;
  decision: ThreatDecision;
}

/** Mapping retourné par /api/blocked */
export type BlockedIpsResponseMap = Record<string, IpScoreData>;

// ─────────────────────────────────────────────────────────────────────────────
// 3. ALERTES & ÉVÉNEMENTS EN DIRECT (SURICATA & ML)
// ─────────────────────────────────────────────────────────────────────────────

export interface IdsAlertEvent {
  timestamp: string;
  event_type: "alert" | "anomaly" | "drop" | string;
  src_ip: string;
  src_port?: number | null;
  dest_ip: string;
  dest_port?: number | null;
  proto: string;
  direction: "input" | "output";
  severity: number;
  signature?: string;
  category?: string;
  action?: string;
  source?: "IA" | "Snort" | "Suricata" | "Combined" | string;
  prediction?: number;
  seq_length?: number;
  features?: number[];
  resolution?: string | null;
}

export interface LastAlertsResponse {
  alerts: IdsAlertEvent[];
  total: number;
  ids_running: boolean;
  detail?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// 4. CONFIGURATION IDS/IPS COMPLÈTE
// ─────────────────────────────────────────────────────────────────────────────

export interface IdsSeuilConfig {
  decision: number; // ex: -0.6
}

export interface IdsScoringConfig {
  ml_predict: number;
  port_weight: number;
  max_score_anomaly: number;
  geo_max: number;
  block_history_weight: number;
  anomaly_frequency_weight: number;
  max_score_total: number;
  max_bonus: number;
}

export interface IdsAnomalyRateThresholds {
  critical: number;
  very_high: number;
  high: number;
  medium: number;
  low: number;
  minimal: number;
}

export interface IdsDecayConfig {
  loss_per_hour: number;
  reset_days: number;
  reset_seconds: number;
  minimum_decay_rate: number;
}

export interface IdsAnomalyConfig {
  max_anomalies_per_file: number;
  anomaly_file_prefix: string;
  seq_length: number;
}

export interface IdsCaptureConfig {
  FILTER: string;
  TIMEOUT_MS: number;
  BUFFER_SIZE: number;
  SRC_IGNORED_IP: string[];
  DST_IGNORED_IP: string[];
}

export interface IdsGlobalConfig {
  model_file: string;
  duration: number;
  save_interval: number;
  mode: "full" | "fast" | string;
  packet_anomaly: number;
  anomaly_dir?: string | null;
  interface?: string[] | string | null;
  combination_mode: "or" | "and" | "weighted" | string;
  ids_mode: IdsMode;
  verbose: number;
  API_CONFIG: {
    port: number;
    host: string;
  };
  REQUEST_LIMIT: number;
  GRAPHS: boolean;
  N_TRIALS: number;
  clear_sets_at_exit: boolean;
  unlock_at_exit: boolean;
  capture_filename: string;
  add_data_to_capture_path?: string | null;
  do_not_fit: boolean;
}

export interface IdsFullConfig {
  SEUIL: IdsSeuilConfig;
  CRITICAL_PORT: Record<string, number>;
  DANGEROUS_LOCALISATION: Record<string, number>;
  SCORING_CONFIG: IdsScoringConfig;
  ANOMALY_RATE_THRESHOLDS: IdsAnomalyRateThresholds;
  DECAY_CONFIG: IdsDecayConfig;
  ANOMALY_CONFIG: IdsAnomalyConfig;
  CAPTURE_CONFIG: IdsCaptureConfig;
  GLOBAL_CONFIG: IdsGlobalConfig;
}

// ─────────────────────────────────────────────────────────────────────────────
// 5. REQUÊTES D'ACTIONS (PAYLOADS POST)
// ─────────────────────────────────────────────────────────────────────────────

export interface UnlockIpRequest {
  ip: string;
  input: boolean;
  rule: NftRuleType | string;
  whitelist?: "true" | "false" | string;
}

export interface BlockIpRequest {
  ip: string;
  input: boolean;
  rule: NftRuleType | string;
  timeout?: number; // en secondes (ex: 3600)
}

export interface ManageWhitelistRequest {
  ip: string;
  add: boolean; // true = ajouter, false = retirer
}

export interface ManageIgnoredIpRequest {
  ip: string;
  direction: "src" | "dst";
  add: boolean;
}

export interface ChangeModeRequest {
  mode: IdsMode;
}

export interface UpdateConfigCategoryRequest {
  key: keyof IdsFullConfig | string;
  data: Record<string, any>;
}

// ─────────────────────────────────────────────────────────────────────────────
// 6. RÉPONSES GÉNÉRIQUES DU SERVEUR
// ─────────────────────────────────────────────────────────────────────────────

export interface IdsActionResponse {
  success: boolean;
  message: string;
  code?: number;
  detail?: string;
}

export interface IdsHealthResponse {
  status: string;
  timestamp: string;
  detector_ready: boolean;
  graph_port?: number | null;
}

export interface IdsGeoLocationResponse {
  location: string; // Code pays (ex: "FR", "RU", "XX")
}

export interface IdsGraphPortResponse {
  port: number | null;
}