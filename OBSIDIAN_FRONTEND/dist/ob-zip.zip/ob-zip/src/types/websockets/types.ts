// ============================================================================
// WEBSOCKET - TYPES (version utile)
// ============================================================================

// ============================================================================
// ENUMS
// ============================================================================

/**
 * Types d'événements WebSocket émis par le serveur
 * Correspond aux messages `{"type": ...}` dans core_router.py
 */
export enum WSEventType {
  // ---- Streaming ----
  STREAM_START = 'stream_start',
  REASONING_TOKEN = 'reasoning_token',
  TOKEN = 'token',
  TOOL_CALL_DELTA = 'tool_call_delta',

  // ---- Tool calls ----
  TOOL_CALLS_PLANNED = 'tool_calls_planned',
  TOOL_EXEC_START = 'tool_exec_start',
  TOOL_EXEC_END = 'tool_exec_end',
  TOOL_EXEC_ERROR = 'tool_exec_error',

  // ---- État ----
  RETRY = 'retry',
  FINISH = 'finish',

  // ---- Résultats & erreurs ----
  REPORT = 'report',
  ERROR = 'error',
  PERSIST_ERROR = 'persist_error',

  // ---- Confirmations ----
  CONFIRMATION_REQUEST = 'confirmation_request',

  // ---- Autres ----
  CONVERSATION_CREATED = 'conversation_created',
  ACK_ERROR = 'ack_error',

  CONVERSATION_BUSY = "conversation_busy",
}

export type WSEventTypeVals = `${WSEventType}`;

/**
 * Types de messages que le client peut envoyer
 */
export enum WSClientMessageType {
  CHAT = 'chat',
  ANALYZE = 'analyze',
  CONFIRMATION_RESPONSE = 'confirmation_response',
}

// ============================================================================
// ÉVÉNEMENTS SORTANTS (serveur -> client)
// ============================================================================

export interface ConfirmationRequestData {
  req_id: string;
  tool: string;
  risk: string;
  args: Record<string, any> | null;
}

export interface WSStreamStartEvent {
  type: WSEventType.STREAM_START;
  run: string;
  iteration: number;
  model: string;
}

export interface WSStreamTokenEvent {
  type: WSEventType.TOKEN | WSEventType.REASONING_TOKEN;
  run: string;
  iteration: number;
  text: string;
}

export interface WSToolCallDeltaEvent {
  type: WSEventType.TOOL_CALL_DELTA;
  run: string;
  iteration: number;
  delta: {
    index?: number;
    id?: string | null;
    name?: string | null;
    arguments_delta?: string;
  };
}

export interface WSConversationBusyEvent {
    type: typeof WSEventType.CONVERSATION_BUSY;
    run: string;
    conversation_id: string;
    message: string;
}

export interface WSToolCallsPlannedEvent {
  type: WSEventType.TOOL_CALLS_PLANNED;
  run: string;
  tool_calls: Array<{ id: string; name: string }>;
}

export interface WSToolExecEvent {
  type: WSEventType.TOOL_EXEC_START | WSEventType.TOOL_EXEC_END | WSEventType.TOOL_EXEC_ERROR;
  run: string;
  tool: string;
  id: string | null;
  args: Record<string, any>;
  result?: string;   // pour TOOL_EXEC_END
  error?: string;    // pour TOOL_EXEC_ERROR
}

export interface WSRetryEvent {
  type: WSEventType.RETRY;
  run: string;
  attempt: number;
  max_retries: number;
  error: string;
}

export interface WSFinishEvent {
  type: WSEventType.FINISH;
  run: string;
  response: string;
  total_time: number;
  iterations: number;
  tool_calls: number;
}

export interface WSReportEvent {
  type: WSEventType.REPORT;
  run: string;
  report: any; // le rapport brut
}

export interface WSErrorEvent {
  type: WSEventType.ERROR | WSEventType.PERSIST_ERROR | WSEventType.ACK_ERROR;
  run?: string;
  error: string;
  message?: string;
}

export interface WSConfirmationRequestEvent {
  type: WSEventType.CONFIRMATION_REQUEST;
  req_id: string;
  tool: string;
  risk: string;
  args: Record<string, any>;
}

export interface WSConversationCreatedEvent {
  type: WSEventType.CONVERSATION_CREATED;
  conversation_id: string;
}

// ---- Union de tous les événements ----

export type WSServerEvent =
  | WSStreamStartEvent
  | WSStreamTokenEvent
  | WSToolCallDeltaEvent
  | WSToolCallsPlannedEvent
  | WSToolExecEvent
  | WSRetryEvent
  | WSFinishEvent
  | WSReportEvent
  | WSErrorEvent
  | WSConfirmationRequestEvent
  | WSConversationBusyEvent
  | WSConversationCreatedEvent;

// ============================================================================
// MESSAGES ENTRANTS (client -> serveur)
// ============================================================================

export interface WSChatMessage {
  type: WSClientMessageType.CHAT;
  message: string;
  conversation_id?: string | null;
}

export interface WSAnalyzeMessage {
  type: WSClientMessageType.ANALYZE;
  content: string;
  source: string;
  asset_id?: string | null;
  base_prompt?: string | null;
}

export interface WSConfirmationResponseMessage {
  type: WSClientMessageType.CONFIRMATION_RESPONSE;
  req_id: string;
  approved: boolean;
  reason?: string | null;
}

export type WSClientMessage =
  | WSChatMessage
  | WSAnalyzeMessage
  | WSConfirmationResponseMessage;

// ============================================================================
// ÉTAT DU WEBSOCKET (pour le store)
// ============================================================================

export interface WSState {
  isConnected: boolean;
  isConnecting: boolean;
  error: string | null;
  runId: string | null;
  isStreaming: boolean;
  currentResponse: string;
  currentReasoning: string;
  pendingConfirmation: {
    reqId: string;
    tool: string;
    risk: string;
    args: Record<string, any>;
  } | null;
}