import { Severity, Source } from "@/types/assets/types";

// ============================================================================
// Type de base
// ============================================================================

export interface Report {
    id: number;
    asset_id: string;
    source: Source;
    severity: Severity;
    has_fix: boolean;                 // flag DB (détecté via ReportManager.has_fix())
    created_at: string;              // ISO datetime
    timestamp: number;                // monotonic float
    content: string;                  // texte brut d'entrée (prompt/scan)
    report: AnalysisReportContent;    // rapport complet généré par Alex
}

// Forme du dict imbriqué "report" — déduite des données de test de
// ReportManager (test_report_manager). À confirmer/étendre si Alex ajoute
// d'autres champs à son AnalystReport.
export interface AnalysisReportContent {
    severity: Severity;
    summary: string;
    comment?: string;
    technical_explanation: string;
    natural_explanation: string;
    have_proposed_fix: boolean;
    prompt_injection_detected: boolean;
    all_fix_applied?: boolean;
    [key: string]: any;
}

// ============================================================================
// Requests
// ============================================================================

export interface GetReportDataRequest {
    identifier: string;   // ID de rapport (entier en string) OU asset_id
    first?: boolean;
    limit?: number;
}

export interface GetByAssetDataRequest {
    asset_id: string;
    limit?: number;
}

export interface ListReportsByFilterDataRequest {
    asset_id?: string | null;
    source?: Source | null;
    severity?: Severity | null;
    min_severity?: Severity | null;   // mutuellement exclusif avec severity
    start_date?: string | null;       // ISO datetime
    end_date?: string | null;         // ISO datetime
    limit?: number;
    order_by?: "created_at.desc" | "created_at.asc";
}

export interface ListCriticalReportsDataRequest {
    limit?: number;   // default: 100, 1-500
}

export interface ReportStatsDataRequest {
    asset_id?: string | null;   // stats globales si omis
}

export interface ReportIdDataRequest {
    report_id: number;
}

export interface UpdateReportSeverityDataRequest extends ReportIdDataRequest {
    severity: Severity;
    has_fix?: boolean | null;
}

export interface DeleteOldReportsDataRequest {
    days: number;   // > 0
}

// ============================================================================
// Responses
// ============================================================================

export interface GetReportResponse {
    reports: Report[] | null;
}

export interface GetLatestReportResponse {
    report: Report | null;
}

export interface GetFirstestReportResponse {
    report: Report | null;
}

export interface ListReportsByFilterResponse {
    reports: Report[];
}

export interface ListCriticalReportsResponse {
    reports: Report[];
}

export interface ReportStatsResponse {
    stats: Record<string, any>;
}

export interface UpdateReportSeverityResponse {
    success: boolean;
}

export interface DeleteReportResponse {
    success: boolean;
}

export interface DeleteOldReportsResponse {
    success: boolean;
    deleted_count: number;
}

// ============================================================================
// Mappings d'affichage
// ============================================================================

export const SourceMapping: Record<Source, string> = {
    scanner_web: "🌐 Scanner web",
    ids_ips: "🛡️ IDS/IPS",
    sandbox: "🧪 Sandbox",
    test: "🧫 Test",
    manual: "✋ Manuel",
    server: "🖥️ Serveur",
    email: "📧 Email",
    code: "💻 Code",
};