// ============================================================================
// Types & Interfaces — Scanner Web IA (ShieldAI)
// ============================================================================

export type VulnSeverity = "critique" | "élevé" | "moyen" | "faible" | "info";

export const VulnSeverityMapping: Record<VulnSeverity, string> = {
  critique: "🔴 Critique",
  élevé: "🟠 Élevé",
  moyen: "🟡 Moyen",
  faible: "🟢 Faible",
  info: "🔵 Info",
};

/**
 * Types primitifs pour les arguments des helpers
 */
export type HelperArgType = 
    | "str" 
    | "int" 
    | "float" 
    | "bool" 
    | "dict" 
    | "list" 
    | "none" 
    | "any";

/**
 * Un argument d'un helper
 */
export interface HelperArg {
    name: string;
    default: string | number | boolean | null;
    type: HelperArgType[];
    input_type: "text" | "number" | "float" | "boolean" | "url" | "json" | "list";
}

/**
 * Représentation d'un helper (sortie de list_helpers())
 */
export interface HelperInfo {
    name: string;
    description: string;
    module: string;
    args: Record<string, HelperArg>;
}

/**
 * Réponse de l'API GET /api/helpers
 */
export interface HelpersListResponse {
    usage: string;
    total: number;
    helpers: HelperInfo[];
}

export interface HelperCall {
  name: string;                           // Nom du helper (ex: "dvwa_auth", "form_login")
  args?: unknown[];                       // Arguments positionnels
  kwargs?: Record<string, unknown>;       // Arguments nommés
}

export interface ScanInstanceArgs {
  config_path?: string | null;            // DEFAULT_SCAN_PATH
  active_scan: boolean;                   // true (Active le Fuzzer)
  use_cache: boolean;                     // true
  restore: boolean;                       // false
  debug: boolean;                         // false
  semaphore: number;                      // 50 (1-200)
  limit_payloads?: number | null;         // null (1-10000)
  use_semantic: boolean;                  // true (Similarité BERT)
  headers_sev_map?: Record<string, unknown> | null;
  theme?: string | null;                  // "multi" | "dark" | "light"
  use_arjun: boolean;                     // false
  arjun_timeout: number;                  // 30 (5-120)
  known_params_dir?: string | null;       // null
  conf_content?: string;                  // "" (JSON5 de surcharge)
}

export interface ScanArgs {
  url: string;                            // Cible (ex: "http://localhost:8080")
  fetch: boolean;                         // true
  use_cache: boolean;                     // false
  put_result_in_cache: boolean;           // true
  filename?: string | null;               // null
  limit_vuln_for_fuzzer?: number | null | string[]; // null ou ["SQLi", "XSS"]
  time_between_for_fuzzer: number;        // 0.001 (0-1s)
  dynamic_timeout_for_fuzzer: boolean;    // true
  allowed_domains?: string[] | null;      // ["http://127.0.0.1", "http://localhost"]
  threshold: number;                      // 0.5 (0-1)
  helpers: HelperCall[];                  // []
  raise_on_helper_error: boolean;         // true
  is_spa: boolean;                        // false (active Playwright si true)
  max_test?: number | null;
}

// ============================================================================
// 1. ROUTE : POST /api/start_scan
// ============================================================================

export interface StartScanRequest {
  pass_phrase: string;
  instance_args: ScanInstanceArgs;
  scan_args: ScanArgs;
}

export interface StartScanResponse {
  scan_id: string;                        // Ex: "sh_sc-a1b2c3d4..."
  status: "started" | string;
  date: string;                           // Format: "DD/MM/YYYY à HH:MM:SS"
  message: string;
}

// ============================================================================
// 2. ROUTE : POST /api/cancel_scan
// ============================================================================

export interface CancelScanRequest {
  scan_id: string;
  pass_phrase: string;
}

export interface CancelScanResponse {
  scan_id: string;
  status: "cancelled" | string;
  date: string;
}

// ============================================================================
// 3. ROUTE : GET /api/status & GET /api/reports/{scan_id}
// ============================================================================

export interface ScannerStatusResponse {
  status: "running" | string;
  active_scans: number;
  date: string;
}

export interface ScanReportsResponse {
  html?: string[];                        // URLs vers les rapports HTML
  json?: string[];                        // URLs vers les rapports JSON
  pdf?: string[];                         // URLs vers les rapports PDF
  llm?: string[];                         // URLs vers les rapports LLM
}

// ============================================================================
// 4. ROUTE : GET /api/default_config & /api/supported_vulns
// ============================================================================

export type SupportedVulnsResponse = string[]; // 30 vulns: ["SQLi", "XSS", "SSRF", ...]

export interface ValidateKnownParamDirResponse {
  can: boolean;
  reason: string | null;
}

// ============================================================================
// 5. STRUCTURE DU RÉSULTAT FINAL REÇU VIA WEBSOCKET (type="scan_result")
// ============================================================================

export interface ScanSummaryResult {
  scan_id: string;
  url: string;
  elapsed: number;
  date: string;
  errors: number;
  pages_crawled: number;
  total_vulns: number;
  vuln_count: Record<string, number>;     // Ex: { "XSS": 3, "SQLi": 1 }
  report_paths: {
    html?: string;
    json?: string;
    pdf?: string;
    llm?: string;
  };
}

export interface WSScanMessage {
  type: "log" | "scan_info" | "scan_result" | "scan_error" | "pong";
  message: string | ScanSummaryResult | Record<string, any>;
}