// ============================================================================
// TYPES DE BASE
// ============================================================================

/**
 * Types de triggers supportés par JobManager.build_trigger()
 */
export type TriggerKind = "cron" | "date" | "interval" | "calendar_interval";

/**
 * État d'un job
 */
export type JobState = "running" | "paused" | "pending";

/**
 * Niveau de risque d'un job
 */
export type JobRisk = "low" | "medium" | "high";

// ============================================================================
// INTERFACES TRIGGER
// ============================================================================

/**
 * Trigger de type CRON
 */
export interface CronTrigger {
  type: "cron";
  year?: number | string;
  month?: number | string;
  day?: number | string;
  week?: number | string;
  day_of_week?: number | string;
  hour?: number | string;
  minute?: number | string;
  second?: number | string;
  start_date?: string; // ISO datetime
  end_date?: string; // ISO datetime
  timezone?: string;
  jitter?: number;
}

/**
 * Trigger de type DATE (exécution unique)
 */
export interface DateTrigger {
  type: "date";
  run_date: string; // ISO datetime (obligatoire)
  timezone?: string;
}

/**
 * Trigger de type INTERVAL
 */
export interface IntervalTrigger {
  type: "interval";
  weeks?: number;
  days?: number;
  hours?: number;
  minutes?: number;
  seconds?: number;
  start_date?: string; // ISO datetime
  end_date?: string; // ISO datetime
  timezone?: string;
  jitter?: number;
}

/**
 * Trigger de type CALENDAR_INTERVAL
 */
export interface CalendarIntervalTrigger {
  type: "calendar_interval";
  years?: number;
  months?: number;
  weeks?: number;
  days?: number;
  hour?: number;
  minute?: number;
  second?: number;
  start_date?: string; // ISO datetime
  end_date?: string; // ISO datetime
  timezone?: string;
  jitter?: number;
}

/**
 * Union de tous les triggers possibles
 */
export type TriggerSpec = 
  | CronTrigger 
  | DateTrigger 
  | IntervalTrigger 
  | CalendarIntervalTrigger;

/**
 * Trigger résolu (format APScheduler)
 */
export interface ResolvedTrigger {
  type: TriggerKind;
  fields?: Record<string, unknown>;
  interval?: Record<string, number>;
  run_date?: string;
  start_date?: string | null;
  end_date?: string | null;
  total_seconds?: number;
  repr: string;
}

// ============================================================================
// INTERFACES FONCTION
// ============================================================================

/**
 * Description d'une fonction exécutée par un job
 */
export interface JobFunction {
  name: string;
  module: string;
  qualname: string;
  type: "function" | "method" | "class" | "builtin" | "lambda" | "unknown";
  is_async: boolean;
  doc?: string;
}

// ============================================================================
// INTERFACE JOB (complète)
// ============================================================================

/**
 * Représentation complète d'un job APScheduler
 */
export interface Job {
  id: string;
  name: string | null;
  func: JobFunction;
  args: unknown[];
  kwargs: Record<string, unknown>;
  trigger: ResolvedTrigger;
  executor: string | null;
  misfire_grace_time: number | null;
  coalesce: boolean | null;
  max_instances: number | null;
  next_run_time: string | null; // ISO datetime
  pending: boolean | null;
  jobstore: string | null;
  repr: string;
}

// ============================================================================
// INTERFACE JOB CATALOG ENTRY
// ============================================================================

/**
 * Entrée du catalogue des jobs planifiables
 */
export interface JobCatalogEntry {
  job_name: string;
  description: string;
  default_trigger: TriggerSpec;
  default_kwargs: Record<string, string | number | boolean>;
  risk?: JobRisk; // Optionnel, par défaut "low"
}

// ============================================================================
// INTERFACES REQUÊTES
// ============================================================================

/**
 * Filtre in_memory : 
 * - true = jobstore mémoire uniquement
 * - false = jobstore persistant uniquement
 * - null / undefined = les deux
 */
export interface InMemoryFilter {
  in_memory?: boolean | null;
}

/**
 * Requête : Récupérer un job par son ID
 */
export interface GetJobRequest extends InMemoryFilter {
  job_id: string | number;
}

/**
 * Requête : Modifier un job
 */
export interface ModifyJobRequest extends InMemoryFilter {
  job_id: string;
  name?: string | null;
  args?: unknown[];
  kwargs?: Record<string, unknown>;
  max_instances?: number | null;
  coalesce?: boolean | null;
  misfire_grace_time?: number | null;
  executor?: "default" | "threadpool" | null;
  trigger?: TriggerSpec | null;
}

/**
 * Requête : Ajouter un job depuis le catalogue
 */
export interface AddJobRequest extends InMemoryFilter {
  job_name: string; // Nom dans le catalogue (ex: "report_cleanup")
  job_id: string | number; // ID unique pour cette instance
  trigger?: TriggerSpec | null; // Trigger custom (sinon default_trigger du catalogue)
  kwargs?: Record<string, unknown> | null; // Kwargs custom (fusionnés avec default_kwargs)
}

/**
 * Requête : Gérer un job (pause, resume, remove)
 */
export interface ManageJobRequest {
  job_id: string | number;
  in_memory?: boolean | null;
}

/**
 * Requête : Gérer tous les jobs (pause_all, resume_all, remove_all)
 */
export interface ManageAllJobsRequest {
  in_memory?: boolean | null;
}

// ============================================================================
// INTERFACES RÉPONSES
// ============================================================================

/**
 * Réponse : Liste des jobs
 */
export interface ListJobsResponse {
  jobs: Job[];
}

/**
 * Réponse : Récupération d'un job
 */
export interface GetJobResponse {
  job: Job | null;
}

/**
 * Réponse : État d'un job
 */
export interface GetJobStateResponse {
  state: JobState | null;
}

/**
 * Réponse : Catalogue des jobs
 */
export interface JobCatalogResponse {
  catalog: JobCatalogEntry[];
}

/**
 * Réponse : Opération sur un job (pause, resume, remove, modify, create)
 */
export interface JobOperationResponse {
  success: boolean;
  error: string | null;
  traceback: string | null;
}

/**
 * Réponse : Opération sur tous les jobs (pause_all, resume_all, remove_all)
 */
export interface JobBulkOperationResponse extends JobOperationResponse {
  affected?: number; // Nombre de jobs affectés
}

// ============================================================================
// INTERFACE COMPLETE POUR LA PAGE DES JOBS (optionnel)
// ============================================================================

/**
 * État d'un job pour l'affichage (enrichi)
 */
export interface JobDisplay extends Job {
  isPaused: boolean;
  triggerDisplay: string;
  nextRunDisplay: string;
}

/**
 * Filtres pour la page des jobs
 */
export interface JobFilters {
  jobstore?: "memory" | "persistent" | "all";
  status?: JobState | "all";
  search?: string;
}