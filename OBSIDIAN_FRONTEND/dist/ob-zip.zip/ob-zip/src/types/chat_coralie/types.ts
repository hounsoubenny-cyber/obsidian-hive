// ============================================================================
// TYPES POUR LES STEPS DE LLMManager (run_agent)
// ============================================================================

/**
 * Un "step" représente une itération complète de la boucle agent.
 * Il contient le raisonnement, les tentatives, et les tool calls exécutés.
 */
export interface AgentStep {
  /** Raisonnement de l'agent pour cette itération (le "thinking") */
  think: string;

  content?: string; 
  
  /** Nombre de tentatives effectuées pour cette itération (1 = succès du premier coup) */
  attempts: number;

  /** Erreurs par tentative (index 0 = première tentative) */
  attempts_error: Record<number, string | null>;

  /** Tool calls exécutés durant cette itération, indexés par leur ID */
  tool_calls: Record<string, ToolCallDetail>;

  /** Timestamp de début (epoch seconds) */
  started_at: number;

  /** Timestamp de fin (epoch seconds) */
  ended_at: number;

  /** Durée totale de l'itération en secondes */
  duration: number;
}

/**
 * Détail d'un tool call exécuté durant une itération.
 */
export interface ToolCallDetail {
  /** Nom de l'outil appelé */
  name: string;

  /** Arguments bruts (string JSON) reçus du LLM */
  args_str: string;

  /** Arguments parsés en objet (désérialisés) */
  args: Record<string, any>;

  /** Résultat de l'exécution de l'outil (string) */
  result: string;

  /** Timestamp de début (epoch seconds) */
  started_at: number;

  /** Timestamp de fin (epoch seconds) */
  ended_at: number;

  /** Durée d'exécution en secondes */
  duration: number;

  /** Succès ou échec de l'exécution */
  success: boolean;

  status?: "planned" | "done" | "executing"  // Ajout coté frontend pour le rendu
}

// ============================================================================
// RÉPONSE COMPLÈTE DE run_agent
// ============================================================================

/**
 * Réponse complète retournée par LLMManager.run_agent()
 * C'est le format que reçoit le frontend via WebSocket (évènement "finish").
 */
export interface AgentResponse {
  /** Réponse finale de l'agent (texte) */
  response: string;

  /** Temps total d'exécution en secondes */
  total_time: number;

  /** Nombre d'itérations effectuées */
  iterations: number;

  /** Nombre total de tool calls exécutés */
  tool_calls: number;

  /** Historique complet des messages (format LLM) */
  messages: Array<{
    role: 'user' | 'assistant' | 'system' | 'tool';
    content: string;
    tool_call_id?: string;
    name?: string;
  }>;

  /** Liste des steps (une par itération) */
  steps: AgentStep[];

  /** Succès ou échec de l'exécution */
  success: boolean;

  /** Message d'erreur si success === false */
  error: string | null;

  max_iter_reached?: boolean | null;
}

// ============================================================================
// TYPES POUR L'AFFICHAGE D'UN STEP DANS L'UI
// ============================================================================

/**
 * État agrégé d'un step pour faciliter l'affichage.
 * Utile pour le composant StepCard.
 */
export interface StepSummary {
  /** Index de l'itération (0-based) */
  index: number;

  /** Le step brut */
  raw: AgentStep;

  /** Nombre total de tool calls */
  toolTotal: number;

  /** Nombre de tool calls réussis */
  toolSuccess: number;

  /** A-t-il des tool calls ? */
  hasTools: boolean;

  /** A-t-il un raisonnement non vide ? */
  hasThinking: boolean;

  /** A-t-il des erreurs dans les tentatives ? */
  hasError: boolean;

  /** Le premier message d'erreur, s'il y en a un */
  firstError: string | null;

  /** Durée totale formatée ("1.2s") */
  durationFormatted: string;

  /** Liste des tool calls (triées par ordre d'exécution) */
  toolCallsList: ToolCallDetail[];
}


// ============================================================================
// CONVERSATION MANAGER - TYPES
// ============================================================================

// ---- Référence à une conversation (conversation_id OU id) ----

export interface ConversationRef {
  conversation_id?: string | null;
  id?: number | null;
}

// ---- Message (lecture) ----

export interface Message {
  id?: number | null;
  conversation_pk?: number | null;
  role: 'user' | 'assistant';
  content: string;
  steps?: AgentStep[] | null; // désérialisé depuis JSON
  total_time?: number | null;
  tool_calls_count?: number | null;
  iterations?: number | null;
  created_at: string; // ISO datetime
  genStart?: boolean;
  genEnd?: boolean;
  max_iter_reached?: boolean | null;
}

// ---- Conversation (lecture) ----

export interface Conversation {
  id?: number | null;
  conversation_id: string;
  owner: string;
  title: string;
  created_at: string;
  updated_at: string;
  archived: boolean;
  is_favorite: boolean;
}

// ============================================================================
// REQUÊTES
// ============================================================================

// ---- CREATE ----

export interface CreateConversationRequest {
  title?: string | null;
}

export interface CreateConversationResponse {
  conversation_id: string;
  id: number;
  title: string;
  created_at: string;
}

// ---- LIST ----

export interface ListConversationsRequest {
  include_archived?: boolean; // default: false
  favorites_only?: boolean;   // default: false
  limit?: number;             // default: 50, max: 200
  offset?: number;            // default: 0
}

export interface ListConversationsResponse {
  conversations: Conversation[];
  total: number;
}

// ---- GET (par conversation_id ou id) ----

export interface GetConversationRequest extends ConversationRef {}

export interface GetConversationResponse {
  conversation_id: string;
  id: number;
  title: string;
  created_at: string;
  updated_at: string;
  archived: boolean;
  is_favorite: boolean;
}

// ---- DELETE ----

export interface DeleteConversationRequest extends ConversationRef {}

export interface DeleteConversationResponse {
  success: boolean;
}

// ---- UPDATE TITLE ----

export interface UpdateConversationTitleRequest extends ConversationRef {
  title: string;
}

export interface UpdateConversationTitleResponse {
  success: boolean;
}

// ---- SET FAVORITE ----

export interface SetFavoriteRequest extends ConversationRef {
  favorite?: boolean; // default: true
}

export interface SetFavoriteResponse {
  success: boolean;
}

// ---- SET ARCHIVED ----

export interface SetArchivedRequest extends ConversationRef {
  archived?: boolean; // default: true
}

export interface SetArchivedResponse {
  success: boolean;
}

// ---- SEARCH ----

export interface SearchConversationsRequest {
  query: string;
  limit?: number; // default: 20, max: 100
}

export interface SearchConversationsResponse {
  conversations: {
    conversation_id: string;
    id: number;
    title: string;
    updated_at: string;
  }[];
}

// ---- MESSAGES ----

export interface GetMessagesRequest extends ConversationRef {
  limit?: number | null; // default: null (tous)
  offset?: number;       // default: 0
}

export interface GetMessagesResponse {
  messages: Message[];
}

// ---- LAST MESSAGE ----

export interface GetLastMessageRequest extends ConversationRef {
  role?: 'user' | 'assistant' | null;
}

export interface GetLastMessageResponse {
  message: Message | null;
}

// ---- UPDATE MESSAGE CONTENT ----

export interface UpdateMessageContentRequest {
  message_id: number;
  content: string;
}

export interface UpdateMessageContentResponse {
  success: boolean;
}

// ---- DELETE MESSAGE ----

export interface DeleteMessageRequest {
  message_id: number;
}

export interface DeleteMessageResponse {
  success: boolean;
}


export type Risks = "low" | "medium" | "high" | "critical";
export const RiskMapping: Record<Risks, string> = {
  low: "Faible",
  medium: "Moyen",
  high: "Haut",
  critical: "Critique"
} 