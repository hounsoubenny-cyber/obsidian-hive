import { BrowserRouter } from "react-router-dom"
import Naviguation from "./components/naviguation";
import { AppConfig, getConfig } from "./hooks/get_config";
import { useEffect, useState } from "react";
import {Toaster} from "react-hot-toast";
import ThemeSelector, { applyTheme, getStoredTheme } from "./components/theme_selector/theme_selector";

function App(){
  const [config, setConfig] = useState<AppConfig | null>(null);
  useEffect(() => {
        async function load() {
            const cfg = await getConfig();
            setConfig(cfg);
        }
        load();
    }, []);

    // Applique le thème sauvegardé (ou "obsidian" par défaut) dès le montage,
    // avant même l'interaction avec le sélecteur.
    useEffect(() => {
        applyTheme(getStoredTheme());
    }, []);

    return(
        <>
            <BrowserRouter>
                <Toaster position="top-right" />
                <ThemeSelector />
                <Naviguation />
            </BrowserRouter>
        </>
    )
}

export default App;
