import {
    ShieldAlert,
    Bug,
    Radar,
    Box,
    Crosshair,
    ScanEye,
    BrainCircuit,
} from "lucide-react";

interface ModuleInterface {
    name: string,
    emoji?: string,
    icon?: any,
    description: string,
    dispo: boolean,
    link: string,
};

export const MODULES: ModuleInterface[] = [
    {
        name: "Anti-Phishing",
        emoji: "🎣",
        icon: ShieldAlert,
        description: "Détecte et bloque les liens et emails malveillants avant qu'ils n'atteignent vos utilisateurs.",
        dispo: true,
        link: "/modules/anti-phishing",
    },
    {
        name: "Scanner de vulnérabilités",
        emoji: "🔍",
        icon: Bug,
        description: "Analyse vos sites et applications web pour repérer les failles OWASP (SQLi, XSS...) avant qu'un attaquant ne les trouve.",
        dispo: true,
        link: "/modules/scanner",
    },
    {
        name: "IDS / IPS",
        emoji: "📡",
        icon: Radar,
        description: "Surveillance réseau H24 : détecte et bloque les intrusions en temps réel.",
        dispo: true,
        link: "/modules/ids-ips",
    },
    {
        name: "Sandbox",
        emoji: "🧪",
        icon: Box,
        description: "Exécute et analyse du code suspect dans un environnement isolé, sans risque pour vos systèmes.",
        dispo: true,
        link: "/modules/sandbox",
    },
    {
        name: "Simulateur d'attaques",
        emoji: "🎯",
        icon: Crosshair,
        description: "Simule de vraies attaques (MITRE ATT&CK) pour tester la résistance de votre infrastructure.",
        dispo: true,
        link: "/modules/simulator",
    },
    {
        name: "Trust Signal",
        emoji: "🕵️",
        icon: ScanEye,
        description: "Détecte le contenu généré par IA (texte, images) pour repérer deepfakes et désinformation.",
        dispo: false,
        link: "/modules/trust-signal",
    },
    {
        name: "Context Guard",
        emoji: "🧠",
        icon: BrainCircuit,
        description: "Protège vos agents IA contre les prompt injections et manipulations de contexte.",
        dispo: false,
        link: "/modules/context-guard",
    },
]