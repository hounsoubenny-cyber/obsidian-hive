import "./utils.css";
import { Link } from "react-router-dom";
import { Lock, ArrowRight, Sparkles } from "lucide-react";

interface ModuleCardProps {
  moduleData: {
    name: string;
    emoji?: string;
    icon?: any;
    description: string;
    dispo: boolean;
    link: string;
    isNew?: boolean;
    isBeta?: boolean;
  };
  onNavigate?: () => void;
}

export function ModuleCard({ moduleData, onNavigate }: ModuleCardProps) {
  const { name, emoji, icon: Icon, description, dispo, link, isNew, isBeta } = moduleData;

  const content = (
    <>
      {/* Badge optionnel */}
      {isNew && <span className="mc-badge mc-badge--new">✨ Nouveau</span>}
      {isBeta && <span className="mc-badge mc-badge--beta">🧪 Bêta</span>}

      <div className="mc-card__top">
        <div className="mc-card__icon">
          {Icon ? <Icon size={24} /> : <span className="mc-card__emoji">{emoji || "📦"}</span>}
        </div>
      </div>

      <div className="mc-card__body">
        <h3 className="mc-card__name">{name}</h3>
        <p className="mc-card__description">{description}</p>
      </div>

      <div className="mc-card__footer">
        {dispo ? (
          <span className="mc-card__status mc-card__status--available">
            Disponible
            <ArrowRight size={14} className="mc-card__arrow" />
          </span>
        ) : (
          <span className="mc-card__status mc-card__status--unavailable">
            <Lock size={13} />
            Indisponible
          </span>
        )}
      </div>
    </>
  );

  if (!dispo) {
    return <div className="mc-card mc-card--locked">{content}</div>;
  }

  return (
    <Link to={link} className="mc-card mc-card--available" onClick={onNavigate}>
      {content}
    </Link>
  );
}