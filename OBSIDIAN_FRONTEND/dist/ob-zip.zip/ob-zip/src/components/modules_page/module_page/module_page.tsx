import "./module_page.css";
import { Lock, LayoutGrid } from "lucide-react";
import { Link } from "react-router-dom";
import { MODULES } from "@/data/modules/data";
import { isLogin, getUsername } from "@/hooks/get_token";
import { ModuleCard } from "../utils/utils";
import { ConfigType } from "@/components/assets/add_asset_modal/utils";
import { useEffect, useState } from "react";
import { AppConfig, getConfig } from "@/hooks/get_config";

function ModulePage() {
  if (!isLogin()) {
    return (
      <div className="mp-locked">
        <div className="mp-locked__card">
          <Lock size={28} className="mp-locked__icon" />
          <h2>Accès restreint</h2>
          <p>
            Veuillez d'abord vous connecter à la <Link to="/login">page de connexion</Link>.
          </p>
        </div>
      </div>
    );
  }

  const username = getUsername();
  const usernameTitle = username.charAt(0).toUpperCase() + username.slice(1);
  const total = MODULES.length;
  const available = MODULES.filter(m => m.dispo).length;
  const unavailable = total - available;
  const [conf, setConf] = useState<AppConfig | null>(null);

  useEffect(
    () => {
        async function loadConf() {
            let conf = await getConfig();
            setConf(conf);
        }
        loadConf();
    }
  , [])

  return (
    <div className="mp-page">
      {/* Header */}
      <header className="mp-header">
        <div className="mp-header__left">
          <h1 className="mp-header__title">
            Bienvenue {usernameTitle}
            <span className="mp-header__wave">👋</span>
          </h1>
          <p className="mp-header__subtitle">
            Gestion des modules {conf?.productName ? conf.productName[0].toLocaleUpperCase() + conf.productName.slice(1) : ""}
        </p>
        </div>
        <div className="mp-header__right">
          <span className="mp-header__badge">
            {total} modules
          </span>
        </div>
      </header>

      <hr className="mp-divider" />

      {/* Contenu principal */}
      <div className="mp-content">
        {/* Barre d'outils */}
        <div className="mp-toolbar">
          <div className="mp-toolbar__left">
            <LayoutGrid size={20} className="mp-toolbar__icon" />
            <h2 className="mp-toolbar__title">Tous les modules</h2>
          </div>
          <div className="mp-toolbar__stats">
            <span className="mp-stat mp-stat--total">{total} total</span>
            <span className="mp-stat mp-stat--available">
              <span className="mp-stat__dot mp-stat__dot--available"></span>
              {available} disponible{available > 1 ? "s" : ""}
            </span>
            {unavailable > 0 && (
              <span className="mp-stat mp-stat--unavailable">
                <span className="mp-stat__dot mp-stat__dot--unavailable"></span>
                {unavailable} indisponible{unavailable > 1 ? "s" : ""}
              </span>
            )}
          </div>
        </div>

        {/* Grille des modules */}
        <div className="mp-grid">
          {MODULES.slice()
            .sort((a, b) => a.name.localeCompare(b.name))
            .map((module, idx) => (
              <ModuleCard key={idx} moduleData={module} />
            ))}
        </div>
      </div>
    </div>
  );
}

export default ModulePage;