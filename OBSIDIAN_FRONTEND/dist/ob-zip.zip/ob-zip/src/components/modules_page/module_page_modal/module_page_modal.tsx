import "./module_page_modal.css";
import { X, Lock, LayoutGrid } from "lucide-react";
import { Link } from "react-router-dom";
import { MODULES } from "@/data/modules/data";
import { isLogin, getUsername } from "@/hooks/get_token";
import { ModuleCard } from "../utils/utils";
import { AppConfig, getConfig } from "@/hooks/get_config";
import { useState, useEffect } from "react";

interface ModulePageModalProps {
  isOpen: boolean;
  onClose: () => void;
}

function ModulePageModal({ isOpen, onClose }: ModulePageModalProps) {
  if (!isOpen) return null;

  if (!isLogin()) {
    return (
      <div className="mpm-overlay" onClick={onClose}>
        <div className="mpm-container" onClick={(e) => e.stopPropagation()}>
          <div className="mpm-header">
            <h2 className="mpm-header__title">🔒 Accès restreint</h2>
            <button className="mpm-header__close" onClick={onClose}>✕</button>
          </div>
          <div className="mpm-body mpm-body--locked">
            <Lock size={28} className="mpm-locked__icon" />
            <p>Veuillez vous connecter pour accéder aux modules.</p>
            <Link to="/login" className="mpm-btn mpm-btn--primary" onClick={onClose}>
              Se connecter
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const username = getUsername();
  const usernameTitle = username.charAt(0).toUpperCase() + username.slice(1);
  const total = MODULES.length;
  const available = MODULES.filter(m => m.dispo).length;
  const unavailable = total - available;
  const [conf, setConf] = useState<AppConfig | null>(null);

  useEffect(
    () => {
        async function loadConf() {
            let conf = await getConfig();
            setConf(conf);
        }
        loadConf();
    }
  , [])
  
  return (
    <div className="mpm-overlay" onClick={onClose}>
      <div className="mpm-container" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="mpm-header">
          <div className="mpm-header__left">
            <h2 className="mpm-header__title">
              📦 Modules {conf?.productName ? conf.productName[0].toLocaleUpperCase() + conf.productName.slice(1) : ""}
            </h2>
            <p className="mpm-header__welcome">Bienvenue {usernameTitle} 👋</p>
          </div>
          <button className="mpm-header__close" onClick={onClose}>✕</button>
        </div>

        {/* Body */}
        <div className="mpm-body">
          {/* Toolbar */}
          <div className="mpm-toolbar">
            <div className="mpm-toolbar__left">
              <LayoutGrid size={18} className="mpm-toolbar__icon" />
              <h3 className="mpm-toolbar__title">Tous les modules</h3>
            </div>
            <div className="mpm-toolbar__stats">
              <span className="mpm-stat mpm-stat--total">{total} total</span>
              <span className="mpm-stat mpm-stat--available">
                <span className="mpm-stat__dot mpm-stat__dot--available"></span>
                {available} disponible{available > 1 ? "s" : ""}
              </span>
              {unavailable > 0 && (
                <span className="mpm-stat mpm-stat--unavailable">
                  <span className="mpm-stat__dot mpm-stat__dot--unavailable"></span>
                  {unavailable} indisponible{unavailable > 1 ? "s" : ""}
                </span>
              )}
            </div>
          </div>

          {/* Grille */}
          <div className="mpm-grid">
            {MODULES.slice()
              .sort((a, b) => a.name.localeCompare(b.name))
              .map((module, idx) => (
                <ModuleCard key={idx} moduleData={module} onNavigate={onClose} />
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default ModulePageModal;