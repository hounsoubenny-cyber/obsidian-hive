import { useEffect, useState } from "react";
import "./scanner.css";
import { 
    ScannerStatusResponse, 
    ScanSummaryResult 
} from "@/types/scanner/types";
import { getScannerStatus } from "./utils";
import { useScannerWSStore } from "@/store/scanner_websocket_store";
import { Link, useNavigate } from "react-router-dom";
import { 
    ShieldAlert, 
    Play, 
    Terminal, 
    FileText, 
    Activity, 
    Settings, 
    Pin, 
    Sparkles, 
    RefreshCw,
    CheckCircle2,
    Radio,
    Trash2,
    Lock
} from "lucide-react";
import toast from "react-hot-toast";

// Sous-composants
import ScanHealthComponent from "./health/health";
import ScanLauncherComponent from "./scan_start/scan_start";
import ScanLiveComponent from "./live/scan_live";
import ScanSettingsComponent from "./settings/settings";
import ScanResultsComponent from "./reports/report";
import { isLogin } from "@/hooks/get_token";

export type ScannerTabType = "scan" | "live" | "results" | "health" | "settings";

function Scanner() {
    const navigate = useNavigate();

    // 1. Récupération de l'onglet par défaut (localStorage)
    const [defaultTab, setDefaultTab] = useState<ScannerTabType>(() => {
        const saved = localStorage.getItem("sc_default_tab");
        return (saved as ScannerTabType) || "scan";
    });

    // 2. Onglet actif
    const [activeTab, setActiveTab] = useState<ScannerTabType | null>(() => {
        const saved = localStorage.getItem("sc_default_tab");
        return (saved as ScannerTabType) || "scan";
    });

    // 3. État partagé du scan en cours / dernier résultat
    const [currentScanId, setCurrentScanId] = useState<string | null>(null);
    const [currentPassPhrase, setCurrentPassPhrase] = useState<string>("");
    const [lastScanResult, setLastScanResult] = useState<ScanSummaryResult | null>(null);

    // 4. Store WebSocket (pour badges et état global)
    const { isScanning, isConnected } = useScannerWSStore();

    // 5. Santé API (Polling toutes les 30s)
    const [apiStatus, setApiStatus] = useState<ScannerStatusResponse | null>(null);
    const [healthLoading, setHealthLoading] = useState<boolean>(false);
    const [healthError, setHealthError] = useState<string | null>(null);

    const checkHealth = () => {
        getScannerStatus(setApiStatus, setHealthError, setHealthLoading, navigate);
    };

    useEffect(() => {
        checkHealth();
        const interval = setInterval(checkHealth, 30000);
        return () => clearInterval(interval);
    }, []);

    const handleSetDefaultTab = (tab: ScannerTabType) => {
        setDefaultTab(tab);
        localStorage.setItem("sc_default_tab", tab);
        toast.success(`📌 Onglet par défaut : ${getTabLabel(tab)}`);
    };

    function getTabLabel(tab: ScannerTabType): string {
        switch (tab) {
            case "scan": return "🚀 Lancer Scan";
            case "live": return "⚡ Console Live";
            case "results": return "📊 Résultats";
            case "health": return "🩺 Santé";
            case "settings": return "⚙️ Configuration";
            default: return "";
        }
    }

    const isHealthy = apiStatus?.status === "running" && !healthError;

    let pulseClass = "scm-health-pulse--loading";
    if (!healthLoading) {
        pulseClass = isHealthy ? "scm-health-pulse--healthy" : "scm-health-pulse--unhealthy";
    }

    // Callbacks de flux de scan
    const handleScanStarted = (scanId: string, passPhrase: string) => {
        setCurrentScanId(scanId);
        setCurrentPassPhrase(passPhrase);
        setActiveTab("live"); // Bascule automatique sur la console live
    };

    const handleScanCompleted = (result: ScanSummaryResult) => {
        setLastScanResult(result);
    };

    const hasActiveSession = Boolean(currentScanId || lastScanResult || isScanning);

    // Fonction de purge complète
    const handleGlobalReset = () => {
        // 1. Reset du store WebSocket (ferme WS, vide logs, sessionStorage, etc.)
        useScannerWSStore.getState().resetScan();

        // 2. Reset des états locaux du module
        setCurrentScanId(null);
        setCurrentPassPhrase("");
        setLastScanResult(null);

        // 3. Retour automatique sur l'onglet de lancement
        setActiveTab("scan");

        toast("🧹 Session et données du scan réinitialisées !", { icon: "✨" });
    };
    const isBusy = isScanning || isConnected;

    if (!isLogin()) {
        return (
            <div id="scm-locked-screen" className="simatk-module">
                <div className="simatk-auth-locked">
                    <Lock size={36} style={{ color: "var(--accent)" }} />
                    <h2>Accès Restreint au Scanner Web</h2>
                    <p>
                        Une session authentifiée est requise pour analyse les vulnérabilités webs.
                    </p>
                    <Link to="/login" className="oh-btn oh-btn--primary" style={{ marginTop: 12 }}>
                        Se Connecter
                    </Link>
                </div>
            </div>
        );
    }
    
    return (
        <div id="scm-module" className="scm-module">
            {/* Header Fixe */}
            <header id="scm-header" className="scm-header">
                <div className="scm-header__top">
                    {/* Logo & Titre */}
                    <div className="scm-header__left">
                        <div className="scm-header__logo">
                            <ShieldAlert size={28} className="scm-header__logo-icon" />
                            <h1 className="scm-header__title">Scanner IA</h1>
                            <span className="scm-header__version">v2.0</span>
                        </div>
                    </div>

                    {/* Zone Droite : Onglet par défaut & Pulse Santé */}

                    {/* Bouton de Purge Globale (affiché uniquement si une session existe) */}
                    {hasActiveSession && !isBusy && (
                        <button
                            type="button"
                            className="oh-btn oh-btn--ghost"
                            style={{ color: "var(--danger)", padding: "6px 12px", fontSize: "0.8rem" }}
                            onClick={handleGlobalReset}
                            title="Effacer les logs, l'ID de scan et les résultats actuels"
                        >
                            <Trash2 size={14} /> Nouvelle session (Purger)
                        </button>
                    )}
                    <div className="scm-header__right">
                        <div className="scm-default-selector">
                            <span className="scm-default-selector__label">
                                <Pin size={13} /> Défaut :
                            </span>
                            <select
                                id="scm-default-select"
                                className="scm-default-selector__select"
                                value={defaultTab}
                                onChange={(e) => handleSetDefaultTab(e.target.value as ScannerTabType)}
                            >
                                <option value="scan">🚀 Lancer Scan</option>
                                <option value="live">⚡ Console Live</option>
                                <option value="results">📊 Résultats</option>
                                <option value="health">🩺 Santé</option>
                                <option value="settings">⚙️ Configuration</option>
                            </select>
                        </div>

                        {/* Pastille Pulse Santé */}
                        <div id="scm-health-pulse" className={`scm-health-pulse ${pulseClass}`}>
                            <span className={`scm-health-pulse__dot ${isHealthy ? "scm-health-pulse__dot--healthy" : "scm-health-pulse__dot--unhealthy"}`} />
                            {healthLoading ? (
                                <span><RefreshCw size={14} className="oh-spin" /> Contrôle...</span>
                            ) : isHealthy ? (
                                <span>🟢 En ligne</span>
                            ) : (
                                <span>🔴 Hors ligne</span>
                            )}
                        </div>
                    </div>
                </div>

                {/* Navigation des Onglets */}
                <nav id="scm-nav" className="scm-nav">
                    <button
                        id="scm-nav-scan"
                        type="button"
                        className={`scm-nav__btn ${activeTab === "scan" ? "scm-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("scan")}
                    >
                        <Play size={16} /> 🚀 Lancer un Scan
                    </button>

                    <button
                        id="scm-nav-live"
                        type="button"
                        className={`scm-nav__btn ${activeTab === "live" ? "scm-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("live")}
                    >
                        <Terminal size={16} /> ⚡ Console Live
                        {isScanning && <span className="scm-nav__btn--badge">Actif</span>}
                    </button>

                    <button
                        id="scm-nav-results"
                        type="button"
                        className={`scm-nav__btn ${activeTab === "results" ? "scm-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("results")}
                    >
                        <FileText size={16} /> 📊 Résultats & Rapports
                        {lastScanResult && (
                            <span className="scm-nav__btn--badge">
                                {lastScanResult.total_vulns} faille{lastScanResult.total_vulns > 1 ? "s" : ""}
                            </span>
                        )}
                    </button>

                    <button
                        id="scm-nav-health"
                        type="button"
                        className={`scm-nav__btn ${activeTab === "health" ? "scm-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("health")}
                    >
                        <Activity size={16} /> 🩺 Santé
                    </button>

                    <button
                        id="scm-nav-settings"
                        type="button"
                        className={`scm-nav__btn ${activeTab === "settings" ? "scm-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("settings")}
                    >
                        <Settings size={16} /> ⚙️ Configuration
                    </button>

                    {activeTab !== null && (
                        <button
                            id="scm-nav-close"
                            type="button"
                            className="scm-nav__btn scm-nav__btn--close"
                            onClick={() => setActiveTab(null)}
                            title="Fermer la vue active"
                        >
                            ✖️ Fermer
                        </button>
                    )}
                </nav>
            </header>

            <hr id="scm-divider" className="scm-divider" />

            {/* Contenu Principal : CONSERVÉ EN MÉMOIRE via display: none */}
            <main id="scm-content" className="scm-content">
                {/* 1. Onglet Lancement */}
                <section style={{ display: activeTab === "scan" ? "block" : "none" }}>
                    <ScanLauncherComponent 
                        onScanStarted={handleScanStarted}
                        onGoToLive={() => setActiveTab("live")}
                    />
                </section>

                {/* 2. Onglet Console Live */}
                <section style={{ display: activeTab === "live" ? "block" : "none" }}>
                    <ScanLiveComponent 
                        scanId={currentScanId}
                        passPhrase={currentPassPhrase}
                        isScanning={isScanning}
                        onScanCompleted={handleScanCompleted}
                        onViewResults={() => setActiveTab("results")}
                    />
                </section>

                {/* 3. Onglet Résultats & Rapports */}
                <section style={{ display: activeTab === "results" ? "block" : "none" }}>
                    <ScanResultsComponent 
                        scanResult={lastScanResult}
                        onNewScan={() => setActiveTab("scan")}
                        onGlobalReset={handleGlobalReset}
                    />
                </section>

                {/* 4. Onglet Santé */}
                <section style={{ display: activeTab === "health" ? "block" : "none" }}>
                    <ScanHealthComponent />
                </section>

                {/* 5. Onglet Paramètres */}
                <section style={{ display: activeTab === "settings" ? "block" : "none" }}>
                    <ScanSettingsComponent />
                </section>

                {/* 6. État Désélectionné (Si activeTab === null) */}
                {activeTab === null && (
                    <div id="scm-empty" className="scm-empty">
                        <Sparkles size={40} style={{ color: "var(--accent)" }} />
                        <h2 className="scm-empty__title">🛡️ Scanner de Vulnérabilités Web IA</h2>
                        <p className="scm-empty__text">
                            Aucun outil actif. Sélectionnez un module ci-dessus ou choisissez une action rapide :
                        </p>

                        <div className="scm-empty__actions">
                            <button className="scm-empty__btn" type="button" onClick={() => setActiveTab("scan")}>
                                <Play size={16} /> 🚀 Configurer & Lancer un Scan
                            </button>
                            <button className="scm-empty__btn" type="button" onClick={() => setActiveTab("live")}>
                                <Terminal size={16} /> ⚡ Ouvrir la Console Live
                            </button>
                            <button className="scm-empty__btn" type="button" onClick={() => setActiveTab("results")}>
                                <FileText size={16} /> 📊 Consulter les Rapports
                            </button>
                            <button className="scm-empty__btn" type="button" onClick={() => setActiveTab("health")}>
                                <Activity size={16} /> 🩺 Examiner la Santé Système
                            </button>
                            <button className="scm-empty__btn" type="button" onClick={() => setActiveTab("settings")}>
                                <Settings size={16} /> ⚙️ Configuration du Scanner
                            </button>
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
}

export default Scanner;