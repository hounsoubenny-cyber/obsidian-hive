import { useEffect, useState } from "react";
import "./health.css";
import { ScannerStatusResponse } from "@/types/scanner/types";
import { getScannerStatus } from "../utils";
import { useNavigate } from "react-router-dom";
import { 
    Activity, 
    Cpu, 
    RefreshCw, 
    Clock, 
    CheckCircle2, 
    AlertTriangle, 
    Server, 
    Radio, 
    Zap, 
    Layers, 
    ShieldCheck
} from "lucide-react";

function ScanHealthComponent() {
    const navigate = useNavigate();
    const [status, setStatus] = useState<ScannerStatusResponse | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [lastRefresh, setLastRefresh] = useState<Date>(new Date());

    const fetchStatus = () => {
        getScannerStatus(setStatus, setError, setLoading, navigate).then(() => {
            setLastRefresh(new Date());
        });
    };

    useEffect(() => {
        fetchStatus();
    }, []);

    const isRunning = status?.status === "running" && !error;

    return (
        <div id="sch-container" className="sch-container">
            {/* Header */}
            <div id="sch-header" className="sch-header">
                <div className="sch-header__left">
                    <h2 className="sch-header__title">
                        <Activity size={24} /> 🩺 État de Santé du Scanner IA
                    </h2>
                    <p className="sch-header__subtitle">
                        Monitoring en temps réel de l'API FastAPI, des workers asynchrones et des modèles IA.
                    </p>
                </div>

                <div className="sch-header__right">
                    <span className="sch-header__last-refresh">
                        <Clock size={14} /> Contrôle : {lastRefresh.toLocaleTimeString()}
                    </span>
                    <button
                        id="sch-btn-refresh"
                        className="sch-btn"
                        type="button"
                        onClick={fetchStatus}
                        disabled={loading}
                        title="Actualiser les métriques"
                    >
                        <RefreshCw size={15} className={loading ? "oh-spin" : ""} />
                        {loading ? "Actualisation..." : "Actualiser"}
                    </button>
                </div>
            </div>

            {/* Erreur de connexion */}
            {error && (
                <div id="sch-error" className="sch-error">
                    <AlertTriangle size={22} className="sch-error__icon" />
                    <div className="sch-error__content">
                        <span className="sch-error__title">❌ Impossible de joindre l'API du Scanner</span>
                        <p className="sch-error__text">{error}</p>
                    </div>
                </div>
            )}

            {/* Bannière d'état global */}
            {status && (
                <div
                    id="sch-banner"
                    className={`sch-banner ${isRunning ? "sch-banner--healthy" : "sch-banner--degraded"}`}
                >
                    <div className="sch-banner__left">
                        <div className="sch-banner__icon">
                            {isRunning ? <CheckCircle2 size={32} /> : <AlertTriangle size={32} />}
                        </div>
                        <div className="sch-banner__content">
                            <div className="sch-banner__status">
                                {isRunning ? "🟢 API Scanner 100% Opérationnelle" : "🔴 Service Dégradé / Erreur"}
                            </div>
                            <span className="sch-banner__detail">
                                FastAPI (Uvicorn Async) • Horodatage serveur : {status.date}
                            </span>
                        </div>
                    </div>

                    <div className="sch-banner__right">
                        <span className="sch-banner__badge">
                            STATUT : {status.status.toUpperCase()}
                        </span>
                    </div>
                </div>
            )}

            {/* Grille de métriques */}
            {status && (
                <div id="sch-grid" className="sch-grid">
                    {/* Carte 1 : Tâches actives */}
                    <div className="sch-card">
                        <div className="sch-card__header">
                            <Radio size={20} className="sch-card__icon" />
                            <h4 className="sch-card__title">Scans en cours</h4>
                        </div>
                        <div className="sch-card__val">
                            {status.active_scans}
                        </div>
                        <p className="sch-card__desc">
                            Tâches de scan asynchrones en cours d'exécution simultanée.
                        </p>
                    </div>

                    {/* Carte 2 : Moteur ML */}
                    <div className="sch-card">
                        <div className="sch-card__header">
                            <Cpu size={20} className="sch-card__icon" />
                            <h4 className="sch-card__title">Modèle Stacking IA</h4>
                        </div>
                        <div className="sch-card__val sch-card__val--ready">
                            🟢 Prêt
                        </div>
                        <p className="sch-card__desc">
                            RandomForest, XGBoost, HistGB & MLP chargés en RAM.
                        </p>
                    </div>

                    {/* Carte 3 : Sémantique BERT */}
                    <div className="sch-card">
                        <div className="sch-card__header">
                            <Zap size={20} className="sch-card__icon" />
                            <h4 className="sch-card__title">Analyse Sémantique</h4>
                        </div>
                        <div className="sch-card__val sch-card__val--ready">
                            🟢 Actif
                        </div>
                        <p className="sch-card__desc">
                            Sentence-BERT prêt pour l'analyse différentielle de contenu.
                        </p>
                    </div>

                    {/* Carte 4 : Fuzzer Actif */}
                    <div className="sch-card">
                        <div className="sch-card__header">
                            <Layers size={20} className="sch-card__icon" />
                            <h4 className="sch-card__title">Points d'Injection</h4>
                        </div>
                        <div className="sch-card__val">
                            6 Vecteurs
                        </div>
                        <p className="sch-card__desc">
                            Query, Headers, Cookies, Formulaires, Chemins & JSON/XML Body.
                        </p>
                    </div>
                </div>
            )}

            {/* Tableau Technique */}
            {status && (
                <div id="sch-table-box" className="sch-table-box">
                    <div className="sch-table-box__title">
                        <Server size={18} /> Composants et Dépendances du Scanner
                    </div>

                    <table className="sch-table">
                        <thead>
                            <tr>
                                <th>Composant</th>
                                <th>Rôle & Technologie</th>
                                <th>État</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div className="sch-table__item">
                                        <Server size={14} /> Service Backend
                                    </div>
                                </td>
                                <td>FastAPI / aiohttp (Workers Asynchrones)</td>
                                <td><span className="sch-badge-ok">🟢 En ligne</span></td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="sch-table__item">
                                        <Radio size={14} /> WebSocket Hub
                                    </div>
                                </td>
                                <td>Streaming temps réel des logs de scan</td>
                                <td><span className="sch-badge-ok">🟢 Opérationnel</span></td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="sch-table__item">
                                        <ShieldCheck size={14} /> Navigateur Headless
                                    </div>
                                </td>
                                <td>Playwright Chromium (Rendu SPA & Dynamic Crawling)</td>
                                <td><span className="sch-badge-ok">🟢 Disponible</span></td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="sch-table__item">
                                        <Clock size={14} /> Date Serveur
                                    </div>
                                </td>
                                <td>{status.date}</td>
                                <td><span className="sch-badge-ok">✅ Synchronisée</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
}

export default ScanHealthComponent;