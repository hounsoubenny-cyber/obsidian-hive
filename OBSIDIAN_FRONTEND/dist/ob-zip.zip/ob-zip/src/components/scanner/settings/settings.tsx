import { useEffect, useState } from "react";
import "./settings.css";
import { getScannerDefaultConfig, getSupportedVulns } from "../utils";
import JsonEditor from "@/components/utils/json_editor/json_editor";
import { useNavigate } from "react-router-dom";
import { 
    Settings, 
    Sliders, 
    Cpu, 
    Database, 
    Shield, 
    RefreshCw, 
    Layers,
    FileCode
} from "lucide-react";
import toast from "react-hot-toast";

function ScanSettingsComponent() {
    const navigate = useNavigate();
    const [defaultConfig, setDefaultConfig] = useState<Record<string, any>>({});
    const [supportedVulns, setSupportedVulns] = useState<string[]>([]);
    const [loading, setLoading] = useState<boolean>(false);

    const fetchAll = async () => {
        setLoading(true);
        await getScannerDefaultConfig(
            (data: any) => setDefaultConfig(data || {}),
            (val: string | null) => {if (val) toast.error("Erreur de chargement de la config serveur")},
            null,
            navigate
        );
        await getSupportedVulns(
            (vulns: string[]) => setSupportedVulns(vulns || []),
            () => {},
            null,
            navigate
        );
        setLoading(false);
    };

    useEffect(() => {
        fetchAll();
    }, []);

    return (
        <div id="scs-container" className="scs-container">
            {/* Header */}
            <div id="scs-header" className="scs-header">
                <h2 className="scs-header__title">
                    <Settings size={24} /> ⚙️ Configuration & Réglages du Scanner
                </h2>
                <p className="scs-header__subtitle">
                    Visualisez les paramètres d'usine du scanner (`shieldai_scanner.config.json5`) et les capacités du moteur d'analyse.
                </p>
            </div>

            {/* Carte Spécifications du Moteur IA */}
            <div id="scs-specs-card" className="scs-card">
                <div className="scs-card__header">
                    <div className="scs-card__title-box">
                        <Cpu size={20} />
                        <h3 className="scs-card__title">🧠 Caractéristiques du Moteur IA</h3>
                    </div>
                </div>

                <div className="scs-specs-grid">
                    <div className="scs-spec-item">
                        <span className="scs-spec-item__label">Architecture ML</span>
                        <span className="scs-spec-item__val">Stacking + ClassifierChain</span>
                        <span className="scs-spec-item__desc">
                            Ensemble Random Forest, XGBoost, HistGB & Réseau de neurones.
                        </span>
                    </div>

                    <div className="scs-spec-item">
                        <span className="scs-spec-item__label">Vecteur d'entrée</span>
                        <span className="scs-spec-item__val">95 Features Extraites</span>
                        <span className="scs-spec-item__desc">
                            Structure HTML, entropie, headers, signaux passifs et fuzzer.
                        </span>
                    </div>

                    <div className="scs-spec-item">
                        <span className="scs-spec-item__label">Classes Détectées</span>
                        <span className="scs-spec-item__val">{supportedVulns.length || 30} Vulnérabilités</span>
                        <span className="scs-spec-item__desc">
                            SQLi, XSS, SSRF, SSTI, CMDi, XXE, IDOR, BrokenAuth, etc.
                        </span>
                    </div>

                    <div className="scs-spec-item">
                        <span className="scs-spec-item__label">Modèle Sémantique</span>
                        <span className="scs-spec-item__val">Sentence-BERT</span>
                        <span className="scs-spec-item__desc">
                            Embeddings haute dimension pour analyse différentielle du contenu.
                        </span>
                    </div>
                </div>
            </div>

            {/* Carte Fichier de Configuration Serveur */}
            <div id="scs-config-card" className="scs-card">
                <div className="scs-card__header">
                    <div className="scs-card__title-box">
                        <FileCode size={20} />
                        <h3 className="scs-card__title">Fichier de Configuration par Défaut (JSON5)</h3>
                    </div>
                    <button
                        id="scs-btn-refresh-conf"
                        type="button"
                        className="scs-btn"
                        onClick={fetchAll}
                        disabled={loading}
                    >
                        <RefreshCw size={14} className={loading ? "oh-spin" : ""} />
                        {loading ? "Chargement..." : "Actualiser"}
                    </button>
                </div>

                <p className="scs-card__desc">
                    Cette configuration est appliquée par défaut à tous les scans. Elle peut être surchargée individuellement lors du lancement d'un scan.
                </p>

                <JsonEditor
                    json={defaultConfig}
                    readOnly={true}
                    onSave={() => {}}
                    fileName="shieldai_scanner.config.json"
                />
            </div>
        </div>
    );
}

export default ScanSettingsComponent;