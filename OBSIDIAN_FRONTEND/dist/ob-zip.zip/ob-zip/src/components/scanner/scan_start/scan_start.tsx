import { useState, useEffect, useMemo } from "react";
import "./scan_start.css";
import { 
    StartScanRequest, 
    HelperInfo, 
    HelperCall, 
    HelperArg 
} from "@/types/scanner/types";
import { 
    startScan, 
    getHelpersList, 
    getSupportedVulns, 
    getScannerDefaultConfig 
} from "../utils";
import { scWsScanStatusRoute } from "@/hooks/backend_routes";
import { useScannerWSStore } from "@/store/scanner_websocket_store";
import JsonEditor from "@/components/utils/json_editor/json_editor";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { 
    Play, 
    Globe, 
    Key, 
    Zap, 
    Shield, 
    Sliders, 
    Plus, 
    Trash2, 
    RotateCcw, 
    Search, 
    Info, 
    ChevronDown, 
    ChevronUp, 
    Terminal, 
    Lock, 
    AlertCircle,
    FileCode,
    Edit3,
    Eye,
    Palette,
    FileText,
    Folder
} from "lucide-react";
import { AppConfig, getConfig } from "@/hooks/get_config";

interface ScanLauncherProps {
    onScanStarted: (scanId: string, passPhrase: string) => void;
    onGoToLive?: () => void;
    onGlobalReset?: () => void; 
}

function generateRandomPassphrase(): string {
    return Array.from(crypto.getRandomValues(new Uint8Array(8)))
        .map(b => b.toString(16).padStart(2, "0"))
        .join("");
}

function RenderHelperArgField({
    arg,
    value,
    onChange,
}: {
    arg: HelperArg;
    value: any;
    onChange: (val: any) => void;
}) {
    const inputType = arg.input_type || "text";

    if (inputType === "boolean") {
        return (
            <input
                type="checkbox"
                className="scl-checkbox"
                checked={Boolean(value)}
                onChange={(e) => onChange(e.target.checked)}
            />
        );
    }

    if (inputType === "number" || inputType === "float") {
        return (
            <input
                type="number"
                step={inputType === "float" ? "0.1" : "1"}
                className="scl-helper-field__input"
                value={value ?? ""}
                onChange={(e) => onChange(e.target.value === "" ? "" : Number(e.target.value))}
            />
        );
    }

    if (inputType === "json") {
        return (
            <textarea
                className="scl-helper-field__input"
                rows={3}
                placeholder='{"key": "value"}'
                value={typeof value === "object" ? JSON.stringify(value, null, 2) : value ?? ""}
                onChange={(e) => {
                    try {
                        onChange(JSON.parse(e.target.value));
                    } catch {
                        onChange(e.target.value);
                    }
                }}
            />
        );
    }

    if (inputType === "list") {
        const textVal = Array.isArray(value) ? value.join(", ") : value ?? "";
        return (
            <input
                type="text"
                className="scl-helper-field__input"
                placeholder="valeur1, valeur2..."
                value={textVal}
                onChange={(e) => {
                    const arr = e.target.value.split(",").map((s) => s.trim()).filter(Boolean);
                    onChange(arr);
                }}
            />
        );
    }

    return (
        <input
            type="text"
            className="scl-helper-field__input"
            placeholder={String(arg.default ?? "")}
            value={value ?? ""}
            onChange={(e) => onChange(e.target.value)}
        />
    );
}

function ScanLauncherComponent({ onScanStarted, onGoToLive }: ScanLauncherProps) {
    const navigate = useNavigate();
    const { isScanning, isConnected } = useScannerWSStore();
    const [conf, setConf] = useState<AppConfig | null>(null);
    
    // ── 1. Cible & Sécurité ───────────────────────────────────────────────────
    const [targetUrl, setTargetUrl] = useState<string>("http://localhost:8080");
    const [passPhrase, setPassPhrase] = useState<string>(generateRandomPassphrase());

    // ── 2. Mode de scan & Comportements ───────────────────────────────────────
    const [activeScan, setActiveScan] = useState<boolean>(false);
    const [isSpa, setIsSpa] = useState<boolean>(false);
    const [fetchJs, setFetchJs] = useState<boolean>(true);
    const [useCache, setUseCache] = useState<boolean>(false);
    const [putResultInCache, setPutResultInCache] = useState<boolean>(true);

    // ── 3. Helpers d'authentification ─────────────────────────────────────────
    const [helpersCatalog, setHelpersCatalog] = useState<HelperInfo[]>([]);
    const [helperSearch, setHelperSearch] = useState<string>("");
    const [selectedHelperInfo, setSelectedHelperInfo] = useState<HelperInfo | null>(null);
    const [helperKwargs, setHelperKwargs] = useState<Record<string, any>>({});
    const [configuredHelpers, setConfiguredHelpers] = useState<HelperCall[]>([]);
    const [raiseOnHelperError, setRaiseOnHelperError] = useState<boolean>(false);

    // ── 4. Ciblage Fuzzer ─────────────────────────────────────────────────────
    const [supportedVulns, setSupportedVulns] = useState<string[]>([]);
    const [vulnTargetMode, setVulnTargetMode] = useState<"all" | "limit" | "custom">("all");
    const [limitVulnNumber, setLimitVulnNumber] = useState<number>(5);
    const [selectedVulns, setSelectedVulns] = useState<string[]>([]);

    // ── 5. Options Avancées (Tuning Fuzzer & Crawler) ──────────────────────────
    const [showAdvanced, setShowAdvanced] = useState<boolean>(false);
    const [semaphore, setSemaphore] = useState<number>(50);
    const [timeBetween, setTimeBetween] = useState<number>(0.001);
    const [threshold, setThreshold] = useState<number>(0.5);
    const [useSemantic, setUseSemantic] = useState<boolean>(true);
    const [limitPayloads, setLimitPayloads] = useState<number | "">("");
    const [maxTest, setMaxTest] = useState<number | "">("");
    
    // Arjun & Paramètres connus
    const [useArjun, setUseArjun] = useState<boolean>(false);
    const [arjunTimeout, setArjunTimeout] = useState<number>(30);
    const [knownParamsDir, setKnownParamsDir] = useState<string>("");

    // Scope & Rapports
    const [allowedDomains, setAllowedDomains] = useState<string[]>(["http://127.0.0.1", "http://localhost"]);
    const [newDomainInput, setNewDomainInput] = useState<string>("");
    const [customFilename, setCustomFilename] = useState<string>("");
    const [reportTheme, setReportTheme] = useState<string>("multi");

    // ── 6. Gestion Config JSON5 ───────────────────────────────────────────────
    const [configObj, setConfigObj] = useState<Record<string, any>>({});
    const [defaultConfigBackup, setDefaultConfigBackup] = useState<Record<string, any>>({});
    const [isCustomConfig, setIsCustomConfig] = useState<boolean>(false);
    const [loadingConfig, setLoadingConfig] = useState<boolean>(false);

    // États de chargement & erreurs
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    // ── Chargements initiaux ──────────────────────────────────────────────────
    const fetchDefaultConfig = async () => {
        setLoadingConfig(true);
        await getScannerDefaultConfig(
            (data: any) => {
                if (data && typeof data === "object") {
                    setConfigObj(data);
                    setDefaultConfigBackup(data);
                }
            },
            (val: string | null) => {if (val) toast.error("Impossible de récupérer la configuration par défaut")},
            null,
            navigate
        );
        setLoadingConfig(false);
    };

    const loadConf = async () => {
        const r = await getConfig();
        setConf(r);
    }
    useEffect(() => {
        getHelpersList((data: any) => setHelpersCatalog(data?.helpers || []), () => {}, null, navigate);
        getSupportedVulns((vulns: string[]) => setSupportedVulns(vulns || []), () => {}, null, navigate);
        fetchDefaultConfig();
        loadConf();
    }, []);

    // Réinitialiser la configuration d'usine
    const handleResetToDefault = () => {
        setConfigObj(defaultConfigBackup);
        setIsCustomConfig(false);
    };

    // 🧹 Réinitialisation complète du formulaire
    const handleResetForm = () => {
        setTargetUrl("");
        setPassPhrase(generateRandomPassphrase());
        setActiveScan(true);
        setIsSpa(false);
        setFetchJs(true);
        setUseCache(false);
        setPutResultInCache(true);
        setConfiguredHelpers([]);
        setSelectedHelperInfo(null);
        setHelperKwargs({});
        setVulnTargetMode("all");
        setLimitVulnNumber(5);
        setSelectedVulns([]);
        setSemaphore(50);
        setTimeBetween(0.001);
        setThreshold(0.5);
        setUseSemantic(true);
        setLimitPayloads("");
        setMaxTest("");
        setUseArjun(false);
        setArjunTimeout(30);
        setKnownParamsDir("");
        setAllowedDomains(["http://127.0.0.1", "http://localhost"]);
        setNewDomainInput("");
        setCustomFilename("");
        setReportTheme("multi");
        handleResetToDefault();
        setError(null);
        toast("🧹 Formulaire réinitialisé !");
    };

    const handleSelectHelper = (h: HelperInfo) => {
        setSelectedHelperInfo(h);
        const defaults: Record<string, any> = {};
        Object.entries(h.args || {}).forEach(([key, arg]) => {
            defaults[key] = arg.default !== "REQUIRED_ARG" ? arg.default : "";
        });
        setHelperKwargs(defaults);
    };

    const handleAddHelper = () => {
        if (!selectedHelperInfo) return;
        const newCall: HelperCall = {
            name: selectedHelperInfo.name,
            kwargs: { ...helperKwargs },
        };
        setConfiguredHelpers((prev) => [...prev, newCall]);
        setSelectedHelperInfo(null);
        setHelperKwargs({});
        toast.success(`🔐 Helper "${selectedHelperInfo.name}" ajouté !`);
    };

    const handleRemoveHelper = (index: number) => {
        setConfiguredHelpers((prev) => prev.filter((_, i) => i !== index));
    };

    const handleAddDomain = () => {
        const d = newDomainInput.trim();
        if (d && !allowedDomains.includes(d)) {
            setAllowedDomains((prev) => [...prev, d]);
            setNewDomainInput("");
        }
    };

    const handleRemoveDomain = (d: string) => {
        setAllowedDomains((prev) => prev.filter((item) => item !== d));
    };

    const toggleVulnSelection = (v: string) => {
        setSelectedVulns((prev) => 
            prev.includes(v) ? prev.filter((item) => item !== v) : [...prev, v]
        );
    };

    const filteredHelpers = useMemo(() => {
        const s = helperSearch.toLowerCase();
        return helpersCatalog.filter(
            (h) => h.name.toLowerCase().includes(s) || (h.description && h.description.toLowerCase().includes(s))
        );
    }, [helpersCatalog, helperSearch]);

    // ── Lancement du scan ─────────────────────────────────────────────────────
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (isScanning || isConnected) {
            toast.error("⚠️ Un scan est déjà en cours d'exécution !");
            return;
        }

        const cleanUrl = targetUrl.trim();
        if (!cleanUrl) {
            toast.error("⚠️ Veuillez spécifier une URL cible !");
            return;
        }

        let limitVulnParam: number | string[] | null = null;
        if (vulnTargetMode === "limit") limitVulnParam = limitVulnNumber;
        else if (vulnTargetMode === "custom") limitVulnParam = selectedVulns.length > 0 ? selectedVulns : null;

        const payload: StartScanRequest = {
            pass_phrase: passPhrase.trim() || generateRandomPassphrase(),
            instance_args: {
                active_scan: activeScan,
                use_cache: useCache,
                restore: false,
                debug: true,
                semaphore: Math.max(1, semaphore || 50),
                limit_payloads: typeof limitPayloads === "number" && limitPayloads > 0 ? limitPayloads : null,
                use_semantic: useSemantic,
                theme: reportTheme,
                use_arjun: useArjun,
                arjun_timeout: arjunTimeout,
                known_params_dir: knownParamsDir.trim() ? knownParamsDir.trim() : null,
                conf_content: isCustomConfig && Object.keys(configObj).length > 0 
                    ? JSON.stringify(configObj, null, 2) 
                    : "",
            },
            scan_args: {
                url: cleanUrl,
                fetch: fetchJs,
                use_cache: useCache,
                put_result_in_cache: putResultInCache,
                filename: customFilename.trim() ? customFilename.trim() : null,
                limit_vuln_for_fuzzer: limitVulnParam,
                time_between_for_fuzzer: timeBetween,
                dynamic_timeout_for_fuzzer: true,
                allowed_domains: allowedDomains,
                threshold: threshold,
                helpers: configuredHelpers,
                raise_on_helper_error: raiseOnHelperError,
                is_spa: isSpa,
                max_test: typeof maxTest === "number" && maxTest > 0 ? maxTest : null,
            },
        };

        const res = await startScan(payload, setLoading, setError, null, navigate);
        setLoading(false);
        if (res && res.status === "started" && res.scan_id) {
            toast.success("🚀 Scan démarré avec succès !");

            const wsProto = window.location.protocol === "https:" ? "wss:" : "ws:";
            const baseUrl = conf.apiBaseUrl.replaceAll("http://", "").replaceAll("https://", "")
            const cleanRoute = scWsScanStatusRoute.startsWith("/") 
                ? scWsScanStatusRoute.slice(1) 
                : scWsScanStatusRoute;
            const wsUrl = `${wsProto}//${baseUrl}/${cleanRoute}?scan_id=${res.scan_id}&pass_phrase=${encodeURIComponent(payload.pass_phrase)}`;
            console.log(cleanUrl, wsUrl);
            useScannerWSStore.getState().connect(wsUrl, { force: true });

            onScanStarted(res.scan_id, payload.pass_phrase);
        }
    };

    const isBusy = isScanning || isConnected;
    console.log("start", isBusy, isScanning, isConnected, loading);
    return (
        <div id="scl-container" className="scl-container">
            {/* Header */}
            <div className="scl-header">
                <h2 className="scl-header__title">
                    <Play size={24} /> 🚀 Nouveau Scan de Vulnérabilités
                </h2>
                <p className="scl-header__subtitle">
                    Configurez votre cible, définissez vos profils d'attaque et lancez une analyse augmentée par IA.
                </p>
            </div>

            {/* Bannière d'état occupé */}
            {isBusy && (
                <div className="scl-busy-banner">
                    <div className="scl-busy-banner__left">
                        <AlertCircle size={22} className="scl-busy-banner__icon" />
                        <div>
                            <strong>Scan en cours d'exécution</strong>
                            <div style={{ fontSize: "0.8rem", opacity: 0.9 }}>
                                Une analyse est actuellement active. Vous devez attendre sa fin ou l'annuler pour en démarrer une autre.
                            </div>
                        </div>
                    </div>
                    {onGoToLive && (
                        <button type="button" className="scl-busy-banner__btn" onClick={onGoToLive}>
                            <Terminal size={14} /> Voir la Console Live
                        </button>
                    )}
                </div>
            )}

            {/* Erreur */}
            {error && (
                <div className="apu-error">
                    <AlertCircle size={20} className="apu-error__icon" />
                    <div className="apu-error__content">
                        <span className="apu-error__title">❌ Erreur de lancement</span>
                        <p className="apu-error__text">{error}</p>
                    </div>
                </div>
            )}

            {/* Formulaire */}
            <form className="scl-form" onSubmit={handleSubmit}>
                {/* ── 1. Cible & Clé ────────────────────────────────────────────── */}
                <div className="scl-section">
                    <div className="scl-section__header">
                        <Globe size={18} />
                        <h3 className="scl-section__title">1. Cible & Clé de Sécurité</h3>
                    </div>

                    <div className="scl-grid-2">
                        <div className="scl-group">
                            <label className="scl-label">🌐 URL Cible à analyser</label>
                            <div className="scl-input-wrapper">
                                <input
                                    type="text"
                                    className="scl-input"
                                    placeholder="https://mon-application.com ou http://localhost:8080"
                                    value={targetUrl}
                                    onChange={(e) => setTargetUrl(e.target.value)}
                                    disabled={isBusy}
                                />
                            </div>
                        </div>

                        <div className="scl-group">
                            <label className="scl-label">
                                <Lock size={13} /> Passphrase WebSocket
                            </label>
                            <div className="scl-input-wrapper">
                                <input
                                    type="text"
                                    className="scl-input"
                                    value={passPhrase}
                                    onChange={(e) => setPassPhrase(e.target.value)}
                                    disabled={isBusy}
                                />
                                <button
                                    type="button"
                                    className="scl-btn-inline"
                                    onClick={() => setPassPhrase(generateRandomPassphrase())}
                                    disabled={isBusy}
                                    title="Générer une nouvelle clé"
                                >
                                    <RotateCcw size={12} />
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                {/* ── 2. Mode de scan ───────────────────────────────────────────── */}
                <div className="scl-section">
                    <div className="scl-section__header">
                        <Zap size={18} />
                        <h3 className="scl-section__title">2. Mode d'Analyse</h3>
                    </div>

                    <div className="scl-mode-grid">
                        <div
                            className={`scl-mode-card ${activeScan ? "scl-mode-card--active" : ""}`}
                            onClick={() => !isBusy && setActiveScan(true)}
                        >
                            <div className="scl-mode-card__top">
                                <span className="scl-mode-card__title">
                                    🔥 Scan Actif & Fuzzing Complet
                                </span>
                                {activeScan && <span className="oh-badge oh-badge--accent">Sélectionné</span>}
                            </div>
                            <p className="scl-mode-card__desc">
                                Crawl approfondi + Injection de payloads (SQLi, XSS, SSRF...) + Inférence par Stacking IA.
                            </p>
                        </div>

                        <div
                            className={`scl-mode-card ${!activeScan ? "scl-mode-card--active" : ""}`}
                            onClick={() => !isBusy && setActiveScan(false)}
                        >
                            <div className="scl-mode-card__top">
                                <span className="scl-mode-card__title">
                                    🛡️ Scan Passif & Heuristique Seul
                                </span>
                                {!activeScan && <span className="oh-badge oh-badge--accent">Sélectionné</span>}
                            </div>
                            <p className="scl-mode-card__desc">
                                Analyse structurelle sans envoi de payloads agressifs (Headers, Cookies, Code statique JS/HTML).
                            </p>
                        </div>
                    </div>
                </div>

                {/* ── 3. Helpers d'authentification ─────────────────────────────── */}
                <div className="scl-section">
                    <div className="scl-section__header">
                        <Key size={18} />
                        <h3 className="scl-section__title">3. Authentification & Pré-requis (Helpers)</h3>
                    </div>
                    <p className="scl-section__desc">
                        Injectez des sessions authentifiées (DVWA, WordPress, Token JWT, Form Login...) avant le crawl.
                    </p>

                    <div className="scl-helpers-3col">
                        {/* Colonne 1 : Catalogue */}
                        <div className="scl-helpers-col">
                            <div className="scl-helpers-col__header">
                                <span>Catalogue ({filteredHelpers.length})</span>
                            </div>
                            <div className="scl-input-wrapper" style={{ padding: "2px 8px" }}>
                                <Search size={14} className="scl-input-icon" />
                                <input
                                    type="text"
                                    className="scl-input"
                                    placeholder="Rechercher un helper..."
                                    value={helperSearch}
                                    onChange={(e) => setHelperSearch(e.target.value)}
                                    style={{ fontSize: "0.8rem", padding: "6px 0" }}
                                />
                            </div>
                            <div className="scl-helpers-list">
                                {filteredHelpers.map((h) => (
                                    <button
                                        key={h.name}
                                        type="button"
                                        className={`scl-helper-item ${selectedHelperInfo?.name === h.name ? "scl-helper-item--active" : ""}`}
                                        onClick={() => handleSelectHelper(h)}
                                        disabled={isBusy}
                                    >
                                        <span className="scl-helper-item__name">{h.name}</span>
                                        <span className="scl-helper-item__desc">{h.description || "Aucune description"}</span>
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Colonne 2 : Configuration du helper sélectionné */}
                        <div className="scl-helpers-col">
                            <div className="scl-helpers-col__header">
                                <span>Configuration des arguments</span>
                            </div>

                            {selectedHelperInfo ? (
                                <div className="scl-helper-config">
                                    <div className="scl-helper-config__title">
                                        <Key size={16} /> {selectedHelperInfo.name}
                                    </div>
                                    <p className="scl-helper-config__desc">{selectedHelperInfo.description}</p>

                                    <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                                        {Object.entries(selectedHelperInfo.args || {}).map(([argName, argSpec]) => (
                                            <div key={argName} className="scl-helper-field">
                                                <label className="scl-helper-field__label">
                                                    {argName}
                                                    <span className="scl-helper-field__type">({argSpec.input_type})</span>
                                                </label>
                                                <RenderHelperArgField
                                                    arg={argSpec}
                                                    value={helperKwargs[argName]}
                                                    onChange={(val) =>
                                                        setHelperKwargs((prev) => ({ ...prev, [argName]: val }))
                                                    }
                                                />
                                            </div>
                                        ))}
                                    </div>

                                    <button
                                        type="button"
                                        className="oh-btn oh-btn--primary"
                                        style={{ marginTop: "auto", fontSize: "0.8rem", padding: "6px 12px" }}
                                        onClick={handleAddHelper}
                                    >
                                        <Plus size={14} /> Ajouter ce helper
                                    </button>
                                </div>
                            ) : (
                                <div className="apu-empty" style={{ padding: "30px 10px" }}>
                                    <Info size={24} style={{ color: "var(--text-tertiary)" }} />
                                    <span style={{ fontSize: "0.8rem" }}>Sélectionnez un helper à gauche pour renseigner ses paramètres.</span>
                                </div>
                            )}
                        </div>

                        {/* Colonne 3 : Helpers retenus */}
                        <div className="scl-helpers-col">
                            <div className="scl-helpers-col__header">
                                <span>Actifs ({configuredHelpers.length})</span>
                                {configuredHelpers.length > 0 && (
                                    <button
                                        type="button"
                                        className="scl-btn-inline"
                                        onClick={() => setConfiguredHelpers([])}
                                        style={{ color: "var(--danger)" }}
                                    >
                                        Tout vider
                                    </button>
                                )}
                            </div>

                            <div className="scl-helpers-list">
                                {configuredHelpers.length === 0 ? (
                                    <div className="apu-empty" style={{ padding: "30px 10px" }}>
                                        <span style={{ fontSize: "0.8rem" }}>Aucun helper configuré (Scan sans authentification).</span>
                                    </div>
                                ) : (
                                    configuredHelpers.map((call, idx) => (
                                        <div key={idx} className="scl-selected-card">
                                            <div className="scl-selected-card__info">
                                                <span className="scl-selected-card__name">{call.name}</span>
                                                <span className="scl-selected-card__args">
                                                    {Object.keys(call.kwargs || {}).length} argument(s)
                                                </span>
                                            </div>
                                            <button
                                                type="button"
                                                className="scl-selected-card__del"
                                                onClick={() => handleRemoveHelper(idx)}
                                                disabled={isBusy}
                                            >
                                                <Trash2 size={14} />
                                            </button>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>
                    </div>
                </div>

                {/* ── 4. Filtrage des vulnérabilités ────────────────────────────── */}
                {activeScan && (
                    <div className="scl-section">
                        <div className="scl-section__header">
                            <Shield size={18} />
                            <h3 className="scl-section__title">4. Ciblage des Vulnérabilités (Fuzzer)</h3>
                        </div>

                        <div className="scl-vulns-wrapper">
                            <div className="scl-vulns-toggle">
                                <button
                                    type="button"
                                    className={`scl-vulns-btn ${vulnTargetMode === "all" ? "scl-vulns-btn--active" : ""}`}
                                    onClick={() => setVulnTargetMode("all")}
                                >
                                    Toutes ({supportedVulns.length})
                                </button>
                                <button
                                    type="button"
                                    className={`scl-vulns-btn ${vulnTargetMode === "limit" ? "scl-vulns-btn--active" : ""}`}
                                    onClick={() => setVulnTargetMode("limit")}
                                >
                                    Limiter en nombre
                                </button>
                                <button
                                    type="button"
                                    className={`scl-vulns-btn ${vulnTargetMode === "custom" ? "scl-vulns-btn--active" : ""}`}
                                    onClick={() => setVulnTargetMode("custom")}
                                >
                                    Sélection manuelle ({selectedVulns.length})
                                </button>
                            </div>

                            {vulnTargetMode === "limit" && (
                                <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                                    <label className="scl-label">Nombre max de vulnérabilités à tester :</label>
                                    <input
                                        type="number"
                                        min={1}
                                        max={supportedVulns.length || 30}
                                        className="scl-helper-field__input"
                                        style={{ width: "80px" }}
                                        value={limitVulnNumber}
                                        onChange={(e) => setLimitVulnNumber(Number(e.target.value))}
                                    />
                                </div>
                            )}

                            {vulnTargetMode === "custom" && (
                                <div className="scl-vulns-grid">
                                    {supportedVulns.map((v) => {
                                        const isSel = selectedVulns.includes(v);
                                        return (
                                            <button
                                                key={v}
                                                type="button"
                                                className={`scl-vuln-chip ${isSel ? "scl-vuln-chip--active" : ""}`}
                                                onClick={() => toggleVulnSelection(v)}
                                            >
                                                {v}
                                            </button>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* ── 5. Options Avancées ───────────────────────────────────────── */}
                <div className="scl-section">
                    <div
                        className="scl-advanced-toggle"
                        onClick={() => setShowAdvanced((prev) => !prev)}
                    >
                        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <Sliders size={18} />
                            <span>Paramètres avancés & Tuning du scan</span>
                        </div>
                        {showAdvanced ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                    </div>

                    {showAdvanced && (
                        <div className="scl-advanced-body">
                            {/* Checkboxes rapides */}
                            <div className="scl-adv-grid">
                                <label className="scl-checkbox-item">
                                    <input
                                        type="checkbox"
                                        checked={isSpa}
                                        onChange={(e) => setIsSpa(e.target.checked)}
                                    />
                                    <span>Mode SPA (Playwright Chromium)</span>
                                </label>

                                <label className="scl-checkbox-item">
                                    <input
                                        type="checkbox"
                                        checked={fetchJs}
                                        onChange={(e) => setFetchJs(e.target.checked)}
                                    />
                                    <span>Télécharger les scripts JS (Fetch)</span>
                                </label>

                                <label className="scl-checkbox-item">
                                    <input
                                        type="checkbox"
                                        checked={useSemantic}
                                        onChange={(e) => setUseSemantic(e.target.checked)}
                                    />
                                    <span>Analyse sémantique (BERT)</span>
                                </label>

                                <label className="scl-checkbox-item">
                                    <input
                                        type="checkbox"
                                        checked={useArjun}
                                        onChange={(e) => setUseArjun(e.target.checked)}
                                    />
                                    <span>Découverte auto (Arjun)</span>
                                </label>

                                <label className="scl-checkbox-item">
                                    <input
                                        type="checkbox"
                                        checked={useCache}
                                        onChange={(e) => setUseCache(e.target.checked)}
                                    />
                                    <span>Lire le Cache</span>
                                </label>

                                <label className="scl-checkbox-item">
                                    <input
                                        type="checkbox"
                                        checked={putResultInCache}
                                        onChange={(e) => setPutResultInCache(e.target.checked)}
                                    />
                                    <span>Sauvegarder dans le Cache</span>
                                </label>

                                <label className="scl-checkbox-item">
                                    <input
                                        type="checkbox"
                                        checked={raiseOnHelperError}
                                        onChange={(e) => setRaiseOnHelperError(e.target.checked)}
                                    />
                                    <span>Bloquer si échec d'un helper</span>
                                </label>
                            </div>

                            {/* Inputs numériques & Limites */}
                            <div className="scl-adv-grid">
                                {/* Sémaphore */}
                                <div className="scl-group">
                                    <label className="scl-label">Sémaphore (Concurrency)</label>
                                    <input
                                        type="text"
                                        inputMode="numeric"
                                        pattern="[0-9]*"
                                        className="scl-helper-field__input"
                                        placeholder="50"
                                        value={semaphore}
                                        onChange={(e) => {
                                            const clean = e.target.value.replace(/\D/g, "");
                                            setSemaphore(clean === "" ? 0 : Number(clean));
                                        }}
                                        onBlur={() => {
                                            if (!semaphore || semaphore < 1) setSemaphore(1);
                                            else if (semaphore > 200) setSemaphore(200);
                                        }}
                                    />
                                    <span style={{ fontSize: "0.72rem", color: "var(--text-tertiary)" }}>
                                        Workers simultanés (1 - 200)
                                    </span>
                                </div>

                                {/* Limite de Payloads par Vulnérabilité */}
                                <div className="scl-group">
                                    <label className="scl-label">Limite de payloads / vuln</label>
                                    <input
                                        type="text"
                                        inputMode="numeric"
                                        className="scl-helper-field__input"
                                        placeholder="Illimité (null)"
                                        value={limitPayloads}
                                        onChange={(e) => {
                                            const clean = e.target.value.replace(/\D/g, "");
                                            setLimitPayloads(clean === "" ? "" : Number(clean));
                                        }}
                                    />
                                    <span style={{ fontSize: "0.72rem", color: "var(--text-tertiary)" }}>
                                        Ex: 3 ou 5 (vide = tous)
                                    </span>
                                </div>

                                {/* Limite globale Max Test */}
                                <div className="scl-group">
                                    <label className="scl-label">Limite absolue de requêtes</label>
                                    <input
                                        type="text"
                                        inputMode="numeric"
                                        className="scl-helper-field__input"
                                        placeholder="Illimité (null)"
                                        value={maxTest}
                                        onChange={(e) => {
                                            const clean = e.target.value.replace(/\D/g, "");
                                            setMaxTest(clean === "" ? "" : Number(clean));
                                        }}
                                    />
                                    <span style={{ fontSize: "0.72rem", color: "var(--text-tertiary)" }}>
                                        Plafond global de fuzzing
                                    </span>
                                </div>

                                {/* Seuil IA */}
                                <div className="scl-group">
                                    <label className="scl-label">Seuil IA ({Math.round(threshold * 100)}%)</label>
                                    <input
                                        type="range"
                                        min={0.1}
                                        max={0.9}
                                        step={0.05}
                                        value={threshold}
                                        onChange={(e) => setThreshold(Number(e.target.value))}
                                    />
                                </div>

                                {/* Délai inter-requêtes */}
                                <div className="scl-group">
                                    <label className="scl-label">Délai inter-requêtes (s)</label>
                                    <input
                                        type="number"
                                        step={0.001}
                                        min={0}
                                        max={1}
                                        className="scl-helper-field__input"
                                        value={timeBetween}
                                        onChange={(e) => setTimeBetween(Number(e.target.value))}
                                    />
                                </div>

                                {/* Timeout Arjun */}
                                {useArjun && (
                                    <div className="scl-group">
                                        <label className="scl-label">Timeout Arjun (s)</label>
                                        <input
                                            type="number"
                                            min={5}
                                            max={120}
                                            className="scl-helper-field__input"
                                            value={arjunTimeout}
                                            onChange={(e) => setArjunTimeout(Number(e.target.value))}
                                        />
                                    </div>
                                )}

                                {/* Nom du rapport */}
                                <div className="scl-group">
                                    <label className="scl-label">
                                        <FileText size={13} /> Nom du rapport (optionnel)
                                    </label>
                                    <input
                                        type="text"
                                        className="scl-helper-field__input"
                                        placeholder="rapport_audit_client"
                                        value={customFilename}
                                        onChange={(e) => setCustomFilename(e.target.value)}
                                    />
                                </div>

                                {/* Thème du rapport */}
                                <div className="scl-group">
                                    <label className="scl-label">
                                        <Palette size={13} /> Thème du rapport
                                    </label>
                                    <select
                                        className="scl-select"
                                        value={reportTheme}
                                        onChange={(e) => setReportTheme(e.target.value)}
                                    >
                                        <option value="multi">🎨 Multi-Thème (Cyber/Light/Dark)</option>
                                        <option value="dark">🌑 Sombre (Dark)</option>
                                        <option value="light">☀️ Clair (Light)</option>
                                    </select>
                                </div>
                            </div>

                            {/* Dossier de paramètres connus */}
                            <div className="scl-group">
                                <label className="scl-label">
                                    <Folder size={13} /> Dossier known_params (optionnel)
                                </label>
                                <input
                                    type="text"
                                    className="scl-helper-field__input"
                                    placeholder="/chemin/vers/known_params_dir"
                                    value={knownParamsDir}
                                    onChange={(e) => setKnownParamsDir(e.target.value)}
                                />
                            </div>

                            {/* Scope Domaines autorisés */}
                            <div className="scl-domains-box">
                                <label className="scl-label">Scope / Domaines autorisés :</label>
                                <div className="scl-domains-tags">
                                    {allowedDomains.map((d) => (
                                        <span key={d} className="scl-domain-tag">
                                            {d}
                                            <button type="button" onClick={() => handleRemoveDomain(d)}>
                                                ×
                                            </button>
                                        </span>
                                    ))}
                                </div>
                                <div style={{ display: "flex", gap: "8px", marginTop: "4px" }}>
                                    <input
                                        type="text"
                                        className="scl-helper-field__input"
                                        placeholder="Ex: http://target.local"
                                        value={newDomainInput}
                                        onChange={(e) => setNewDomainInput(e.target.value)}
                                        onKeyDown={(e) => {
                                            if (e.key === "Enter") {
                                                e.preventDefault();
                                                handleAddDomain();
                                            }
                                        }}
                                    />
                                    <button type="button" className="scl-btn-inline" onClick={handleAddDomain}>
                                        Ajouter domaine
                                    </button>
                                </div>
                            </div>

                            {/* ── Configuration JSON5 ── */}
                            <div className="scl-group">
                                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px", flexWrap: "wrap", gap: "8px" }}>
                                    <label className="scl-label">
                                        <FileCode size={13} /> Configuration du Scanner (JSON5)
                                    </label>
                                    
                                    <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
                                        <button
                                            type="button"
                                            className={`scl-btn-inline ${isCustomConfig ? "scl-vulns-btn--active" : ""}`}
                                            onClick={() => {
                                                const nextState = !isCustomConfig;
                                                setIsCustomConfig(nextState);
                                                if (nextState) {
                                                    toast("✏️ Mode Personnalisation activé : vous pouvez modifier la config.");
                                                } else {
                                                    toast("🔒 Mode Lecture Seule activé : la config par défaut sera utilisée.");
                                                }
                                            }}
                                            title="Basculer entre config par défaut et config personnalisée"
                                        >
                                            {isCustomConfig ? <Edit3 size={13} /> : <Eye size={13} />}
                                            {isCustomConfig ? "Mode Édition (Personnalisé)" : "Mode Défaut (Lecture Seule)"}
                                        </button>

                                        <button
                                            type="button"
                                            className="scl-btn-inline"
                                            onClick={handleResetToDefault}
                                            disabled={loadingConfig}
                                            title="Restaurer la configuration d'usine du serveur"
                                        >
                                            <RotateCcw size={12} className={loadingConfig ? "oh-spin" : ""} /> Restaurer d'usine
                                        </button>
                                    </div>
                                </div>

                                <JsonEditor
                                    json={configObj}
                                    readOnly={!isCustomConfig}
                                    onSave={(updated) => {
                                        setConfigObj(updated);
                                        setIsCustomConfig(true);
                                        toast.success("✅ Configuration personnalisée enregistrée !");
                                    }}
                                    saveLabel="💾 Valider la configuration"
                                    fileName="shieldai_scanner.config.json"
                                />
                            </div>
                        </div>
                    )}
                </div>

                {/* ── Actions finales : Réinitialiser + Lancer ───────────────────── */}
                <div className="scl-actions">
                    <button
                        type="button"
                        className="oh-btn oh-btn--ghost"
                        style={{ padding: "12px 20px" }}
                        onClick={handleResetForm}
                        disabled={isBusy || loading}
                    >
                        <RotateCcw size={16} /> Réinitialiser
                    </button>

                    <button
                        type="submit"
                        className="oh-btn oh-btn--primary"
                        style={{ padding: "12px 28px", fontSize: "1rem" }}
                        disabled={loading || isBusy || !targetUrl.trim()}
                    >
                        {isBusy ? (
                            <>🔒 Scan déjà en cours</>
                        ) : loading ? (
                            <>⏳ Démarrage du scan...</>
                        ) : (
                            <>
                                <Play size={18} /> 🚀 Lancer le Scan
                            </>
                        )}
                    </button>
                </div>
            </form>
        </div>
    );
}

export default ScanLauncherComponent;