import { logError } from "@/hooks/error_utils";
import { getToken, refreshToken } from "@/hooks/get_token";
import { 
    StartScanRequest,
    StartScanResponse,
    CancelScanRequest,
    CancelScanResponse,
    ScannerStatusResponse,
    ScanReportsResponse,
    HelpersListResponse,
    SupportedVulnsResponse,
    ValidateKnownParamDirResponse
} from "@/types/scanner/types";
import { 
    scStartScan,
    scCancelScan,
    scGetStatus,
    scGetReports,
    scGetDefaultConfig,
    scGetSupportedVulns,
    scGetHelpers,
    scValidateParamsDir
} from "@/hooks/fetch_functions";
import { useNavigate } from "react-router-dom";

// ============================================================================
// 1. DÉMARRER UN SCAN
// ============================================================================

export async function startScan(
    data: StartScanRequest,
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<StartScanResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const result = await scStartScan(data, getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as StartScanResponse;
            if (setResult) setResult(json);
            return json;
        }

        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await startScan(data, setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }

        if (setResult) setResult(null);
        setError(result.error);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans startScan : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ============================================================================
// 2. ANNULER UN SCAN EN COURS
// ============================================================================

export async function cancelScan(
    data: CancelScanRequest,
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<CancelScanResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const result = await scCancelScan(data, getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as CancelScanResponse;
            if (setResult) setResult(json);
            return json;
        }

        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await cancelScan(data, setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }

        if (setResult) setResult(null);
        setError(result.error);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans cancelScan : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ============================================================================
// 3. STATUT GLOBAL DU SCANNER
// ============================================================================

export async function getScannerStatus(
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<ScannerStatusResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const result = await scGetStatus(getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as ScannerStatusResponse;
            if (setResult) setResult(json);
            return json;
        }

        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getScannerStatus(setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }

        if (setResult) setResult(null);
        setError(result.error);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getScannerStatus : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ============================================================================
// 4. RÉCUPÉRER LES RAPPORTS GÉNÉRÉS D'UN SCAN
// ============================================================================

export async function getScanReports(
    scan_id: string,
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<ScanReportsResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const result = await scGetReports(scan_id, getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as ScanReportsResponse;
            if (setResult) setResult(json);
            return json;
        }

        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getScanReports(scan_id, setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }

        if (setResult) setResult(null);
        setError(result.error);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getScanReports : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ============================================================================
// 5. CATALOGUE DES HELPERS D'AUTHENTIFICATION
// ============================================================================

export async function getHelpersList(
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<HelpersListResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const result = await scGetHelpers(getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as HelpersListResponse;
            if (setResult) setResult(json);
            return json;
        }

        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getHelpersList(setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }

        if (setResult) setResult(null);
        setError(result.error);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getHelpersList : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ============================================================================
// 6. VULNÉRABILITÉS SUPPORTÉES & CONFIG PAR DÉFAUT
// ============================================================================

export async function getSupportedVulns(
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<SupportedVulnsResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const result = await scGetSupportedVulns(getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as SupportedVulnsResponse;
            if (setResult) setResult(json);
            return json;
        }

        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getSupportedVulns(setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }

        if (setResult) setResult(null);
        setError(result.error);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getSupportedVulns : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function getScannerDefaultConfig(
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<Record<string, any> | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const result = await scGetDefaultConfig(getToken());
        const json_ = result.response;
        if (result.ok) {
            if (setResult) setResult(json_);
            return json_;
        }

        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getScannerDefaultConfig(setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }

        if (setResult) setResult(null);
        setError(result.error);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getScannerDefaultConfig : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}