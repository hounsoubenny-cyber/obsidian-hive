import { useEffect, useRef, useState } from "react";
import "./scan_live.css";
import { useScannerWSStore } from "@/store/scanner_websocket_store";
import { cancelScan } from "../utils";
import { useNavigate } from "react-router-dom";
import { 
    Terminal, 
    Square, 
    Copy, 
    Trash2, 
    CheckCircle2, 
    RotateCw, 
    Eye, 
    AlertTriangle,
    ShieldCheck
} from "lucide-react";
import toast from "react-hot-toast";

interface ScanLiveProps {
    scanId: string | null;
    passPhrase: string;
    isScanning: boolean;
    onScanCompleted?: (result: any) => void;
    onViewResults?: () => void;
}

const PHASES = [
    "Crawl & Parse",
    "Passif",
    "Code Statique",
    "Fuzzer",
    "Features ML",
    "Inférence IA",
    "Rapport"
];

function ScanLiveComponent({ scanId, passPhrase, onScanCompleted, onViewResults }: ScanLiveProps) {
    const navigate = useNavigate();
    const { logs, scanInfos, scanResult, scanError, isScanning, isConnected, clearLogs } = useScannerWSStore();
    const terminalEndRef = useRef<HTMLDivElement>(null);
    const [autoScroll, setAutoScroll] = useState<boolean>(true);
    const [cancelling, setCancelling] = useState<boolean>(false);

    // Auto-scroll du terminal
    useEffect(() => {
        if (autoScroll) {
            terminalEndRef.current?.scrollIntoView({ behavior: "smooth" });
        }
    }, [logs, autoScroll]);

    // Détection de fin de scan
    useEffect(() => {
        if (scanResult && onScanCompleted) {
            onScanCompleted(scanResult);
            toast.success("🏁 Analyse terminée !");
        }
    }, [scanResult]);

    const handleCopyLogs = () => {
        navigator.clipboard.writeText(logs.join("\n"));
        toast.success("📋 Logs copiés dans le presse-papier !");
    };

    const handleCancel = async () => {
        if (!scanId || !passPhrase) return;
        setCancelling(true);
        const res = await cancelScan({ scan_id: scanId, pass_phrase: passPhrase }, null, () => {}, null, navigate);
        if (res && res.status === "cancelled") {
            toast("🛑 Demande d'annulation transmise", { icon: "⚠️" });
        }
        setCancelling(false);
    };

    // Calcul de la phase active selon les messages
    const currentPhaseIndex = Math.min(
        PHASES.length - 1,
        scanInfos.length > 0 ? Math.floor((scanInfos.length / 5) * PHASES.length) : 0
    );

    return (
        <div id="sclv-container" className="sclv-container">
            {/* Header */}
            <div className="sclv-header">
                <div>
                    <h2 className="sclv-header__title">
                        <Terminal size={24} /> ⚡ Console d'Exécution en Direct
                    </h2>
                    <div className="sclv-header__meta">
                        ID: {scanId || "Aucun scan actif"} • WebSocket:{" "}
                        <span style={{ color: isConnected ? "var(--success)" : "var(--danger)" }}>
                            {isConnected ? "Connecté" : "Déconnecté"}
                        </span>
                    </div>
                </div>

                <div style={{ display: "flex", gap: "10px" }}>
                    {isScanning && (
                        <button 
                            type="button" 
                            className="oh-btn oh-btn--ghost" 
                            style={{ color: "var(--danger)" }}
                            onClick={handleCancel}
                            disabled={cancelling}
                        >
                            <Square size={14} /> {cancelling ? "Annulation..." : "Stopper le scan"}
                        </button>
                    )}

                    {scanResult && onViewResults && (
                        <button type="button" className="oh-btn oh-btn--primary" onClick={onViewResults}>
                            <Eye size={16} /> Consulter le Rapport
                        </button>
                    )}
                </div>
            </div>

            {/* Stepper des Phases */}
            <div className="sclv-stepper">
                {PHASES.map((phase, idx) => {
                    const isDone = !isScanning && scanResult ? true : idx < currentPhaseIndex;
                    const isActive = isScanning && idx === currentPhaseIndex;

                    return (
                        <div
                            key={phase}
                            className={`sclv-step ${isActive ? "sclv-step--active" : ""} ${isDone ? "sclv-step--done" : ""}`}
                        >
                            <div className="sclv-step__icon">
                                {isDone ? "✓" : isActive ? <RotateCw size={12} className="oh-spin" /> : idx + 1}
                            </div>
                            <span className="sclv-step__label">{phase}</span>
                        </div>
                    );
                })}
            </div>

            {/* Bannière de Résultat Final */}
            {scanResult && (
                <div className="sclv-result-banner">
                    <div>
                        <h4 style={{ margin: "0 0 4px", fontSize: "1.1rem" }}>
                            🎉 Scan terminé avec succès !
                        </h4>
                        <div className="sclv-result-banner__stats">
                            <span className="sclv-result-banner__stat">
                                Cible : <strong>{scanResult.url}</strong>
                            </span>
                            <span className="sclv-result-banner__stat">
                                Pages : <strong>{scanResult.pages_crawled}</strong>
                            </span>
                            <span className="sclv-result-banner__stat">
                                Failles trouvées : <strong>{scanResult.total_vulns}</strong>
                            </span>
                            <span className="sclv-result-banner__stat">
                                Durée : <strong>{scanResult.elapsed.toFixed(1)}s</strong>
                            </span>
                        </div>
                    </div>

                    {onViewResults && (
                        <button type="button" className="oh-btn oh-btn--primary" onClick={onViewResults}>
                            📊 Voir les Résultats Détaillés
                        </button>
                    )}
                </div>
            )}

            {/* Terminal */}
            <div className="sclv-terminal">
                <div className="sclv-terminal__bar">
                    <div style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.8rem", color: "#9ca3af" }}>
                        <span style={{ width: 10, height: 10, borderRadius: "50%", background: isScanning ? "var(--success)" : "#4b5563" }} />
                        <span>Terminal Output ({logs.length} lignes)</span>
                    </div>

                    <div className="sclv-terminal__actions">
                        <label style={{ fontSize: "0.75rem", color: "#9ca3af", display: "flex", alignItems: "center", gap: "4px", cursor: "pointer" }}>
                            <input
                                type="checkbox"
                                checked={autoScroll}
                                onChange={(e) => setAutoScroll(e.target.checked)}
                            />
                            Auto-scroll
                        </label>
                        <button type="button" className="scl-btn-inline" onClick={handleCopyLogs}>
                            <Copy size={12} /> Copier
                        </button>
                        <button type="button" className="scl-btn-inline" onClick={clearLogs}>
                            <Trash2 size={12} /> Vider
                        </button>
                    </div>
                </div>

                <div className="sclv-terminal__body">
                    {logs.length === 0 ? (
                        <span style={{ color: "#6b7280" }}>En attente de démarrage ou de logs...</span>
                    ) : (
                        logs.map((log, i) => (
                            <div key={i} className="sclv-log-line">
                                <span style={{ color: "#4b5563", userSelect: "none" }}>&gt;</span>
                                <span>{log}</span>
                            </div>
                        ))
                    )}
                    <div ref={terminalEndRef} />
                </div>
            </div>
        </div>
    );
}

export default ScanLiveComponent;