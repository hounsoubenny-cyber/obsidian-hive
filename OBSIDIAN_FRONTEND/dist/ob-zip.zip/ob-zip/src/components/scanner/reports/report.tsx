import { useState, useEffect, useMemo } from "react";
import "./report.css";
import { ScanSummaryResult, ScanReportsResponse } from "@/types/scanner/types";
import { getScanReports } from "../utils";
import { useNavigate } from "react-router-dom";
import { 
    FileText, 
    Download, 
    ShieldAlert, 
    ExternalLink, 
    Play, 
    Bug,
    ShieldCheck,
    Sparkles,
    Copy,
    Check,
    RefreshCw,
    Layers,
    Trash2
} from "lucide-react";
import toast from "react-hot-toast";
import { AppConfig, getConfig } from "@/hooks/get_config";
import { scReportDirRoute } from "@/hooks/backend_routes";

// Rendu Markdown partagé
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { rehypePlugins, markdownComponents } from "@/components/utils/markdown_renderer/markdown_renderer";

interface ScanResultsProps {
    scanResult: ScanSummaryResult | null;
    onNewScan?: () => void;
    onGlobalReset?: () => void; 
}

function ScanResultsComponent({ scanResult, onNewScan, onGlobalReset }: ScanResultsProps) {
    const navigate = useNavigate();
    const [conf, setConf] = useState<AppConfig | null>(null);
    const [reports, setReports] = useState<ScanReportsResponse | null>(null);
    const [loadingReports, setLoadingReports] = useState<boolean>(false);
    
    // Onglet actif : "summary" (Synthèse) ou "llm" (Rapport IA)
    const [activeView, setActiveView] = useState<"summary" | "llm">("summary");

    // Contenu Markdown du rapport LLM
    const [llmMarkdown, setLlmMarkdown] = useState<string | null>(null);
    const [loadingLlm, setLoadingLlm] = useState<boolean>(false);
    const [copiedLlm, setCopiedLlm] = useState<boolean>(false);

    // 1. Chargement de la configuration
    useEffect(() => {
        getConfig().then(setConf);
    }, []);

    // 2. Récupération des chemins des rapports générés
    useEffect(() => {
        if (scanResult?.scan_id) {
            getScanReports(
                scanResult.scan_id,
                setReports,
                () => {},
                setLoadingReports,
                navigate
            );
        }
    }, [scanResult?.scan_id]);

    // 3. Construction des URLs des fichiers
    const getReportUrl = (filePath?: string): string => {
        if (!filePath || !conf?.apiBaseUrl) return "";
        const cleanPath = filePath.replace(/^\/?reports\//, "");
        const cleanRoute = scReportDirRoute.startsWith("/") ? scReportDirRoute.slice(1) : scReportDirRoute;
        return `${conf.apiBaseUrl}/${cleanRoute}/${cleanPath}`;
    };

    // 4. Téléchargement du contenu Markdown du rapport IA
    useEffect(() => {
        const llmPath = reports?.llm && reports.llm.length > 0 ? reports.llm[0] : null;
        if (llmPath && conf?.apiBaseUrl) {
            const url = getReportUrl(llmPath);
            if (url) {
                setLoadingLlm(true);
                fetch(url)
                    .then((r) => r.text())
                    .then((text) => setLlmMarkdown(text))
                    .catch((err) => console.error("Erreur chargement rapport LLM :", err))
                    .finally(() => setLoadingLlm(false));
            }
        }
    }, [reports?.llm, conf?.apiBaseUrl]);

    // 🔍 Validation stricte : True UNIQUEMENT si le LLM a réussi (pas de fallback)
    const isLlmValid = useMemo(() => {
        if (!llmMarkdown) return false;
        const normalized = llmMarkdown.trim();
        const isFallback = (
            normalized.startsWith("# Fallback LLM indisponible") ||
            normalized.includes("Fallback LLM indisponible") ||
            normalized.includes("⚠️ Erreur lors de la génération du rapport IA")
        );
        return !isFallback && normalized.length > 0;
    }, [llmMarkdown]);

    // Sécurité : si on était sur l'onglet LLM et qu'il s'avère invalide, on revient sur la synthèse
    useEffect(() => {
        if (!isLlmValid && activeView === "llm") {
            setActiveView("summary");
        }
    }, [isLlmValid, activeView]);

    // Copie du texte Markdown
    const handleCopyMarkdown = async () => {
        if (!llmMarkdown) return;
        try {
            await navigator.clipboard.writeText(llmMarkdown);
            setCopiedLlm(true);
            toast.success("📋 Rapport copié en Markdown !");
            setTimeout(() => setCopiedLlm(false), 1500);
        } catch {
            toast.error("Impossible de copier dans le presse-papier");
        }
    };

    const downloadFile = async (url: string, defaultFilename: string) => {
        try {
            const res = await fetch(url);
            const blob = await res.blob();
            const blobUrl = window.URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = blobUrl;
            a.download = defaultFilename;
            document.body.appendChild(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(blobUrl);
        } catch {
            // Fallback standard si fetch échoue
            window.open(url, "_blank");
        }
    };

    if (!scanResult) {
        return (
            <div className="apu-empty" style={{ padding: "60px 20px" }}>
                <ShieldAlert size={40} style={{ color: "var(--accent)" }} />
                <h3 style={{ margin: "12px 0 6px" }}>Aucun résultat de scan disponible</h3>
                <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>
                    Lancez une analyse depuis l'onglet "Lancer un Scan" pour afficher les résultats et rapports.
                </p>
                {onNewScan && (
                    <button type="button" className="oh-btn oh-btn--primary" style={{ marginTop: 12 }} onClick={onNewScan}>
                        <Play size={16} /> Lancer un scan
                    </button>
                )}
            </div>
        );
    }

    const totalVulns = scanResult.total_vulns || 0;
    const riskScore = Math.min(100, totalVulns * 15);
    const riskColor = riskScore > 60 ? "var(--danger)" : riskScore > 30 ? "var(--warning)" : "var(--success)";

    const htmlUrl = reports?.html && reports.html.length > 0 ? getReportUrl(reports.html[0]) : scanResult.report_paths?.html;
    const pdfUrl  = reports?.pdf && reports.pdf.length > 0   ? getReportUrl(reports.pdf[0])  : scanResult.report_paths?.pdf;
    const jsonUrl = reports?.json && reports.json.length > 0 ? getReportUrl(reports.json[0]) : scanResult.report_paths?.json;
    const llmUrl  = reports?.llm && reports.llm.length > 0   ? getReportUrl(reports.llm[0])  : scanResult.report_paths?.llm;

    return (
        <div id="scres-container" className="scres-container">
            {/* Header */}
            <div className="scres-header">
                <div className="scres-header__left">
                    <h2 className="scres-header__title">
                        <FileText size={24} /> 📊 Résultats & Rapports d'Analyse
                    </h2>
                    <p className="scres-header__subtitle">
                        Cible : <strong>{scanResult.url}</strong> • ID : <span style={{ fontFamily: "var(--font-mono)" }}>{scanResult.scan_id}</span>
                    </p>
                </div>

                
                {/* Boutons d'exportation */}
                <div className="scres-downloads">
                    {/* 1. Ouvrir le rapport HTML dans un nouvel onglet */}
                    {htmlUrl && (
                        <a href={htmlUrl} target="_blank" rel="noopener noreferrer" className="oh-btn oh-btn--primary">
                            <ExternalLink size={14} /> Voir le Rapport HTML
                        </a>
                    )}

                    {/* 2. Téléchargement garanti du PDF */}
                    {pdfUrl && (
                        <button 
                            type="button" 
                            className="oh-btn oh-btn--ghost" 
                            onClick={() => downloadFile(pdfUrl, `rapport_${scanResult.scan_id}.pdf`)}
                        >
                            <Download size={14} /> PDF
                        </button>
                    )}

                    {/* 3. Téléchargement garanti du JSON */}
                    {jsonUrl && (
                        <button 
                            type="button" 
                            className="oh-btn oh-btn--ghost" 
                            onClick={() => downloadFile(jsonUrl, `rapport_${scanResult.scan_id}.json`)}
                        >
                            <Download size={14} /> JSON
                        </button>
                    )}

                    {/* 4. Téléchargement garanti du Markdown */}
                    {llmUrl && isLlmValid && (
                        <button 
                            type="button" 
                            className="oh-btn oh-btn--ghost" 
                            onClick={() => downloadFile(llmUrl, `rapport_ia_${scanResult.scan_id}.md`)}
                            title="Télécharger le rapport rédigé par IA"
                        >
                            <Download size={14} /> Markdown (.md)
                        </button>
                    )}

                    {/* Bouton Effacer la session */}
                    {onGlobalReset && (
                        <button
                            type="button"
                            className="oh-btn oh-btn--ghost"
                            style={{ color: "var(--danger)" }}
                            onClick={onGlobalReset}
                            title="Effacer définitivement cette session et réinitialiser"
                        >
                            <Trash2 size={14} /> Effacer la session
                        </button>
                    )}
                </div>
            </div>

            {/* Bascule de Vue : affichée UNIQUEMENT si un vrai rapport LLM existe */}
            {isLlmValid && (
                <div className="scres-view-toggle">
                    <button
                        type="button"
                        className={`scres-view-btn ${activeView === "summary" ? "active" : ""}`}
                        onClick={() => setActiveView("summary")}
                    >
                        <Layers size={15} /> 📊 Synthèse & Vulnérabilités
                    </button>
                    <button
                        type="button"
                        className={`scres-view-btn ${activeView === "llm" ? "active" : ""}`}
                        onClick={() => setActiveView("llm")}
                    >
                        <Sparkles size={15} /> 🤖 Analyse Expert IA (LLM)
                    </button>
                </div>
            )}

            {/* ── VUE 1 : SYNTHÈSE & VULNÉRABILITÉS ──────────────────────────── */}
            {activeView === "summary" && (
                <>
                    {/* Jauge Exécutive */}
                    <div className="scres-summary-card">
                        <div className="scres-gauge">
                            <div className="scres-gauge__score" style={{ color: riskColor }}>
                                {riskScore}
                            </div>
                            <span className="scres-gauge__label" style={{ color: riskColor }}>
                                Score de Risque
                            </span>
                        </div>

                        <div className="scres-stats-grid">
                            <div className="scres-stat-box">
                                <span className="scres-stat-box__label">Pages Crawlées</span>
                                <span className="scres-stat-box__val">{scanResult.pages_crawled}</span>
                            </div>
                            <div className="scres-stat-box">
                                <span className="scres-stat-box__label">Vulnérabilités</span>
                                <span className="scres-stat-box__val" style={{ color: totalVulns > 0 ? "var(--danger)" : "var(--success)" }}>
                                    {totalVulns}
                                </span>
                            </div>
                            <div className="scres-stat-box">
                                <span className="scres-stat-box__label">Erreurs</span>
                                <span className="scres-stat-box__val">{scanResult.errors}</span>
                            </div>
                            <div className="scres-stat-box">
                                <span className="scres-stat-box__label">Temps d'exécution</span>
                                <span className="scres-stat-box__val">{scanResult.elapsed.toFixed(1)}s</span>
                            </div>
                        </div>

                        {onNewScan && (
                            <button type="button" className="oh-btn oh-btn--ghost" onClick={onNewScan}>
                                <Play size={14} /> Re-scanner
                            </button>
                        )}
                    </div>

                    {/* Liste des failles confirmées */}
                    <div className="scres-section">
                        <div className="scres-section__header">
                            <Bug size={18} />
                            <h3 className="scres-section__title">
                                Vulnérabilités Confirmées ({Object.keys(scanResult.vuln_count || {}).length} types)
                            </h3>
                        </div>

                        <div className="scres-vuln-list">
                            {Object.entries(scanResult.vuln_count || {}).length === 0 ? (
                                <div className="apu-empty" style={{ padding: "30px 20px" }}>
                                    <ShieldCheck size={32} style={{ color: "var(--success)" }} />
                                    <span>Aucune faille de sécurité critique n'a été détectée.</span>
                                </div>
                            ) : (
                                Object.entries(scanResult.vuln_count).map(([name, count]) => (
                                    <div key={name} className="scres-vuln-card">
                                        <div className="scres-vuln-card__top">
                                            <span className="scres-vuln-card__title">
                                                🔴 {name}
                                            </span>
                                            <span className="oh-badge oh-badge--danger">
                                                {count} occurrence{count > 1 ? "s" : ""}
                                            </span>
                                        </div>
                                        <div className="scres-vuln-card__desc">
                                            Vecteur d'attaque validé par injection dynamique et inférence multi-modèles.
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </>
            )}

            {/* ── VUE 2 : RAPPORT D'EXPERTISE IA (affiché uniquement si valide) ── */}
            {activeView === "llm" && isLlmValid && (
                <div className="scres-llm-card">
                    <div className="scres-llm-header">
                        <div className="scres-llm-title">
                            <Sparkles size={20} style={{ color: "var(--accent)" }} />
                            <span>Audit & Recommandations Cyber IA (Llama 3.3)</span>
                            <span className="scres-llm-badge">LLM Report</span>
                        </div>

                        <div style={{ display: "flex", gap: "8px" }}>
                            <button
                                type="button"
                                className="scl-btn-inline"
                                onClick={handleCopyMarkdown}
                                disabled={!llmMarkdown || loadingLlm}
                            >
                                {copiedLlm ? <Check size={14} /> : <Copy size={14} />}
                                {copiedLlm ? "Copié !" : "Copier Markdown"}
                            </button>
                        </div>
                    </div>

                    <div className="scres-llm-content">
                        {loadingLlm ? (
                            <div className="apu-empty" style={{ padding: "40px 20px" }}>
                                <RefreshCw size={24} className="oh-spin" />
                                <span>Chargement et mise en page du rapport IA...</span>
                            </div>
                        ) : (
                            <ReactMarkdown
                                remarkPlugins={[remarkGfm]}
                                rehypePlugins={rehypePlugins}
                                components={markdownComponents}
                            >
                                {llmMarkdown || ""}
                            </ReactMarkdown>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}

export default ScanResultsComponent;