import React, { useState, useEffect } from "react";
import "./add_job_modal.css";
import { AddJobRequest, JobCatalogEntry, TriggerSpec } from "@/types/jobs/types";
import { createJob as _createJob } from "@/hooks/fetch_functions";
import { useNavigate } from "react-router-dom";
import { getToken, refreshToken } from "@/hooks/get_token";
import { logError } from "@/hooks/error_utils";
import {
  Clock,
  X,
  Plus,
  Terminal,
  Sparkles,
} from "lucide-react";
import toast from "react-hot-toast";

async function createJob(
  data: AddJobRequest,
  setError: Function,
  setLoading: ((v: boolean) => void) | null = null,
  navigate: ReturnType<typeof useNavigate>
): Promise<boolean> {
  try {
    if (setLoading) setLoading(true);
    const result = await _createJob(data, getToken());
    if (result.ok) return true;

    const json = result.response as Record<string, any>;
    if (json?.detail === "TOKEN_EXPIRED") {
      const refreshed = await refreshToken(getToken(), navigate);
      if (refreshed) return await createJob(data, setError, setLoading, navigate);
      throw new Error("Session expirée");
    }
    setError(result.error || "Erreur lors de la planification du job");
    return false;
  } catch (err) {
    const msg = logError(err);
    setError(msg);
    return false;
  } finally {
    if (setLoading) setLoading(false);
  }
}

// Générateurs de champs Cron
const getYearOptions = () => ["*", ...Array.from({ length: 6 }, (_, i) => String(new Date().getFullYear() + i))];
const getMonthOptions = () => [
  "*", "1 (Jan)", "2 (Fév)", "3 (Mar)", "4 (Avr)", "5 (Mai)", "6 (Juin)",
  "7 (Juil)", "8 (Août)", "9 (Sep)", "10 (Oct)", "11 (Nov)", "12 (Déc)"
];
const getDayOptions = () => ["*", ...Array.from({ length: 31 }, (_, i) => String(i + 1))];
const getWeekOptions = () => ["*", ...Array.from({ length: 53 }, (_, i) => String(i + 1))];
const getDayOfWeekOptions = () => [
  "*", "0 (Dim)", "1 (Lun)", "2 (Mar)", "3 (Mer)", "4 (Jeu)", "5 (Ven)", "6 (Sam)",
  "mon-fri", "sat-sun", "mon", "tue", "wed", "thu", "fri", "sat", "sun"
];
const getHourOptions = () => ["*", ...Array.from({ length: 24 }, (_, i) => String(i))];
const getMinuteOptions = () => ["*", ...Array.from({ length: 60 }, (_, i) => String(i))];
const getSecondOptions = () => ["*", ...Array.from({ length: 60 }, (_, i) => String(i))];

function JobCatPreview({ jobCatalogEntry }: { jobCatalogEntry: JobCatalogEntry }) {
  return (
    <div className="jb_modal_cat_preview">
      <div className="jb_modal_cat_preview_header">
        <span className="jb_modal_cat_preview_name oh-mono">{jobCatalogEntry.job_name}</span>
        <span className={`oh-badge oh-badge--${jobCatalogEntry.risk === "high" ? "danger" : "accent"}`}>
          {jobCatalogEntry.risk || "standard"}
        </span>
      </div>
      <div className="jb_modal_cat_preview_desc">{jobCatalogEntry.description}</div>
    </div>
  );
}

function JobCatDetail({
  jobCatalogEntry,
  onDeselect,
  navigate,
  onJobCreated,
}: {
  jobCatalogEntry: JobCatalogEntry;
  onDeselect: () => void;
  navigate: ReturnType<typeof useNavigate>;
  onJobCreated: () => void;
}) {
  const [useDefaultTrigger, setUseDefaultTrigger] = useState<boolean>(true);
  const [triggerType, setTriggerType] = useState<"cron" | "date" | "interval" | "calendarinterval">("cron");
  const [customTrigger, setCustomTrigger] = useState<Record<string, any>>({});
  const [jobId, setJobId] = useState<string>("");
  const [inMemory, setInMemory] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>("");

  useEffect(() => {
    setCustomTrigger({ ...jobCatalogEntry.default_trigger });
    setUseDefaultTrigger(true);
    setError("");
    setJobId(`${jobCatalogEntry.job_name}_${Date.now().toString().slice(-5)}`);
  }, [jobCatalogEntry]);

  const handleSubmit = async () => {
    if (!jobId.trim()) {
      setError("Veuillez définir un identifiant unique.");
      return;
    }

    const trigger = useDefaultTrigger
      ? (jobCatalogEntry.default_trigger as TriggerSpec)
      : ({ type: triggerType, ...customTrigger } as TriggerSpec);

    const requestData: AddJobRequest = {
      job_name: jobCatalogEntry.job_name,
      job_id: jobId.trim(),
      trigger,
      kwargs: jobCatalogEntry.default_kwargs as Record<string, unknown>,
      in_memory: inMemory,
    };

    setLoading(true);
    setError("");
    try {
      const ok = await createJob(requestData, setError, setLoading, navigate);
      if (ok) {
        toast.success("✅ Tâche planifiée avec succès !");
        onJobCreated();
      }
    } finally {
      setLoading(false);
    }
  };

  const renderTriggerFields = () => {
    if (triggerType === "cron") {
      const fields = [
        { key: "year", label: "Année", opts: getYearOptions() },
        { key: "month", label: "Mois", opts: getMonthOptions() },
        { key: "day", label: "Jour", opts: getDayOptions() },
        { key: "week", label: "Semaine", opts: getWeekOptions() },
        { key: "day_of_week", label: "Jour Semaine", opts: getDayOfWeekOptions() },
        { key: "hour", label: "Heure", opts: getHourOptions() },
        { key: "minute", label: "Minute", opts: getMinuteOptions() },
        { key: "second", label: "Seconde", opts: getSecondOptions() },
      ];
      return fields.map((f) => (
        <div key={f.key} className="jb_trigger_input_box">
          <label>{f.label}</label>
          <select
            className="jb_modal_select"
            value={String(customTrigger[f.key] ?? "*")}
            onChange={(e) => setCustomTrigger((prev) => ({ ...prev, [f.key]: e.target.value }))}
          >
            {f.opts.map((opt) => (
              <option key={opt} value={opt.includes(" ") ? opt.split(" ")[0] : opt}>
                {opt}
              </option>
            ))}
          </select>
        </div>
      ));
    }

    if (triggerType === "date") {
      return (
        <div className="jb_trigger_input_box" style={{ gridColumn: "1 / -1" }}>
          <label>Date/heure d'exécution unique</label>
          <input
            type="datetime-local"
            className="jb_modal_input"
            value={String(customTrigger.run_date || "")}
            onChange={(e) => setCustomTrigger((prev) => ({ ...prev, run_date: e.target.value }))}
          />
        </div>
      );
    }

    if (triggerType === "interval") {
      const fields = [
        { key: "weeks", label: "Semaines" },
        { key: "days", label: "Jours" },
        { key: "hours", label: "Heures" },
        { key: "minutes", label: "Minutes" },
        { key: "seconds", label: "Secondes" },
      ];
      return fields.map((f) => (
        <div key={f.key} className="jb_trigger_input_box">
          <label>{f.label}</label>
          <input
            type="number"
            className="jb_modal_input"
            min={0}
            value={Number(customTrigger[f.key] ?? 0)}
            onChange={(e) =>
              setCustomTrigger((prev) => ({ ...prev, [f.key]: parseInt(e.target.value, 10) || 0 }))
            }
          />
        </div>
      ));
    }

    return null;
  };

  return (
    <div className="jb_modal_detail">
      <div className="jb_modal_detail_header">
        <h3 className="jb_modal_detail_title oh-mono">{jobCatalogEntry.job_name}</h3>
        <button type="button" className="oh-btn oh-btn--ghost jb_modal_btn_icon" onClick={onDeselect}>
          <X size={14} />
        </button>
      </div>

      <p className="jb_modal_detail_desc">{jobCatalogEntry.description}</p>

      {/* ID */}
      <div className="jb_modal_form_group">
        <label>🆔 Identifiant de la tâche planifiée</label>
        <input
          type="text"
          className="jb_modal_input"
          value={jobId}
          onChange={(e) => setJobId(e.target.value)}
          placeholder="ex: cleanup_weekly_001"
        />
      </div>

      {/* Trigger */}
      <div className="jb_modal_section">
        <label className="jb_modal_section_label">⏰ Configuration du Trigger</label>
        <div className="jb_modal_toggle_group">
          <button
            type="button"
            className={`jb_modal_toggle_btn ${useDefaultTrigger ? "is-active" : ""}`}
            onClick={() => setUseDefaultTrigger(true)}
          >
            ✅ Par défaut
          </button>
          <button
            type="button"
            className={`jb_modal_toggle_btn ${!useDefaultTrigger ? "is-active" : ""}`}
            onClick={() => setUseDefaultTrigger(false)}
          >
            🛠️ Personnalisé
          </button>
        </div>

        {useDefaultTrigger ? (
          <div className="jb_modal_default_trigger oh-mono">
            <code>{JSON.stringify(jobCatalogEntry.default_trigger, null, 2)}</code>
          </div>
        ) : (
          <div className="jb_modal_custom_trigger">
            <select
              className="jb_modal_select"
              value={triggerType}
              onChange={(e) => setTriggerType(e.target.value as any)}
            >
              <option value="cron">⏰ Cron (Calendrier)</option>
              <option value="date">📅 Date (Exécution unique)</option>
              <option value="interval">🔄 Intervalle fixe</option>
            </select>
            <div className="jb_modal_trigger_fields">{renderTriggerFields()}</div>
          </div>
        )}
      </div>

      {/* Jobstore */}
      <div className="jb_modal_form_group">
        <label>💾 Jobstore cible</label>
        <select
          className="jb_modal_select"
          value={inMemory ? "memory" : "persistent"}
          onChange={(e) => setInMemory(e.target.value === "memory")}
        >
          <option value="persistent">💾 Persistant (SQLite)</option>
          <option value="memory">🧠 Mémoire (Volatile)</option>
        </select>
      </div>

      {error && <div className="jb_modal_error">{error}</div>}

      <div className="jb_modal_detail_actions">
        <button
          type="button"
          className="oh-btn oh-btn--primary jb_btn_submit"
          onClick={handleSubmit}
          disabled={loading}
        >
          {loading ? "Planification..." : "✅ Planifier cette tâche"}
        </button>
      </div>
    </div>
  );
}

export function AddJobModal({
  jobCatalog,
  naviguate,
  setShowModal,
  onJobCreated,
}: {
  jobCatalog: JobCatalogEntry[];
  naviguate: ReturnType<typeof useNavigate>;
  setShowModal: (val: boolean) => void;
  onJobCreated: () => void;
}) {
  const [selectedEntry, setSelectedEntry] = useState<JobCatalogEntry | null>(null);

  const close = () => setShowModal(false);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
    };
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, []);

  return (
    <div className="jb_modal_overlay" onClick={close}>
      <div className="jb_modal_container" onClick={(e) => e.stopPropagation()}>
        <header className="jb_modal_header">
          <div className="jb_modal_header__title">
            <Sparkles size={18} color="var(--accent)" />
            <h2>Planifier une Tâche depuis le Catalogue</h2>
          </div>
          <button type="button" className="jb_modal_close" onClick={close}>
            <X size={16} />
          </button>
        </header>

        <div className="jb_modal_body">
          {/* Colonne Gauche : Catalogue */}
          <aside className="jb_modal_list">
            <span className="jb_modal_list_title">Catalogue des Tâches ({jobCatalog.length})</span>
            {jobCatalog.length === 0 ? (
              <div className="jb_modal_empty">Aucun job disponible</div>
            ) : (
              jobCatalog.map((job, idx) => (
                <div
                  key={idx}
                  className={`jb_modal_list_item ${
                    selectedEntry?.job_name === job.job_name ? "selected" : ""
                  }`}
                  onClick={() => setSelectedEntry(job)}
                >
                  <JobCatPreview jobCatalogEntry={job} />
                </div>
              ))
            )}
          </aside>

          {/* Colonne Droite : Configuration */}
          <section className="jb_modal_detail_wrapper">
            {selectedEntry ? (
              <JobCatDetail
                jobCatalogEntry={selectedEntry}
                onDeselect={() => setSelectedEntry(null)}
                navigate={naviguate}
                onJobCreated={() => {
                  onJobCreated();
                  close();
                }}
              />
            ) : (
              <div className="jb_modal_empty_detail">
                <Clock size={36} />
                <p>Sélectionnez un job dans le catalogue pour paramétrer son trigger et le planifier.</p>
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}

export default AddJobModal;