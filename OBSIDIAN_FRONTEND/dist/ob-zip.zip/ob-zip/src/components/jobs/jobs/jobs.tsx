import "./jobs.css";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { useState, useEffect, useMemo, useCallback } from "react";
import { isLogin, getToken } from "@/hooks/get_token";
import AddJobModal from "../add_job_modal/add_job_modal";
import { Job, JobCatalogEntry, JobState } from "@/types/jobs/types";
import { 
  getJobCatalog,
  listJob,
  filterJobs as _filterJobs,
  getJob,
  pauseJob,
  resumeJob,
  removeJob,
  modifyJobName,
  pauseAllJobs,
  resumeAllJobs,
  removeAllJobs
} from "./utils";
import { JobPreview, JobDetail } from "./job_componant_utils";
import { ConfirmModal } from "@/components/utils/confirm_modal/confirm_modal";
import toast from "react-hot-toast";
import {
  Plus,
  RefreshCw,
  Search,
  SlidersHorizontal,
  ListFilter,
  FileText,
  Lock,
  Zap,
  Pause,
  Play,
  Trash2,
  TriangleAlert,
} from "lucide-react";

export function JobPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const jobIdFromUrl = searchParams.get("job_id");

  // ── Données ──
  const [jobCatalog, setJobCatalog] = useState<JobCatalogEntry[] | null>(null);
  const [jobCatalogError, setJobCatalogError] = useState<string>("");
  const [jobCatalogLoading, setJobCatalogLoading] = useState<boolean>(false);

  const [jobList, setJobList] = useState<Job[] | null>(null);
  const [jobListCopy, setJobListCopy] = useState<Job[] | null>(null);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [jobListError, setJobListError] = useState<string>("");
  const [jobListLoading, setJobListLoading] = useState<boolean>(false);
  const [actionLoading, setActionLoading] = useState<Record<string, boolean>>({});

  // ── Filtres ──
  const [idFilter, setIdFilter] = useState<string>("");
  const [idSearchMode, setIdSearchMode] = useState<"partial" | "exact">("partial");
  const [pendingFilter, setPendingFilter] = useState<boolean | null>(null);
  const [jobstoreFilter, setJobstoreFilter] = useState<"memory" | "persistent" | "all" | null>("all");
  const [stateFilter, setStateFilter] = useState<JobState | null>(null);
  const [autoFilter, setAutoFilter] = useState<boolean>(true);

  // ── Pagination & Limites ──
  const [listLimit, setListLimit] = useState<number>(6);
  const [localListLimit, setLocalListLimit] = useState<number>(6);
  const [listShowAll, setListShowAll] = useState<boolean>(false);
  const [searchLimit] = useState<number>(4);
  const [searchShowAll, setSearchShowAll] = useState<boolean>(false);

  // ── Toggles des 4 Sections ──
  const [showSearchBar, setShowSearchBar] = useState<boolean>(true);
  const [showFilters, setShowFilters] = useState<boolean>(true);
  const [showList, setShowList] = useState<boolean>(true);
  const [showDetail, setShowDetail] = useState<boolean>(true);

  // ── Recherche ──
  const [searchJobInput, setSearchJobInput] = useState<string>("");
  const [searchInMemory, setSearchInMemory] = useState<boolean | null>(null);
  const [searchJobResult, setSearchJobResult] = useState<Job[] | null>(null);
  const [searchJobError, setSearchJobError] = useState<string>("");
  const [searchJobLoading, setSearchJobLoading] = useState<boolean>(false);

  // ── Rechargement & Actions Groupées ──
  const [isReloading, setIsReloading] = useState<boolean>(false);
  const [bulkOpsInMemory, setBulkOpsInMemory] = useState<boolean | null>(null);
  const [bulkLoading, setBulkLoading] = useState<boolean>(false);

  // ── Modales ──
  const [showAddJobModal, setShowAddJobModal] = useState<boolean>(false);
  const [bulkPauseModal, setBulkPauseModal] = useState<boolean>(false);
  const [bulkResumeModal, setBulkResumeModal] = useState<boolean>(false);
  const [bulkDeleteModal, setBulkDeleteModal] = useState<boolean>(false);
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);

  // ── Édition Nom ──
  const [editingJobId, setEditingJobId] = useState<string | null>(null);
  const [newJobName, setNewJobName] = useState<string>("");
  const [modifyNameLoading, setModifyNameLoading] = useState<boolean>(false);
  const [modifyNameError, setModifyNameError] = useState<string>("");

  // Chargement initial
  const reload = useCallback(async () => {
    setIsReloading(true);
    await Promise.allSettled([
      getJobCatalog([setJobCatalog], setJobCatalogError, setJobCatalogLoading, navigate),
      listJob(null, [setJobList, setJobListCopy], setJobListError, setJobListLoading, navigate),
    ]);
    setIsReloading(false);
  }, [navigate]);

  useEffect(() => {
    reload();
  }, [reload]);

  useEffect(() => {
    if (jobList && jobIdFromUrl) {
      const found = jobList.find((j) => j.id === jobIdFromUrl);
      if (found) setSelectedJob(found);
    }
  }, [jobList, jobIdFromUrl]);

  // Filtrage combiné
  const filterJobs = useCallback(() => {
    const filtered = _filterJobs(
      jobListCopy || [],
      idFilter,
      idSearchMode,
      pendingFilter,
      jobstoreFilter,
      stateFilter
    );
    setJobList(filtered);
  }, [jobListCopy, idFilter, idSearchMode, pendingFilter, jobstoreFilter, stateFilter]);

  const resetFilters = () => {
    setIdFilter("");
    setIdSearchMode("partial");
    setPendingFilter(null);
    setJobstoreFilter("all");
    setStateFilter(null);
    setJobList(jobListCopy ? [...jobListCopy] : []);
  };

  useEffect(() => {
    if (autoFilter) filterJobs();
  }, [autoFilter, filterJobs]);

  // Recherche API
  const handleSearch = async () => {
    if (!searchJobInput.trim()) {
      setSearchJobResult(null);
      return;
    }
    await getJob(
      searchJobInput.trim(),
      searchInMemory,
      [setSearchJobResult],
      setSearchJobError,
      setSearchJobLoading,
      navigate
    );
  };

  // Application de la limite par lot
  const handleApplyLimit = (val: number) => {
    const cleanVal = isNaN(val) || val < 1 ? 1 : Math.min(val, 500);
    setLocalListLimit(cleanVal);
    setListLimit(cleanVal);
  };

  // Actions Unitaires
  const handlePause = async (id: string) => {
    setActionLoading((prev) => ({ ...prev, [id]: true }));
    try {
      const result = await pauseJob(id, null, () => {}, null, navigate);
      if (result?.success) {
        toast.success("Tâche mise en pause");
        await reload();
      } else {
        toast.error(`Échec : ${result?.error}`);
      }
    } finally {
      setActionLoading((prev) => ({ ...prev, [id]: false }));
    }
  };

  const handleResume = async (id: string) => {
    setActionLoading((prev) => ({ ...prev, [id]: true }));
    try {
      const result = await resumeJob(id, null, () => {}, null, navigate);
      if (result?.success) {
        toast.success("Tâche reprise");
        await reload();
      } else {
        toast.error(`Échec : ${result?.error}`);
      }
    } finally {
      setActionLoading((prev) => ({ ...prev, [id]: false }));
    }
  };

  const confirmDeleteJob = async () => {
    if (!deleteTargetId) return;
    const id = deleteTargetId;
    setDeleteTargetId(null);
    setActionLoading((prev) => ({ ...prev, [id]: true }));
    try {
      const result = await removeJob(id, null, () => {}, null, navigate);
      if (result?.success) {
        toast.success("Tâche supprimée");
        if (selectedJob?.id === id) handleDeselect();
        if (searchJobResult) {
          setSearchJobResult((prev) => (prev ? prev.filter((j) => j.id !== id) : null));
        }
        await reload();
      } else {
        toast.error(`Échec : ${result?.error}`);
      }
    } finally {
      setActionLoading((prev) => ({ ...prev, [id]: false }));
    }
  };

  // Actions Groupées
  const executeBulkPause = async () => {
    setBulkPauseModal(false);
    setBulkLoading(true);
    try {
      const result = await pauseAllJobs(bulkOpsInMemory, () => {}, null, navigate);
      if (result?.success) {
        toast.success("⏸️ Toutes les tâches ont été suspendues");
        await reload();
      }
    } finally {
      setBulkLoading(false);
    }
  };

  const executeBulkResume = async () => {
    setBulkResumeModal(false);
    setBulkLoading(true);
    try {
      const result = await resumeAllJobs(bulkOpsInMemory, () => {}, null, navigate);
      if (result?.success) {
        toast.success("▶️ Toutes les tâches ont été relancées");
        await reload();
      }
    } finally {
      setBulkLoading(false);
    }
  };

  const executeBulkDelete = async () => {
    setBulkDeleteModal(false);
    setBulkLoading(true);
    try {
      const result = await removeAllJobs(bulkOpsInMemory, () => {}, null, navigate);
      if (result?.success) {
        toast.success("🗑️ Toutes les tâches ont été supprimées");
        setSelectedJob(null);
        await reload();
      }
    } finally {
      setBulkLoading(false);
    }
  };

  // Édition Nom
  const startEditName = (job: Job) => {
    setEditingJobId(job.id);
    setNewJobName(job.name || job.id);
    setModifyNameError("");
  };

  const cancelEditName = () => {
    setEditingJobId(null);
    setNewJobName("");
    setModifyNameError("");
  };

  const confirmEditName = async (jobId: string, inMemory: boolean | null) => {
    if (!newJobName.trim()) {
      setModifyNameError("Le nom ne peut pas être vide.");
      return;
    }
    const success = await modifyJobName(
      jobId,
      newJobName.trim(),
      inMemory,
      setModifyNameError,
      setModifyNameLoading,
      navigate
    );
    if (success) {
      toast.success("Nom mis à jour");
      setEditingJobId(null);
      setNewJobName("");
      await reload();
    }
  };

  const handleSelectJob = (job: Job) => {
    setSelectedJob(job);
    setSearchParams(
      (prev) => {
        prev.set("job_id", job.id);
        return prev;
      },
      { replace: true }
    );
  };

  const handleDeselect = () => {
    setSelectedJob(null);
    setSearchParams(
      (prev) => {
        prev.delete("job_id");
        return prev;
      },
      { replace: true }
    );
  };

  const totalJobs = jobListCopy?.length || 0;
  const totalFiltered = jobList?.length || 0;
  const totalSearchResults = searchJobResult?.length || 0;

  const displayedJobs = useMemo(() => {
    const list = jobList || [];
    if (listShowAll) return list;
    return list.slice(0, listLimit);
  }, [jobList, listShowAll, listLimit]);

  const displayedSearchResults = useMemo(() => {
    if (!searchJobResult) return [];
    if (searchShowAll) return searchJobResult;
    return searchJobResult.slice(0, searchLimit);
  }, [searchJobResult, searchShowAll, searchLimit]);

  const gridLayoutClass = useMemo(() => {
    const activeCount = [showFilters, showList, showDetail].filter(Boolean).length;
    if (activeCount === 3) return "jb_layout_3cols";
    if (activeCount === 2) {
      if (showFilters && showList) return "jb_layout_filters_list";
      if (showList && showDetail) return "jb_layout_list_detail";
      if (showFilters && showDetail) return "jb_layout_filters_detail";
    }
    return "jb_layout_1col";
  }, [showFilters, showList, showDetail]);

  if (!isLogin()) {
    return (
      <div id="jb_page_locked" className="jb_page_locked">
        <div className="grid-dots" />
        <div className="jb_not_authenticated">
          <Lock size={26} className="jb_not_authenticated_icon" />
          <h2>Accès restreint</h2>
          <p>
            Veuillez d'abord vous connecter à la <Link to="/login">page de connexion</Link>.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div id="jb_page" className="jb_page">
      {/* ── 1. TOOLBAR SUPÉRIEURE ── */}
      <header id="jb_toolbar" className="jb_toolbar">
        <div className="jb_toolbar_title_group">
          <h1>Planificateur de Tâches</h1>
          <span className="jb_toolbar_count_badge">
            {totalFiltered} / {totalJobs}
          </span>
        </div>

        <div className="jb_toolbar_actions">
          {/* Sélecteur de Portée */}
          <div className="jb_scope_pill">
            <label>Portée :</label>
            <select
              value={bulkOpsInMemory === null ? "all" : bulkOpsInMemory ? "memory" : "persistent"}
              onChange={(e) => {
                const val = e.target.value;
                if (val === "all") setBulkOpsInMemory(null);
                else if (val === "memory") setBulkOpsInMemory(true);
                else setBulkOpsInMemory(false);
              }}
            >
              <option value="all">🌐 Tous</option>
              <option value="memory">🧠 Mémoire</option>
              <option value="persistent">💾 Persistant</option>
            </select>
          </div>

          <button
            type="button"
            className="oh-btn oh-btn--ghost jb_btn_toolbar_warning"
            onClick={() => setBulkPauseModal(true)}
            disabled={bulkLoading || totalJobs === 0}
            title="Mettre en pause toutes les tâches de la portée"
          >
            <Pause size={14} /> Tout suspendre
          </button>

          <button
            type="button"
            className="oh-btn oh-btn--ghost jb_btn_toolbar_success"
            onClick={() => setBulkResumeModal(true)}
            disabled={bulkLoading || totalJobs === 0}
            title="Reprendre toutes les tâches de la portée"
          >
            <Play size={14} /> Tout relancer
          </button>

          <button
            type="button"
            className="oh-btn oh-btn--ghost jb_btn_toolbar_danger"
            onClick={() => setBulkDeleteModal(true)}
            disabled={bulkLoading || totalJobs === 0}
            title="Supprimer toutes les tâches de la portée"
          >
            <Trash2 size={14} /> Tout supprimer
          </button>

          <button
            type="button"
            className="oh-btn oh-btn--primary"
            onClick={() => setShowAddJobModal(true)}
          >
            <Plus size={16} /> Ajouter un job
          </button>

          <button
            type="button"
            className="oh-btn oh-btn--ghost"
            onClick={reload}
            disabled={isReloading}
            title="Actualiser la liste"
          >
            <RefreshCw size={14} className={isReloading ? "oh-spin" : ""} /> Actualiser
          </button>
        </div>
      </header>

      {/* ── 2. TOGGLES DES 4 SECTIONS ── */}
      <div id="jb_section_toggles" className="jb_section_toggles">
        <button
          type="button"
          className={`jb_btn_toggle_section ${showSearchBar ? "is-active" : ""}`}
          onClick={() => setShowSearchBar(!showSearchBar)}
        >
          <Search size={14} /> Recherche
        </button>
        <button
          type="button"
          className={`jb_btn_toggle_section ${showFilters ? "is-active" : ""}`}
          onClick={() => setShowFilters(!showFilters)}
        >
          <SlidersHorizontal size={14} /> Filtres
        </button>
        <button
          type="button"
          className={`jb_btn_toggle_section ${showList ? "is-active" : ""}`}
          onClick={() => setShowList(!showList)}
        >
          <ListFilter size={14} /> Liste ({totalFiltered})
        </button>
        <button
          type="button"
          className={`jb_btn_toggle_section ${showDetail ? "is-active" : ""}`}
          onClick={() => setShowDetail(!showDetail)}
        >
          <FileText size={14} /> Détails
        </button>
      </div>

      {/* ── 3. BARRE DE RECHERCHE AVANCÉE ── */}
      {showSearchBar && (
        <div id="jb_search_bar" className="jb_search_bar">
          <div className="jb_search_input_group">
            <label>Recherche par identifiant</label>
            <input
              id="jb_search_input"
              className="jb_search_input"
              value={searchJobInput}
              onChange={(e) => setSearchJobInput(e.target.value)}
              placeholder="ex : cleanup_1, daily_scan..."
              type="text"
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              disabled={searchJobLoading}
            />
          </div>

          <div className="jb_search_toggle_group">
            <label>Jobstore cible</label>
            <select
              className="jb_search_select"
              value={searchInMemory === null ? "all" : searchInMemory ? "memory" : "persistent"}
              onChange={(e) => {
                const val = e.target.value;
                if (val === "all") setSearchInMemory(null);
                else if (val === "memory") setSearchInMemory(true);
                else setSearchInMemory(false);
              }}
            >
              <option value="all">🌐 Tous</option>
              <option value="memory">🧠 Mémoire</option>
              <option value="persistent">💾 Persistant</option>
            </select>
          </div>

          <button
            type="button"
            className="oh-btn oh-btn--primary jb_btn_search"
            onClick={handleSearch}
            disabled={searchJobLoading}
          >
            <Search size={15} />
            {searchJobLoading ? "Recherche..." : "Rechercher"}
          </button>

          {searchJobError && (
            <p className="jb_search_error_text">
              <TriangleAlert size={13} /> {searchJobError}
            </p>
          )}

          {/* Résultats de recherche intégrés */}
          {searchJobResult !== null && (
            <div className="jb_search_results">
              <div className="jb_search_results_header">
                <span className="jb_search_results_count">
                  {totalSearchResults} résultat{totalSearchResults > 1 ? "s" : ""}
                </span>
                <button
                  type="button"
                  className="oh-btn oh-btn--ghost jb_btn_close_search"
                  onClick={() => setSearchJobResult(null)}
                >
                  ✕ Fermer recherche
                </button>
              </div>

              {searchJobResult.length === 0 ? (
                <div className="jb_empty_state">Aucune tâche trouvée</div>
              ) : (
                <>
                  <div className="jb_search_results_grid">
                    {displayedSearchResults.map((job) => (
                      <JobPreview
                        key={`search-${job.id}`}
                        job={job}
                        selected={selectedJob?.id === job.id}
                        onSelect={() => handleSelectJob(job)}
                        onPause={handlePause}
                        onResume={handleResume}
                        onDelete={(id) => setDeleteTargetId(id)}
                        isActionLoading={(id) => Boolean(actionLoading[id])}
                      />
                    ))}
                  </div>

                  {totalSearchResults > searchLimit && (
                    <div className="jb_see_more_controls">
                      <button
                        type="button"
                        onClick={() => setSearchShowAll(!searchShowAll)}
                        className="jb_btn_see_more"
                      >
                        {searchShowAll ? "Voir moins" : `Voir tout (${totalSearchResults})`}
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      )}

      {/* ── 4. CORPS PRINCIPAL : GRILLE 3 COLONNES DYNAMIQUE ── */}
      <div className={`jb_main_content ${gridLayoutClass}`}>
        {/* COLONNE 1 : FILTRES */}
        {showFilters && (
          <aside id="jb_filters_panel" className="jb_filters_panel">
            <h3>
              <SlidersHorizontal size={15} /> Filtres
            </h3>

            {/* Auto-filtre avec Statut visible */}
            <div className="jb_filter_group jb_auto_filter_box">
              <div className="jb_auto_filter_info">
                <label className="jb_auto_filter_label">
                  <Zap size={13} /> Auto-filtre
                </label>
                <span className={`jb_auto_filter_badge ${autoFilter ? "is-live" : "is-manual"}`}>
                  {autoFilter ? "⚡ En direct" : "🖐️ Manuel"}
                </span>
              </div>
              <button
                type="button"
                className={`jb_toggle_switch ${autoFilter ? "is-on" : ""}`}
                onClick={() => setAutoFilter(!autoFilter)}
                title="Filtrer automatiquement à chaque changement"
              >
                <span className="jb_toggle_knob" />
              </button>
            </div>

            {/* ID + Mode Partiel / Exact */}
            <div className="jb_filter_group">
              <label>Identifiant (ID)</label>
              <input
                className="jb_filter_input"
                value={idFilter}
                onChange={(e) => setIdFilter(e.target.value)}
                placeholder="ex : cleanup, daily..."
                type="text"
              />
              <div className="jb_filter_mode_toggle">
                <button
                  type="button"
                  className={`jb_btn_mode ${idSearchMode === "partial" ? "active" : ""}`}
                  onClick={() => setIdSearchMode("partial")}
                >
                  🔍 Partiel
                </button>
                <button
                  type="button"
                  className={`jb_btn_mode ${idSearchMode === "exact" ? "active" : ""}`}
                  onClick={() => setIdSearchMode("exact")}
                >
                  🎯 Exact
                </button>
              </div>
            </div>

            {/* État */}
            <div className="jb_filter_group">
              <label>État d'exécution</label>
              <select
                className="jb_select"
                value={stateFilter || ""}
                onChange={(e) => setStateFilter(e.target.value ? (e.target.value as JobState) : null)}
              >
                <option value="">Tous les états</option>
                <option value="running">▶️ En cours (Actif)</option>
                <option value="paused">⏸️ En pause</option>
                <option value="pending">⏳ En attente</option>
              </select>
            </div>

            {/* Jobstore */}
            <div className="jb_filter_group">
              <label>Type de Jobstore</label>
              <select
                className="jb_select"
                value={jobstoreFilter || "all"}
                onChange={(e) =>
                  setJobstoreFilter(e.target.value as "memory" | "persistent" | "all")
                }
              >
                <option value="all">🌐 Tous</option>
                <option value="memory">🧠 Mémoire (Volatile)</option>
                <option value="persistent">💾 Persistant (SQLite)</option>
              </select>
            </div>

            {/* Pending */}
            <div className="jb_filter_group">
              <label>En attente (Pending)</label>
              <select
                className="jb_select"
                value={pendingFilter === null ? "" : pendingFilter ? "true" : "false"}
                onChange={(e) => {
                  const val = e.target.value;
                  setPendingFilter(val === "" ? null : val === "true");
                }}
              >
                <option value="">Tous</option>
                <option value="true">✅ Oui</option>
                <option value="false">❌ Non</option>
              </select>
            </div>

            <div className="jb_filter_actions">
              <button type="button" className="jb_btn_apply_filters" onClick={filterJobs}>
                Filtrer
              </button>
              <button type="button" className="oh-btn oh-btn--ghost jb_btn_reset_filters" onClick={resetFilters}>
                <RefreshCw size={13} /> Réinitialiser
              </button>
            </div>
          </aside>
        )}

        {/* COLONNE 2 : LISTE DES TÂCHES */}
        {showList && (
          <section id="jb_list_panel" className="jb_list_panel">
            {jobListError && (
              <p className="jb_list_error">
                <TriangleAlert size={13} /> {jobListError}
              </p>
            )}
            <div className="jb_list_header">
              <span className="jb_list_count">{totalFiltered} tâche(s) au total</span>
              <span className="jb_list_showing_count">
                Affichées : {displayedJobs.length} / {totalFiltered}
              </span>
            </div>

            {totalFiltered === 0 && !jobListLoading ? (
              <div className="jb_empty_state">Aucune tâche planifiée</div>
            ) : (
              <div className="jb_cards_stack">
                {displayedJobs.map((job) => (
                  <JobPreview
                    key={`job-${job.id}`}
                    job={job}
                    selected={selectedJob?.id === job.id}
                    onSelect={() => handleSelectJob(job)}
                    onPause={handlePause}
                    onResume={handleResume}
                    onDelete={(id) => setDeleteTargetId(id)}
                    isActionLoading={(id) => Boolean(actionLoading[id])}
                  />
                ))}
              </div>
            )}

            {/* ── PAGINATION FIXÉE EN BAS ── */}
            <div className="jb_see_more_controls">
              <div className="jb_limit_setter_box">
                <label>Afficher par lot de :</label>
                <input
                  className="jb_limit_input"
                  type="number"
                  min={1}
                  max={500}
                  value={localListLimit}
                  onChange={(e) => setLocalListLimit(parseInt(e.target.value, 10) || 1)}
                  onBlur={(e) => handleApplyLimit(parseInt(e.target.value, 10))}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      handleApplyLimit(localListLimit);
                      (e.target as HTMLInputElement).blur();
                    }
                  }}
                  title="Modifiez la valeur et cliquez ailleurs pour appliquer"
                />
              </div>

              {totalFiltered > listLimit && (
                <button
                  type="button"
                  onClick={() => setListShowAll(!listShowAll)}
                  className="jb_btn_see_more"
                >
                  {listShowAll ? "Voir moins" : `Voir tout (${totalFiltered})`}
                </button>
              )}
            </div>
          </section>
        )}

        {/* COLONNE 3 : PANNEAU DÉTAIL */}
        {showDetail && (
          <section id="jb_detail_panel_wrapper" className="jb_detail_panel_wrapper">
            <JobDetail
              job={selectedJob}
              onPause={handlePause}
              onResume={handleResume}
              onDelete={(id) => setDeleteTargetId(id)}
              onDeselect={handleDeselect}
              onEditName={startEditName}
              isActionLoading={(id) => Boolean(actionLoading[id])}
              editingJobId={editingJobId}
              newJobName={newJobName}
              setNewJobName={setNewJobName}
              confirmEditName={confirmEditName}
              cancelEditName={cancelEditName}
              modifyNameLoading={modifyNameLoading}
              modifyNameError={modifyNameError}
            />
          </section>
        )}
      </div>

      {/* ── 5. MODALES DE CONFIRMATION SÉCURISÉES ── */}
      <ConfirmModal
        isOpen={bulkPauseModal}
        title="Suspendre toutes les tâches ?"
        message={`Cette action mettra en pause toutes les tâches de la portée sélectionnée (${
          bulkOpsInMemory === null ? "Tous les jobstores" : bulkOpsInMemory ? "Mémoire uniquement" : "Persistant uniquement"
        }).`}
        confirmText="Suspendre tout"
        variant="warning"
        isLoading={bulkLoading}
        onConfirm={executeBulkPause}
        onCancel={() => setBulkPauseModal(false)}
      />

      <ConfirmModal
        isOpen={bulkResumeModal}
        title="Relancer toutes les tâches ?"
        message={`Cette action relancera immédiatement toutes les tâches de la portée sélectionnée (${
          bulkOpsInMemory === null ? "Tous les jobstores" : bulkOpsInMemory ? "Mémoire uniquement" : "Persistant uniquement"
        }).`}
        confirmText="Relancer tout"
        variant="info"
        isLoading={bulkLoading}
        onConfirm={executeBulkResume}
        onCancel={() => setBulkResumeModal(false)}
      />

      <ConfirmModal
        isOpen={bulkDeleteModal}
        title="Supprimer TOUTES les tâches planifiées ?"
        message={`⚠️ ATTENTION : Cette action est irréversible. Toutes les tâches de la portée (${
          bulkOpsInMemory === null ? "Tous les jobstores" : bulkOpsInMemory ? "Mémoire" : "Persistant"
        }) seront définitivement détruites.`}
        confirmText="Tout supprimer"
        variant="danger"
        isLoading={bulkLoading}
        onConfirm={executeBulkDelete}
        onCancel={() => setBulkDeleteModal(false)}
      />

      <ConfirmModal
        isOpen={Boolean(deleteTargetId)}
        title="Supprimer cette tâche ?"
        message="Cette action est irréversible. La tâche sera retirée du planificateur APScheduler."
        confirmText="Supprimer définitivement"
        variant="danger"
        isLoading={Boolean(deleteTargetId && actionLoading[deleteTargetId])}
        onConfirm={confirmDeleteJob}
        onCancel={() => setDeleteTargetId(null)}
      />

      {/* Modale d'Ajout de Job depuis le Catalogue */}
      {showAddJobModal && (
        <AddJobModal
          jobCatalog={jobCatalog || []}
          naviguate={navigate}
          setShowModal={setShowAddJobModal}
          onJobCreated={reload}
        />
      )}
    </div>
  );
}

export default JobPage;