import "./jobs.css";
import {
    GetJobRequest,
    GetJobResponse,
    Job,
    JobBulkOperationResponse,
    JobCatalogResponse,
    JobOperationResponse,
    JobState,
    ListJobsResponse,
    ManageAllJobsRequest,
    ManageJobRequest,
    ModifyJobRequest,
    TriggerKind,
} from "@/types/jobs/types";
import { useNavigate } from "react-router-dom";
import {
    jobCatalog as _jobCatalog,
    listJob as _listJob,
    getJob as _getJob,
    pauseJob as _pauseJob,
    resumeJob as _resumeJob,
    removeJob as _removeJob,
    modifyJob as _modifyJob,
    pauseAllJobs as _pauseAllJobs,
    removeAllJobs as _removeAllJobs,
    resumeAllJobs as _resumeAllJobs,
} from "@/hooks/fetch_functions";
import { refreshToken } from "@/hooks/get_token";
import { getToken } from "@/hooks/get_token";
import { logError } from "@/hooks/error_utils";

// ============================================================================
// FONCTIONS DE RÉCUPÉRATION
// ============================================================================

export async function getJobCatalog(
    setResult: Function[] | null,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<JobCatalogResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await _jobCatalog(getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as JobCatalogResponse;
            if (setResult) {
                for (const fn of setResult) fn(json.catalog);
            }
            return json;
        }
        const json = json_ as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getJobCatalog(setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) {
            for (const fn of setResult) fn(null);
        }
        setError(result.error || json?.detail?.error || "Erreur lors du chargement du catalogue");
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getJobCatalog : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function listJob(
    in_memory: boolean | null = null,
    setResult: Function[] | null,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<ListJobsResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const data = { in_memory };
        const result = await _listJob(data, getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as ListJobsResponse;
            if (setResult) {
                for (const fn of setResult) fn(json.jobs);
            }
            return json;
        }
        const json = json_ as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await listJob(in_memory, setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) {
            for (const fn of setResult) fn(null);
        }
        setError(result.error || json?.detail?.error || "Erreur lors du chargement des jobs");
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans listJob : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function getJob(
    job_id: string | number,
    in_memory: boolean | null,
    setResult: Function[] | null,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<GetJobResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const data: GetJobRequest = { in_memory, job_id };
        const result = await _getJob(data, getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as GetJobResponse;
            if (setResult) {
                for (const fn of setResult) fn([json.job]);
            }
            return json;
        }
        const json = json_ as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getJob(job_id, in_memory, setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) {
            for (const fn of setResult) fn(null);
        }
        setError(result.error || json?.detail?.error  || "Erreur lors du chargement des jobs");
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getJob : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ============================================================================
// MODIFICATION DU NOM D'UN JOB
// ============================================================================

export async function modifyJobName(
    jobId: string,
    newName: string,
    inMemory: boolean | null,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<boolean> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const data: ModifyJobRequest = {
            job_id: jobId,
            name: newName,
            //in_memory: inMemory,
        };

        const result = await _modifyJob(data, getToken());

        if (result.ok) {
            return true;
        }

        const json = result.response as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await modifyJobName(jobId, newName, inMemory, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }

        setError(result.error || json?.detail?.error || "Erreur lors de la modification du nom");
        return false;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans modifyJobName : ", msg);
        return false;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ============================================================================
// FILTRE DES JOBS
// ============================================================================

export function filterJobs(
    jobs: Job[],
    idFilter: string | null,
    idSearchMode: "partial" | "exact",
    pendingFilter: boolean | null,
    jobstoreFilter: "memory" | "persistent" | "all" | null,
    stateFilter: JobState | null
): Job[] {
    return jobs.filter((job) => {
        let can = true;

        if (idFilter && idFilter.trim()) {
            const query = idFilter.trim().toLowerCase();
            const jobId = job.id.toLowerCase();
            can = can && (idSearchMode === "exact" ? jobId === query : jobId.includes(query));
        }

        if (pendingFilter !== null) {
            can = can && job.pending === pendingFilter;
        }

        if (jobstoreFilter && jobstoreFilter !== "all") {
            const isMemory = jobstoreFilter === "memory";
            can = can && (job.jobstore === (isMemory ? "memory" : "default"));
        }

        if (stateFilter) {
            const isPaused = job.next_run_time === null;
            const state: JobState = job.pending ? "pending" : isPaused ? "paused" : "running";
            can = can && state === stateFilter;
        }

        return can;
    });
}

// ============================================================================
// GESTION DES JOBS (actions individuelles + groupées)
// ============================================================================

type opOnOneJobFuncName = "pauseJob" | "resumeJob" | "removeJob";
type opOnBulkJobFuncName = "pauseAllJobs" | "resumeAllJobs" | "removeAllJobs";

const OpsMapping: Record<opOnOneJobFuncName, Function> = {
    pauseJob: _pauseJob,
    removeJob: _removeJob,
    resumeJob: _resumeJob,
};

const OpsBulkMapping: Record<opOnBulkJobFuncName, Function> = {
    pauseAllJobs: _pauseAllJobs,
    removeAllJobs: _removeAllJobs,
    resumeAllJobs: _resumeAllJobs,
};

async function opOnOneJob(
    job_id: string | number,
    in_memory: boolean | null,
    funcName: opOnOneJobFuncName,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<JobOperationResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const data: ManageJobRequest = { in_memory, job_id };
        const result = await OpsMapping[funcName](data, getToken());
        const json_ = result.response;

        if (result.ok) {
            return json_ as JobOperationResponse;
        }
        const json = json_ as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await opOnOneJob(job_id, in_memory, funcName, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        setError(result.error || json?.detail?.error || "Erreur lors de l'opération");
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans opOnOneJob : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

async function opOnBulkJob(
    in_memory: boolean | null,
    funcName: opOnBulkJobFuncName,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<JobBulkOperationResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const data: ManageAllJobsRequest = { in_memory };
        const result = await OpsBulkMapping[funcName](data, getToken());
        const json_ = result.response;

        if (result.ok) {
            return json_ as JobBulkOperationResponse;
        }
        const json = json_ as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await opOnBulkJob(in_memory, funcName, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        setError(result.error || json?.detail?.error || "Erreur lors de l'opération groupée");
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans opOnBulkJob : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function pauseJob(job_id: string | number, in_memory: boolean | null, setError: Function, setLoading: ((v: boolean) => void) | null = null, navigate: ReturnType<typeof useNavigate>): Promise<JobOperationResponse | null> {
    return await opOnOneJob(job_id, in_memory, "pauseJob", setError, setLoading, navigate);
}

export async function resumeJob(job_id: string | number, in_memory: boolean | null, setError: Function, setLoading: ((v: boolean) => void) | null = null, navigate: ReturnType<typeof useNavigate>): Promise<JobOperationResponse | null> {
    return await opOnOneJob(job_id, in_memory, "resumeJob", setError, setLoading, navigate);
}

export async function removeJob(job_id: string | number, in_memory: boolean | null, setError: Function, setLoading: ((v: boolean) => void) | null = null, navigate: ReturnType<typeof useNavigate>): Promise<JobOperationResponse | null> {
    return await opOnOneJob(job_id, in_memory, "removeJob", setError, setLoading, navigate);
}

export async function pauseAllJobs(in_memory: boolean | null, setError: Function, setLoading: ((v: boolean) => void) | null = null, navigate: ReturnType<typeof useNavigate>): Promise<JobBulkOperationResponse | null> {
    return await opOnBulkJob(in_memory, "pauseAllJobs", setError, setLoading, navigate);
}

export async function resumeAllJobs(in_memory: boolean | null, setError: Function, setLoading: ((v: boolean) => void) | null = null, navigate: ReturnType<typeof useNavigate>): Promise<JobBulkOperationResponse | null> {
    return await opOnBulkJob(in_memory, "resumeAllJobs", setError, setLoading, navigate);
}

export async function removeAllJobs(in_memory: boolean | null, setError: Function, setLoading: ((v: boolean) => void) | null = null, navigate: ReturnType<typeof useNavigate>): Promise<JobBulkOperationResponse | null> {
    return await opOnBulkJob(in_memory, "removeAllJobs", setError, setLoading, navigate);
}

// ============================================================================
// MAPPINGS D'AFFICHAGE
// ============================================================================

export const jobStateIcon: Record<JobState, string> = {
    running: "▶️",
    paused: "⏸️",
    pending: "⏳",
};

export const jobStateClass: Record<JobState, string> = {
    running: "jb_state_running",
    paused: "jb_state_paused",
    pending: "jb_state_pending",
};

export const jobstoreLabel: Record<string, string> = {
    memory: "🧠 Mémoire",
    default: "💾 Persistant",
};

export const triggerTypeLabel: Record<TriggerKind, string> = {
    cron: "⏰ Cron",
    date: "📅 Date",
    interval: "🔄 Intervalle",
    calendar_interval: "📆 Calendrier",
};
