import React, { useState } from "react";
import {
  Job,
  JobState,
  TriggerKind,
} from "@/types/jobs/types";
import { jobStateClass, jobStateIcon, jobstoreLabel, triggerTypeLabel } from "./utils";
import {
  Pause,
  Play,
  Trash2,
  X,
  Edit3,
  Check,
  Calendar,
  ChevronDown,
  ChevronUp,
  Copy,
  FolderOpen,
} from "lucide-react";
import toast from "react-hot-toast";
import "./jobs.css";

// ── FORMATAGE DU TRIGGER ──
function formatCronExprSingle(expr: { first?: number; last?: number; step?: number } | undefined): string {
  if (!expr) return "*";
  if (expr.first !== undefined && expr.first !== null) {
    if (expr.step) {
      return expr.last !== undefined && expr.last !== expr.first
        ? `${expr.first}-${expr.last}/${expr.step}`
        : `${expr.first}/${expr.step}`;
    }
    return expr.last !== undefined && expr.last !== expr.first
      ? `${expr.first}-${expr.last}`
      : String(expr.first);
  }
  return expr.step ? `*/${expr.step}` : "*";
}

function formatCronField(field: { expressions?: any[] } | null | undefined): string {
  if (!field || !field.expressions || field.expressions.length === 0) return "*";
  return field.expressions.map(formatCronExprSingle).join(", ");
}

function formatTriggerFields(trigger: Job["trigger"]): Array<{ label: string; value: string }> {
  const type = trigger.type as TriggerKind;
  const fields: Array<{ label: string; value: string }> = [];

  switch (type) {
    case "cron": {
      const cronFields = (trigger.fields || {}) as Record<string, any>;
      const order: [string, string][] = [
        ["year", "Année"],
        ["month", "Mois"],
        ["day", "Jour"],
        ["week", "Semaine"],
        ["day_of_week", "Jour de la semaine"],
        ["hour", "Heure"],
        ["minute", "Minute"],
        ["second", "Seconde"],
      ];
      for (const [key, label] of order) {
        fields.push({ label, value: formatCronField(cronFields[key]) });
      }
      break;
    }

    case "date": {
      fields.push({
        label: "Date d'exécution",
        value: trigger.run_date ? new Date(trigger.run_date).toLocaleString("fr-FR") : "—",
      });
      break;
    }

    case "interval": {
      const interval = (trigger.interval || {}) as Record<string, number>;
      const units: [string, string][] = [
        ["weeks", "Semaines"],
        ["days", "Jours"],
        ["hours", "Heures"],
        ["minutes", "Minutes"],
        ["seconds", "Secondes"],
      ];
      for (const [key, label] of units) {
        fields.push({ label, value: String(interval[key] ?? 0) });
      }
      break;
    }

    case "calendar_interval": {
      const interval = (trigger.interval || {}) as Record<string, number>;
      const units: [string, string][] = [
        ["years", "Années"],
        ["months", "Mois"],
        ["weeks", "Semaines"],
        ["days", "Jours"],
      ];
      for (const [key, label] of units) {
        fields.push({ label, value: String(interval[key] ?? 0) });
      }
      break;
    }

    default:
      fields.push({ label: "Type", value: trigger.type || "Inconnu" });
      fields.push({ label: "Expression", value: trigger.repr || "—" });
  }

  return fields;
}

export function TriggerFieldTree({ fields }: { fields: Array<{ label: string; value: string }> }) {
  return (
    <div className="jb_trigger_tree">
      {fields.map((f, i) => (
        <div className="jb_trigger_tree_row" key={i}>
          <span className="jb_trigger_tree_label">{f.label}</span>
          <span className="jb_trigger_tree_value oh-mono">{f.value}</span>
        </div>
      ))}
    </div>
  );
}

// ============================================================================
// COMPOSANT : JOB PREVIEW (CARTE COMPACTE AVEC CLASSSES JB_*)
// ============================================================================

export function JobPreview({
  job,
  selected,
  onSelect,
  onPause,
  onResume,
  onDelete,
  isActionLoading,
}: {
  job: Job;
  selected: boolean;
  onSelect: () => void;
  onPause: (id: string) => void;
  onResume: (id: string) => void;
  onDelete: (id: string) => void;
  isActionLoading: (id: string) => boolean;
}) {
  const isLoading = isActionLoading(job.id);
  const isPaused = job.next_run_time === null;
  const state: JobState = job.pending ? "pending" : isPaused ? "paused" : "running";

  return (
    <div
      className={`jb_card ${selected ? "jb_card_selected" : ""}`}
      onClick={onSelect}
    >
      <div className="jb_card_header">
        <span className="jb_card_icon">{jobStateIcon[state]}</span>
        <div className="jb_card_title_group">
          <h4 className="jb_card_name">{job.name || job.id}</h4>
          <div className="jb_card_id_badge">
            <span className="oh-mono">{job.id}</span>
          </div>
        </div>
      </div>

      <div className="jb_card_meta">
        <span className={`jb_card_state_badge ${jobStateClass[state]}`}>
          <span className={`jb_state_dot ${isPaused ? "jb_state_dot_paused" : "jb_state_dot_running"}`} />
          {state}
        </span>
        <span className="oh-badge oh-badge--accent">
          {jobstoreLabel[job.jobstore || "default"] || job.jobstore}
        </span>
        <span className="jb_card_trigger_badge">
          ⏰ {triggerTypeLabel[job.trigger.type as TriggerKind] || job.trigger.type}
        </span>
      </div>

      <div className="jb_card_func_box">
        <span className="jb_card_func_name oh-mono">{job.func.name}</span>
        <span className="jb_card_func_type">
          {job.func.is_async ? "⚡ async" : "🔄 sync"}
        </span>
      </div>

      {job.next_run_time && (
        <div className="jb_card_next_run">
          ⏭️ {new Date(job.next_run_time).toLocaleString("fr-FR")}
        </div>
      )}

      <div className="jb_card_actions" onClick={(e) => e.stopPropagation()}>
        {isPaused ? (
          <button
            type="button"
            className="jb_btn_card_action jb_btn_card_resume"
            onClick={() => onResume(job.id)}
            disabled={isLoading}
            title="Reprendre cette tâche"
          >
            <Play size={13} />
          </button>
        ) : (
          <button
            type="button"
            className="jb_btn_card_action jb_btn_card_pause"
            onClick={() => onPause(job.id)}
            disabled={isLoading}
            title="Mettre en pause"
          >
            <Pause size={13} />
          </button>
        )}
        <button
          type="button"
          className="jb_btn_card_action jb_btn_card_delete"
          onClick={() => onDelete(job.id)}
          disabled={isLoading}
          title="Supprimer"
        >
          <Trash2 size={13} />
        </button>
      </div>
    </div>
  );
}

// ============================================================================
// COMPOSANT : JOB DETAIL (PANNEAU DÉTAIL DENSE AVEC CLASSES JB_*)
// ============================================================================

export function JobDetail({
  job,
  onPause,
  onResume,
  onDelete,
  onDeselect,
  onEditName,
  isActionLoading,
  editingJobId,
  newJobName,
  setNewJobName,
  confirmEditName,
  cancelEditName,
  modifyNameLoading,
  modifyNameError,
}: {
  job: Job | null;
  onPause: (id: string) => void;
  onResume: (id: string) => void;
  onDelete: (id: string) => void;
  onDeselect: () => void;
  onEditName: (job: Job) => void;
  isActionLoading: (id: string) => boolean;
  editingJobId: string | null;
  newJobName: string;
  setNewJobName: (value: string) => void;
  confirmEditName: (jobId: string, inMemory: boolean | null) => void;
  cancelEditName: () => void;
  modifyNameLoading: boolean;
  modifyNameError: string;
}) {
  const [showMoreDetails, setShowMoreDetails] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<boolean>(false);

  if (!job) {
    return (
      <div className="jb_detail_empty">
        <FolderOpen size={32} className="jb_detail_empty_icon" />
        <h3 className="jb_detail_empty_title">Aucune tâche sélectionnée</h3>
        <p className="jb_detail_empty_desc">
          Cliquez sur un job dans la liste pour voir sa configuration complète, ses triggers et ses arguments.
        </p>
      </div>
    );
  }

  const isLoading = isActionLoading(job.id);
  const isPaused = job.next_run_time === null;
  const state: JobState = job.pending ? "pending" : isPaused ? "paused" : "running";

  const handleCopyId = async () => {
    await navigator.clipboard.writeText(job.id);
    setCopiedId(true);
    toast.success("ID copié !");
    setTimeout(() => setCopiedId(false), 1500);
  };

  const formatValue = (value: unknown): string => {
    if (value === null || value === undefined) return "—";
    if (typeof value === "string") return value;
    if (typeof value === "boolean") return value ? "✅ Oui" : "❌ Non";
    if (typeof value === "object") {
      try {
        return JSON.stringify(value, null, 2);
      } catch {
        return "[Objet non sérialisable]";
      }
    }
    return String(value);
  };

  return (
    <div className="jb_detail_card">
      {/* ── HEADER AVEC MODIFICATION DU NOM & ID MIS EN AVANT ── */}
      <div className="jb_detail_header">
        <span className="jb_detail_icon">{jobStateIcon[state]}</span>

        {editingJobId === job.id ? (
          <div className="jb_detail_name_edit">
            <input
              className="jb_detail_name_input"
              type="text"
              value={newJobName}
              onChange={(e) => setNewJobName(e.target.value)}
              autoFocus
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  confirmEditName(job.id, job.jobstore !== "memory");
                }
                if (e.key === "Escape") {
                  cancelEditName();
                }
              }}
            />
            <button
              type="button"
              className="oh-btn oh-btn--primary jb_btn_icon"
              onClick={() => confirmEditName(job.id, job.jobstore !== "memory")}
              disabled={modifyNameLoading}
              title="Valider"
            >
              <Check size={13} />
            </button>
            <button
              type="button"
              className="oh-btn oh-btn--ghost jb_btn_icon"
              onClick={cancelEditName}
              disabled={modifyNameLoading}
              title="Annuler"
            >
              <X size={13} />
            </button>
            {modifyNameError && <span className="jb_detail_name_error">{modifyNameError}</span>}
          </div>
        ) : (
          <div className="jb_detail_info">
            <div className="jb_detail_title_row">
              <h2 className="jb_detail_name">{job.name || job.id}</h2>
              <button
                type="button"
                className="jb_btn_edit_name"
                onClick={() => onEditName(job)}
                title="Renommer la tâche"
              >
                <Edit3 size={13} />
              </button>
            </div>
            <div className="jb_detail_id_badge">
              <span className="oh-mono">{job.id}</span>
              <button type="button" className="jb_copy_btn" onClick={handleCopyId} title="Copier l'identifiant">
                {copiedId ? <Check size={12} /> : <Copy size={12} />}
              </button>
            </div>
          </div>
        )}

        <button type="button" className="oh-btn oh-btn--ghost jb_btn_icon" onClick={onDeselect}>
          <X size={14} />
        </button>
      </div>

      {/* ── CORPS DES LIGNES FORMATÉES (.jb_detail_row) ── */}
      <div className="jb_detail_body">
        <div className="jb_detail_row">
          <span className="jb_detail_label">📶 État</span>
          <div className="jb_detail_value">
            <span className={`jb_state_dot ${isPaused ? "jb_state_dot_paused" : "jb_state_dot_running"}`} />
            <strong>{state}</strong>
          </div>
        </div>

        <div className="jb_detail_row">
          <span className="jb_detail_label">💾 Jobstore</span>
          <span className="jb_detail_value oh-badge oh-badge--accent">
            {jobstoreLabel[job.jobstore || "default"] || job.jobstore}
          </span>
        </div>

        <div className="jb_detail_row">
          <span className="jb_detail_label">📦 Fonction</span>
          <span className="jb_detail_value oh-mono">{job.func.name}</span>
        </div>

        <div className="jb_detail_row">
          <span className="jb_detail_label">📂 Module Python</span>
          <span className="jb_detail_value oh-mono">{job.func.module}</span>
        </div>

        <div className="jb_detail_row">
          <span className="jb_detail_label">⚡ Type d'exécution</span>
          <span className="jb_detail_value">{job.func.is_async ? "Asynchrone (AsyncIO)" : "Synchrone (ThreadPool)"}</span>
        </div>

        {job.func.doc && (
          <div className="jb_detail_row">
            <span className="jb_detail_label">📝 Description</span>
            <span className="jb_detail_value">{job.func.doc}</span>
          </div>
        )}

        {/* Arguments positionnels & nommés */}
        {job.args && job.args.length > 0 && (
          <div className="jb_detail_row">
            <span className="jb_detail_label">📥 Args</span>
            <span className="jb_detail_value oh-mono">{formatValue(job.args)}</span>
          </div>
        )}
        {job.kwargs && Object.keys(job.kwargs).length > 0 && (
          <div className="jb_detail_row">
            <span className="jb_detail_label">📥 Kwargs</span>
            <span className="jb_detail_value oh-mono">{formatValue(job.kwargs)}</span>
          </div>
        )}

        <div className="jb_detail_row">
          <span className="jb_detail_label">⏭️ Prochaine exécution</span>
          <span className="jb_detail_value">
            {job.next_run_time ? (
              <>
                <Calendar size={12} /> {new Date(job.next_run_time).toLocaleString("fr-FR")}
              </>
            ) : (
              <span className="oh-badge oh-badge--warning">En pause</span>
            )}
          </span>
        </div>

        <div className="jb_detail_row">
          <span className="jb_detail_label">⏰ Type de Trigger</span>
          <span className="jb_detail_value">
            {triggerTypeLabel[job.trigger.type as TriggerKind] || job.trigger.type}
          </span>
        </div>

        <div className="jb_detail_row">
          <span className="jb_detail_label">📝 Expression</span>
          <span className="jb_detail_value oh-mono">{job.trigger.repr}</span>
        </div>

        {/* ── ACCORDÉON DÉTAILS AVANCÉS (.jb_detail_accordion) ── */}
        <div className="jb_detail_accordion">
          <button
            type="button"
            className="jb_detail_accordion_btn"
            onClick={() => setShowMoreDetails(!showMoreDetails)}
          >
            <span>{showMoreDetails ? "Masquer les détails avancés" : "Voir les paramètres détaillés du trigger"}</span>
            {showMoreDetails ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </button>

          {showMoreDetails && (
            <div className="jb_detail_accordion_body">
              <TriggerFieldTree fields={formatTriggerFields(job.trigger)} />

              <div className="jb_detail_row">
                <span className="jb_detail_label">⚙️ Exécuteur</span>
                <span className="jb_detail_value oh-mono">
                  {(job.executor || "—") === "default" ? "AsyncIO Pool" : job.executor}
                </span>
              </div>
              <div className="jb_detail_row">
                <span className="jb_detail_label">🔄 Coalesce</span>
                <span className="jb_detail_value">{job.coalesce ? "✅ Oui" : "❌ Non"}</span>
              </div>
              <div className="jb_detail_row">
                <span className="jb_detail_label">📊 Max Instances</span>
                <span className="jb_detail_value oh-mono">{job.max_instances || "—"}</span>
              </div>
              <div className="jb_detail_row">
                <span className="jb_detail_label">⏱️ Misfire grace time</span>
                <span className="jb_detail_value oh-mono">{job.misfire_grace_time || "—"}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── BOUTONS D'ACTION EN BAS (.jb_detail_actions) ── */}
      <div className="jb_detail_actions">
        {isPaused ? (
          <button
            type="button"
            className="jb_btn_action_detail jb_btn_resume"
            onClick={() => onResume(job.id)}
            disabled={isLoading}
          >
            <Play size={13} /> {isLoading ? "Reprise..." : "Reprendre"}
          </button>
        ) : (
          <button
            type="button"
            className="jb_btn_action_detail jb_btn_pause"
            onClick={() => onPause(job.id)}
            disabled={isLoading}
          >
            <Pause size={13} /> {isLoading ? "Mise en pause..." : "Mettre en pause"}
          </button>
        )}
        <button
          type="button"
          className="jb_btn_action_detail jb_btn_delete"
          onClick={() => onDelete(job.id)}
          disabled={isLoading}
        >
          <Trash2 size={13} /> {isLoading ? "Suppression..." : "Supprimer"}
        </button>
        <button
          type="button"
          className="jb_btn_action_detail jb_btn_deselect"
          onClick={onDeselect}
          disabled={isLoading}
        >
          <X size={13} /> Désélectionner
        </button>
      </div>
    </div>
  );
}