import { logError } from "@/hooks/error_utils";
import "./login.css";
import { setToken, setUsername as persistUsername } from "@/hooks/get_token";
import { getConfig, AppConfig } from "@/hooks/get_config";
import { loginRoute } from "@/hooks/backend_routes";
import { LoginRequest, LoginResponse } from "@/types/login_types/types";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { 
    Lock, 
    User, 
    Shield, 
    ArrowRight, 
    CheckCircle2, 
    AlertCircle, 
    Loader2,
    Eye,
    EyeOff,
    Sparkles,
    Fingerprint
} from "lucide-react";
import { toTitleCaseWithUnderscore } from "../utils/to_lower_case";

function capitalize(str: string): string {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}

function ShowLoginResponse({ 
    result, 
    username, 
    error 
}: { 
    result: LoginResponse | null; 
    username: string; 
    error: string;
}) {
    if (result && Boolean(result.access_token)) {
        return (
            <div id="login_success_block" className="login-response login-response--success">
                <CheckCircle2 size={20} className="login-response__icon" />
                <div className="login-response__content">
                    <span className="login-response__title">Connexion réussie !</span>
                    <span className="login-response__subtitle">
                        Bienvenue <strong>{username}</strong>
                    </span>
                </div>
            </div>
        );
    }
    
    if (error) {
        return (
            <div id="login_error_block" className="login-response login-response--error">
                <AlertCircle size={20} className="login-response__icon" />
                <div className="login-response__content">
                    <span className="login-response__title">Erreur</span>
                    <span className="login-response__subtitle">{error}</span>
                </div>
            </div>
        );
    }

    return null;
}

function Login() {
    const [username, setUsername] = useState<string>("");
    const [usernameCopy, setUsernameCopy] = useState<string>("");
    const [password, setPassword] = useState<string>("");
    const [showPassword, setShowPassword] = useState<boolean>(false);
    const [result, setResult] = useState<LoginResponse | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string>("");
    const [baseUrl, setBaseUrl] = useState<string>("");
    const [redirectDelay, setRedirectDelay] = useState<number | null>(null);
    const [isFocused, setIsFocused] = useState<{ username: boolean; password: boolean }>({
        username: false,
        password: false,
    });
    const [conf, setConf] = useState<AppConfig | null>(null);
    const navigate = useNavigate();
    const DEFAULT_REDIECT_DELAY = 5;

    useEffect(() => {
        async function load() {
            const cfg: AppConfig = await getConfig();
            setBaseUrl(cfg.apiBaseUrl);
            setConf(cfg);
            setRedirectDelay(cfg.redirectDelayAfterLogin ?? DEFAULT_REDIECT_DELAY);
        }
        load();
    }, []);

    useEffect(() => {
        let timer: ReturnType<typeof setTimeout>;
        if (result && !!result.access_token) {
            timer = setTimeout(
                () => {
                    navigate("/dashboard");
                },
                (redirectDelay ?? DEFAULT_REDIECT_DELAY) * 1000
            );
        }
        return () => { clearTimeout(timer); };
    }, [result, navigate, redirectDelay]);

    const productName = conf?.productName ? toTitleCaseWithUnderscore(conf.productName) : "Obsidian Hive";

    const validateInput = (): boolean => {
        return Boolean(username.trim() && password.trim());
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        await login();
    };

    const login = async (): Promise<LoginResponse | null> => {
        try {
            setLoading(true);
            setError("");
            setResult(null);

            if (!validateInput()) {
                throw new Error("Nom d'utilisateur et mot de passe requis.");
            }

            const loginData: LoginRequest = {
                username: username.trim(),
                password: password.trim(),
            };

            const response = await fetch(
                `${baseUrl}/${loginRoute}`,
                {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(loginData),
                }
            );

            if (!response.ok) {
                const text = await response.text();
                throw new Error(`Erreur ${response.status}: ${text || response.statusText}`);
            }

            const json: LoginResponse = await response.json();
            persistUsername(username.trim());
            setToken(json.access_token);
            setResult(json);
            setUsernameCopy(username.trim());
            setUsername("");
            setPassword("");
            return json;
        } catch (err) {
            const errorMessage: string = logError(err);
            setError(errorMessage);
            setResult(null);
            return null;
        } finally {
            setLoading(false);
        }
    };

    return (
        <div id="login_page" className="login-page">
            {/* Dots de fond */}
            <div className="login-page__dots"></div>

            {/* Carte principale */}
            <div className="login-card">
                {/* Logo */}
                <div className="login-card__brand">
                    <div className="login-card__icon-wrapper">
                        <Shield size={28} className="login-card__brand-icon" />
                    </div>
                    <h1 className="login-card__title">
                        {productName}
                        <span className="login-card__title-badge">v2.0</span>
                    </h1>
                    <p className="login-card__subtitle">
                        Sécurisez vos actifs avec intelligence
                    </p>
                </div>

                {/* Divider */}
                <div className="login-card__divider">
                    <span className="login-card__divider-text">Connexion</span>
                </div>

                {/* Formulaire */}
                <form className="login-form" onSubmit={handleSubmit}>
                    <div className="login-form__group">
                        <label className="login-form__label" htmlFor="username_input_login">
                            <User size={16} />
                            Nom d'utilisateur
                        </label>
                        <div className={`login-form__input-wrapper ${isFocused.username ? "login-form__input-wrapper--focused" : ""}`}>
                            <input
                                id="username_input_login"
                                className="login-form__input"
                                type="text"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                onFocus={() => setIsFocused(prev => ({ ...prev, username: true }))}
                                onBlur={() => setIsFocused(prev => ({ ...prev, username: false }))}
                                placeholder="ex: john.doe"
                                minLength={3}
                                disabled={loading}
                                autoComplete="username"
                                required
                            />
                        </div>
                    </div>

                    <div className="login-form__group">
                        <label className="login-form__label" htmlFor="password_input_login">
                            <Lock size={16} />
                            Mot de passe
                        </label>
                        <div className={`login-form__input-wrapper ${isFocused.password ? "login-form__input-wrapper--focused" : ""}`}>
                            <input
                                id="password_input_login"
                                className="login-form__input"
                                type={showPassword ? "text" : "password"}
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                onFocus={() => setIsFocused(prev => ({ ...prev, password: true }))}
                                onBlur={() => setIsFocused(prev => ({ ...prev, password: false }))}
                                placeholder="••••••••"
                                disabled={loading}
                                autoComplete="current-password"
                                required
                            />
                            <button
                                type="button"
                                className="login-form__toggle-password"
                                onClick={() => setShowPassword(!showPassword)}
                                disabled={loading}
                                aria-label={showPassword ? "Masquer le mot de passe" : "Afficher le mot de passe"}
                            >
                                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                            </button>
                        </div>
                    </div>

                    <button
                        id="btn_submit_login"
                        className="login-form__submit"
                        type="submit"
                        disabled={loading || !validateInput()}
                    >
                        {loading ? (
                            <>
                                <Loader2 size={18} className="login-form__spinner" />
                                Connexion en cours...
                            </>
                        ) : (
                            <>
                                <Fingerprint size={18} />
                                Se connecter
                            </>
                        )}
                    </button>
                </form>

                {/* Messages de réponse */}
                <ShowLoginResponse
                    result={result}
                    username={usernameCopy}
                    error={error}
                />

                {/* Redirect notice */}
                {result && !!result.access_token && (
                    <div id="login_redirect_notice" className="login-redirect">
                        <Sparkles size={16} className="login-redirect__icon" />
                        <span className="login-redirect__text">
                            Bienvenue {capitalize(usernameCopy)} !
                            Redirection dans <strong>{redirectDelay ?? DEFAULT_REDIECT_DELAY}</strong> seconde{redirectDelay && redirectDelay > 1 ? "s" : ""}
                        </span>
                        <Link to="/dashboard" className="login-redirect__link">
                            <ArrowRight size={16} />
                            Accéder au tableau de bord
                        </Link>
                    </div>
                )}

                {/* Footer */}
                <div className="login-card__footer">
                    <span className="login-card__footer-text">
                        {
                            `© ${new Date().getFullYear()} ${toTitleCaseWithUnderscore(productName)} — Tous droits réservés`
                        }
                    </span>
                </div>
            </div>
        </div>
    );
}

export default Login;