import "./logout.css";
import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { logout, getUsername, isLogin } from "@/hooks/get_token";
import { LogOut, CheckCircle2, XCircle, Loader2, ArrowRight, Shield, User, Clock } from "lucide-react";
import toast from "react-hot-toast";

function LogoutPage() {
    const navigate = useNavigate();
    const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
    const [countdown, setCountdown] = useState<number>(5);
    let username = getUsername() || "Utilisateur";
    username = username[0].toLocaleUpperCase() + username.slice(1);

    // ── Déconnexion ──
    const handleLogout = async () => {
        setStatus("loading");
        
        // Simuler un délai pour l'effet visuel
        await new Promise((resolve) => setTimeout(resolve, 1200));
        
        try {
            logout();
            setStatus("success");
            toast.success("👋 Déconnexion réussie !");
            
            // Redirection après 5 secondes
            let seconds = 3;
            setCountdown(seconds);
            const interval = setInterval(() => {
                seconds -= 1;
                setCountdown(seconds);
                if (seconds <= 0) {
                    clearInterval(interval);
                    navigate("/login");
                }
            }, 1000);
        } catch (err) {
            setStatus("error");
            toast.error("❌ Erreur lors de la déconnexion");
        }
    };

    // ── Si déjà déconnecté, rediriger ──
    useEffect(() => {
        if (!isLogin()) {
            navigate("/login");
        }
    }, [navigate]);

    // ── Rendu ──
    return (
        <div className="logout-page">
            {/* Dots de fond */}
            <div className="logout-page__dots"></div>
            
            {/* Carte principale */}
            <div className="logout-card">
                {/* Icône */}
                <div className="logout-card__icon-wrapper">
                    <Shield size={32} className="logout-card__icon" />
                </div>

                {/* Titre */}
                <h1 className="logout-card__title">Déconnexion</h1>
                <p className="logout-card__subtitle">
                    {status === "idle" && (
                        <>Bonjour <strong>{username}</strong>, êtes-vous sûr de vouloir vous déconnecter ?</>
                    )}
                    {status === "loading" && (
                        <>Déconnexion en cours...</>
                    )}
                    {status === "success" && (
                        <>✅ Vous avez été déconnecté avec succès.</>
                    )}
                    {status === "error" && (
                        <>❌ Une erreur est survenue lors de la déconnexion.</>
                    )}
                </p>

                {/* Statut de la session */}
                <div className="logout-card__session-info">
                    <div className="logout-card__session-item">
                        <User size={14} />
                        <span>{username}</span>
                    </div>
                    <div className="logout-card__session-item">
                        <Clock size={14} />
                        <span>Session active</span>
                    </div>
                </div>

                {/* États */}
                {status === "idle" && (
                    <div className="logout-card__actions">
                        <button
                            className="logout-btn logout-btn--danger"
                            onClick={handleLogout}
                        >
                            <LogOut size={18} />
                            Se déconnecter
                        </button>
                        <Link to="/" className="logout-btn logout-btn--secondary">
                            <ArrowRight size={18} />
                            Retour à l'accueil
                        </Link>
                        <Link to="/dashboard" className="logout-btn logout-btn--secondary">
                            <ArrowRight size={18} />
                            Retour au tableau de bord
                        </Link>
                    </div>
                )}

                {status === "loading" && (
                    <div className="logout-card__loading">
                        <Loader2 size={28} className="logout-card__spinner" />
                        <span>Déconnexion en cours...</span>
                    </div>
                )}

                {status === "success" && (
                    <div className="logout-card__success">
                        <CheckCircle2 size={48} className="logout-card__success-icon" />
                        <p className="logout-card__success-text">
                            Redirection vers la page de connexion dans <strong>{countdown}</strong> seconde{countdown > 1 ? "s" : ""}...
                        </p>
                        <Link to="/login" className="logout-btn logout-btn--primary">
                            Se reconnecter maintenant
                        </Link>
                    </div>
                )}

                {status === "error" && (
                    <div className="logout-card__error">
                        <XCircle size={48} className="logout-card__error-icon" />
                        <p className="logout-card__error-text">
                            Une erreur est survenue. Veuillez réessayer.
                        </p>
                        <div className="logout-card__actions">
                            <button
                                className="logout-btn logout-btn--danger"
                                onClick={handleLogout}
                            >
                                <LogOut size={18} />
                                Réessayer
                            </button>
                            <Link to="/" className="logout-btn logout-btn--secondary">
                                <ArrowRight size={18} />
                                Retour au tableau de bord
                            </Link>
                        </div>
                    </div>
                )}

                {/* Footer */}
                <div className="logout-card__footer">
                    <span className="logout-card__footer-text">
                        Vous serez redirigé automatiquement après déconnexion.
                    </span>
                </div>
            </div>
        </div>
    );
}

export default LogoutPage;