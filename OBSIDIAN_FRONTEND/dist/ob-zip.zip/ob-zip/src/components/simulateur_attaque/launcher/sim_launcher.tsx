import { useState, useEffect, useMemo } from "react";
import "./sim_launcher.css";
import { 
    StartSimRequest, 
    SimMode, 
    DockerImageInfo, 
    SimConfig 
} from "@/types/simulateur_attaque/types";
import { 
    startSimulation, 
    getDockerImages, 
    captureHostServices, 
} from "../utils";
import { simWsRoute } from "@/hooks/backend_routes";
import { useSimulateurAttaqueWSStore } from "@/store/simulateur_attaque_websocket_store";
import { getToken } from "@/hooks/get_token";
import { AppConfig, getConfig } from "@/hooks/get_config";
import { useNavigate } from "react-router-dom";
import { 
    Play, 
    Box, 
    Zap, 
    Sliders, 
    ChevronDown, 
    ChevronUp, 
    Layers, 
    RefreshCw, 
    RotateCcw, 
    UploadCloud, 
    FileCheck, 
    Trash2, 
    Eye,
    EyeOff
} from "lucide-react";
import toast from "react-hot-toast";

interface SimLauncherProps {
    onStarted?: () => void;
}

function generateRandomContainerName(): string {
    const id = Array.from(crypto.getRandomValues(new Uint8Array(4)))
        .map(b => b.toString(16).padStart(2, "0"))
        .join("");
    return `simatk_target_${id}`;
}

export function SimLauncherComponent({ onStarted }: SimLauncherProps) {
    const navigate = useNavigate();
    const { isSimulating, isConnected, resetSimulation } = useSimulateurAttaqueWSStore();
    const [conf, setConf] = useState<AppConfig | null>(null);

    // ── 1. Cible Docker ───────────────────────────────────────────────────────
    const [images, setImages] = useState<DockerImageInfo[]>([]);
    const [selectedImage, setSelectedImage] = useState<string>("ubuntu:22.04");
    const [containerName, setContainerName] = useState<string>(generateRandomContainerName());
    const [networkCaps, setNetworkCaps] = useState<boolean>(true);
    const [authorizeNetwork, setAuthorizeNetwork] = useState<boolean>(false);

    // ── 2. Mode d'Exécution & IA ──────────────────────────────────────────────
    const [mode, setMode] = useState<SimMode>("auto");
    const [useLlm, setUseLlm] = useState<boolean>(true);

    // ── 3. Services & Environnement ───────────────────────────────────────────
    const [serviceSource, setServiceSource] = useState<"auto" | "custom" | "none">("auto");
    const [capturedServices, setCapturedServices] = useState<Record<string, any>>({});
    const [showCapturedPreview, setShowCapturedPreview] = useState<boolean>(false);
    const [serviceFilterText, setServiceFilterText] = useState<string>("");

    const [customServicesFile, setCustomServicesFile] = useState<File | null>(null);
    const [customServicesObj, setCustomServicesObj] = useState<Record<string, any> | null>(null);

    // Options fines de capture
    const [onlyListening, setOnlyListening] = useState<boolean>(false);
    const [useDefaultExcludes, setUseDefaultExcludes] = useState<boolean>(true);
    const [excludedNames, setExcludedNames] = useState<string>("systemd, containerd, dockerd");
    const [excludedPorts, setExcludedPorts] = useState<string>("");
    const [excludedPids, setExcludedPids] = useState<string>("");

    // Fake Services (Honeypots de test)
    const [enableFakeServices, setEnableFakeServices] = useState<boolean>(false);
    const [fakeSshPorts, setFakeSshPorts] = useState<string>("22");
    const [fakeFtpPorts, setFakeFtpPorts] = useState<string>("21");
    const [fakeHttpPorts, setFakeHttpPorts] = useState<string>("80, 8080");

    // ── 4. Tuning Avancé des Tactiques (SimConfig) ────────────────────────────
    const [showTuning, setShowTuning] = useState<boolean>(false);
    const [reconPorts, setReconPorts] = useState<string>("22, 21, 80, 443, 8080, 8081, 9090");
    const [reconTimeout, setReconTimeout] = useState<number>(0.2);

    const [sshUsers, setSshUsers] = useState<string>("root, admin, testuser, ubuntu");
    const [sshPasswords, setSshPasswords] = useState<string>("toor, password, admin123, 123456");
    const [sshMaxAttempts, setSshMaxAttempts] = useState<number>(50);

    const [attackerIp, setAttackerIp] = useState<string>("172.17.0.1");
    const [attackerPort, setAttackerPort] = useState<number>(4444);

    const [cronScriptPath, setCronScriptPath] = useState<string>("/opt/backdoor.sh");
    const [sshKeyAlgo, setSshKeyAlgo] = useState<string>("Ed25519");
    const [c2Url, setC2Url] = useState<string>("http://127.0.0.1:8888/exfil");

    const [lateralMaxDepth, setLateralMaxDepth] = useState<number>(3);
    const [lateralMaxWorkers, setLateralMaxWorkers] = useState<number>(5);

    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const fetchImages = () => {
        getDockerImages(
            (data: { images: DockerImageInfo[] } | null) => {
                if (data?.images) {
                    const validImages = data.images.filter(
                        (img) => img.tags && img.tags.length > 0 && img.tags.some((t) => t && t !== "<none>")
                    );
                    setImages(validImages);
                    if (validImages.length > 0) {
                        const firstTag = validImages[0].tags.find((t) => t && t !== "<none>");
                        if (firstTag) setSelectedImage(firstTag);
                    }
                }
            },
            (err: string | null) => { if (err) toast.error(err); },
            null,
            navigate
        );
    };

    useEffect(() => {
        getConfig().then(setConf);
        fetchImages();
    }, []);

    const handleCapture = async () => {
        await captureHostServices(
            (data: { services: Record<string, any> } | null) => {
                if (data?.services) {
                    setCapturedServices(data.services);
                    setShowCapturedPreview(true);
                    toast.success(`🔍 ${Object.keys(data.services).length} service(s) capturé(s) !`);
                }
            },
            (err: string | null) => { if (err) toast.error(err); },
            null,
            navigate
        );
    };

    const handleServicesFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onload = (event) => {
                try {
                    const parsed = JSON.parse(event.target?.result as string);
                    setCustomServicesObj(parsed);
                    setCustomServicesFile(file);
                    toast.success(`📄 ${file.name} chargé (${Object.keys(parsed).length} entrées)`);
                } catch {
                    toast.error("Format JSON invalide dans le fichier importé");
                }
            };
            reader.readAsText(file);
            e.target.value = "";
        }
    };

    const filteredCapturedServices = useMemo(() => {
        const query = serviceFilterText.toLowerCase();
        return Object.entries(capturedServices).filter(([pid, proc]) => {
            const name = (proc.name || "").toLowerCase();
            const ports = (proc.ports || []).join(" ");
            const user = (proc.user || "").toLowerCase();
            return pid.includes(query) || name.includes(query) || ports.includes(query) || user.includes(query);
        });
    }, [capturedServices, serviceFilterText]);

    // 🚀 Lancement & Purge des logs précédents
    const handleLaunch = async (e: React.FormEvent) => {
        e.preventDefault();

        if (isSimulating || isConnected) {
            toast.error("⚠️ Une simulation est déjà active !");
            return;
        }

        // PURGE EXPLICITE DE LA SESSION PRÉCÉDENTE
        resetSimulation();
        setError(null);

        const parsedReconPorts = reconPorts.split(",").map(p => Number(p.trim())).filter(p => !isNaN(p) && p > 0);
        const parsedExcludedPorts = excludedPorts.split(",").map(p => Number(p.trim())).filter(p => !isNaN(p));
        const parsedExcludedPids = excludedPids.split(",").map(p => Number(p.trim())).filter(p => !isNaN(p));
        const parsedExcludedNames = excludedNames.split(",").map(n => n.trim()).filter(Boolean);

        const parsedSshUsers = sshUsers.split(",").map(u => u.trim()).filter(Boolean);
        const parsedSshPasswords = sshPasswords.split(",").map(p => p.trim()).filter(Boolean);

        let defaultServicesPayload: Record<string, number[]> | null = null;
        if (enableFakeServices) {
            defaultServicesPayload = {
                ssh: fakeSshPorts.split(",").map(p => Number(p.trim())).filter(p => !isNaN(p)),
                ftp: fakeFtpPorts.split(",").map(p => Number(p.trim())).filter(p => !isNaN(p)),
                http: fakeHttpPorts.split(",").map(p => Number(p.trim())).filter(p => !isNaN(p)),
            };
        }

        const simConfig: SimConfig = {
            recon: {
                port_range: parsedReconPorts.length > 0 ? parsedReconPorts : undefined,
                timeout_socket: reconTimeout,
            },
            ssh: {
                usernames: parsedSshUsers,
                passwords: parsedSshPasswords,
                max_attempts: sshMaxAttempts,
            },
            reverse_shell: {
                attaquant_ip: attackerIp,
                attaquant_port: attackerPort,
            },
            persistence: {
                cron_script_path: cronScriptPath,
                ssh_key_algo: sshKeyAlgo,
            },
            exfiltration: {
                c2_url: c2Url,
            },
            lateral_movement: {
                max_depth: lateralMaxDepth,
                max_workers: lateralMaxWorkers,
            }
        };

        const payload: StartSimRequest = {
            image: selectedImage,
            mode: mode,
            use_llm: useLlm,
            container_name: containerName.trim() || null,
            network_caps: networkCaps,
            authorize_network: authorizeNetwork,
            auto_capture: serviceSource === "auto",
            default_services: defaultServicesPayload,
            services: serviceSource === "custom" ? customServicesObj : (serviceSource === "auto" && Object.keys(capturedServices).length > 0 ? capturedServices : null),
            only_listening: onlyListening,
            use_default_excludes: useDefaultExcludes,
            capture_excluded_names: parsedExcludedNames.length > 0 ? parsedExcludedNames : null,
            capture_excluded_ports: parsedExcludedPorts.length > 0 ? parsedExcludedPorts : null,
            capture_excluded_pids: parsedExcludedPids.length > 0 ? parsedExcludedPids : null,
            sim_config: simConfig,
        };

        const res = await startSimulation(
            payload, 
            null, 
            (err: string | null) => { if (err) setError(err); }, 
            setLoading, 
            navigate
        );

        if (res && res.session_id) {
            toast.success(`🚀 Simulation démarrée (${res.session_id}) !`);

            const wsProto = window.location.protocol === "https:" ? "wss:" : "ws:";
            const baseUrl = (conf?.apiBaseUrl || window.location.host)
                .replaceAll("http://", "")
                .replaceAll("https://", "")
                .replace(/\/$/, "");

            const cleanRoute = simWsRoute.startsWith("/") ? simWsRoute.slice(1) : simWsRoute;
            const wsUrl = `${wsProto}//${baseUrl}/${cleanRoute}/${res.session_id}?token=${encodeURIComponent(getToken())}`;

            useSimulateurAttaqueWSStore.getState().connect(wsUrl);
            if (onStarted) onStarted();
        }
    };

    const isBusy = isSimulating || isConnected;

    return (
        <div id="sml-container" className="sml-container">
            <div className="scl-header">
                <h2 className="scl-header__title">
                    <Play size={24} /> 🚀 Nouvelle Simulation d'Attaque
                </h2>
                <p className="scl-header__subtitle">
                    Configurez le bac à sable Docker cible et lancez la chaîne offensive MITRE ATT&CK (Automatique ou Opérateur Interactif).
                </p>
            </div>

            {error && (
                <div className="sml-error-box">
                    <span>❌ {error}</span>
                </div>
            )}

            <form className="sml-form" onSubmit={handleLaunch}>
                {/* ── 1. Cible Docker ─────────────────────────────────────────── */}
                <div className="sml-section">
                    <div className="sml-section__header">
                        <Box size={18} />
                        <h3 className="sml-section__title">1. Image Cible & Conteneur</h3>
                    </div>

                    <div className="sml-grid-2">
                        <div className="sml-group">
                            <label className="sml-label">Image Docker Cible</label>
                            <div style={{ display: "flex", gap: "8px" }}>
                                <select
                                    className="sml-select"
                                    style={{ flex: 1 }}
                                    value={selectedImage}
                                    onChange={(e) => setSelectedImage(e.target.value)}
                                    disabled={isBusy}
                                >
                                    {images.length > 0 ? (
                                        images.map((img) => {
                                            const tag = img.tags.find(t => t && t !== "<none>") || img.tags[0];
                                            return (
                                                <option key={img.id} value={tag}>
                                                    🐳 {tag} ({img.size_human})
                                                </option>
                                            );
                                        })
                                    ) : (
                                        <option value="ubuntu:22.04">ubuntu:22.04</option>
                                    )}
                                </select>
                                <button type="button" className="simatk-btn" onClick={fetchImages}>
                                    <RefreshCw size={13} />
                                </button>
                            </div>
                        </div>

                        <div className="sml-group">
                            <label className="sml-label">Nom du Conteneur Cible</label>
                            <div className="sml-input-wrapper">
                                <input
                                    type="text"
                                    className="sml-input"
                                    value={containerName}
                                    onChange={(e) => setContainerName(e.target.value)}
                                    disabled={isBusy}
                                />
                                <button
                                    type="button"
                                    className="simatk-btn"
                                    onClick={() => setContainerName(generateRandomContainerName())}
                                    title="Générer un nom aléatoire"
                                >
                                    <RotateCcw size={12} />
                                </button>
                            </div>
                        </div>
                    </div>

                    <div className="sml-checkbox-grid">
                        <label className="sml-checkbox-item">
                            <input
                                type="checkbox"
                                checked={networkCaps}
                                onChange={(e) => setNetworkCaps(e.target.checked)}
                            />
                            <span>Capacités Réseau (NET_RAW / NET_ADMIN)</span>
                        </label>

                        <label className="sml-checkbox-item">
                            <input
                                type="checkbox"
                                checked={authorizeNetwork}
                                onChange={(e) => setAuthorizeNetwork(e.target.checked)}
                            />
                            <span>Autoriser Accès Réseau Externe (Bridge)</span>
                        </label>
                    </div>
                </div>

                {/* ── 2. Mode d'Exécution & IA ──────────────────────────────────── */}
                <div className="sml-section">
                    <div className="sml-section__header">
                        <Zap size={18} />
                        <h3 className="sml-section__title">2. Mode d'Exécution & Copilote IA</h3>
                    </div>

                    <div className="sml-mode-cards">
                        <div
                            className={`sml-mode-card ${mode === "auto" ? "sml-mode-card--active" : ""}`}
                            onClick={() => !isBusy && setMode("auto")}
                        >
                            <div className="sml-mode-card__top">
                                <span>🚀 Mode Automatique</span>
                                {mode === "auto" && <span className="oh-badge oh-badge--accent">Sélectionné</span>}
                            </div>
                            <p className="sml-mode-card__desc">
                                L'orchestrateur autonome déroule toutes les tactiques du kill chain via le graphe LangGraph.
                            </p>
                        </div>

                        <div
                            className={`sml-mode-card ${mode === "interactive" ? "sml-mode-card--active" : ""}`}
                            onClick={() => !isBusy && setMode("interactive")}
                        >
                            <div className="sml-mode-card__top">
                                <span>🎮 Mode Interactif (Opérateur)</span>
                                {mode === "interactive" && <span className="oh-badge oh-badge--accent">Sélectionné</span>}
                            </div>
                            <p className="sml-mode-card__desc">
                                Vous déclenchez manuellement chaque étape avec l'aide et les suggestions en temps réel de l'IA.
                            </p>
                        </div>
                    </div>

                    <label className="sml-checkbox-item" style={{ marginTop: 6 }}>
                        <input
                            type="checkbox"
                            checked={useLlm}
                            onChange={(e) => setUseLlm(e.target.checked)}
                        />
                        <span>🤖 Activer le Copilote IA (Avis et suggestions de tactiques)</span>
                    </label>
                </div>

                {/* ── 3. Services & Environnement Cible ─────────────────────────── */}
                <div className="sml-section">
                    <div className="sml-section__header">
                        <Layers size={18} />
                        <h3 className="sml-section__title">3. Services & Environnement Cible</h3>
                    </div>

                    <div className="sml-services-box">
                        <div className="sml-source-selector">
                            <button
                                type="button"
                                className={`sml-source-btn ${serviceSource === "auto" ? "active" : ""}`}
                                onClick={() => setServiceSource("auto")}
                            >
                                🔍 Capture Automatique du Host
                            </button>
                            <button
                                type="button"
                                className={`sml-source-btn ${serviceSource === "custom" ? "active" : ""}`}
                                onClick={() => setServiceSource("custom")}
                            >
                                📁 Importer services.json
                            </button>
                            <button
                                type="button"
                                className={`sml-source-btn ${serviceSource === "none" ? "active" : ""}`}
                                onClick={() => setServiceSource("none")}
                            >
                                🚫 Conteneur Vierge (Sans services)
                            </button>
                        </div>

                        {serviceSource === "auto" && (
                            <div className="sml-source-content">
                                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 10 }}>
                                    <div>
                                        <strong style={{ fontSize: "0.9rem" }}>Inspection des processus du système hôte</strong>
                                        <div style={{ fontSize: "0.78rem", color: "var(--text-tertiary)" }}>
                                            Reconstitue les processus et bannières réseau du host dans le conteneur.
                                        </div>
                                    </div>

                                    <div style={{ display: "flex", gap: "8px" }}>
                                        <button type="button" className="simatk-btn" onClick={handleCapture}>
                                            <RefreshCw size={13} /> Pré-capturer
                                        </button>
                                        {Object.keys(capturedServices).length > 0 && (
                                            <button
                                                type="button"
                                                className="simatk-btn"
                                                onClick={() => setShowCapturedPreview(!showCapturedPreview)}
                                            >
                                                {showCapturedPreview ? <EyeOff size={13} /> : <Eye size={13} />}
                                                {showCapturedPreview ? "Masquer" : `Aperçu (${Object.keys(capturedServices).length})`}
                                            </button>
                                        )}
                                    </div>
                                </div>

                                <div className="sml-checkbox-grid" style={{ marginTop: 4 }}>
                                    <label className="sml-checkbox-item">
                                        <input
                                            type="checkbox"
                                            checked={onlyListening}
                                            onChange={(e) => setOnlyListening(e.target.checked)}
                                        />
                                        <span>Ne capturer que les ports en écoute (LISTEN)</span>
                                    </label>

                                    <label className="sml-checkbox-item">
                                        <input
                                            type="checkbox"
                                            checked={useDefaultExcludes}
                                            onChange={(e) => setUseDefaultExcludes(e.target.checked)}
                                        />
                                        <span>Exclure les utilitaires desktop / GUI</span>
                                    </label>
                                </div>

                                {showCapturedPreview && Object.keys(capturedServices).length > 0 && (
                                    <div style={{ display: "flex", flexDirection: "column", gap: "8px", marginTop: "8px" }}>
                                        <input
                                            type="text"
                                            className="sml-input-wrapper"
                                            style={{ padding: "6px 12px", fontSize: "0.8rem" }}
                                            placeholder="Filtrer les services (nom, port, pid)..."
                                            value={serviceFilterText}
                                            onChange={(e) => setServiceFilterText(e.target.value)}
                                        />

                                        <div className="sml-captured-table-wrapper">
                                            <table className="sml-captured-table">
                                                <thead>
                                                    <tr>
                                                        <th>PID</th>
                                                        <th>Processus</th>
                                                        <th>Ports (LISTEN)</th>
                                                        <th>Utilisateur</th>
                                                        <th>Commande</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {filteredCapturedServices.map(([pid, proc]) => (
                                                        <tr key={pid}>
                                                            <td style={{ fontFamily: "var(--font-mono)", fontWeight: 700 }}>{pid}</td>
                                                            <td><strong style={{ color: "var(--text-primary)" }}>{proc.name}</strong></td>
                                                            <td style={{ color: proc.ports?.length > 0 ? "var(--success)" : "var(--text-tertiary)" }}>
                                                                {proc.ports?.length > 0 ? `[${proc.ports.join(", ")}]` : "—"}
                                                            </td>
                                                            <td>{proc.user || "—"}</td>
                                                            <td style={{ fontFamily: "var(--font-mono)", fontSize: "0.72rem", maxWidth: "260px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                                                                {(proc.cmdline || []).join(" ")}
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                )}
                            </div>
                        )}

                        {serviceSource === "custom" && (
                            <div className="sml-source-content">
                                {customServicesFile ? (
                                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                                        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                                            <FileCheck size={20} style={{ color: "var(--success)" }} />
                                            <span><strong>{customServicesFile.name}</strong> ({Object.keys(customServicesObj || {}).length} services prêts)</span>
                                        </div>
                                        <button type="button" className="simatk-btn" style={{ color: "var(--danger)" }} onClick={() => { setCustomServicesFile(null); setCustomServicesObj(null); }}>
                                            <Trash2 size={13} /> Supprimer
                                        </button>
                                    </div>
                                ) : (
                                    <label className="sml-upload-box">
                                        <UploadCloud size={30} style={{ color: "var(--accent)", margin: "0 auto 6px" }} />
                                        <div style={{ fontSize: "0.88rem", color: "var(--text-primary)" }}>
                                            Glissez votre fichier <strong>services.json</strong> ici
                                        </div>
                                        <input type="file" accept=".json" onChange={handleServicesFileUpload} />
                                    </label>
                                )}
                            </div>
                        )}

                        {/* Fake Services Honeypots */}
                        <div style={{ borderTop: "1px solid var(--border)", paddingTop: "14px" }}>
                            <label className="sml-checkbox-item" style={{ background: "transparent", border: "none", padding: 0 }}>
                                <input
                                    type="checkbox"
                                    checked={enableFakeServices}
                                    onChange={(e) => setEnableFakeServices(e.target.checked)}
                                />
                                <span style={{ fontWeight: 700, color: "var(--text-primary)" }}>
                                    📦 Déployer des Fake Services (Honeypots SSH / FTP / HTTP)
                                </span>
                            </label>

                            {enableFakeServices && (
                                <div className="sml-fake-grid">
                                    <div className="sml-fake-card">
                                        <div className="sml-fake-card__header">
                                            <span>🔑 Fake SSH</span>
                                            <span className="oh-badge oh-badge--accent">Port</span>
                                        </div>
                                        <input
                                            type="text"
                                            className="sml-fake-card__input"
                                            value={fakeSshPorts}
                                            onChange={(e) => setFakeSshPorts(e.target.value)}
                                            placeholder="22"
                                        />
                                    </div>

                                    <div className="sml-fake-card">
                                        <div className="sml-fake-card__header">
                                            <span>📁 Fake FTP</span>
                                            <span className="oh-badge oh-badge--accent">Port</span>
                                        </div>
                                        <input
                                            type="text"
                                            className="sml-fake-card__input"
                                            value={fakeFtpPorts}
                                            onChange={(e) => setFakeFtpPorts(e.target.value)}
                                            placeholder="21"
                                        />
                                    </div>

                                    <div className="sml-fake-card">
                                        <div className="sml-fake-card__header">
                                            <span>🌐 Fake HTTP</span>
                                            <span className="oh-badge oh-badge--accent">Ports</span>
                                        </div>
                                        <input
                                            type="text"
                                            className="sml-fake-card__input"
                                            value={fakeHttpPorts}
                                            onChange={(e) => setFakeHttpPorts(e.target.value)}
                                            placeholder="80, 8080"
                                        />
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* ── 4. Tuning Avancé des 9 Tactiques ──────────────────────────── */}
                <div className="sml-section">
                    <div className="sml-tuning-toggle" onClick={() => setShowTuning((p) => !p)}>
                        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <Sliders size={18} />
                            <span>Tuning Fin des 9 Tactiques MITRE ATT&CK</span>
                        </div>
                        {showTuning ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                    </div>

                    {showTuning && (
                        <div className="sml-adv-body">
                            <div className="sml-grid-2">
                                <div className="sml-group">
                                    <label className="sml-label">Ports à Scanner (Reconnaissance)</label>
                                    <input
                                        type="text"
                                        className="sml-input-wrapper"
                                        style={{ padding: "8px 12px" }}
                                        value={reconPorts}
                                        onChange={(e) => setReconPorts(e.target.value)}
                                    />
                                </div>

                                <div className="sml-group">
                                    <label className="sml-label">Timeout Socket Scan (s)</label>
                                    <input
                                        type="number"
                                        step={0.05}
                                        className="sml-input-wrapper"
                                        style={{ padding: "8px 12px" }}
                                        value={reconTimeout}
                                        onChange={(e) => setReconTimeout(Number(e.target.value))}
                                    />
                                </div>
                            </div>

                            <div className="sml-grid-2">
                                <div className="sml-group">
                                    <label className="sml-label">Utilisateurs SSH (Initial Access)</label>
                                    <input
                                        type="text"
                                        className="sml-input-wrapper"
                                        style={{ padding: "8px 12px" }}
                                        value={sshUsers}
                                        onChange={(e) => setSshUsers(e.target.value)}
                                    />
                                </div>

                                <div className="sml-group">
                                    <label className="sml-label">Mots de passe SSH (Initial Access)</label>
                                    <input
                                        type="text"
                                        className="sml-input-wrapper"
                                        style={{ padding: "8px 12px" }}
                                        value={sshPasswords}
                                        onChange={(e) => setSshPasswords(e.target.value)}
                                    />
                                </div>
                            </div>

                            <div className="sml-grid-2">
                                <div className="sml-group">
                                    <label className="sml-label">IP Listener (Reverse Shell)</label>
                                    <input
                                        type="text"
                                        className="sml-input-wrapper"
                                        style={{ padding: "8px 12px" }}
                                        value={attackerIp}
                                        onChange={(e) => setAttackerIp(e.target.value)}
                                    />
                                </div>

                                <div className="sml-group">
                                    <label className="sml-label">Port Listener (Reverse Shell)</label>
                                    <input
                                        type="number"
                                        className="sml-input-wrapper"
                                        style={{ padding: "8px 12px" }}
                                        value={attackerPort}
                                        onChange={(e) => setAttackerPort(Number(e.target.value))}
                                    />
                                </div>
                            </div>

                            <div className="sml-grid-2">
                                <div className="sml-group">
                                    <label className="sml-label">URL Serveur C2 (Exfiltration)</label>
                                    <input
                                        type="text"
                                        className="sml-input-wrapper"
                                        style={{ padding: "8px 12px" }}
                                        value={c2Url}
                                        onChange={(e) => setC2Url(e.target.value)}
                                    />
                                </div>

                                <div className="sml-group">
                                    <label className="sml-label">Algorithme Clé SSH (Persistence)</label>
                                    <select
                                        className="sml-select"
                                        value={sshKeyAlgo}
                                        onChange={(e) => setSshKeyAlgo(e.target.value)}
                                    >
                                        <option value="Ed25519">Ed25519 (Recommandé)</option>
                                        <option value="RSA">RSA 2048</option>
                                        <option value="ECDSA">ECDSA</option>
                                    </select>
                                </div>
                            </div>

                            <div className="sml-grid-2">
                                <div className="sml-group">
                                    <label className="sml-label">Profondeur Max BFS (Mouvement Latéral)</label>
                                    <input
                                        type="number"
                                        min={1}
                                        max={10}
                                        className="sml-input-wrapper"
                                        style={{ padding: "8px 12px" }}
                                        value={lateralMaxDepth}
                                        onChange={(e) => setLateralMaxDepth(Number(e.target.value))}
                                    />
                                </div>

                                <div className="sml-group">
                                    <label className="sml-label">Workers Parallèles (Mouvement Latéral)</label>
                                    <input
                                        type="number"
                                        min={1}
                                        max={20}
                                        className="sml-input-wrapper"
                                        style={{ padding: "8px 12px" }}
                                        value={lateralMaxWorkers}
                                        onChange={(e) => setLateralMaxWorkers(Number(e.target.value))}
                                    />
                                </div>
                            </div>
                        </div>
                    )}
                </div>

                {/* Bouton de Soumission */}
                <div className="sml-actions">
                    <button
                        type="submit"
                        className="oh-btn oh-btn--primary"
                        style={{ padding: "12px 32px", fontSize: "1rem" }}
                        disabled={loading || isBusy || !selectedImage}
                    >
                        {loading ? (
                            <>⏳ Démarrage en cours...</>
                        ) : isBusy ? (
                            <>🔒 Simulation en cours</>
                        ) : (
                            <>
                                <Play size={18} /> 🚀 Déployer & Lancer l'Attaque
                            </>
                        )}
                    </button>
                </div>
            </form>
        </div>
    );
}

export default SimLauncherComponent;