import { useState, useEffect, useMemo } from "react";
import "./containers_view.css";
import { 
    ContainerInfo, 
    ContainerExecResponse, 
    ContainerCreateRequest,
    DockerImageInfo,
    NetworkInfo 
} from "@/types/simulateur_attaque/types";
import { 
    getContainersList, 
    stopDockerContainer, 
    execInContainer, 
    createDockerContainer, 
    getDockerImages,
    getNetworksList,
    connectContainerToNet,
    disconnectContainerFromNet,
    moveContainerBetweenNets
} from "../utils";
import { simNetworkContainersRoute } from "@/hooks/backend_routes";
import { getConfig, AppConfig } from "@/hooks/get_config";
import { getToken } from "@/hooks/get_token";
import { useNavigate } from "react-router-dom";
import { 
    Box, 
    Square, 
    Terminal, 
    RefreshCw, 
    Plus, 
    Lock,
    Network as NetworkIcon,
    RotateCcw,
    ChevronDown,
    Unlink,
    Link as LinkIcon,
    Copy,
    Check,
    AlertCircle,
    CheckCircle2,
    Search,
    ArrowRightLeft,
    Shield,
    Trash2
} from "lucide-react";
import toast from "react-hot-toast";

function generateRandomContainerName(): string {
    const id = Array.from(crypto.getRandomValues(new Uint8Array(4)))
        .map(b => b.toString(16).padStart(2, "0"))
        .join("");
    return `simatk_target_${id}`;
}

const PROTECTED_NETWORKS = ["bridge", "host", "none", "isolated"];

export function ContainersViewComponent() {
    const navigate = useNavigate();
    const [conf, setConf] = useState<AppConfig | null>(null);
    const [containers, setContainers] = useState<ContainerInfo[]>([]);
    const [loading, setLoading] = useState<boolean>(false);
    const [filterType, setFilterType] = useState<"all" | "user">("all");
    const [searchQuery, setSearchQuery] = useState<string>("");

    // Données de création
    const [availableImages, setAvailableImages] = useState<DockerImageInfo[]>([]);
    const [availableNetworks, setAvailableNetworks] = useState<NetworkInfo[]>([]);

    // Modale de Création
    const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
    const [createImage, setCreateImage] = useState<string>("ubuntu:22.04");
    const [createName, setCreateName] = useState<string>(generateRandomContainerName());
    const [createNetwork, setCreateNetwork] = useState<string>("bridge");
    const [capNetRaw, setCapNetRaw] = useState<boolean>(true);
    const [capNetAdmin, setCapNetAdmin] = useState<boolean>(true);
    const [creating, setCreating] = useState<boolean>(false);

    // Modale Exec Shell
    const [activeContainer, setActiveContainer] = useState<string | null>(null);
    const [execCommand, setExecCommand] = useState<string>("whoami");
    const [execOutput, setExecOutput] = useState<ContainerExecResponse | null>(null);
    const [execTab, setExecTab] = useState<"stdout" | "stderr">("stdout");
    const [copiedExec, setCopiedExec] = useState<boolean>(false);
    const [executing, setExecuting] = useState<boolean>(false);
    const [cmdHistory, setCmdHistory] = useState<string[]>(["whoami", "id", "uname -a", "ip a", "netstat -tuln"]);

    // Modale Gestion Réseaux du Conteneur
    const [netModalContainer, setNetModalContainer] = useState<ContainerInfo | null>(null);
    const [attachedNetsDetails, setAttachedNetsDetails] = useState<Array<{ name: string; ip: string; subnet?: string }>>([]);
    const [selectedNetToJoin, setSelectedNetToJoin] = useState<string>("");
    const [moveSourceNet, setMoveSourceNet] = useState<string>("");
    const [moveDestNet, setMoveDestNet] = useState<string>("");
    const [netActionLoading, setNetActionLoading] = useState<boolean>(false);

    useEffect(() => {
        getConfig().then(setConf);
    }, []);

    const fetchContainers = () => {
        getContainersList(
            undefined, 
            (data: any) => setContainers(data?.containers || []), 
            (err: string | null) => { if (err) toast.error(err); }, 
            setLoading, 
            navigate
        );
    };

    useEffect(() => {
        fetchContainers();
    }, []);

    // ── Inspection réelle des réseaux rattachés au conteneur ──
    const handleOpenNetModal = async (container: ContainerInfo) => {
        setNetModalContainer(container);
        setNetActionLoading(true);

        getNetworksList(false, async (data: any) => {
            const allNets: NetworkInfo[] = (data?.networks || []).filter((n: NetworkInfo) => n.name !== "none");
            setAvailableNetworks(allNets);

            if (!conf?.apiBaseUrl) {
                setNetActionLoading(false);
                return;
            }

            // Interrogation de tous les réseaux en parallèle pour trouver ceux contenant ce conteneur
            const cleanRoute = simNetworkContainersRoute.startsWith("/") 
                ? simNetworkContainersRoute.slice(1) 
                : simNetworkContainersRoute;

            const attachedList: Array<{ name: string; ip: string; subnet?: string }> = [];

            await Promise.all(
                allNets.map(async (net) => {
                    try {
                        const res = await fetch(`${conf.apiBaseUrl}/${cleanRoute}/${encodeURIComponent(net.name)}/containers`, {
                            headers: { Authorization: `Bearer ${getToken()}` }
                        });
                        if (res.ok) {
                            const json = await res.json();
                            const found = (json?.containers || []).find((c: any) => c.name === container.name || c.id === container.id);
                            if (found) {
                                attachedList.push({
                                    name: net.name,
                                    ip: found.ip || "IP dynamique",
                                    subnet: net.subnet || undefined
                                });
                            }
                        }
                    } catch {}
                })
            );

            // Si aucune liaison trouvée par l'API, fallback sur le réseau bridge
            if (attachedList.length === 0) {
                attachedList.push({ name: "bridge", ip: container.ip || "127.0.0.1" });
            }

            setAttachedNetsDetails(attachedList);

            const attachedNames = attachedList.map(a => a.name);
            const unattachedNets = allNets.filter(n => !attachedNames.includes(n.name));
            if (unattachedNets.length > 0) {
                setSelectedNetToJoin(unattachedNets[0].name);
            } else {
                setSelectedNetToJoin("");
            }

            if (attachedList.length > 0) {
                setMoveSourceNet(attachedList[0].name);
            }
            if (unattachedNets.length > 0) {
                setMoveDestNet(unattachedNets[0].name);
            }

            setNetActionLoading(false);
        }, () => setNetActionLoading(false), null, navigate);
    };

    const handleConnectNet = async () => {
        if (!netModalContainer || !selectedNetToJoin) return;
        setNetActionLoading(true);

        const res = await connectContainerToNet(selectedNetToJoin, { container_name: netModalContainer.name }, null, (err: string | null) => { if (err) toast.error(err); }, null, navigate);
        setNetActionLoading(false);

        if (res?.success) {
            toast.success(`Conteneur raccordé au réseau ${selectedNetToJoin} !`);
            handleOpenNetModal(netModalContainer);
            fetchContainers();
        }
    };

    const handleDisconnectNet = async (netName: string) => {
        if (!netModalContainer) return;
        setNetActionLoading(true);

        const res = await disconnectContainerFromNet(netName, netModalContainer.name, false, null, (err: string | null) => { if (err) toast.error(err); }, null, navigate);
        setNetActionLoading(false);

        if (res?.success) {
            toast.success(`Déconnecté du réseau ${netName}`);
            handleOpenNetModal(netModalContainer);
            fetchContainers();
        }
    };

    const handleMoveNet = async () => {
        if (!netModalContainer || !moveSourceNet || !moveDestNet) return;
        if (moveSourceNet === moveDestNet) {
            toast.error("Le réseau source et destination doivent être différents");
            return;
        }

        setNetActionLoading(true);
        const res = await moveContainerBetweenNets({
            container_name: netModalContainer.name,
            source_network: moveSourceNet,
            destination_network: moveDestNet,
            force: false
        }, null, (err: string | null) => { if (err) toast.error(err); }, null, navigate);
        setNetActionLoading(false);

        if (res?.success) {
            toast.success(`Déplacé de ${moveSourceNet} vers ${moveDestNet}`);
            handleOpenNetModal(netModalContainer);
            fetchContainers();
        }
    };

    const handleOpenCreateModal = () => {
        setCreateName(generateRandomContainerName());
        setShowCreateModal(true);

        getDockerImages((data: any) => {
            if (data?.images) {
                const valid = data.images.filter(
                    (img: DockerImageInfo) => img.tags && img.tags.length > 0 && img.tags.some(t => t && t !== "<none>")
                );
                setAvailableImages(valid);
                if (valid.length > 0) {
                    const tag = valid[0].tags.find((t: string) => t && t !== "<none>");
                    if (tag) setCreateImage(tag);
                }
            }
        }, () => {}, null, navigate);

        getNetworksList(false, (data: any) => {
            const filtered = (data?.networks || []).filter((n: NetworkInfo) => n.name !== "none");
            setAvailableNetworks(filtered);
            if (filtered.length > 0) setCreateNetwork(filtered[0].name);
        }, () => {}, null, navigate);
    };

    const handleCreateContainer = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!createImage.trim()) return;

        setCreating(true);
        const caps: string[] = [];
        if (capNetRaw) caps.push("NET_RAW");
        if (capNetAdmin) caps.push("NET_ADMIN");

        const req: ContainerCreateRequest = {
            image: createImage.trim(),
            name: createName.trim() || null,
            network: createNetwork,
            cap_add: caps.length > 0 ? caps : null,
        };

        const res = await createDockerContainer(req, null, (err: string | null) => { if (err) toast.error(err); }, null, navigate);
        setCreating(false);

        if (res?.success) {
            toast.success(`Conteneur ${res.container?.name || ""} déployé avec succès !`);
            setShowCreateModal(false);
            fetchContainers();
        }
    };

    const handleStop = async (name: string) => {
        const res = await stopDockerContainer(name, null, (err: string | null) => { if (err) toast.error(err); }, null, navigate);
        if (res?.success) {
            toast.success(`Conteneur ${name} arrêté et nettoyé`);
            fetchContainers();
        }
    };

    // ── Envoi de la commande brute directe sans emballage bash ──
    const handleExec = async () => {
        if (!activeContainer || !execCommand.trim()) return;
        setExecuting(true);

        const rawCmd = execCommand.trim();

        // Mémorisation dans l'historique local
        if (!cmdHistory.includes(rawCmd)) {
            setCmdHistory(prev => [rawCmd, ...prev.slice(0, 8)]);
        }

        const res = await execInContainer(
            activeContainer, 
            rawCmd, 
            (out) => {
                setExecOutput(out);
                if (out?.exit_code !== 0 && out?.stderr) {
                    setExecTab("stderr");
                } else {
                    setExecTab("stdout");
                }
            }, 
            (err: string | null) => { if (err) toast.error(err); }, 
            null, 
            navigate
        );
        setExecuting(false);
    };

    const handleCopyOutput = async () => {
        const textToCopy = execTab === "stdout" ? execOutput?.stdout : execOutput?.stderr;
        if (!textToCopy) return;
        try {
            await navigator.clipboard.writeText(textToCopy);
            setCopiedExec(true);
            toast.success(`📋 Sortie ${execTab.toUpperCase()} copiée !`);
            setTimeout(() => setCopiedExec(false), 1200);
        } catch {
            toast.error("Impossible de copier");
        }
    };

    const filteredContainers = useMemo(() => {
        return containers.filter((c) => {
            const isSimatkUser = c.is_simatk || c.labels?.["simatk.owner"] === "user" || c.name.startsWith("simatk_");
            if (filterType === "user" && !isSimatkUser) return false;

            const q = searchQuery.toLowerCase();
            return c.name.toLowerCase().includes(q) || c.image.toLowerCase().includes(q) || (c.ip || "").includes(q);
        });
    }, [containers, filterType, searchQuery]);

    const unattachedNetsForModal = useMemo(() => {
        const attachedNames = attachedNetsDetails.map(a => a.name);
        return availableNetworks.filter(n => !attachedNames.includes(n.name));
    }, [availableNetworks, attachedNetsDetails]);

    return (
        <div id="smc-container" className="simatk-subview">
            {/* Header & Filtres */}
            <div className="simatk-subview__header">
                <div className="simatk-subview__left">
                    <h2 className="simatk-subview__title">
                        <Box size={24} /> 🐳 Gestionnaire de Conteneurs Docker
                    </h2>
                    <p className="simatk-subview__subtitle">
                        Déployez des conteneurs cibles, inspectez leurs IP réseau réelles ou envoyez des commandes shell.
                    </p>
                </div>

                <div style={{ display: "flex", gap: "8px", alignItems: "center", flexWrap: "wrap" }}>
                    <div className="smc-filter-group">
                        <button
                            type="button"
                            className={`smc-filter-btn ${filterType === "all" ? "active" : ""}`}
                            onClick={() => setFilterType("all")}
                        >
                            Tous ({containers.length})
                        </button>
                        <button
                            type="button"
                            className={`smc-filter-btn ${filterType === "user" ? "active" : ""}`}
                            onClick={() => setFilterType("user")}
                        >
                            Mes Cibles Lab ({containers.filter(c => c.is_simatk || c.labels?.["simatk.owner"] === "user" || c.name.startsWith("simatk_")).length})
                        </button>
                    </div>

                    <button className="oh-btn oh-btn--primary" type="button" onClick={handleOpenCreateModal}>
                        <Plus size={14} /> Déployer Conteneur
                    </button>
                    <button className="simatk-btn" type="button" onClick={fetchContainers} disabled={loading}>
                        <RefreshCw size={14} className={loading ? "oh-spin" : ""} />
                    </button>
                </div>
            </div>

            {/* Barre de Recherche */}
            <div className="smc-search-bar">
                <Search size={16} style={{ color: "var(--text-tertiary)" }} />
                <input
                    type="text"
                    className="smc-search-input"
                    placeholder="Filtrer les conteneurs par nom, image Docker ou adresse IP..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
                {searchQuery && (
                    <button type="button" className="scl-btn-inline" onClick={() => setSearchQuery("")}>
                        Effacer
                    </button>
                )}
            </div>

            {/* Grille des Conteneurs */}
            <div className="smc-grid">
                {filteredContainers.length === 0 ? (
                    <div className="apu-empty" style={{ gridColumn: "1 / -1" }}>
                        <Box size={36} style={{ color: "var(--text-tertiary)" }} />
                        <h4 style={{ margin: 0 }}>Aucun conteneur ne correspond à votre filtre</h4>
                        <p style={{ color: "var(--text-secondary)", fontSize: "0.85rem" }}>
                            Déployez une nouvelle cible ou réinitialisez les critères de recherche.
                        </p>
                    </div>
                ) : (
                    filteredContainers.map((c) => {
                        const isSimatkUser = c.is_simatk || c.labels?.["simatk.owner"] === "user" || c.name.startsWith("simatk_");

                        return (
                            <div key={c.id} className={`smc-card ${!isSimatkUser ? "smc-card--locked" : ""}`}>
                                <div className="smc-card__top">
                                    <span className="smc-card__name" title={c.name}>{c.name}</span>
                                    <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                                        <span className={`oh-badge ${c.status === "running" ? "oh-badge--success" : "oh-badge--warning"}`}>
                                            <span className={`smc-status-dot ${c.status === "running" ? "smc-status-dot--pulse" : ""}`} />
                                            {c.status}
                                        </span>
                                        {!isSimatkUser && (
                                            <span className="simatk-badge--locked" title="Conteneur système non modifiable">
                                                <Lock size={10} /> Protégé
                                            </span>
                                        )}
                                    </div>
                                </div>

                                <div className="smc-card__body">
                                    <div className="smc-card__info-row">
                                        <span>Image :</span>
                                        <strong className="smc-mono" title={c.image}>{c.image}</strong>
                                    </div>
                                    <div className="smc-card__info-row">
                                        <span>IP Hôte :</span>
                                        <strong className="smc-mono" style={{ color: "var(--accent-strong)" }}>{c.ip || "Non attribuée"}</strong>
                                    </div>
                                    <div className="smc-card__info-row">
                                        <span>Espace Disque :</span>
                                        <span>{c.size_human}</span>
                                    </div>
                                </div>

                                <div className="smc-card__actions">
                                    <button
                                        type="button"
                                        className={`simatk-btn ${!isSimatkUser ? "simatk-btn--locked" : ""}`}
                                        onClick={() => {
                                            setActiveContainer(c.name);
                                            setExecOutput(null);
                                        }}
                                        disabled={!isSimatkUser}
                                        title={!isSimatkUser ? "Action impossible : conteneur externe protégé" : "Ouvrir un shell distant"}
                                    >
                                        <Terminal size={13} /> Shell Exec
                                    </button>

                                    <button
                                        type="button"
                                        className={`simatk-btn ${!isSimatkUser ? "simatk-btn--locked" : ""}`}
                                        onClick={() => handleOpenNetModal(c)}
                                        disabled={!isSimatkUser}
                                        title={!isSimatkUser ? "Action impossible : conteneur externe protégé" : "Inspecter et gérer les segments réseaux"}
                                    >
                                        <NetworkIcon size={13} /> Réseaux
                                    </button>

                                    <button
                                        type="button"
                                        className={`simatk-btn ${!isSimatkUser ? "simatk-btn--locked" : ""}`}
                                        style={{ color: isSimatkUser ? "var(--danger)" : "var(--text-tertiary)" }}
                                        onClick={() => handleStop(c.name)}
                                        disabled={!isSimatkUser}
                                        title={!isSimatkUser ? "Action impossible : conteneur externe protégé" : "Arrêter et détruire le conteneur"}
                                    >
                                        <Square size={13} /> Arrêter
                                    </button>
                                </div>
                            </div>
                        );
                    })
                )}
            </div>

            {/* ── MODALE GESTION RÉSEAUX DU CONTENEUR ENRICHI ── */}
            {netModalContainer && (
                <div className="smc-modal-overlay" onClick={() => setNetModalContainer(null)}>
                    <div className="smc-modal-box" style={{ maxWidth: 580 }} onClick={(e) => e.stopPropagation()}>
                        <div className="smc-modal-header">
                            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                <NetworkIcon size={18} style={{ color: "var(--accent)" }} />
                                <h4>Segments Réseaux : {netModalContainer.name}</h4>
                            </div>
                            <button className="smc-close-btn" onClick={() => setNetModalContainer(null)}>✕</button>
                        </div>

                        <div className="smc-modal-body">
                            {/* 1. Réseaux Connectés Réels */}
                            <div className="smc-net-modal-section">
                                <span className="smc-net-modal-title">
                                    <LinkIcon size={14} style={{ color: "var(--success)" }} /> Réseaux Actuellement Raccordés ({attachedNetsDetails.length})
                                </span>

                                <div className="smc-net-list">
                                    {netActionLoading ? (
                                        <div style={{ padding: "12px", textAlign: "center", color: "var(--text-tertiary)" }}>
                                            <RefreshCw size={18} className="oh-spin" /> Inspection des liaisons...
                                        </div>
                                    ) : (
                                        attachedNetsDetails.map((net) => {
                                            const isSingle = attachedNetsDetails.length <= 1;
                                            const isProtected = PROTECTED_NETWORKS.includes(net.name);
                                            const canDisconnect = !isSingle && !isProtected;

                                            return (
                                                <div key={net.name} className="smc-net-item">
                                                    <div className="smc-net-item__info">
                                                        <span className="smc-net-item__name">🌐 {net.name}</span>
                                                        <span className="smc-net-item__ip">IP : {net.ip} {net.subnet ? `(${net.subnet})` : ""}</span>
                                                    </div>

                                                    <button
                                                        type="button"
                                                        className="smn-disconnect-btn"
                                                        disabled={!canDisconnect || netActionLoading}
                                                        onClick={() => handleDisconnectNet(net.name)}
                                                        title={isSingle ? "Impossible de déconnecter l'unique réseau du conteneur" : isProtected ? "Réseau système protégé" : "Déconnecter de ce segment"}
                                                    >
                                                        <Unlink size={12} /> {isSingle ? "Réseau Unique" : "Déconnecter"}
                                                    </button>
                                                </div>
                                            );
                                        })
                                    )}
                                </div>
                            </div>

                            {/* 2. Raccorder à un Nouveau Réseau (Menu filtré avec réseaux non encore connectés) */}
                            <div className="smc-net-modal-section">
                                <span className="smc-net-modal-title">
                                    <Plus size={14} style={{ color: "var(--accent)" }} /> Raccorder à un autre réseau du Lab
                                </span>

                                {unattachedNetsForModal.length === 0 ? (
                                    <div className="smc-net-empty-hint">
                                        ℹ️ Ce conteneur est déjà connecté à tous les réseaux disponibles du Lab.
                                    </div>
                                ) : (
                                    <div style={{ display: "flex", gap: 8 }}>
                                        <select
                                            className="sml-select"
                                            style={{ flex: 1 }}
                                            value={selectedNetToJoin}
                                            onChange={(e) => setSelectedNetToJoin(e.target.value)}
                                            disabled={netActionLoading}
                                        >
                                            {unattachedNetsForModal.map(n => (
                                                <option key={n.id} value={n.name}>
                                                    {n.name} {n.internal ? "(Isolé)" : "(Bridge)"}
                                                </option>
                                            ))}
                                        </select>
                                        <button
                                            type="button"
                                            className="oh-btn oh-btn--primary"
                                            onClick={handleConnectNet}
                                            disabled={!selectedNetToJoin || netActionLoading}
                                        >
                                            Connecter
                                        </button>
                                    </div>
                                )}
                            </div>

                            {/* 3. Déplacement direct d'un réseau vers un autre */}
                            {attachedNetsDetails.length > 0 && unattachedNetsForModal.length > 0 && (
                                <div className="smc-net-modal-section">
                                    <span className="smc-net-modal-title">
                                        <ArrowRightLeft size={14} style={{ color: "var(--warning)" }} /> Déplacer (Transition réseau)
                                    </span>

                                    <div style={{ display: "grid", gridTemplateColumns: "1fr auto 1fr auto", gap: 8, alignItems: "center" }}>
                                        <select
                                            className="sml-select"
                                            value={moveSourceNet}
                                            onChange={(e) => setMoveSourceNet(e.target.value)}
                                            disabled={netActionLoading}
                                        >
                                            {attachedNetsDetails.map(n => (
                                                <option key={n.name} value={n.name}>{n.name}</option>
                                            ))}
                                        </select>

                                        <span style={{ color: "var(--text-tertiary)" }}>➔</span>

                                        <select
                                            className="sml-select"
                                            value={moveDestNet}
                                            onChange={(e) => setMoveDestNet(e.target.value)}
                                            disabled={netActionLoading}
                                        >
                                            {unattachedNetsForModal.map(n => (
                                                <option key={n.name} value={n.name}>{n.name}</option>
                                            ))}
                                        </select>

                                        <button
                                            type="button"
                                            className="simatk-btn"
                                            onClick={handleMoveNet}
                                            disabled={netActionLoading || moveSourceNet === moveDestNet}
                                        >
                                            Déplacer
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* ── MODALE CRÉATION DE CONTENEUR ── */}
            {showCreateModal && (
                <div className="smc-modal-overlay" onClick={() => setShowCreateModal(false)}>
                    <div className="smc-modal-box" onClick={(e) => e.stopPropagation()}>
                        <div className="smc-modal-header">
                            <h4>🐳 Déployer un Nouveau Conteneur</h4>
                            <button className="smc-close-btn" onClick={() => setShowCreateModal(false)}>✕</button>
                        </div>

                        <form onSubmit={handleCreateContainer} className="smc-modal-body">
                            <div className="sml-group">
                                <label className="sml-label">Image Docker</label>
                                <select
                                    className="sml-select"
                                    value={createImage}
                                    onChange={(e) => setCreateImage(e.target.value)}
                                    required
                                >
                                    {availableImages.map((img) => {
                                        const tag = img.tags.find(t => t && t !== "<none>") || img.tags[0];
                                        return (
                                            <option key={img.id} value={tag}>
                                                {tag} ({img.size_human})
                                            </option>
                                        );
                                    })}
                                </select>
                            </div>

                            <div className="sml-group">
                                <label className="sml-label">Nom du Conteneur</label>
                                <div className="sml-input-wrapper">
                                    <input
                                        type="text"
                                        className="sml-input"
                                        value={createName}
                                        onChange={(e) => setCreateName(e.target.value)}
                                        placeholder="Nom automatique si vide"
                                    />
                                    <button
                                        type="button"
                                        className="simatk-btn"
                                        onClick={() => setCreateName(generateRandomContainerName())}
                                        title="Générer un autre nom"
                                    >
                                        <RotateCcw size={12} />
                                    </button>
                                </div>
                            </div>

                            <div className="sml-group">
                                <label className="sml-label">Réseau Initial</label>
                                <select
                                    className="sml-select"
                                    value={createNetwork}
                                    onChange={(e) => setCreateNetwork(e.target.value)}
                                >
                                    {availableNetworks.map((net) => (
                                        <option key={net.id} value={net.name}>
                                            {net.name} {net.internal ? "(Isolé)" : "(Bridge)"}
                                        </option>
                                    ))}
                                </select>
                            </div>

                            <div style={{ display: "flex", gap: 16, marginTop: 4 }}>
                                <label className="sml-checkbox-item">
                                    <input
                                        type="checkbox"
                                        checked={capNetRaw}
                                        onChange={(e) => setCapNetRaw(e.target.checked)}
                                    />
                                    <span>NET_RAW (Sockets bruts / Ping)</span>
                                </label>
                                <label className="sml-checkbox-item">
                                    <input
                                        type="checkbox"
                                        checked={capNetAdmin}
                                        onChange={(e) => setCapNetAdmin(e.target.checked)}
                                    />
                                    <span>NET_ADMIN (Routage)</span>
                                </label>
                            </div>

                            <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 12 }}>
                                <button type="button" className="simatk-btn" onClick={() => setShowCreateModal(false)}>
                                    Annuler
                                </button>
                                <button type="submit" className="oh-btn oh-btn--primary" disabled={creating || !createImage.trim()}>
                                    {creating ? "Déploiement..." : "Créer le Conteneur"}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* ── MODALE TERMINAL EXEC (COMMANDE DIRECTE & HISTORIQUE) ── */}
            {activeContainer && (
                <div className="smc-modal-overlay" onClick={() => setActiveContainer(null)}>
                    <div className="smc-modal-box" style={{ maxWidth: 700 }} onClick={(e) => e.stopPropagation()}>
                        <div className="smc-modal-header">
                            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                <Terminal size={18} style={{ color: "var(--accent)" }} />
                                <h4>Shell Distant : {activeContainer}</h4>
                            </div>
                            <button className="smc-close-btn" onClick={() => setActiveContainer(null)}>✕</button>
                        </div>

                        <div className="smc-modal-body">
                            {/* Raccourcis commandes fréquentes */}
                            <div className="smc-quick-cmds">
                                <span style={{ fontSize: "0.74rem", color: "var(--text-tertiary)" }}>Raccourcis :</span>
                                {cmdHistory.map((cmd, i) => (
                                    <button
                                        key={i}
                                        type="button"
                                        className="smc-quick-btn"
                                        onClick={() => setExecCommand(cmd)}
                                    >
                                        {cmd}
                                    </button>
                                ))}
                            </div>

                            <div style={{ display: "flex", gap: "8px" }}>
                                <div className="sml-input-wrapper" style={{ flex: 1 }}>
                                    <Terminal size={15} style={{ color: "var(--text-tertiary)" }} />
                                    <input
                                        type="text"
                                        className="sml-input"
                                        style={{ fontFamily: "var(--font-mono)", fontSize: "0.88rem" }}
                                        value={execCommand}
                                        onChange={(e) => setExecCommand(e.target.value)}
                                        placeholder="Commande brute (ex: whoami, cat /etc/passwd, id)..."
                                        onKeyDown={(e) => e.key === "Enter" && handleExec()}
                                    />
                                </div>
                                <button type="button" className="oh-btn oh-btn--primary" onClick={handleExec} disabled={executing}>
                                    {executing ? "..." : "Exécuter"}
                                </button>
                            </div>

                            {/* Boîte de Sortie Stylisée */}
                            {execOutput && (
                                <div className="smc-exec-box">
                                    <div className="smc-exec-header">
                                        <span className={`smc-exec-code-badge ${execOutput.exit_code === 0 ? "smc-exec-code-badge--ok" : "smc-exec-code-badge--error"}`}>
                                            {execOutput.exit_code === 0 ? <CheckCircle2 size={13} /> : <AlertCircle size={13} />}
                                            Exit Code : {execOutput.exit_code}
                                        </span>
                                        <button type="button" className="scl-btn-inline" onClick={handleCopyOutput}>
                                            {copiedExec ? <Check size={12} /> : <Copy size={12} />}
                                            {copiedExec ? "Copié !" : `Copier ${execTab.toUpperCase()}`}
                                        </button>
                                    </div>

                                    <div className="smc-exec-tabs">
                                        <button
                                            type="button"
                                            className={`smc-exec-tab smc-exec-tab--stdout ${execTab === "stdout" ? "active" : ""}`}
                                            onClick={() => setExecTab("stdout")}
                                        >
                                            Stdout {execOutput.stdout ? `(${execOutput.stdout.length} car.)` : "(vide)"}
                                        </button>
                                        <button
                                            type="button"
                                            className={`smc-exec-tab smc-exec-tab--stderr ${execTab === "stderr" ? "active" : ""}`}
                                            onClick={() => setExecTab("stderr")}
                                        >
                                            Stderr {execOutput.stderr ? `(${execOutput.stderr.length} car.)` : "(0)"}
                                        </button>
                                    </div>

                                    <div className={`smc-exec-body ${execTab === "stdout" ? "smc-exec-body--stdout" : "smc-exec-body--stderr"}`}>
                                        {execTab === "stdout" ? (
                                            execOutput.stdout || <span className="smc-exec-empty">(Sortie standard vide)</span>
                                        ) : (
                                            execOutput.stderr || <span className="smc-exec-empty">(Aucune erreur standard générée)</span>
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

export default ContainersViewComponent;