import { logError } from "@/hooks/error_utils";
import { getToken, refreshToken } from "@/hooks/get_token";
import { useNavigate } from "react-router-dom";
import {
  simStart,
  simStop,
  simGetStatus,
  simListActive,
  simGetReport,
  simGetActions,
  simListImages,
  simStartClone,
  simGetCloneStatus,
  simStopClone,
  simCaptureServices,
  simValidateServices,
  simListContainers,
  simCreateContainer,
  simStopContainer,
  simExecContainer,
  simListNetworks,
  simCreateNetwork,
  simRemoveNetwork,
  simConnectNetwork,
  simDisconnectNetwork,
  simMoveNetwork
} from "@/hooks/fetch_functions";

import {
  StartSimRequest,
  StartSimResponse,
  StopSimResponse,
  SimStatusResponse,
  AvailableActionsResponse,
  SimulationReport,
  DockerImageInfo,
  ContainerInfo,
  ContainerCreateRequest,
  ContainerExecResponse,
  NetworkInfo,
  NetworkCreateRequest,
  NetworkConnectRequest,
  NetworkMoveRequest,
  CloneRequest,
  CloneStatusResponse,
  ValidateServicesResponse
} from "@/types/simulateur_attaque/types";

async function withAuthRetry<T>(
  apiCall: (token: string) => Promise<{ ok: boolean; response: any; error?: string }>,
  setResult: ((val: T | null) => void) | null,
  setError: ((err: string | null) => void) | null,
  setLoading: ((loading: boolean) => void) | null = null,
  navigate?: ReturnType<typeof useNavigate>
): Promise<T | null> {
  try {
    if (setLoading) setLoading(true);
    if (setError) setError(null);

    const result = await apiCall(getToken());
    if (result.ok) {
      if (setResult) setResult(result.response);
      return result.response as T;
    }

    if (result.response?.detail === "TOKEN_EXPIRED" && navigate) {
      const refreshed = await refreshToken(getToken(), navigate);
      if (refreshed) return withAuthRetry(apiCall, setResult, setError, setLoading, navigate);
    }

    const err = result.error || result.response?.detail || "Une erreur est survenue";
    if (setError) setError(err);
    if (setResult) setResult(null);
    return null;
  } catch (e: any) {
    const msg = logError(e);
    if (setError) setError(msg);
    if (setResult) setResult(null);
    return null;
  } finally {
    if (setLoading) setLoading(false);
  }
}

// ─── Simulations ─────────────────────────────────────────────────────────────
export const startSimulation = (data: StartSimRequest, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<StartSimResponse>((t) => simStart(data, t), setResult, setError, setLoading, nav);

export const stopSimulation = (sessionId: string, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<StopSimResponse>((t) => simStop(sessionId, t), setResult, setError, setLoading, nav);

export const getSimulationStatus = (sessionId: string, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<SimStatusResponse>((t) => simGetStatus(sessionId, t), setResult, setError, setLoading, nav);

export const getActiveSimulations = (setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<{ sims: SimStatusResponse[] }>((t) => simListActive(t), setResult, setError, setLoading, nav);

export const getSimulationReport = (sessionId: string, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<SimulationReport>((t) => simGetReport(sessionId, t), setResult, setError, setLoading, nav);

export const getAvailableActions = (sessionId: string, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<AvailableActionsResponse>((t) => simGetActions(sessionId, t), setResult, setError, setLoading, nav);

// ─── Images & Clonage ────────────────────────────────────────────────────────
export const getDockerImages = (setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<{ images: DockerImageInfo[] }>((t) => simListImages(t), setResult, setError, setLoading, nav);

export const startSystemClone = (data: CloneRequest, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<{ clone_id: string; status: string; message: string }>((t) => simStartClone(data, t), setResult, setError, setLoading, nav);

export const getCloneStatus = (cloneId: string, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<CloneStatusResponse>((t) => simGetCloneStatus(cloneId, t), setResult, setError, setLoading, nav);

export const stopSystemClone = (cloneId: string, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<{ clone_id: string; status: string }>((t) => simStopClone(cloneId, t), setResult, setError, setLoading, nav);

export const captureHostServices = (setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<{ services: Record<string, any> }>((t) => simCaptureServices(t), setResult, setError, setLoading, nav);

export const validateServicesConfig = (services: Record<string, any>, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<ValidateServicesResponse>((t) => simValidateServices(services, t), setResult, setError, setLoading, nav);

// ─── Conteneurs ──────────────────────────────────────────────────────────────
export const getContainersList = (running: boolean | undefined, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<{ total: number; containers: ContainerInfo[] }>((t) => simListContainers(t, running), setResult, setError, setLoading, nav);

export const createDockerContainer = (data: ContainerCreateRequest, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<{ success: boolean; container: any; message: string }>((t) => simCreateContainer(data, t), setResult, setError, setLoading, nav);

export const stopDockerContainer = (name: string, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<{ success: boolean; container: string; message: string }>((t) => simStopContainer(name, t), setResult, setError, setLoading, nav);

export const execInContainer = (name: string, command: string | string[], setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<ContainerExecResponse>((t) => simExecContainer(name, { command }, t), setResult, setError, setLoading, nav);

// ─── Réseaux Docker (Lab) ────────────────────────────────────────────────────
export const getNetworksList = (onlySimatk: boolean, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<{ total: number; networks: NetworkInfo[] }>((t) => simListNetworks(t, onlySimatk), setResult, setError, setLoading, nav);

export const createDockerNetwork = (data: NetworkCreateRequest, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<{ success: boolean; network: any; message: string; error?: string }>((t) => simCreateNetwork(data, t), setResult, setError, setLoading, nav);

export const removeDockerNetwork = (name: string, force: boolean, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<{ success: boolean; network: string; message: string }>((t) => simRemoveNetwork(name, force, t), setResult, setError, setLoading, nav);

export const connectContainerToNet = (networkName: string, data: NetworkConnectRequest, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<{ success: boolean; container: string; network: string; ip?: string }>((t) => simConnectNetwork(networkName, data, t), setResult, setError, setLoading, nav);

export const disconnectContainerFromNet = (networkName: string, containerName: string, force: boolean, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<{ success: boolean; message: string }>((t) => simDisconnectNetwork(networkName, containerName, force, t), setResult, setError, setLoading, nav);

export const moveContainerBetweenNets = (data: NetworkMoveRequest, setResult: any, setError: any, setLoading: any, nav: any) =>
  withAuthRetry<{ success: boolean; message: string; ip?: string }>((t) => simMoveNetwork(data, t), setResult, setError, setLoading, nav);