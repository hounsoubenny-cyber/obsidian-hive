import { useState, useEffect, useMemo } from "react";
import "./networks_view.css";
import { NetworkInfo, NetworkCreateRequest, NetworkContainerInfo } from "@/types/simulateur_attaque/types";
import { 
    getNetworksList, 
    createDockerNetwork, 
    removeDockerNetwork,
    disconnectContainerFromNet 
} from "../utils";
import { simNetworkContainersRoute } from "@/hooks/backend_routes";
import { getConfig, AppConfig } from "@/hooks/get_config";
import { getToken } from "@/hooks/get_token";
import { useNavigate } from "react-router-dom";
import { 
    Network as NetworkIcon, 
    Plus, 
    Trash2, 
    RefreshCw, 
    Lock, 
    Layers, 
    Box, 
    Unlink, 
    RotateCcw,
    Radio,
    Search,
    Shield,
    Activity
} from "lucide-react";
import toast from "react-hot-toast";

const PROTECTED_SYSTEM_NETWORKS = ["bridge", "host", "none", "isolated"];

function generateRandomNetworkName(): string {
    const id = Array.from(crypto.getRandomValues(new Uint8Array(3)))
        .map(b => b.toString(16).padStart(2, "0"))
        .join("");
    return `simatk_net_${id}`;
}

export function NetworksViewComponent() {
    const navigate = useNavigate();
    const [conf, setConf] = useState<AppConfig | null>(null);
    const [networks, setNetworks] = useState<NetworkInfo[]>([]);
    const [networkCounts, setNetworkCounts] = useState<Record<string, number>>({});
    const [loading, setLoading] = useState<boolean>(false);
    const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
    const [searchQuery, setSearchQuery] = useState<string>("");

    // Topologie & Nœuds Visuels
    const [selectedNetwork, setSelectedNetwork] = useState<NetworkInfo | null>(null);
    const [networkContainers, setNetworkContainers] = useState<NetworkContainerInfo[]>([]);
    const [loadingTopology, setLoadingTopology] = useState<boolean>(false);

    // Formulaire Réseau Simple (sans champ subnet manuel pour éviter erreurs)
    const [netName, setNetName] = useState<string>(generateRandomNetworkName());
    const [driver, setDriver] = useState<"bridge" | "overlay">("bridge");
    const [isInternal, setIsInternal] = useState<boolean>(true);
    const [creating, setCreating] = useState<boolean>(false);

    useEffect(() => {
        getConfig().then(setConf);
    }, []);

    // ── Récupération et comptage précis et découplé ──
    const fetchNetworks = () => {
        getNetworksList(
            false,
            async (data: any) => {
                const rawNets = (data?.networks || []).filter((n: NetworkInfo) => n.name !== "none");
                setNetworks(rawNets);

                // Comptage asynchrone précis pour chaque réseau
                if (conf?.apiBaseUrl) {
                    const cleanRoute = simNetworkContainersRoute.startsWith("/") 
                        ? simNetworkContainersRoute.slice(1) 
                        : simNetworkContainersRoute;

                    const counts: Record<string, number> = {};
                    await Promise.all(
                        rawNets.map(async (n: NetworkInfo) => {
                            try {
                                const res = await fetch(`${conf.apiBaseUrl}/${cleanRoute}/${encodeURIComponent(n.name)}/containers`, {
                                    headers: { Authorization: `Bearer ${getToken()}` }
                                });
                                if (res.ok) {
                                    const json = await res.json();
                                    counts[n.name] = (json?.containers || []).length;
                                }
                            } catch {
                                counts[n.name] = n.containers_count || 0;
                            }
                        })
                    );
                    setNetworkCounts(counts);
                }
            },
            (err: string | null) => { if (err) toast.error(err); },
            setLoading,
            navigate
        );
    };

    useEffect(() => {
        fetchNetworks();
    }, [conf]);

    const handleOpenTopology = async (net: NetworkInfo) => {
        setSelectedNetwork(net);
        setNetworkContainers([]);
        if (!conf?.apiBaseUrl) return;

        setLoadingTopology(true);
        try {
            const cleanRoute = simNetworkContainersRoute.startsWith("/") 
                ? simNetworkContainersRoute.slice(1) 
                : simNetworkContainersRoute;
            const res = await fetch(`${conf.apiBaseUrl}/${cleanRoute}/${encodeURIComponent(net.name)}/containers`, {
                headers: { Authorization: `Bearer ${getToken()}` }
            });
            const json = await res.json();
            const conts = json?.containers || [];
            setNetworkContainers(conts);
            setNetworkCounts(prev => ({ ...prev, [net.name]: conts.length }));
        } catch {
            toast.error("Impossible de charger les conteneurs du réseau");
        } finally {
            setLoadingTopology(false);
        }
    };

    const handleDisconnectNode = async (containerName: string) => {
        if (!selectedNetwork) return;
        const res = await disconnectContainerFromNet(selectedNetwork.name, containerName, false, null, (err: string | null) => { if (err) toast.error(err); }, null, navigate);
        if (res?.success) {
            toast.success(`Conteneur ${containerName} déconnecté du segment`);
            handleOpenTopology(selectedNetwork);
            fetchNetworks();
        }
    };

    const handleCreate = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!netName.trim()) return;

        setCreating(true);
        const req: NetworkCreateRequest = {
            name: netName.trim(),
            driver: driver,
            internal: isInternal,
        };

        const res = await createDockerNetwork(req, null, (err: string | null) => { if (err) toast.error(err); }, null, navigate);
        setCreating(false);

        if (res?.success) {
            toast.success(`Réseau ${netName} créé avec succès !`);
            setNetName(generateRandomNetworkName());
            setShowCreateModal(false);
            fetchNetworks();
        } else {
            toast.error(res?.message || "Erreur création réseau");
        }
    };

    const handleRemove = async (name: string, e: React.MouseEvent) => {
        e.stopPropagation();

        if (PROTECTED_SYSTEM_NETWORKS.includes(name)) {
            toast.error(`Le réseau ${name} est protégé par le système`);
            return;
        }

        const res = await removeDockerNetwork(name, true, null, (err: string | null) => { if (err) toast.error(err); }, null, navigate);
        if (res?.success) {
            toast.success(`Réseau ${name} supprimé`);
            fetchNetworks();
        }
    };

    const filteredNetworks = useMemo(() => {
        const q = searchQuery.toLowerCase();
        return networks.filter(n => n.name.toLowerCase().includes(q) || (n.subnet || "").includes(q));
    }, [networks, searchQuery]);

    return (
        <div id="simatk-networks-container" className="simatk-subview">
            <div className="simatk-subview__header">
                <div className="simatk-subview__left">
                    <h2 className="simatk-subview__title">
                        <NetworkIcon size={24} /> 🌐 Réseaux & Topologie du Lab
                    </h2>
                    <p className="simatk-subview__subtitle">
                        Inspectez la topologie visuelle et les conteneurs connectés sur chaque segment réseau.
                    </p>
                </div>

                <div style={{ display: "flex", gap: "8px" }}>
                    <button
                        className="oh-btn oh-btn--primary"
                        type="button"
                        onClick={() => {
                            setNetName(generateRandomNetworkName());
                            setShowCreateModal(true);
                        }}
                    >
                        <Plus size={14} /> Créer un Réseau
                    </button>
                    <button className="simatk-btn" type="button" onClick={fetchNetworks} disabled={loading}>
                        <RefreshCw size={14} className={loading ? "oh-spin" : ""} />
                    </button>
                </div>
            </div>

            {/* Barre de Recherche */}
            <div className="smn-search-bar">
                <Search size={16} style={{ color: "var(--text-tertiary)" }} />
                <input
                    type="text"
                    className="smn-search-input"
                    placeholder="Rechercher un segment réseau par nom ou sous-réseau..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
            </div>

            {/* Grille des Réseaux */}
            <div className="smn-grid">
                {filteredNetworks.map((net) => {
                    const isProtected = PROTECTED_SYSTEM_NETWORKS.includes(net.name);
                    const isSimatkOwner = net.labels?.["simatk.owner"] === "user" || (!isProtected && net.labels?.simatk === "true");
                    const count = networkCounts[net.name] ?? net.containers_count ?? 0;

                    return (
                        <div
                            key={net.id}
                            className="smn-card"
                            onClick={() => handleOpenTopology(net)}
                            title="Inspecter la topologie visuelle de ce réseau"
                        >
                            <div className="smn-card__header">
                                <span className="smn-card__title">{net.name}</span>
                                <div style={{ display: "flex", gap: 6 }}>
                                    <span className={`oh-badge ${net.internal ? "oh-badge--accent" : "oh-badge--info"}`}>
                                        {net.internal ? "🛡️ Isolé" : "🌍 Bridge"}
                                    </span>
                                    {isProtected && (
                                        <span className="simatk-badge--locked" title="Réseau Docker Système">
                                            <Lock size={10} /> Protégé
                                        </span>
                                    )}
                                </div>
                            </div>

                            <div className="smn-card__info-box">
                                <div>Driver : <strong>{net.driver}</strong></div>
                                <div>Subnet : <strong style={{ fontFamily: "var(--font-mono)" }}>{net.subnet || "Auto (IPAM)"}</strong></div>
                                <div>Conteneurs raccordés : <strong style={{ color: count > 0 ? "var(--accent-strong)" : "var(--text-tertiary)" }}>{count}</strong></div>
                            </div>

                            <div className="smn-card__footer">
                                <span className="smn-card__action-view">
                                    <Layers size={13} /> Voir Topologie
                                </span>

                                <button
                                    type="button"
                                    className={`simatk-btn ${isProtected || !isSimatkOwner ? "simatk-btn--locked" : ""}`}
                                    style={{ color: isProtected ? "var(--text-tertiary)" : "var(--danger)" }}
                                    onClick={(e) => handleRemove(net.name, e)}
                                    disabled={isProtected || !isSimatkOwner}
                                >
                                    <Trash2 size={13} /> {isProtected ? "Verrouillé" : "Supprimer"}
                                </button>
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* ── MODALE TOPOLOGIE VISUELLE HAUTE FIDÉLITÉ ── */}
            {selectedNetwork && (
                <div className="smc-modal-overlay" onClick={() => setSelectedNetwork(null)}>
                    <div className="smc-modal-box" style={{ maxWidth: 760 }} onClick={(e) => e.stopPropagation()}>
                        <div className="smc-modal-header">
                            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                <Radio size={18} style={{ color: "var(--accent)" }} />
                                <h4>Topologie Interactive : {selectedNetwork.name}</h4>
                            </div>
                            <button className="smc-close-btn" onClick={() => setSelectedNetwork(null)}>✕</button>
                        </div>

                        <div className="smc-modal-body">
                            <div className="smn-topology-canvas">
                                {/* Hub Central Lumineux */}
                                <div className="smn-hub-node">
                                    <NetworkIcon size={22} className="smn-hub-icon" />
                                    <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
                                        <span className="smn-hub-title">HUB : {selectedNetwork.name}</span>
                                        <span className="smn-hub-sub">
                                            {selectedNetwork.subnet ? `Subnet : ${selectedNetwork.subnet}` : "Allocation IPAM Automatique"} • {selectedNetwork.driver}
                                        </span>
                                    </div>
                                    <span className="oh-badge oh-badge--accent" style={{ marginLeft: "auto" }}>
                                        {networkContainers.length} Hôte{networkContainers.length > 1 ? "s" : ""} Connecté{networkContainers.length > 1 ? "s" : ""}
                                    </span>
                                </div>

                                <div className="smn-topology-bus">
                                    <div className="smn-topology-line-vertical" />
                                </div>

                                {loadingTopology ? (
                                    <div style={{ padding: "36px", textAlign: "center", color: "var(--text-tertiary)" }}>
                                        <RefreshCw size={24} className="oh-spin" />
                                        <p style={{ marginTop: 8, fontSize: "0.85rem" }}>Cartographie du segment en cours...</p>
                                    </div>
                                ) : networkContainers.length === 0 ? (
                                    <div className="smn-empty-topology">
                                        <Box size={28} style={{ color: "var(--text-tertiary)" }} />
                                        <span>Aucun conteneur n'est raccordé à ce segment réseau pour le moment.</span>
                                    </div>
                                ) : (
                                    <div className="smn-nodes-cluster">
                                        {networkContainers.map((c) => {
                                            const isSimatkUser = c.is_simatk || c.labels?.["simatk.owner"] === "user" || c.name.startsWith("simatk_");

                                            return (
                                                <div key={c.id} className={`smn-node-card ${!isSimatkUser ? "smn-node-card--locked" : ""}`}>
                                                    <div className="smn-node-header">
                                                        <span className="smn-node-name" title={c.name}>
                                                            <Box size={14} style={{ color: "var(--accent-strong)" }} /> {c.name}
                                                        </span>
                                                        <span className={`oh-badge ${c.status === "running" ? "oh-badge--success" : "oh-badge--warning"}`} style={{ fontSize: "0.7rem", padding: "1px 6px" }}>
                                                            {c.status}
                                                        </span>
                                                    </div>

                                                    <div className="smn-node-body">
                                                        <div className="smn-node-row">
                                                            <span>IP Réseau :</span>
                                                            <strong className="smn-node-ip">{c.ip || "127.0.0.1"}</strong>
                                                        </div>
                                                        <div className="smn-node-row">
                                                            <span>Image :</span>
                                                            <span className="smn-node-img" title={c.image}>{c.image}</span>
                                                        </div>
                                                    </div>

                                                    <div className="smn-node-footer">
                                                        <button
                                                            type="button"
                                                            className="smn-disconnect-btn"
                                                            onClick={() => handleDisconnectNode(c.name)}
                                                            disabled={!isSimatkUser}
                                                            title={!isSimatkUser ? "Conteneur système non modifiable" : "Déconnecter de ce segment"}
                                                        >
                                                            <Unlink size={12} /> {isSimatkUser ? "Déconnecter" : "Protégé"}
                                                        </button>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* ── MODALE CRÉATION RÉSEAU ── */}
            {showCreateModal && (
                <div className="smc-modal-overlay" onClick={() => setShowCreateModal(false)}>
                    <div className="smc-modal-box" style={{ maxWidth: 480 }} onClick={(e) => e.stopPropagation()}>
                        <div className="smc-modal-header">
                            <h4>🌐 Créer un Réseau Docker pour le Lab</h4>
                            <button className="smc-close-btn" onClick={() => setShowCreateModal(false)}>✕</button>
                        </div>

                        <form onSubmit={handleCreate} className="smc-modal-body">
                            <div className="sml-group">
                                <label className="sml-label">Nom du Réseau</label>
                                <div className="sml-input-wrapper">
                                    <NetworkIcon size={16} />
                                    <input
                                        type="text"
                                        className="sml-input"
                                        value={netName}
                                        onChange={(e) => setNetName(e.target.value)}
                                        required
                                    />
                                    <button
                                        type="button"
                                        className="simatk-btn"
                                        onClick={() => setNetName(generateRandomNetworkName())}
                                        title="Générer un nom aléatoire"
                                    >
                                        <RotateCcw size={12} />
                                    </button>
                                </div>
                            </div>

                            <div className="sml-group">
                                <label className="sml-label">Type de Driver</label>
                                <div className="smn-driver-grid">
                                    <div
                                        className={`smn-driver-card ${driver === "bridge" ? "smn-driver-card--active" : ""}`}
                                        onClick={() => setDriver("bridge")}
                                    >
                                        <span className="smn-driver-card__title">🌉 Bridge (Standard)</span>
                                        <span className="smn-driver-card__desc">Réseau local sur l'hôte, idéal pour relier les cibles du Lab.</span>
                                    </div>
                                    <div
                                        className={`smn-driver-card ${driver === "overlay" ? "smn-driver-card--active" : ""}`}
                                        onClick={() => setDriver("overlay")}
                                    >
                                        <span className="smn-driver-card__title">🌐 Overlay</span>
                                        <span className="smn-driver-card__desc">Réseau multi-hôtes pour architectures distribuées.</span>
                                    </div>
                                </div>
                            </div>

                            <label className="sml-checkbox-item" style={{ marginTop: 4 }}>
                                <input
                                    type="checkbox"
                                    checked={isInternal}
                                    onChange={(e) => setIsInternal(e.target.checked)}
                                />
                                <span>🛡️ Réseau Isolé (Interne — Bloque l'accès Internet sortant)</span>
                            </label>

                            <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 12 }}>
                                <button type="button" className="simatk-btn" onClick={() => setShowCreateModal(false)}>
                                    Annuler
                                </button>
                                <button type="submit" className="oh-btn oh-btn--primary" disabled={creating || !netName.trim()}>
                                    {creating ? "Création..." : "Créer le Réseau"}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}

export default NetworksViewComponent;