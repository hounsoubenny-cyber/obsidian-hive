import { useEffect, useState } from "react";
import "./simulateur_attaque.css";
import { SimulateurAttaqueTabType, SimStatusResponse } from "@/types/simulateur_attaque/types";
import { getActiveSimulations } from "./utils";
import { useSimulateurAttaqueWSStore } from "@/store/simulateur_attaque_websocket_store";
import { isLogin } from "@/hooks/get_token";
import { useNavigate, Link } from "react-router-dom";
import { 
    Crosshair, 
    Play, 
    Terminal, 
    Box, 
    Network, 
    FileText, 
    Activity, 
    Trash2, 
    Pin, 
    Sparkles,
    Lock
} from "lucide-react";
import toast from "react-hot-toast";

import SimLauncherComponent from "./launcher/sim_launcher";
import SimLiveComponent from "./live/sim_live";
import ContainersViewComponent from "./containers/containers_view";
import NetworksViewComponent from "./networks/networks_view";
import SimReportsComponent from "./reports/sim_reports";
import SimHealthComponent from "./health/sim_health";

function SimulateurAttaque() {
    const navigate = useNavigate();

    const [defaultTab, setDefaultTab] = useState<SimulateurAttaqueTabType>(() => {
        return (localStorage.getItem("simatk_default_tab") as SimulateurAttaqueTabType) || "launcher";
    });

    const [activeTab, setActiveTab] = useState<SimulateurAttaqueTabType | null>(() => {
        return (localStorage.getItem("simatk_default_tab") as SimulateurAttaqueTabType) || "launcher";
    });

    const { isSimulating, isConnected, sessionId, resetSimulation } = useSimulateurAttaqueWSStore();
    const [activeSimsCount, setActiveSimsCount] = useState<number>(0);
    const [healthLoading, setHealthLoading] = useState<boolean>(false);
    const [healthError, setHealthError] = useState<string | null>(null);

    // 🔒 1. Contrôle d'authentification global
    if (!isLogin()) {
        return (
            <div id="simatk-locked-screen" className="simatk-module">
                <div className="simatk-auth-locked">
                    <Lock size={36} style={{ color: "var(--accent)" }} />
                    <h2>Accès Restreint au Simulateur d'Attaque</h2>
                    <p>
                        Une session authentifiée est requise pour orchestrer des cyber-attaques et manipuler l'infrastructure Docker.
                    </p>
                    <Link to="/login" className="oh-btn oh-btn--primary" style={{ marginTop: 12 }}>
                        Se Connecter
                    </Link>
                </div>
            </div>
        );
    }

    const checkActiveSims = () => {
        getActiveSimulations(
            (data: { sims: SimStatusResponse[] } | null) => {
                setActiveSimsCount(data?.sims?.length || 0);
            },
            setHealthError,
            setHealthLoading,
            navigate
        );
    };

    useEffect(() => {
        checkActiveSims();
        const interval = setInterval(checkActiveSims, 30000);
        return () => clearInterval(interval);
    }, []);

    const handleSetDefaultTab = (tab: SimulateurAttaqueTabType) => {
        setDefaultTab(tab);
        localStorage.setItem("simatk_default_tab", tab);
        toast.success(`📌 Onglet par défaut défini : ${tab}`);
    };

    const isHealthy = !healthError;
    const hasActiveSession = Boolean(sessionId || isSimulating || isConnected);

    return (
        <div id="simatk-module" className="simatk-module">
            {/* Header Global */}
            <header id="simatk-header" className="simatk-header">
                <div className="simatk-header__top">
                    <div className="simatk-header__left">
                        <div className="simatk-header__title">
                            <Crosshair size={26} className="simatk-header__logo-icon" />
                            <span>Simulateur d'Attaque IA</span>
                            <span className="simatk-header__version">MITRE ATT&CK v2.0</span>
                        </div>
                    </div>

                    <div className="simatk-header__right">
                        {hasActiveSession && (
                            <button
                                type="button"
                                className="oh-btn oh-btn--ghost"
                                style={{ color: "var(--danger)", padding: "6px 12px", fontSize: "0.8rem" }}
                                onClick={() => {
                                    resetSimulation();
                                    setActiveTab("launcher");
                                    toast("🧹 Session réinitialisée et logs purgés !");
                                }}
                            >
                                <Trash2 size={13} /> Purger Session
                            </button>
                        )}

                        <div className="simatk-default-selector">
                            <span className="simatk-default-selector__label"><Pin size={12} /> Défaut :</span>
                            <select
                                className="simatk-default-selector__select"
                                value={defaultTab}
                                onChange={(e) => handleSetDefaultTab(e.target.value as SimulateurAttaqueTabType)}
                            >
                                <option value="launcher">🚀 Lancer Simulation</option>
                                <option value="live">⚡ Live & Copilote</option>
                                <option value="containers">🐳 Conteneurs</option>
                                <option value="networks">🌐 Réseaux & Lab</option>
                                <option value="reports">📜 Rapports</option>
                                <option value="health">🩺 Monitoring</option>
                            </select>
                        </div>

                        <div className={`simatk-pulse ${isHealthy ? "simatk-pulse--healthy" : "simatk-pulse--unhealthy"}`}>
                            <span className={`simatk-pulse__dot ${isHealthy ? "simatk-pulse__dot--healthy" : "simatk-pulse__dot--unhealthy"}`} />
                            {healthLoading ? (
                                <span>Contrôle...</span>
                            ) : isHealthy ? (
                                <span>🟢 En ligne ({activeSimsCount} active{activeSimsCount > 1 ? "s" : ""})</span>
                            ) : (
                                <span>🔴 Déconnecté</span>
                            )}
                        </div>
                    </div>
                </div>

                {/* Navigation par Onglets */}
                <nav id="simatk-nav" className="simatk-nav">
                    <button
                        type="button"
                        className={`simatk-nav__btn ${activeTab === "launcher" ? "simatk-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("launcher")}
                    >
                        <Play size={15} /> 🚀 Lancer Simulation
                    </button>

                    <button
                        type="button"
                        className={`simatk-nav__btn ${activeTab === "live" ? "simatk-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("live")}
                    >
                        <Terminal size={15} /> ⚡ Live & Copilote IA
                        {isSimulating && <span className="simatk-nav__badge">Actif</span>}
                    </button>

                    <button
                        type="button"
                        className={`simatk-nav__btn ${activeTab === "containers" ? "simatk-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("containers")}
                    >
                        <Box size={15} /> 🐳 Conteneurs Docker
                    </button>

                    <button
                        type="button"
                        className={`simatk-nav__btn ${activeTab === "networks" ? "simatk-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("networks")}
                    >
                        <Network size={15} /> 🌐 Réseaux & Lab
                    </button>

                    <button
                        type="button"
                        className={`simatk-nav__btn ${activeTab === "reports" ? "simatk-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("reports")}
                    >
                        <FileText size={15} /> 📜 Rapports & Matrice
                    </button>

                    <button
                        type="button"
                        className={`simatk-nav__btn ${activeTab === "health" ? "simatk-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("health")}
                    >
                        <Activity size={15} /> 🩺 Monitoring
                    </button>

                    {activeTab !== null && (
                        <button
                            type="button"
                            className="simatk-nav__btn simatk-nav__btn--close"
                            onClick={() => setActiveTab(null)}
                        >
                            ✖️ Réduire
                        </button>
                    )}
                </nav>
            </header>

            {/* Contenu Principal */}
            <main id="simatk-content" className="simatk-content">
                <section style={{ display: activeTab === "launcher" ? "block" : "none" }}>
                    <SimLauncherComponent onStarted={() => setActiveTab("live")} />
                </section>

                <section style={{ display: activeTab === "live" ? "block" : "none" }}>
                    <SimLiveComponent onShowReports={() => setActiveTab("reports")} />
                </section>

                <section style={{ display: activeTab === "containers" ? "block" : "none" }}>
                    <ContainersViewComponent />
                </section>

                <section style={{ display: activeTab === "networks" ? "block" : "none" }}>
                    <NetworksViewComponent />
                </section>

                <section style={{ display: activeTab === "reports" ? "block" : "none" }}>
                    <SimReportsComponent onNewSim={() => setActiveTab("launcher")} />
                </section>

                <section style={{ display: activeTab === "health" ? "block" : "none" }}>
                    <SimHealthComponent />
                </section>

                {activeTab === null && (
                    <div className="apu-empty" style={{ padding: "60px 20px" }}>
                        <Sparkles size={40} style={{ color: "var(--accent)" }} />
                        <h3 style={{ margin: "14px 0 6px" }}>Module d'Émulation d'Adversaire</h3>
                        <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>
                            Sélectionnez un onglet ci-dessus pour orchestrer une attaque, inspecter le Lab ou visualiser vos rapports MITRE ATT&CK.
                        </p>
                    </div>
                )}
            </main>
        </div>
    );
}

export default SimulateurAttaque;