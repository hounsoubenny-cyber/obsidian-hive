import { useState, useEffect } from "react";
import "./sim_health.css";
import { getActiveSimulations, getContainersList, getNetworksList } from "../utils";
import { useNavigate } from "react-router-dom";
import { Activity, Cpu, Box, Network, RefreshCw, Radio } from "lucide-react";

export function SimHealthComponent() {
    const navigate = useNavigate();
    const [simsCount, setSimsCount] = useState<number>(0);
    const [containersCount, setContainersCount] = useState<number>(0);
    const [networksCount, setNetworksCount] = useState<number>(0);
    const [loading, setLoading] = useState<boolean>(false);

    const fetchAll = async () => {
        setLoading(true);
        await getActiveSimulations((d: any) => setSimsCount(d?.sims?.length || 0), () => {}, null, navigate);
        await getContainersList(undefined, (d: any) => setContainersCount(d?.total || 0), () => {}, null, navigate);
        await getNetworksList(false, (d: any) => setNetworksCount(d?.total || 0), () => {}, null, navigate);
        setLoading(false);
    };

    useEffect(() => {
        fetchAll();
    }, []);

    return (
        <div id="smh-container" className="simatk-subview">
            <div className="simatk-subview__header">
                <div className="simatk-subview__left">
                    <h2 className="simatk-subview__title">
                        <Activity size={24} /> 🩺 Monitoring Système & Moteur IA
                    </h2>
                    <p className="simatk-subview__subtitle">
                        État de santé du démon Docker, des orchestrateurs LangGraph et du serveur LLM local.
                    </p>
                </div>

                <button className="simatk-btn" type="button" onClick={fetchAll} disabled={loading}>
                    <RefreshCw size={14} className={loading ? "oh-spin" : ""} /> Actualiser
                </button>
            </div>

            <div className="smh-grid">
                <div className="smh-card">
                    <div className="smh-card__top">
                        <Radio size={20} style={{ color: "var(--accent)" }} />
                        <h4 className="smh-card__title">Simulations Actives</h4>
                    </div>
                    <div className="smh-card__val">{simsCount}</div>
                    <p className="smh-card__desc">Sessions en cours d'exécution simultanée.</p>
                </div>

                <div className="smh-card">
                    <div className="smh-card__top">
                        <Box size={20} style={{ color: "var(--info)" }} />
                        <h4 className="smh-card__title">Conteneurs Déployés</h4>
                    </div>
                    <div className="smh-card__val">{containersCount}</div>
                    <p className="smh-card__desc">Conteneurs cibles et clones gérés dans Docker.</p>
                </div>

                <div className="smh-card">
                    <div className="smh-card__top">
                        <Network size={20} style={{ color: "var(--success)" }} />
                        <h4 className="smh-card__title">Réseaux Docker</h4>
                    </div>
                    <div className="smh-card__val">{networksCount}</div>
                    <p className="smh-card__desc">Topologies et segments actifs du Lab.</p>
                </div>

                <div className="smh-card">
                    <div className="smh-card__top">
                        <Cpu size={20} style={{ color: "var(--warning)" }} />
                        <h4 className="smh-card__title">Moteur Copilote IA</h4>
                    </div>
                    <div className="smh-card__val" style={{ color: "var(--success)", fontSize: "1.4rem" }}>
                        🟢 Opérationnel
                    </div>
                    <p className="smh-card__desc">Modèle local prêt pour les décisions et reviews.</p>
                </div>
            </div>
        </div>
    );
}

export default SimHealthComponent;