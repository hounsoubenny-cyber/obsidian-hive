import { useState, useEffect, useMemo } from "react";
import "./sim_reports.css";
import { 
    SimulationReport, 
    CompromisedCredential, 
    CompromisedShadowHash, 
    StolenSshKey, 
    LateralHostCompromised,
    RemediationItem,
    ExecutiveSummary
} from "@/types/simulateur_attaque/types";
import { useSimulateurAttaqueWSStore } from "@/store/simulateur_attaque_websocket_store";
import { getSimulationReport } from "../utils";
import { useNavigate } from "react-router-dom";
import { 
    FileText, 
    ShieldAlert, 
    Play, 
    Crosshair, 
    Award, 
    Key,
    Lock,
    Network,
    RefreshCw,
    Download,
    Copy,
    Check,
    ChevronDown,
    ChevronUp,
    Search,
    ChevronLeft,
    ChevronRight,
    FileCode,
    Clock,
    FileCheck2,
    ShieldCheck,
    Layers,
    FolderPlus
} from "lucide-react";
import toast from "react-hot-toast";

interface SimReportsProps {
    onNewSim?: () => void;
}

// ── SYNTHÉTISEUR DE RAPPORT POUR LE MODE INTERACTIF (Uniformisation Auto <-> Interactif) ──
function normalizeSimulationReport(raw: any): SimulationReport {
    if (!raw) return raw;

    // Si le rapport a déjà la structure consolidée (mode Auto)
    if (raw.executive_summary && raw.mitre_attack_matrix) {
        return raw;
    }

    const stepsResults = raw.steps_results || {};
    const targetIp = raw.ip || raw.metadata?.target_ip || "127.0.0.1";

    const report: SimulationReport = {
        metadata: {
            target_ip: targetIp,
            generated_at: raw.ended_at || raw.started_at || new Date().toISOString(),
            status: "Terminé",
            simulator_version: "2.0.0 (Interactif)",
        },
        executive_summary: {
            compromised: false,
            root_access: false,
            credentials_harvested_count: 0,
            lateral_movement_hosts_count: 0,
            persistence_installed_count: 0,
            criticality_level: "FAIBLE",
        },
        mitre_attack_matrix: {},
        compromised_data: {
            ports_discovered: [],
            credentials: [],
            system_hashes: [],
            stolen_ssh_keys: [],
            known_hosts_discovered: [],
            lateral_hosts_compromised: [],
            exfiltrated_payloads_count: 0,
            created_files_on_target: [],
        },
        technical_timeline: [],
        remediation_plan: [],
    };

    // 1. Matrice MITRE & Timeline
    for (const [key, entries] of Object.entries<any[]>(stepsResults)) {
        const [technique, tactic] = key.includes("|") ? key.split("|") : [key, "Action"];
        const hasSuccess = entries.some(e => e.result?.results?.success || e.result?.results?.founds?.length > 0 || e.result?.results?.success_number > 0 || e.result?.severity === "HIGH");

        report.mitre_attack_matrix![tactic] = report.mitre_attack_matrix![tactic] || {};
        report.mitre_attack_matrix![tactic][technique] = {
            status: hasSuccess ? "SUCCÈS" : "ÉCHEC",
            errors: [],
        };

        report.technical_timeline!.push({
            tactic,
            technique,
            success: hasSuccess,
        });

        // Extraction Butin : Reconnaissance
        if (key.includes("Reconnaissance") || key.includes("NetworkServiceDiscover")) {
            for (const entry of entries) {
                const ports = entry.result?.results?.open_ports || [];
                if (ports.length > 0) {
                    report.compromised_data!.ports_discovered = Array.from(new Set([...report.compromised_data!.ports_discovered, ...ports]));
                }
            }
        }

        // Extraction Butin : Initial Access
        if (key.includes("InitialAccess") || key.includes("BruteForce")) {
            for (const entry of entries) {
                const founds = entry.result?.results?.founds || [];
                const service = key.split("|")[0].replace("BruteForce", "").toLowerCase();
                for (const item of founds) {
                    if (service === "http") {
                        report.compromised_data!.credentials.push({
                            service: "http",
                            port: entry.port || 80,
                            username: "[Chemin Trouvé]",
                            password: item.url || item.path || "",
                        });
                    } else {
                        report.compromised_data!.credentials.push({
                            service,
                            port: entry.port || (service === "ssh" ? 22 : 21),
                            username: item.username || "",
                            password: item.password || "",
                        });
                    }
                }
            }
        }

        // Extraction Butin : Privilege Escalation
        if (key.includes("PrivilegeEscalation")) {
            for (const entry of entries) {
                const res = entry.result?.results || {};
                if (res.success_number > 0 || res.exploit_success?.length > 0) {
                    report.executive_summary!.root_access = true;
                }
            }
        }

        // Extraction Butin : Credential Access
        if (key.includes("PasswordFileDump")) {
            for (const entry of entries) {
                const hashes = entry.result?.results?.hashes || [];
                for (const h of hashes) {
                    report.compromised_data!.system_hashes.push({
                        user: h.user,
                        algo: h.algo,
                        hash: h.hash_full || h.hash,
                    });
                }
            }
        }

        if (key.includes("SSHKeyTheft")) {
            for (const entry of entries) {
                const stolen = entry.result?.results?.stolen_keys || [];
                for (const k of stolen) {
                    report.compromised_data!.stolen_ssh_keys.push({
                        name: k.name,
                        source: k.source,
                        type: k.type,
                        usable: Boolean(k.usable),
                    });
                }
                const known = entry.result?.results?.known_hosts || [];
                report.compromised_data!.known_hosts_discovered.push(...known);
            }
        }

        // Extraction Butin : Lateral Movement
        if (key.includes("LateralMovement")) {
            for (const entry of entries) {
                const hosts = entry.result?.results?.sessions || entry.result?.results?.compromised_hosts || {};
                for (const [target, info] of Object.entries<any>(hosts)) {
                    const hostInfo = Array.isArray(info) ? info[0] : info;
                    report.compromised_data!.lateral_hosts_compromised.push({
                        target,
                        user: hostInfo?.username || "root",
                        auth_method: hostInfo?.auth_method || "key",
                    });
                }
            }
        }

        // Extraction Butin : Exfiltration
        if (key.includes("Exfiltration")) {
            for (const entry of entries) {
                report.compromised_data!.exfiltrated_payloads_count += entry.result?.results?.sent_count || 0;
            }
        }

        // Extraction Butin : Persistence
        if (key.includes("Persistence")) {
            for (const entry of entries) {
                if (entry.result?.results?.success || entry.result?.results?.inject?.success) {
                    report.executive_summary!.persistence_installed_count += 1;
                }
            }
        }
    }

    // 2. Calculs du Risque Exécutif
    const credsCount = report.compromised_data!.credentials.length;
    const hashesCount = report.compromised_data!.system_hashes.length;
    const keysCount = report.compromised_data!.stolen_ssh_keys.filter(k => k.usable).length;
    const lateralCount = report.compromised_data!.lateral_hosts_compromised.length;

    report.executive_summary!.credentials_harvested_count = credsCount + hashesCount + keysCount;
    report.executive_summary!.lateral_movement_hosts_count = lateralCount;

    if (credsCount > 0 || hashesCount > 0 || lateralCount > 0) {
        report.executive_summary!.compromised = true;
        report.executive_summary!.criticality_level = "ÉLEVÉ";
    }
    if (report.executive_summary!.root_access) {
        report.executive_summary!.compromised = true;
        report.executive_summary!.criticality_level = "CRITIQUE";
    }

    // 3. Plan de Remédiation
    if (credsCount > 0) {
        report.remediation_plan!.push({
            vulnerability: "Mots de passe par défaut ou faibles découverts lors du brute force",
            impact: "Permet un accès initial non autorisé à la cible.",
            mitigation: "Renforcer les politiques de mot de passe et activer l'authentification par clé SSH avec désactivation des mots de passe.",
        });
    }
    if (report.executive_summary!.root_access) {
        report.remediation_plan!.push({
            vulnerability: "Privilèges Sudo NOPASSWD ou binaires SUID non sécurisés",
            impact: "Élévation de privilèges totale vers le compte root.",
            mitigation: "Auditer /etc/sudoers et retirer les bits SUID non indispensables (chmod u-s).",
        });
    }
    if (keysCount > 0) {
        report.remediation_plan!.push({
            vulnerability: "Clés SSH privées stockées sans mot de passe sur le disque",
            impact: "Rebond et propagation latérale immédiate vers d'autres serveurs du réseau.",
            mitigation: "Chiffrer systématiquement les clés privées SSH avec une passphrase robuste.",
        });
    }
    if (report.executive_summary!.persistence_installed_count > 0) {
        report.remediation_plan!.push({
            vulnerability: "Installation de mécanismes de persistance (Tâches Cron / Clés autorisées)",
            impact: "Maintien d'un accès furtif permanent même après redémarrage.",
            mitigation: "Surveiller les crontabs et auditer ~/.ssh/authorized_keys.",
        });
    }

    if (report.remediation_plan!.length === 0) {
        report.remediation_plan!.push({
            vulnerability: "Aucune vulnérabilité critique majeure exploitée avec succès",
            impact: "Surface d'attaque limitée sur le périmètre scanné.",
            mitigation: "Continuer les audits périodiques et maintenir les composants à jour.",
        });
    }

    return report;
}

// ── Générateur Markdown ──
function generateMarkdownReport(report: SimulationReport): string {
    const meta = report.metadata || {};
    const exec = report.executive_summary || {
        compromised: false,
        root_access: false,
        criticality_level: "FAIBLE",
        credentials_harvested_count: 0,
        persistence_installed_count: 0,
        lateral_movement_hosts_count: 0
    };
    const target = meta.target_ip || report.ip || "Hôte inconnu";
    const date = meta.generated_at || new Date().toISOString();

    let md = `# RAPPORT D'AUDIT D'ÉMULATION D'ADVERSAIRE (SHIELDAI)
**Cible Évaluée :** ${target}  
**Date d'Exécution :** ${date}  
**Niveau de Risque Global :** ${exec.criticality_level}  
**Version Simulateur :** ${meta.simulator_version || "2.0.0"}  

---

## 1. Résumé Exécutif
* **Compromission Confirmée :** ${exec.compromised ? "OUI" : "NON"}
* **Élévation de Privilèges Root :** ${exec.root_access ? "OBTENUE" : "NON OBTENUE"}
* **Identifiants & Secrets Récoltés :** ${exec.credentials_harvested_count}
* **Persistances Implantées :** ${exec.persistence_installed_count}
* **Machines Réseau Compromises (Rebond Latéral) :** ${exec.lateral_movement_hosts_count}

---

## 2. Matrice MITRE ATT&CK
`;

    const matrix = report.mitre_attack_matrix || {};
    for (const [tactic, techniques] of Object.entries(matrix)) {
        md += `\n### Tactique : ${tactic}\n`;
        for (const [tech, detail] of Object.entries(techniques)) {
            md += `- **${tech}** : ${detail.status}\n`;
        }
    }

    const comp = report.compromised_data;
    if (comp) {
        md += `\n---

## 3. Inventaire Technique du Butin Collecté
`;
        if (comp.ports_discovered && comp.ports_discovered.length > 0) {
            md += `\n### Ports Découverts\n- ${comp.ports_discovered.join(", ")}\n`;
        }

        if (comp.credentials && comp.credentials.length > 0) {
            md += `\n### Identifiants\n`;
            for (const c of comp.credentials) {
                md += `- Port \`${c.port}\` (${c.service}) | Utilisateur : \`${c.username}\` | Secret : \`${c.password}\`\n`;
            }
        }

        if (comp.system_hashes && comp.system_hashes.length > 0) {
            md += `\n### Empreintes /etc/shadow\n`;
            for (const h of comp.system_hashes) {
                md += `- Utilisateur : \`${h.user}\` | Algo : \`${h.algo}\` | Hash : \`${h.hash}\`\n`;
            }
        }

        if (comp.stolen_ssh_keys && comp.stolen_ssh_keys.length > 0) {
            md += `\n### Clés SSH Privées Volées\n`;
            for (const k of comp.stolen_ssh_keys) {
                md += `- Nom : \`${k.name}\` | Source : \`${k.source}\` (${k.type}) | Statut : ${k.usable ? "UTILISABLE" : "CHIFFRÉE"}\n`;
            }
        }

        if (comp.lateral_hosts_compromised && comp.lateral_hosts_compromised.length > 0) {
            md += `\n### Rebond Latéral\n`;
            for (const h of comp.lateral_hosts_compromised) {
                md += `- Cible : \`${h.target}\` | Compte : \`${h.user}\` | Auth : \`${h.auth_method}\`\n`;
            }
        }
    }

    const rem = report.remediation_plan || [];
    if (rem.length > 0) {
        md += `\n---

## 4. Plan de Remédiation Prioritaire
`;
        rem.forEach((r, i) => {
            md += `\n### ${i + 1}. ${r.vulnerability}\n`;
            md += `* **Impact :** ${r.impact}\n`;
            md += `* **Mesure Corrective :** ${r.mitigation}\n`;
        });
    }

    return md;
}

export function SimReportsComponent({ onNewSim }: SimReportsProps) {
    const navigate = useNavigate();
    const { report: liveReport, sessionId } = useSimulateurAttaqueWSStore();
    const [rawReport, setRawReport] = useState<any>(liveReport);
    const [loading, setLoading] = useState<boolean>(false);

    // ── Masquer / Afficher les sections ──
    const [showSummary, setShowSummary] = useState<boolean>(true);
    const [showMatrix, setShowMatrix] = useState<boolean>(true);
    const [showCredentials, setShowCredentials] = useState<boolean>(true);
    const [showHashes, setShowHashes] = useState<boolean>(true);
    const [showSshKeys, setShowSshKeys] = useState<boolean>(true);
    const [showLateral, setShowLateral] = useState<boolean>(true);
    const [showTimeline, setShowTimeline] = useState<boolean>(false);
    const [showRemediation, setShowRemediation] = useState<boolean>(true);

    // ── Pagination & Recherche : Identifiants ──
    const [credSearch, setCredSearch] = useState<string>("");
    const [credPage, setCredPage] = useState<number>(1);
    const [credPageSize, setCredPageSize] = useState<number>(10);

    // ── Pagination & Recherche : Hashes Shadow ──
    const [hashSearch, setHashSearch] = useState<string>("");
    const [hashPage, setHashPage] = useState<number>(1);
    const [hashPageSize, setHashPageSize] = useState<number>(5);

    // ── Pagination : Clés SSH ──
    const [sshPage, setSshPage] = useState<number>(1);
    const [sshPageSize, setSshPageSize] = useState<number>(5);

    // ── Pagination : Rebond Latéral ──
    const [lateralPage, setLateralPage] = useState<number>(1);
    const [lateralPageSize, setLateralPageSize] = useState<number>(5);

    // ── États de copie ──
    const [copiedMd, setCopiedMd] = useState<boolean>(false);
    const [copiedJson, setCopiedJson] = useState<boolean>(false);

    const loadReport = async () => {
        if (liveReport) {
            setRawReport(liveReport);
        } else if (sessionId) {
            setLoading(true);
            await getSimulationReport(sessionId, (data: any) => {
                let finalData = data;
                if (data?.report && data.report.executive_summary) {
                    finalData = data.report;
                }
                setRawReport(finalData);
            }, () => {}, setLoading, navigate);
        }
    };

    useEffect(() => {
        loadReport();
    }, [liveReport, sessionId]);

    // 🛡️ Normalisation du rapport (Gère Mode Auto ET Mode Interactif)
    const report: SimulationReport | null = useMemo(() => {
        return normalizeSimulationReport(rawReport);
    }, [rawReport]);

    const allExpanded = showSummary && showMatrix && showCredentials && showHashes && showSshKeys && showLateral && showRemediation;
    const toggleAllSections = () => {
        const target = !allExpanded;
        setShowSummary(target);
        setShowMatrix(target);
        setShowCredentials(target);
        setShowHashes(target);
        setShowSshKeys(target);
        setShowLateral(target);
        setShowTimeline(target);
        setShowRemediation(target);
    };

    const handleDownloadMarkdown = () => {
        if (!report) return;
        const mdContent = generateMarkdownReport(report);
        const blob = new Blob([mdContent], { type: "text/markdown;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        const filename = `audit_${(report.metadata?.target_ip || report.ip || "cible").replace(/\./g, "_")}_${new Date().toISOString().slice(0, 10)}.md`;
        link.setAttribute("download", filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        toast.success(`📄 Rapport téléchargé : ${filename}`);
    };

    const handleDownloadJson = () => {
        if (!report) return;
        const jsonContent = JSON.stringify(report, null, 2);
        const blob = new Blob([jsonContent], { type: "application/json;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        const filename = `audit_${(report.metadata?.target_ip || report.ip || "cible").replace(/\./g, "_")}_${new Date().toISOString().slice(0, 10)}.json`;
        link.setAttribute("download", filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        toast.success(`📦 Export JSON téléchargé : ${filename}`);
    };

    const handleCopyMarkdown = async () => {
        if (!report) return;
        try {
            await navigator.clipboard.writeText(generateMarkdownReport(report));
            setCopiedMd(true);
            toast.success("📋 Rapport Markdown copié dans le presse-papier !");
            setTimeout(() => setCopiedMd(false), 1500);
        } catch {
            toast.error("Impossible de copier le markdown");
        }
    };

    const handleCopyJson = async () => {
        if (!report) return;
        try {
            await navigator.clipboard.writeText(JSON.stringify(report, null, 2));
            setCopiedJson(true);
            toast.success("📋 Données JSON brutes copiées !");
            setTimeout(() => setCopiedJson(false), 1500);
        } catch {
            toast.error("Impossible de copier le JSON");
        }
    };

    if (!report || (!report.executive_summary && !report.steps_results)) {
        return (
            <div className="apu-empty" style={{ padding: "60px 20px" }}>
                <ShieldAlert size={40} style={{ color: "var(--accent)" }} />
                <h3 style={{ margin: "12px 0 6px" }}>Aucun rapport de simulation disponible</h3>
                <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>
                    Lancez ou terminez une simulation pour générer la synthèse MITRE ATT&CK et le plan de remédiation.
                </p>
                {sessionId && (
                    <button type="button" className="simatk-btn" style={{ marginTop: 10 }} onClick={loadReport} disabled={loading}>
                        <RefreshCw size={13} className={loading ? "oh-spin" : ""} /> Recharger le rapport
                    </button>
                )}
                {onNewSim && (
                    <button type="button" className="oh-btn oh-btn--primary" style={{ marginTop: 14 }} onClick={onNewSim}>
                        <Play size={15} /> Démarrer une simulation
                    </button>
                )}
            </div>
        );
    }

    const execSummary = report.executive_summary;
    const mitreMatrix = report.mitre_attack_matrix || {};
    const compromisedData = report.compromised_data;
    const remediationPlan = report.remediation_plan || [];
    const technicalTimeline = report.technical_timeline || [];

    // Pagination : Identifiants
    const filteredCredentials = (compromisedData?.credentials || []).filter((c) => {
        const q = credSearch.toLowerCase();
        return c.service.toLowerCase().includes(q) || String(c.port).includes(q) || c.username.toLowerCase().includes(q) || c.password.toLowerCase().includes(q);
    });
    const totalCredPages = Math.ceil(filteredCredentials.length / credPageSize) || 1;
    const paginatedCredentials = filteredCredentials.slice((credPage - 1) * credPageSize, credPage * credPageSize);

    // Pagination : Hashes
    const filteredHashes = (compromisedData?.system_hashes || []).filter((h) => {
        const q = hashSearch.toLowerCase();
        return h.user.toLowerCase().includes(q) || h.algo.toLowerCase().includes(q) || h.hash.toLowerCase().includes(q);
    });
    const totalHashPages = Math.ceil(filteredHashes.length / hashPageSize) || 1;
    const paginatedHashes = filteredHashes.slice((hashPage - 1) * hashPageSize, hashPage * hashPageSize);

    // Pagination : Clés SSH
    const totalSshKeys = compromisedData?.stolen_ssh_keys || [];
    const totalSshPages = Math.ceil(totalSshKeys.length / sshPageSize) || 1;
    const paginatedSshKeys = totalSshKeys.slice((sshPage - 1) * sshPageSize, sshPage * sshPageSize);

    // Pagination : Rebond Latéral
    const totalLateral = compromisedData?.lateral_hosts_compromised || [];
    const totalLateralPages = Math.ceil(totalLateral.length / lateralPageSize) || 1;
    const paginatedLateral = totalLateral.slice((lateralPage - 1) * lateralPageSize, lateralPage * lateralPageSize);

    return (
        <div id="smr-container" className="smr-container">
            {/* Header & Barre d'Actions d'Exportation */}
            <div className="smr-header-bar">
                <div>
                    <h2 className="scl-header__title">
                        <FileText size={24} /> 📊 Rapport d'Audit MITRE ATT&CK
                    </h2>
                    <p className="scl-header__subtitle">
                        Cible : <strong className="smc-mono">{report.metadata?.target_ip || report.ip || "Hôte"}</strong> • Statut : <span className="oh-badge oh-badge--accent">{report.metadata?.status || "Terminé"}</span>
                    </p>
                </div>

                <div className="smr-actions-toolbar">
                    <button type="button" className="simatk-btn" onClick={toggleAllSections}>
                        {allExpanded ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
                        {allExpanded ? "Tout masquer" : "Tout afficher"}
                    </button>

                    <button type="button" className="simatk-btn" onClick={handleCopyMarkdown}>
                        {copiedMd ? <Check size={13} /> : <Copy size={13} />}
                        {copiedMd ? "Copié !" : "Copier Markdown"}
                    </button>

                    <button type="button" className="simatk-btn" onClick={handleCopyJson}>
                        {copiedJson ? <Check size={13} /> : <FileCode size={13} />}
                        {copiedJson ? "Copié !" : "Copier JSON"}
                    </button>

                    <button type="button" className="oh-btn oh-btn--primary" style={{ padding: "6px 14px", fontSize: "0.8rem" }} onClick={handleDownloadMarkdown}>
                        <Download size={13} /> Exporter .MD
                    </button>

                    <button type="button" className="oh-btn oh-btn--ghost" style={{ padding: "6px 14px", fontSize: "0.8rem" }} onClick={handleDownloadJson}>
                        <Download size={13} /> Exporter .JSON
                    </button>
                </div>
            </div>

            {/* ── 1. RÉSUMÉ EXÉCUTIF & JAUGE DE RISQUE ── */}
            <div className="smr-collapsible-card">
                <div className="smr-collapsible-header" onClick={() => setShowSummary(!showSummary)}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <ShieldAlert size={18} style={{ color: "var(--accent)" }} />
                        <h3 className="smr-section-title">1. Synthèse Exécutive & Score de Risque</h3>
                    </div>
                    {showSummary ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                </div>

                {showSummary && execSummary && (
                    <div className="smr-summary-content">
                        <div className="smr-gauge">
                            <div className="smr-gauge__score" style={{ 
                                color: execSummary.criticality_level === "CRITIQUE" ? "var(--danger)" : execSummary.criticality_level === "ÉLEVÉ" ? "var(--warning)" : "var(--success)" 
                            }}>
                                {execSummary.criticality_level}
                            </div>
                            <span className="smr-gauge__label">Niveau de Risque Global</span>
                        </div>

                        <div className="smr-stats-grid">
                            <div className="smr-stat-box">
                                <span className="smr-stat-box__label">Compromission</span>
                                <span className="smr-stat-box__val" style={{ color: execSummary.compromised ? "var(--danger)" : "var(--success)" }}>
                                    {execSummary.compromised ? "CONFIRMÉE" : "AUCUNE"}
                                </span>
                            </div>
                            <div className="smr-stat-box">
                                <span className="smr-stat-box__label">Accès Root</span>
                                <span className="smr-stat-box__val" style={{ color: execSummary.root_access ? "var(--danger)" : "var(--success)" }}>
                                    {execSummary.root_access ? "OBTENU" : "ÉCHOUÉ"}
                                </span>
                            </div>
                            <div className="smr-stat-box">
                                <span className="smr-stat-box__label">Secrets Récoltés</span>
                                <span className="smr-stat-box__val">{execSummary.credentials_harvested_count}</span>
                            </div>
                            <div className="smr-stat-box">
                                <span className="smr-stat-box__label">Pivots Réseau</span>
                                <span className="smr-stat-box__val">{execSummary.lateral_movement_hosts_count}</span>
                            </div>
                        </div>
                    </div>
                )}
            </div>

            {/* ── 2. MATRICE DES TACTIQUES MITRE ATT&CK ── */}
            {Object.keys(mitreMatrix).length > 0 && (
                <div className="smr-collapsible-card">
                    <div className="smr-collapsible-header" onClick={() => setShowMatrix(!showMatrix)}>
                        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                            <Crosshair size={18} style={{ color: "var(--accent)" }} />
                            <h3 className="smr-section-title">2. Matrice des Tactiques Exécutées ({Object.keys(mitreMatrix).length} Tactiques)</h3>
                        </div>
                        {showMatrix ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                    </div>

                    {showMatrix && (
                        <div className="smr-matrix-grid">
                            {Object.entries(mitreMatrix).map(([tactic, techniques]) => (
                                <div key={tactic} className="smr-tactic-card">
                                    <span className="smr-tactic-card__title">{tactic}</span>
                                    {Object.entries(techniques).map(([tech, detail]) => (
                                        <div key={tech} className="smr-tech-row">
                                            <span>{tech}</span>
                                            <span className={detail.status === "SUCCÈS" ? "smr-tech-status--ok" : "smr-tech-status--fail"}>
                                                {detail.status}
                                            </span>
                                        </div>
                                    ))}
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            )}

            {/* ── 3. INVENTAIRE DU BUTIN & DONNÉES COMPROMISES ── */}
            {compromisedData && (
                <div className="smr-collapsible-card">
                    <div className="smr-collapsible-header" onClick={() => setShowCredentials(!showCredentials)}>
                        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                            <Key size={18} style={{ color: "var(--accent)" }} />
                            <h3 className="smr-section-title">3. Données & Identifiants Récoltés</h3>
                        </div>
                        {showCredentials ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                    </div>

                    {showCredentials && (
                        <div className="smr-collapsible-body">
                            {/* Ports découverts */}
                            {compromisedData.ports_discovered && compromisedData.ports_discovered.length > 0 && (
                                <div className="smr-sub-block">
                                    <h4 className="smr-sub-title">📡 Ports Ouverts Découverts ({compromisedData.ports_discovered.length})</h4>
                                    <div className="smr-pills-list">
                                        {compromisedData.ports_discovered.map(p => (
                                            <span key={p} className="smr-port-pill">Port {p}</span>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* 3.1 Tableau des Identifiants */}
                            {compromisedData.credentials && compromisedData.credentials.length > 0 && (
                                <div className="smr-sub-block">
                                    <div className="smr-table-header-controls">
                                        <h4 className="smr-sub-title">🔑 Identifiants & Accès Directs ({filteredCredentials.length})</h4>
                                        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                                            <div className="smr-search-box">
                                                <Search size={14} style={{ color: "var(--text-tertiary)" }} />
                                                <input
                                                    type="text"
                                                    placeholder="Filtrer identifiants..."
                                                    value={credSearch}
                                                    onChange={(e) => { setCredSearch(e.target.value); setCredPage(1); }}
                                                />
                                            </div>

                                            <select
                                                className="smr-pagesize-select"
                                                value={credPageSize}
                                                onChange={(e) => { setCredPageSize(Number(e.target.value)); setCredPage(1); }}
                                            >
                                                <option value={5}>5 / page</option>
                                                <option value={10}>10 / page</option>
                                                <option value={25}>25 / page</option>
                                                <option value={100}>100 / page</option>
                                            </select>
                                        </div>
                                    </div>

                                    <table className="smr-table">
                                        <thead>
                                            <tr>
                                                <th>Service</th>
                                                <th>Port</th>
                                                <th>Identifiant</th>
                                                <th>Mot de Passe / Chemin</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {paginatedCredentials.map((c, i) => (
                                                <tr key={i}>
                                                    <td><strong>{c.service}</strong></td>
                                                    <td>{c.port}</td>
                                                    <td style={{ color: "var(--success)" }}>{c.username}</td>
                                                    <td className="smc-mono" style={{ color: "var(--danger)" }}>{c.password}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>

                                    <div className="smr-pagination-footer">
                                        <span>Page {credPage} sur {totalCredPages} ({filteredCredentials.length} entrées)</span>
                                        <div style={{ display: "flex", gap: 4 }}>
                                            <button
                                                type="button"
                                                className="simatk-btn"
                                                disabled={credPage <= 1}
                                                onClick={() => setCredPage(p => p - 1)}
                                            >
                                                <ChevronLeft size={13} />
                                            </button>
                                            <button
                                                type="button"
                                                className="simatk-btn"
                                                disabled={credPage >= totalCredPages}
                                                onClick={() => setCredPage(p => p + 1)}
                                            >
                                                <ChevronRight size={13} />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* 3.2 Hashes Shadow */}
                            {compromisedData.system_hashes && compromisedData.system_hashes.length > 0 && (
                                <div className="smr-sub-block">
                                    <div className="smr-table-header-controls">
                                        <h4 className="smr-sub-title">🔒 Empreintes Système (/etc/shadow) ({filteredHashes.length})</h4>
                                        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                                            <div className="smr-search-box">
                                                <Search size={14} style={{ color: "var(--text-tertiary)" }} />
                                                <input
                                                    type="text"
                                                    placeholder="Filtrer hashes..."
                                                    value={hashSearch}
                                                    onChange={(e) => { setHashSearch(e.target.value); setHashPage(1); }}
                                                />
                                            </div>

                                            <select
                                                className="smr-pagesize-select"
                                                value={hashPageSize}
                                                onChange={(e) => { setHashPageSize(Number(e.target.value)); setHashPage(1); }}
                                            >
                                                <option value={5}>5 / page</option>
                                                <option value={10}>10 / page</option>
                                                <option value={50}>50 / page</option>
                                            </select>
                                        </div>
                                    </div>

                                    <table className="smr-table">
                                        <thead>
                                            <tr>
                                                <th>Utilisateur</th>
                                                <th>Algorithme</th>
                                                <th>Hash extrait</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {paginatedHashes.map((h, i) => (
                                                <tr key={i}>
                                                    <td><strong>{h.user}</strong></td>
                                                    <td><span className="oh-badge oh-badge--warning">{h.algo}</span></td>
                                                    <td className="smc-mono" style={{ fontSize: "0.78rem" }}>{h.hash}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>

                                    <div className="smr-pagination-footer">
                                        <span>Page {hashPage} sur {totalHashPages} ({filteredHashes.length} hashes)</span>
                                        <div style={{ display: "flex", gap: 4 }}>
                                            <button
                                                type="button"
                                                className="simatk-btn"
                                                disabled={hashPage <= 1}
                                                onClick={() => setHashPage(p => p - 1)}
                                            >
                                                <ChevronLeft size={13} />
                                            </button>
                                            <button
                                                type="button"
                                                className="simatk-btn"
                                                disabled={hashPage >= totalHashPages}
                                                onClick={() => setHashPage(p => p + 1)}
                                            >
                                                <ChevronRight size={13} />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* 3.3 Clés SSH Volées */}
                            {totalSshKeys.length > 0 && (
                                <div className="smr-sub-block">
                                    <div className="smr-table-header-controls">
                                        <h4 className="smr-sub-title">🗝️ Clés SSH Privées Volées ({totalSshKeys.length})</h4>
                                        <select
                                            className="smr-pagesize-select"
                                            value={sshPageSize}
                                            onChange={(e) => { setSshPageSize(Number(e.target.value)); setSshPage(1); }}
                                        >
                                            <option value={5}>5 / page</option>
                                            <option value={10}>10 / page</option>
                                        </select>
                                    </div>

                                    <table className="smr-table">
                                        <thead>
                                            <tr>
                                                <th>Nom</th>
                                                <th>Source</th>
                                                <th>Type</th>
                                                <th>État</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {paginatedSshKeys.map((k, i) => (
                                                <tr key={i}>
                                                    <td><strong>{k.name}</strong></td>
                                                    <td>{k.source}</td>
                                                    <td>{k.type}</td>
                                                    <td>
                                                        <span className={`oh-badge ${k.usable ? "oh-badge--danger" : "oh-badge--warning"}`}>
                                                            {k.usable ? "UTILISABLE DIRECTEMENT" : "CHIFFRÉE"}
                                                        </span>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>

                                    <div className="smr-pagination-footer">
                                        <span>Page {sshPage} sur {totalSshPages}</span>
                                        <div style={{ display: "flex", gap: 4 }}>
                                            <button
                                                type="button"
                                                className="simatk-btn"
                                                disabled={sshPage <= 1}
                                                onClick={() => setSshPage(p => p - 1)}
                                            >
                                                <ChevronLeft size={13} />
                                            </button>
                                            <button
                                                type="button"
                                                className="simatk-btn"
                                                disabled={sshPage >= totalSshPages}
                                                onClick={() => setSshPage(p => p + 1)}
                                            >
                                                <ChevronRight size={13} />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* 3.4 Hôtes Réseau Rebond Latéral */}
                            {totalLateral.length > 0 && (
                                <div className="smr-sub-block">
                                    <div className="smr-table-header-controls">
                                        <h4 className="smr-sub-title">🕸️ Hôtes Compromis par Rebond Latéral ({totalLateral.length})</h4>
                                        <select
                                            className="smr-pagesize-select"
                                            value={lateralPageSize}
                                            onChange={(e) => { setLateralPageSize(Number(e.target.value)); setLateralPage(1); }}
                                        >
                                            <option value={5}>5 / page</option>
                                            <option value={10}>10 / page</option>
                                        </select>
                                    </div>

                                    <table className="smr-table">
                                        <thead>
                                            <tr>
                                                <th>Cible</th>
                                                <th>Utilisateur</th>
                                                <th>Méthode d'Auth</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {paginatedLateral.map((h, i) => (
                                                <tr key={i}>
                                                    <td className="smc-mono" style={{ fontWeight: 700 }}>{h.target}</td>
                                                    <td>{h.user}</td>
                                                    <td><span className="oh-badge oh-badge--accent">{h.auth_method}</span></td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>

                                    <div className="smr-pagination-footer">
                                        <span>Page {lateralPage} sur {totalLateralPages}</span>
                                        <div style={{ display: "flex", gap: 4 }}>
                                            <button
                                                type="button"
                                                className="simatk-btn"
                                                disabled={lateralPage <= 1}
                                                onClick={() => setLateralPage(p => p - 1)}
                                            >
                                                <ChevronLeft size={13} />
                                            </button>
                                            <button
                                                type="button"
                                                className="simatk-btn"
                                                disabled={lateralPage >= totalLateralPages}
                                                onClick={() => setLateralPage(p => p + 1)}
                                            >
                                                <ChevronRight size={13} />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* 3.5 Fichiers Créés sur la Cible */}
                            {compromisedData.created_files_on_target && compromisedData.created_files_on_target.length > 0 && (
                                <div className="smr-sub-block">
                                    <h4 className="smr-sub-title">📁 Fichiers Résiduels Créés sur la Cible</h4>
                                    <div className="smr-pills-list">
                                        {compromisedData.created_files_on_target.map((f, i) => (
                                            <span key={i} className="smr-file-pill">{f}</span>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            )}

            {/* ── 4. CHRONOLOGIE TECHNIQUE (TIMELINE) ── */}
            {technicalTimeline.length > 0 && (
                <div className="smr-collapsible-card">
                    <div className="smr-collapsible-header" onClick={() => setShowTimeline(!showTimeline)}>
                        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                            <Clock size={18} style={{ color: "var(--accent)" }} />
                            <h3 className="smr-section-title">4. Chronologie Technique d'Infiltration ({technicalTimeline.length} Actions)</h3>
                        </div>
                        {showTimeline ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                    </div>

                    {showTimeline && (
                        <div className="smr-timeline-list">
                            {technicalTimeline.map((item, i) => (
                                <div key={i} className="smr-timeline-item">
                                    <div className={`smr-timeline-dot ${item.success ? "smr-timeline-dot--ok" : "smr-timeline-dot--fail"}`} />
                                    <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
                                        <span style={{ fontWeight: 700, fontSize: "0.88rem" }}>{item.technique}</span>
                                        <span style={{ fontSize: "0.76rem", color: "var(--text-tertiary)" }}>Tactique : {item.tactic}</span>
                                    </div>
                                    <span className={item.success ? "smr-tech-status--ok" : "smr-tech-status--fail"} style={{ marginLeft: "auto" }}>
                                        {item.success ? "SUCCÈS" : "ÉCHEC"}
                                    </span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            )}

            {/* ── 5. PLAN DE REMÉDIATION PRIORITAIRE ── */}
            {remediationPlan.length > 0 && (
                <div className="smr-collapsible-card">
                    <div className="smr-collapsible-header" onClick={() => setShowRemediation(!showRemediation)}>
                        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                            <Award size={18} style={{ color: "var(--accent)" }} />
                            <h3 className="smr-section-title">5. Plan de Remédiation & Recommandations SOC ({remediationPlan.length})</h3>
                        </div>
                        {showRemediation ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                    </div>

                    {showRemediation && (
                        <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                            {remediationPlan.map((rem, i) => (
                                <div key={i} className="smr-remediation-card">
                                    <div style={{ fontWeight: 700, fontSize: "0.95rem", color: "var(--text-primary)" }}>
                                        🛡️ {rem.vulnerability}
                                    </div>
                                    <div style={{ fontSize: "0.85rem", color: "var(--text-secondary)", marginTop: "4px" }}>
                                        <strong>Impact :</strong> {rem.impact}
                                    </div>
                                    <div style={{ fontSize: "0.85rem", color: "var(--success)", marginTop: "2px" }}>
                                        <strong>Mesure corrective :</strong> {rem.mitigation}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}

export default SimReportsComponent;