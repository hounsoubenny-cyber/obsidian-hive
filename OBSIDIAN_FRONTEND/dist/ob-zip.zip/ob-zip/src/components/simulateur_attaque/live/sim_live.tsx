import { useState, useEffect, useRef } from "react";
import "./sim_live.css";
import { useSimulateurAttaqueWSStore, normalizeActionKey } from "@/store/simulateur_attaque_websocket_store";
import { stopSimulation } from "../utils";
import { useNavigate } from "react-router-dom";
import { 
    Terminal as TerminalIcon, 
    Square, 
    Sparkles, 
    Trash2, 
    Eye,
    Send,
    HelpCircle,
    CheckCircle2,
    Clock,
    LayoutGrid,
    CornerDownLeft,
    FileText,
    CheckSquare,
    RotateCw,
    ChevronRight
} from "lucide-react";
import toast from "react-hot-toast";

interface SimLiveProps {
    onShowReports?: () => void;
}

const MITRE_TACTICS = [
    { key: "reconnaissance", num: "1", label: "Reconnaissance", desc: "Scan de ports & détection bannières" },
    { key: "initial_access", num: "2", label: "Initial Access", desc: "Brute force SSH / FTP / HTTP" },
    { key: "execution", num: "3", label: "Execution", desc: "Commandes shell distantes" },
    { key: "privilege_escalation", num: "4", label: "PrivEsc", desc: "Exploitation Sudo NOPASSWD / SUID" },
    { key: "credential_access", num: "5", label: "Cred Access", desc: "Dump /etc/shadow & clés SSH" },
    { key: "lateral_movement", num: "6", label: "Lateral Mov.", desc: "Propagation SSH par rebond" },
    { key: "exfiltration", num: "7", label: "Exfiltration", desc: "Envoi des données vers le C2" },
    { key: "defense_evasion", num: "8", label: "Evasion", desc: "Nettoyage des logs & Timestomp" },
    { key: "persistence", num: "9", label: "Persistence", desc: "Backdoors cron et clés autorisées" },
];

export function SimLiveComponent({ onShowReports }: SimLiveProps) {
    const navigate = useNavigate();
    const { 
        sessionId, 
        mode, 
        isSimulating, 
        logs, 
        currentStep, 
        actionsDone, 
        actionsAvailable, 
        actionsDetails, 
        llmSuggestion, 
        llmReview,
        llmLoading, 
        report, 
        executeAction, 
        requestLlmSuggest, 
        requestLlmReview,
        finishInteractive, 
        clearLogs, 
    } = useSimulateurAttaqueWSStore();

    const [controlViewMode, setControlViewMode] = useState<"deck" | "cli">("deck");
    const [cliInput, setCliInput] = useState<string>("");

    const terminalEndRef = useRef<HTMLDivElement>(null);
    const cliInputRef = useRef<HTMLInputElement>(null);
    const [selectedReviewAction, setSelectedReviewAction] = useState<string>("execution");

    useEffect(() => {
        terminalEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [logs]);

    const handleStop = async () => {
        if (sessionId) {
            await stopSimulation(sessionId, null, () => {}, null, navigate);
            toast("Simulation arrêtée.");
        }
    };

    // ── Déclenchement d'un snapshot de rapport sans clore la session ──
    const handleRequestReportSnapshot = () => {
        if (mode === "interactive" && isSimulating) {
            executeAction("report");
            toast.success("📊 Synthèse du rapport intermédiaire demandée !");
        }
        if (onShowReports) {
            onShowReports();
        }
    };

    const normalizedDone = actionsDone.map(normalizeActionKey);
    const currentNormalized = currentStep ? normalizeActionKey(currentStep) : null;
    const normalizedAvail = actionsAvailable.map(normalizeActionKey);

    // ── Interpréteur de Commandes CLI Terminal ──
    const handleCliSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const cmd = cliInput.trim().toLowerCase();
        if (!cmd) return;

        setCliInput("");

        // 1. Aide
        if (cmd === "help" || cmd === "?") {
            useSimulateurAttaqueWSStore.setState((s) => ({
                logs: [
                    ...s.logs,
                    "━━━━━━━━━━━━━━━━━━━ 📖 AIDE CLI SIMULATEUR ━━━━━━━━━━━━━━━━━━━",
                    "  1 | reconnaissance          - Lancer le scan de ports",
                    "  2 | initial_access          - Tenter le brute force",
                    "  3 | execution               - Exécuter les commandes",
                    "  4 | privilege_escalation    - Tenter l'élévation root",
                    "  5 | credential_access       - Extraire shadow & clés",
                    "  6 | lateral_movement        - Propagation réseau",
                    "  7 | exfiltration            - Exfiltrer vers C2",
                    "  8 | defense_evasion         - Effacer les traces",
                    "  9 | persistence             - Installer backdoors",
                    "  report                      - Générer snapshot du rapport",
                    "  status                      - Afficher l'état du scan",
                    "  suggest                     - Demander conseil au Copilote IA",
                    "  review <action>             - Demander avis IA sur une action",
                    "  finish                      - Conclure la session",
                    "  clear                       - Vider le terminal",
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
                ],
            }));
            return;
        }

        // 2. Vider
        if (cmd === "clear" || cmd === "cls") {
            clearLogs();
            return;
        }

        // 3. Snapshot Rapport
        if (cmd === "report" || cmd === "rapport") {
            handleRequestReportSnapshot();
            return;
        }

        // 4. Conclure
        if (cmd === "finish" || cmd === "exit" || cmd === "quit" || cmd === "end") {
            finishInteractive();
            toast.success("Conclusion de la simulation...");
            return;
        }

        // 5. Copilote IA Suggest
        if (cmd === "suggest" || cmd === "ia" || cmd === "aide") {
            requestLlmSuggest();
            toast("Demande de suggestion IA envoyée...");
            return;
        }

        // 6. Copilote IA Review
        if (cmd.startsWith("review ") || cmd.startsWith("avis ")) {
            const act = cmd.replace("review ", "").replace("avis ", "").trim();
            const norm = normalizeActionKey(act);
            requestLlmReview(norm);
            toast(`Demande d'avis IA sur '${norm}'...`);
            return;
        }

        // 7. Statut
        if (cmd === "status" || cmd === "etat") {
            useSimulateurAttaqueWSStore.setState((s) => ({
                logs: [
                    ...s.logs,
                    `📊 [STATUS] Session: ${sessionId || "N/A"} | Étape en cours: ${currentStep || "En attente"}`,
                    `   Actions effectuées : [${normalizedDone.join(", ") || "Aucune"}]`,
                    `   Actions disponibles : [${normalizedAvail.join(", ") || "Aucune"}]`,
                ],
            }));
            return;
        }

        // 8. Lancement par numéro ou par nom
        const matchByNum = MITRE_TACTICS.find(t => t.num === cmd);
        const matchByName = MITRE_TACTICS.find(t => t.key === normalizeActionKey(cmd));
        const targetTactic = matchByNum || matchByName;

        if (targetTactic) {
            if (!normalizedAvail.includes(targetTactic.key)) {
                toast.error(`⚠️ L'action '${targetTactic.label}' n'est pas encore disponible.`);
                useSimulateurAttaqueWSStore.setState((s) => ({
                    logs: [...s.logs, `⚠️ [REFUS] Action '${targetTactic.label}' bloquée : prérequis manquants.`],
                }));
                return;
            }

            executeAction(targetTactic.key);
            toast.success(`🚀 Exécution : ${targetTactic.label}`);
            return;
        }

        toast.error(`Commande inconnue : '${cmd}'. Tapez 'help'.`);
    };

    const hasDoneAnyAction = normalizedDone.length > 0 || Boolean(report);

    return (
        <div id="smlv-container" className="smlv-container">
            {/* Header */}
            <div className="smlv-header">
                <div>
                    <h2 className="scl-header__title">
                        <TerminalIcon size={24} /> ⚡ Console d'Attaque Live & Copilote IA
                    </h2>
                    <p className="scl-header__subtitle">
                        Session : <strong className="smc-mono">{sessionId || "Aucune session active"}</strong> • Mode : <span className="oh-badge oh-badge--accent">{(mode || "auto").toUpperCase()}</span>
                    </p>
                </div>

                <div style={{ display: "flex", gap: "8px", alignItems: "center", flexWrap: "wrap" }}>
                    {/* Bouton 1 : Arrêter d'urgence */}
                    {isSimulating && (
                        <button type="button" className="oh-btn oh-btn--ghost" style={{ color: "var(--danger)" }} onClick={handleStop}>
                            <Square size={14} /> Arrêter
                        </button>
                    )}

                    {/* Bouton 2 : Consulter / Générer le Rapport (Snapshot répété possible) */}
                    {hasDoneAnyAction && (
                        <button 
                            type="button" 
                            className="oh-btn oh-btn--ghost" 
                            style={{ color: "var(--accent-strong)", borderColor: "var(--accent-soft)" }}
                            onClick={handleRequestReportSnapshot}
                            title="Générer un snapshot intermédiaire ou consulter le rapport"
                        >
                            <FileText size={14} /> {mode === "interactive" && isSimulating ? "Snapshot Rapport" : "Consulter Rapport"}
                        </button>
                    )}

                    {/* Bouton 3 : Conclure Définitivement la Simulation Interactive */}
                    {mode === "interactive" && isSimulating && (
                        <button type="button" className="oh-btn oh-btn--primary" onClick={finishInteractive}>
                            <CheckSquare size={14} /> Conclure Session
                        </button>
                    )}
                </div>
            </div>

            {/* Stepper MITRE ATT&CK */}
            <div className="smlv-mitre-stepper">
                {MITRE_TACTICS.map((t) => {
                    const isDone = normalizedDone.includes(t.key);
                    const isActive = currentNormalized === t.key;

                    return (
                        <div
                            key={t.key}
                            className={`smlv-mitre-step ${isActive ? "smlv-mitre-step--active" : ""} ${isDone ? "smlv-mitre-step--done" : ""}`}
                        >
                            <span className="smlv-mitre-step__icon">
                                {isDone ? (
                                    <CheckCircle2 size={16} style={{ color: "var(--success)" }} />
                                ) : isActive ? (
                                    <Clock size={16} className="oh-spin" style={{ color: "var(--accent)" }} />
                                ) : (
                                    <span style={{ opacity: 0.35 }}>⚪</span>
                                )}
                            </span>
                            <span className="smlv-mitre-step__label">{t.label}</span>
                        </div>
                    );
                })}
            </div>

            {/* Mode Interactif : Choix GUI Deck ou Hacker CLI */}
            {mode === "interactive" ? (
                <div className="smlv-interactive-grid">
                    {/* 1. Panneau de Commande (Deck ou CLI) */}
                    <div className="smlv-deck">
                        <div className="smlv-deck__header">
                            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                                <span style={{ fontWeight: 700, fontSize: "0.92rem" }}>Contrôle des Tactiques</span>
                                <span style={{ fontSize: "0.74rem", color: "var(--text-tertiary)" }}>
                                    ({actionsAvailable.length} disponible{actionsAvailable.length > 1 ? "s" : ""})
                                </span>
                            </div>

                            <div className="smlv-view-switch">
                                <button
                                    type="button"
                                    className={`smlv-switch-btn ${controlViewMode === "deck" ? "active" : ""}`}
                                    onClick={() => setControlViewMode("deck")}
                                    title="Mode Cartes & Boutons"
                                >
                                    <LayoutGrid size={13} /> Deck
                                </button>
                                <button
                                    type="button"
                                    className={`smlv-switch-btn ${controlViewMode === "cli" ? "active" : ""}`}
                                    onClick={() => {
                                        setControlViewMode("cli");
                                        setTimeout(() => cliInputRef.current?.focus(), 100);
                                    }}
                                    title="Mode Terminal CLI Interactif"
                                >
                                    <TerminalIcon size={13} /> CLI
                                </button>
                            </div>
                        </div>

                        {controlViewMode === "deck" ? (
                            <div className="smlv-cards-list">
                                {MITRE_TACTICS.map((t) => {
                                    const isDone = normalizedDone.includes(t.key);
                                    const isAvailable = normalizedAvail.includes(t.key);
                                    const details = actionsDetails?.[t.key];

                                    return (
                                        <div
                                            key={t.key}
                                            className={`smlv-action-card ${isDone ? "smlv-action-card--done" : isAvailable ? "smlv-action-card--available" : "smlv-action-card--locked"}`}
                                        >
                                            <div style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
                                                <div style={{ fontWeight: 700, fontSize: "0.86rem", display: "flex", alignItems: "center", gap: 6 }}>
                                                    <span className="smlv-action-num">{t.num}</span> {t.label}
                                                </div>
                                                <div style={{ fontSize: "0.74rem", color: "var(--text-secondary)" }}>
                                                    {details?.reason || (isDone ? "Exécuté avec succès" : isAvailable ? t.desc : "Prérequis manquant")}
                                                </div>
                                            </div>

                                            {isAvailable && (
                                                <button
                                                    type="button"
                                                    className="oh-btn oh-btn--primary"
                                                    style={{ padding: "5px 12px", fontSize: "0.78rem" }}
                                                    onClick={() => executeAction(t.key)}
                                                >
                                                    <Send size={12} /> Lancer
                                                </button>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        ) : (
                            <div className="smlv-cli-panel">
                                <div className="smlv-cli-help-box">
                                    <span style={{ fontWeight: 700, color: "var(--accent-strong)", fontSize: "0.8rem" }}>
                                        ⌨️ Invite de commande interactive Red Team :
                                    </span>
                                    <div className="smlv-cli-quick-tags">
                                        {MITRE_TACTICS.map((t) => {
                                            const isAvailable = normalizedAvail.includes(t.key);
                                            return (
                                                <button
                                                    key={t.key}
                                                    type="button"
                                                    className={`smlv-cli-tag ${isAvailable ? "smlv-cli-tag--avail" : ""}`}
                                                    onClick={() => {
                                                        setCliInput(t.num);
                                                        cliInputRef.current?.focus();
                                                    }}
                                                >
                                                    {t.num}. {t.label}
                                                </button>
                                            );
                                        })}
                                    </div>
                                    <div style={{ fontSize: "0.72rem", color: "var(--text-tertiary)" }}>
                                        Entrez le numéro (ex: <strong>1</strong>) ou la commande (ex: <strong>report</strong>, <strong>suggest</strong>, <strong>finish</strong>, <strong>help</strong>).
                                    </div>
                                </div>

                                <form onSubmit={handleCliSubmit} className="smlv-cli-form">
                                    <div className="smlv-cli-input-box">
                                        <ChevronRight size={16} style={{ color: "var(--accent-strong)" }} />
                                        <input
                                            ref={cliInputRef}
                                            type="text"
                                            className="smlv-cli-input"
                                            placeholder="Tapez une commande (1-9, report, finish, help)..."
                                            value={cliInput}
                                            onChange={(e) => setCliInput(e.target.value)}
                                        />
                                        <button type="submit" className="smlv-cli-send-btn" title="Exécuter la commande">
                                            <CornerDownLeft size={14} />
                                        </button>
                                    </div>
                                </form>
                            </div>
                        )}
                    </div>

                    {/* 2. Copilote IA & Flux Terminal */}
                    <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
                        <div className="smlv-copilot-card">
                            <div className="smlv-copilot-header">
                                <div style={{ display: "flex", alignItems: "center", gap: "8px", fontWeight: 700 }}>
                                    <Sparkles size={18} style={{ color: "var(--accent)" }} />
                                    <span>Copilote IA (Advisor)</span>
                                </div>

                                <button
                                    type="button"
                                    className="simatk-btn"
                                    onClick={requestLlmSuggest}
                                    disabled={llmLoading}
                                >
                                    💡 Proposer Action
                                </button>
                            </div>

                            <div className="smlv-copilot-bubble">
                                {llmLoading ? (
                                    <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                        <Clock size={14} className="oh-spin" /> Analyse tactique de la situation...
                                    </span>
                                ) : llmSuggestion ? (
                                    <div>
                                        <strong style={{ color: "var(--accent-strong)" }}>Conseil Stratégique :</strong>
                                        <p style={{ marginTop: "4px" }}>{llmSuggestion}</p>
                                    </div>
                                ) : (
                                    <span style={{ color: "var(--text-tertiary)" }}>
                                        Interrogez le Copilote IA pour obtenir la recommandation d'étape la plus judicieuse.
                                    </span>
                                )}
                            </div>

                            {/* Évaluer une action */}
                            <div style={{ display: "flex", gap: "8px", alignItems: "center", borderTop: "1px solid var(--border)", paddingTop: "12px" }}>
                                <select
                                    className="sml-select"
                                    style={{ flex: 1, padding: "6px 10px", fontSize: "0.8rem" }}
                                    value={selectedReviewAction}
                                    onChange={(e) => setSelectedReviewAction(e.target.value)}
                                >
                                    {MITRE_TACTICS.map((t) => (
                                        <option key={t.key} value={t.key}>{t.num}. {t.label}</option>
                                    ))}
                                </select>
                                <button
                                    type="button"
                                    className="simatk-btn"
                                    onClick={() => requestLlmReview(selectedReviewAction)}
                                    disabled={llmLoading}
                                >
                                    <HelpCircle size={13} /> Avis IA
                                </button>
                            </div>

                            {llmReview && (
                                <div className="smlv-copilot-bubble" style={{ borderLeft: "3px solid var(--info)", background: "var(--bg-surface)" }}>
                                    <strong style={{ color: "var(--info)" }}>Avis sur '{selectedReviewAction}' :</strong>
                                    <p style={{ marginTop: "4px" }}>{llmReview}</p>
                                </div>
                            )}
                        </div>

                        {/* Terminal Output */}
                        <div className="sclv-terminal" style={{ height: "320px" }}>
                            <div className="sclv-terminal__bar">
                                <span style={{ fontSize: "0.8rem", color: "var(--text-secondary)" }}>Terminal Output Stream</span>
                                <button type="button" className="scl-btn-inline" onClick={clearLogs}>
                                    <Trash2 size={12} />
                                </button>
                            </div>
                            <div className="sclv-terminal__body">
                                {logs.length === 0 ? (
                                    <span style={{ color: "var(--text-tertiary)", fontStyle: "italic" }}>En attente de messages...</span>
                                ) : (
                                    logs.map((l, i) => (
                                        <div key={i} className="sclv-log-line">
                                            <span>&gt; {l}</span>
                                        </div>
                                    ))
                                )}
                                <div ref={terminalEndRef} />
                            </div>
                        </div>
                    </div>
                </div>
            ) : (
                /* Mode Automatique */
                <div className="sclv-terminal" style={{ minHeight: "440px" }}>
                    <div className="sclv-terminal__bar">
                        <span style={{ fontSize: "0.8rem", color: "var(--text-secondary)" }}>
                            Flux d'Exécution Automatique ({logs.length} ligne{logs.length > 1 ? "s" : ""})
                        </span>
                        <button type="button" className="scl-btn-inline" onClick={clearLogs}>
                            <Trash2 size={12} /> Vider
                        </button>
                    </div>
                    <div className="sclv-terminal__body">
                        {logs.length === 0 ? (
                            <span style={{ color: "var(--text-tertiary)", fontStyle: "italic" }}>En attente du démarrage de la simulation...</span>
                        ) : (
                            logs.map((l, i) => (
                                <div key={i} className="sclv-log-line">
                                    <span>&gt; {l}</span>
                                </div>
                            ))
                        )}
                        <div ref={terminalEndRef} />
                    </div>
                </div>
            )}
        </div>
    );
}

export default SimLiveComponent;