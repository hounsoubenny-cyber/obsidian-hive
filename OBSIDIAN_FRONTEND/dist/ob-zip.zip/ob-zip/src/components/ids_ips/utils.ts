// utils.ts

import { logError } from "@/hooks/error_utils";
import { getToken, refreshToken as centralRefreshToken } from "@/hooks/get_token";
import { useNavigate } from "react-router-dom";
import {
  idsListEndpoints,
  idsStart,
  idsStop,
  idsGetHealth,
  idsGetMode,
  idsChangeMode,
  idsGetAlerts,
  idsGetGraphPort,
  idsGetBlockedIps,
  idsBlockIp,
  idsUnlockIp,
  idsManageWhitelist,
  idsManageIgnoredIp,
  idsGetGeoLocation,
  idsGetConfig,
  idsUpdateConfig,
  idsGetDefaultConfig,
  idsGetHelp
} from "@/hooks/fetch_functions";

import {
  NetworkEndpointsMap,
  IdsActionResponse,
  IdsHealthResponse,
  IdsMode,
  ChangeModeRequest,
  LastAlertsResponse,
  IdsGraphPortResponse,
  BlockedIpsResponseMap,
  BlockIpRequest,
  UnlockIpRequest,
  ManageWhitelistRequest,
  ManageIgnoredIpRequest,
  IdsGeoLocationResponse,
  IdsFullConfig,
  UpdateConfigCategoryRequest
} from "@/types/ids_ips/types";
import toast from "react-hot-toast";

// ============================================================================
// 0. GESTION DE SESSION UNIQUE POUR LA SONDE ACTIVE
// ============================================================================

export function getProbeToken(): string {
  return sessionStorage.getItem("probe_token") || "";
}

export function getProbeUsername(): string {
  return sessionStorage.getItem("probe_user") || "admin";
}

export const probIsLogin = () => {
  return Boolean(getProbeToken());
}
export function setProbeSession(token: string, username: string): void {
  sessionStorage.setItem("probe_token", token);
  sessionStorage.setItem("probe_user", username);
}

export function clearProbeSession(): void {
  sessionStorage.removeItem("probe_token");
  sessionStorage.removeItem("probe_user");
}

// ============================================================================
// 1. AUTHENTIFICATION DIRECTE SUR LA SONDE (LOGIN & REFRESH TOKEN)
// ============================================================================

/**
 * Connecte l'administrateur directement sur la sonde active.
 * POST ${probeUrl}/login -> { access_token, username, expires_in, success }
 */
export async function probeLogin(
  probeUrl: string,
  data: { username: string; password: string }
): Promise<{ success: boolean; access_token?: string; username?: string; error?: string }> {
  try {
    const response = await fetch(`${probeUrl}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });

    const json = await response.json();
    //console.log(json);
    if (!response.ok) {
      return { success: false, error: json.detail || `Erreur ${response.status}` };
    }

    if (json.access_token) {
      setProbeSession(json.access_token, json.username || data.username);
    }

    return {
      success: true,
      access_token: json.access_token,
      username: json.username || data.username,
    };
  } catch (err: any) {
    return { success: false, error: err.message || "Impossible de joindre la sonde" };
  }
}

/**
 * Rafraîchit automatiquement le token JWT de la sonde active.
 * POST ${probeUrl}/refresh_token -> { access_token }
 */
export async function probeRefreshToken(
  probeUrl: string,
  navigate?: ReturnType<typeof useNavigate> | any
): Promise<string | null> {
  const currentToken = getProbeToken();
  const currentUsername = getProbeUsername();

  if (!currentToken || !currentUsername) return null;

  try {
    console.log("🔄 Rafraîchissement du token de la sonde en cours...");
    const response = await fetch(`${probeUrl}/refresh_token`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: currentUsername, token: currentToken }),
    });
    const json = await response.json();
    //console.log(response, json);
    //console.log(currentToken, currentToken);
    if (!response.ok) {
      toast.error('Session expirée !')
      console.log("❌ Échec du refresh token sur la sonde, session expirée.");
      clearProbeSession();
      if (navigate) setTimeout(() => navigate("/modules/ids-ips"), 2000);
      return null;
    }

    if (json.access_token) {
      setProbeSession(json.access_token, currentUsername);
      console.log("✅ Token de la sonde rafraîchi avec succès !");
      return json.access_token;
    }
    return null;
  } catch (err) {
    console.error("❌ Erreur réseau refresh token sonde :", err);
    clearProbeSession();
    if (navigate) navigate("/modules/ids-ips");
    return null;
  }
}

// ============================================================================
// 2. HELPERS GÉNÉRIQUES AVEC AUTO-REFRESH & RETRY
// ============================================================================

async function withProbeAuthRetry<T>(
  probeUrl: string,
  apiCall: (token: string) => Promise<{ ok: boolean; response: any; error?: string, status?: number | null }>,
  setResult: ((val: T | null) => void) | null,
  setError: (err: string | null) => void,
  setLoading: ((loading: boolean) => void) | null = null,
  navigate?: ReturnType<typeof useNavigate> | any
): Promise<T | null> {
  try {
    if (setLoading) setLoading(true);
    setError?.(null);

    let token = getProbeToken();
    const result = await apiCall(token);
    if (result.ok) {
      if (setResult) setResult(result.response);
      return result.response as T;
    }

    // Gestion expiration du token sonde -> Refresh automatique
    if (result.response?.detail === "TOKEN_EXPIRED") {
      const refreshedToken = await probeRefreshToken(probeUrl, navigate);
      if (refreshedToken) {
        const retryResult = await apiCall(refreshedToken);
        if (retryResult.ok) {
          if (setResult) setResult(retryResult.response);
          return retryResult.response as T;
        }
      }
    }

    const err = result.error || result.response?.detail || "Une erreur est survenue sur la sonde";
    setError?.(err);
    if (setResult) setResult(null);
    return null;
  } catch (e: any) {
    const msg = logError(e);
    setError?.(msg);
    if (setResult) setResult(null);
    return null;
  } finally {
    if (setLoading) setLoading(false);
  }
}

async function withCentralAuthRetry<T>(
  apiCall: (token: string) => Promise<{ ok: boolean; response: any; error?: string }>,
  setResult: ((val: T | null) => void) | null,
  setError: (err: string | null) => void,
  setLoading: ((loading: boolean) => void) | null = null,
  navigate?: ReturnType<typeof useNavigate> | any
): Promise<T | null> {
  try {
    if (setLoading) setLoading(true);
    setError?.(null);

    const result = await apiCall(getToken());
    if (result.ok) {
      if (setResult) setResult(result.response);
      return result.response as T;
    }

    if (result.response?.detail === "TOKEN_EXPIRED") {
      const refreshed = await centralRefreshToken(getToken(), navigate);
      if (refreshed) return withCentralAuthRetry(apiCall, setResult, setError, setLoading, navigate);
    }

    const err = result.error || result.response?.detail || "Erreur Central API";
    setError?.(err);
    if (setResult) setResult(null);
    return null;
  } catch (e: any) {
    const msg = logError(e);
    setError?.(msg);
    if (setResult) setResult(null);
    return null;
  } finally {
    if (setLoading) setLoading(false);
  }
}

// ============================================================================
// 3. FLOTTE DES SONDES (Central Core API)
// ============================================================================

export const fetchNetworkEndpoints = (
  setResult: (data: NetworkEndpointsMap | null) => void,
  setError: (err: string | null) => void,
  setLoading: (loading: boolean) => void,
  nav?: any
) => withCentralAuthRetry<NetworkEndpointsMap>((t) => idsListEndpoints(t), setResult, setError, setLoading, nav);

// ============================================================================
// 4. CONTRÔLE DE LA SONDE ACTIVE (Direct Sonde)
// ============================================================================

export const startIdsEngine = (
  probeUrl: string,
  setResult: (res: IdsActionResponse | null) => void,
  setError: (err: string | null) => void,
  setLoading: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<IdsActionResponse>(probeUrl, (t) => idsStart(probeUrl, t), setResult, setError, setLoading, nav);

export const stopIdsEngine = (
  probeUrl: string,
  setResult: (res: IdsActionResponse | null) => void,
  setError: (err: string | null) => void,
  setLoading: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<IdsActionResponse>(probeUrl, (t) => idsStop(probeUrl, t), setResult, setError, setLoading, nav);

export const getIdsHealth = (
  probeUrl: string,
  setResult: (res: IdsHealthResponse | null) => void,
  setError: (err: string | null) => void,
  setLoading: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<IdsHealthResponse>(probeUrl, (t) => idsGetHealth(probeUrl, t), setResult, setError, setLoading, nav);

export const getIdsMode = (
  probeUrl: string,
  setResult: (res: { mode: IdsMode } | null) => void,
  setError: (err: string | null) => void,
  setLoading: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<{ mode: IdsMode }>(probeUrl, (t) => idsGetMode(probeUrl, t), setResult, setError, setLoading, nav);

export const changeIdsMode = (
  probeUrl: string,
  data: ChangeModeRequest & { username: string; password?: string },
  setResult: (res: { success: boolean } | null) => void,
  setError: (err: string | null) => void,
  setLoading: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<{ success: boolean }>(probeUrl, (t) => idsChangeMode(probeUrl, { ...data, token: t }, t), setResult, setError, setLoading, nav);

// ============================================================================
// 5. ALERTES & GRAPHIQUE BOKEH
// ============================================================================

export const getIdsAlerts = (
  probeUrl: string,
  n: number = 30,
  setResult: (res: LastAlertsResponse | null) => void,
  setError: (err: string | null) => void,
  setLoading?: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<LastAlertsResponse>(probeUrl, (t) => idsGetAlerts(probeUrl, n, t), setResult, setError, setLoading || null, nav);

export const getIdsGraphPort = (
  probeUrl: string,
  setResult: (res: IdsGraphPortResponse | null) => void,
  setError: (err: string | null) => void,
  setLoading?: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<IdsGraphPortResponse>(probeUrl, (t) => idsGetGraphPort(probeUrl, t), setResult, setError, setLoading || null, nav);

// ============================================================================
// 6. BLOCAGES, WHITELIST & GÉOLOCALISATION
// ============================================================================

export const getBlockedIps = (
  probeUrl: string,
  username: string,
  setResult: (res: { blocked: BlockedIpsResponseMap; message: string } | null) => void,
  setError: (err: string | null) => void,
  setLoading: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<{ blocked: BlockedIpsResponseMap; message: string }>(probeUrl, (t) => idsGetBlockedIps(probeUrl, { username, token: t }, t), setResult, setError, setLoading, nav);

export const blockIpAddress = (
  probeUrl: string,
  data: BlockIpRequest & { username: string; password?: string },
  setResult: (res: IdsActionResponse | null) => void,
  setError: (err: string | null) => void,
  setLoading: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<IdsActionResponse>(probeUrl, (t) => idsBlockIp(probeUrl, { ...data, token: t }, t), setResult, setError, setLoading, nav);

export const unlockIpAddress = (
  probeUrl: string,
  data: UnlockIpRequest & { username: string; password?: string },
  setResult: (res: IdsActionResponse | null) => void,
  setError: (err: string | null) => void,
  setLoading: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<IdsActionResponse>(probeUrl, (t) => idsUnlockIp(probeUrl, { ...data, token: t }, t), setResult, setError, setLoading, nav);

export const manageWhitelistIp = (
  probeUrl: string,
  data: ManageWhitelistRequest & { username: string; password?: string },
  setResult: (res: IdsActionResponse | null) => void,
  setError: (err: string | null) => void,
  setLoading: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<IdsActionResponse>(probeUrl, (t) => idsManageWhitelist(probeUrl, { ...data, token: t }, t), setResult, setError, setLoading, nav);

export const manageIgnoredIpAddress = (
  probeUrl: string,
  data: ManageIgnoredIpRequest & { username: string; password?: string },
  setResult: (res: IdsActionResponse | null) => void,
  setError: (err: string | null) => void,
  setLoading: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<IdsActionResponse>(probeUrl, (t) => idsManageIgnoredIp(probeUrl, { ...data, token: t }, t), setResult, setError, setLoading, nav);

export const getIpGeoLocation = (
  probeUrl: string,
  ip: string,
  setResult: (res: IdsGeoLocationResponse | null) => void,
  setError: (err: string | null) => void,
  setLoading?: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<IdsGeoLocationResponse>(probeUrl, (t) => idsGetGeoLocation(probeUrl, ip, t), setResult, setError, setLoading || null, nav);

// ============================================================================
// 7. CONFIGURATION & HELP
// ============================================================================

export const getFullIdsConfig = (
  probeUrl: string,
  username: string,
  setResult: (res: { "ids/ips_config": any; api_config: any; host: string; port: number } | null) => void,
  setError: (err: string | null) => void,
  setLoading: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<any>(probeUrl, (t) => idsGetConfig(probeUrl, { username, token: t }, t), setResult, setError, setLoading, nav);

export const updateCategoryConfig = (
  probeUrl: string,
  data: UpdateConfigCategoryRequest & { username: string; password?: string },
  setResult: (res: IdsActionResponse | null) => void,
  setError: (err: string | null) => void,
  setLoading: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<IdsActionResponse>(probeUrl, (t) => idsUpdateConfig(probeUrl, { ...data, token: t }, t), setResult, setError, setLoading, nav);

export const getDefaultConfigTemplate = (
  probeUrl: string,
  setResult: (res: IdsFullConfig | null) => void,
  setError: (err: string | null) => void,
  setLoading: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<IdsFullConfig>(probeUrl, (t) => idsGetDefaultConfig(probeUrl, t), setResult, setError, setLoading, nav);

export const getIdsApiHelp = (
  probeUrl: string,
  setResult: (res: any) => void,
  setError: (err: string | null) => void,
  setLoading?: (loading: boolean) => void,
  nav?: any
) => withProbeAuthRetry<any>(probeUrl, (t) => idsGetHelp(probeUrl, t), setResult, setError, setLoading || null, nav);