import React, { useState, useEffect, useCallback } from "react";
import "./ids_ips.css";
import { 
  NetworkEndpointsMap, 
  IdsMode, 
  IdsAlertEvent, 
  BlockedIpsResponseMap, 
  NftRuleType 
} from "@/types/ids_ips/types";
import { NetworkAsset } from "@/types/assets/types";
import { 
  fetchNetworkEndpoints, 
  getIdsAlerts, 
  getBlockedIps, 
  unlockIpAddress, 
  blockIpAddress, 
  manageWhitelistIp, 
  changeIdsMode, 
  getIdsGraphPort,
  getFullIdsConfig,
  updateCategoryConfig,
  getIdsApiHelp,
  getProbeUsername,
  manageIgnoredIpAddress
} from "./utils";
import { listAsset } from "@/hooks/fetch_functions";
import { getToken, getUsername, isLogin } from "@/hooks/get_token";
import { Link, useNavigate } from "react-router-dom";
import { Shield, RefreshCw } from "lucide-react";
import toast from "react-hot-toast";
import { resolveProbeApiUrl } from "./probe_url";
import { usePasswordPrompt } from "../utils/password_prompt/password_prompt";
import { FleetView } from "./fleet_view";
import { ProbeDetailView } from "./probe_detail_view";
import { EnrichedProbe } from "./cards/probe_card";
import { Lock } from "lucide-react";

export function IdsIps() {
  const navigate = useNavigate();
  let username = getProbeUsername();
  const { prompt: promptPassword, modal: passwordModal } = usePasswordPrompt();

  // ── État Flotte des sondes ────────────────────────────────────────────────
  const [probesList, setProbesList] = useState<EnrichedProbe[]>([]);
  const [loadingProbes, setLoadingProbes] = useState(false);
  const [selectedProbe, setSelectedProbe] = useState<EnrichedProbe | null>(null);

  // ── État de la Sonde Sélectionnée ─────────────────────────────────────────
  const [idsMode, setIdsMode] = useState<IdsMode>("ids");
  const [bokehPort, setBokehPort] = useState<number | null>(null);
  const [alerts, setAlerts] = useState<IdsAlertEvent[]>([]);
  const [blockedIps, setBlockedIps] = useState<BlockedIpsResponseMap>({});
  const [seuilDecision, setSeuilDecision] = useState<number>(-0.6);
  const [helpData, setHelpData] = useState<any>(null);
  const [loadingProbeData, setLoadingProbeData] = useState(false);

  // ── 1. Chargement & Fusion des Sondes ──────────────────────────────────────
  const loadFleetProbes = useCallback(async () => {
    setLoadingProbes(true);
    const token = getToken();

    try {
      let epMap: NetworkEndpointsMap = {};
      await fetchNetworkEndpoints(
        (data) => { epMap = data || {}; },
        (err) => { if (err) toast.error(`Erreur endpoints: ${err}`); },
        () => {},
        navigate
      );
      let networkAssets: NetworkAsset[] = [];
      const assetRes = await listAsset({ type_: "network" }, token);
      if (assetRes.ok && assetRes.response?.assets) {
        networkAssets = assetRes.response.assets as NetworkAsset[];
      }

      const enriched: EnrichedProbe[] = Object.entries(epMap).map(([id, ep]) => {
        const assetMeta = networkAssets.find((a) => a.id === id || a.item_db_id?.toString() === id);
        return {
          id,
          name: assetMeta?.name || `Sonde Réseau (${ep.host})`,
          host: ep.host,
          port: ep.port,
          is_open: ep.is_open,
          deployment_mode: assetMeta?.deployment_mode,
          priority: assetMeta?.priority,
          tags: assetMeta?.tags || [],
          status: assetMeta?.status || "active",
        };
      });

      setProbesList(enriched);
    } catch (err: any) {
      toast.error(`Erreur chargement flotte: ${err?.message || err}`);
    } finally {
      setLoadingProbes(false);
    }
  }, [navigate]);

  useEffect(() => {
    loadFleetProbes();
  }, [loadFleetProbes]);

  // URL directe de la sonde active (nettoyée par le helper)
  const activeProbeUrl = selectedProbe ? resolveProbeApiUrl(selectedProbe.host, selectedProbe.port) : "";

  // ── 2. Chargement des Données de la Sonde Active ───────────────────────────
  const refreshProbeData = useCallback(() => {
    if (!activeProbeUrl || !selectedProbe?.is_open) return;
    setLoadingProbeData(true);

    getIdsAlerts(activeProbeUrl, 30, (res) => { if (res?.alerts) setAlerts(res.alerts); }, () => {}, undefined, navigate);
    getBlockedIps(activeProbeUrl, username, (res) => { if (res?.blocked) setBlockedIps(res.blocked); }, () => {}, () => {}, navigate);
    getIdsGraphPort(activeProbeUrl, (res) => setBokehPort(res?.port || null), () => {}, () => {}, navigate);
    getIdsApiHelp(activeProbeUrl, (res) => setHelpData(res), () => {}, undefined, navigate);

    getFullIdsConfig(activeProbeUrl, username, (res) => {
      if (res && res["ids/ips_config"]?.SEUIL?.decision !== undefined) {
        setSeuilDecision(res["ids/ips_config"].SEUIL.decision);
      }
      setLoadingProbeData(false);
    }, () => setLoadingProbeData(false), () => {}, navigate);
  }, [activeProbeUrl, selectedProbe, username, navigate]);

  useEffect(() => {
    if (selectedProbe && selectedProbe.is_open) {
      refreshProbeData();
      const interval = setInterval(refreshProbeData, 8000);
      return () => clearInterval(interval);
    }
  }, [selectedProbe, refreshProbeData]);

  // ── 3. Actions Opérateur Sécurisées par PasswordPrompt ─────────────────────

  const handleUnlock = async (ip: string, rule: string) => {
    const password = await promptPassword(`Débloquer l'adresse IP ${ip} ?`);
    if (!password) return;

    const res = await unlockIpAddress(activeProbeUrl, { ip, rule, input: true, username, password }, () => {}, (err) => { if (err) toast.error(err); }, () => {}, navigate);
    if (res?.success) {
      toast.success(`IP ${ip} débloquée !`);
      refreshProbeData();
    }
  };

  const handleBlockManual = async (ip: string, rule: NftRuleType) => {
    const password = await promptPassword(`Bloquer ${ip} (${rule.toUpperCase()}) ?`);
    if (!password) return;

    const res = await blockIpAddress(activeProbeUrl, { ip, rule, input: true, username, password }, () => {}, (err) => { if (err) toast.error(err); }, () => {}, navigate);
    if (res?.success) {
      toast.success(`IP ${ip} bloquée avec succès`);
      refreshProbeData();
    }
  };

  const handleWhitelistManual = async (ip: string, add: boolean) => {
    const password = await promptPassword(`${add ? "Ajouter" : "Retirer"} ${ip} ${add ? "à" : "de"} la whitelist ?`);
    if (!password) return;

    const res = await manageWhitelistIp(activeProbeUrl, { ip, add, username, password }, () => {}, (err) => { if (err) toast.error(err); }, () => {}, navigate);
    if (res?.success) {
      toast.success(`Whitelist mise à jour pour ${ip}`);
      refreshProbeData();
    }
  };

  const handleModeChange = async (newMode: IdsMode) => {
    if (newMode === idsMode) return;
    const password = await promptPassword(`Basculer la sonde en mode ${newMode.toUpperCase()} ?`);
    if (!password) return;

    const res = await changeIdsMode(activeProbeUrl, { mode: newMode, username, password }, () => {}, (err) => { if (err) toast.error(err); }, () => {}, navigate);
    if (res?.success) {
      setIdsMode(newMode);
      toast.success(`Mode basculé sur ${newMode.toUpperCase()}`);
    }
  };

  const handleUpdateSeuil = async (newSeuil: number) => {
    const password = await promptPassword(`Mettre à jour le seuil de décision à ${newSeuil} ?`);
    if (!password) return;

    const res = await updateCategoryConfig(activeProbeUrl, { key: "SEUIL", data: { decision: newSeuil }, username, password }, () => {}, (err) => { if (err) toast.error(err); }, () => {}, navigate);
    if (res?.success) {
      setSeuilDecision(newSeuil);
      toast.success(`Seuil configuré à ${newSeuil}`);
      refreshProbeData();
    }
  };

  const handleSaveCategoryConfig = async (key: string, data: Record<string, any>): Promise<boolean> => {
    const password = await promptPassword(`Mettre à jour la catégorie de configuration "${key}" ?`);
    if (!password) return false;

    const res = await updateCategoryConfig(activeProbeUrl, { key, data, username, password }, () => {}, (err) => { if (err) toast.error(err); }, () => {}, navigate);
    if (res?.success) {
      toast.success(`Catégorie ${key} mise à jour !`);
      refreshProbeData();
      return true;
    }
    return false;
  };

  const handleManageIgnoredIp = async (ip: string, direction: "src" | "dst", add: boolean) => {
    const password = await promptPassword(`${add ? "Ignorer" : "Réactiver"} l'IP ${ip} en capture (${direction.toUpperCase()}) ?`);
    if (!password) return;

    const res = await manageIgnoredIpAddress(
      activeProbeUrl,
      { ip, direction, add, username: getProbeUsername(), password },
      () => {},
      (err) => { if (err) toast.error(err); },
      () => {},
      navigate
    );

    if (res?.success) {
      toast.success(`IP ${ip} (${direction.toUpperCase()}) ${add ? "ignorée" : "réactivée"} en capture !`);
    }
  };

   if (!isLogin()) {
        return (
            <div id="ap-locked-screen" className="simatk-module">
                <div className="simatk-auth-locked">
                    <Lock size={36} style={{ color: "var(--accent)" }} />
                    <h2>Accès Restreint aux IDS/IPS</h2>
                    <p>
                        Une session authentifiée est requise pour accéder aux outils réseau.
                    </p>
                    <Link to="/login" className="oh-btn oh-btn--primary" style={{ marginTop: 12 }}>
                        Se Connecter
                    </Link>
                </div>
            </div>
        );
    }
    
  return (
    <div id="ids-container" className="ids-container">
      {/* ── HEADER SUPÉRIEUR GLOBAL ── */}
      <header className="ids-header">
        <div className="ids-header__left">
          <h1>
            <Shield size={26} className="ids-header__logo" />
            <span>IDS / IPS — SURVEILLANCE RÉSEAU</span>
          </h1>
        </div>

        <div className="ids-header__right">
          <button
            type="button"
            className="oh-btn oh-btn--ghost"
            onClick={() => {
              if (selectedProbe) refreshProbeData();
              else loadFleetProbes();
            }}
            disabled={loadingProbes || loadingProbeData}
          >
            <RefreshCw size={14} className={(loadingProbes || loadingProbeData) ? "oh-spin" : ""} /> Actualiser
          </button>
          
          {getUsername() && <div className="ids-header__user-badge">
            <span>👤 {getUsername()[0].toUpperCase() + getUsername().slice(1)}</span>
          </div>}
        </div>
      </header>

      {/* ── BASCULE VUE 1 (FLOTTE) <-> VUE 2 (SONDE ACTIVE) ── */}
      {!selectedProbe ? (
        <FleetView probes={probesList} onSelectProbe={setSelectedProbe} />
      ) : (
        <ProbeDetailView
          probe={selectedProbe}
          probeUrl={activeProbeUrl}
          username={username}
          idsMode={idsMode}
          bokehPort={bokehPort}
          alerts={alerts}
          blockedIps={blockedIps}
          seuilDecision={seuilDecision}
          helpData={helpData}
          loadingProbeData={loadingProbeData}
          onBackToFleet={() => setSelectedProbe(null)}
          onRefreshData={refreshProbeData}
          onClearAlerts={() => setAlerts([])}
          onUnlockIp={handleUnlock}
          onUpdateSeuil={handleUpdateSeuil}
          onModeChange={handleModeChange}
          onBlockIp={handleBlockManual}
          onManageWhitelist={handleWhitelistManual}
          onSaveCategoryConfig={handleSaveCategoryConfig}
          onManageIgnoredIp={handleManageIgnoredIp}
        />
      )}

      {/* ── MODALE PASSWORDPROMPT RÉUTILISABLE ── */}
      {passwordModal}
    </div>
  );
}

export default IdsIps;