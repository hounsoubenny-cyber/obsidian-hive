import React from "react";
import "./bokeh_tab.css";
import { ExternalLink, LineChart } from "lucide-react";
import { resolveProbeBokehUrl } from "../probe_url";
import { probIsLogin } from "../utils";

interface BokehTabProps {
  host: string;
  bokehPort: number | null;
}

export const BokehTab: React.FC<BokehTabProps> = ({ host, bokehPort }) => {
  if (!probIsLogin()){
    return (
      <div>
        
      </div>
    )
  }
  if (!bokehPort) {
    return (
      <div className="bokeh-empty">
        <LineChart size={44} className="bokeh-empty__icon" />
        <h3 className="bokeh-empty__title">Serveur Graphique Bokeh Inactif</h3>
        <p className="bokeh-empty__desc">
          Le serveur de visualisation temps réel n'est pas démarré sur cette sonde (paramètre <code>GRAPH=false</code> dans la configuration ou port non attribué).
        </p>
      </div>
    );
  }

  const bokehUrl = resolveProbeBokehUrl(host, bokehPort);

  return (
    <div className="bokeh-container">
      {/* ── HEADER DU GRAPHIQUE ── */}
      <div className="bokeh-header">
        <div className="bokeh-header__title">
          <LineChart size={18} style={{ color: "var(--accent-strong)" }} />
          <span>Visualisation des Flux & Anomalies en Temps Réel (Bokeh Server)</span>
        </div>

        <a
          href={bokehUrl}
          target="_blank"
          rel="noreferrer"
          className="oh-btn oh-btn--ghost bokeh-open-btn"
          title="Ouvrir le graphique Bokeh dans un nouvel onglet plein écran"
        >
          <ExternalLink size={13} />
          <span>Ouvrir en grand</span>
        </a>
      </div>

      {/* ── IFRAME BOKEH THEME-ADAPTIVE ── */}
      <div className="bokeh-iframe-wrapper">
        <iframe
          src={bokehUrl}
          title="Bokeh Real-Time Dashboard"
          className="bokeh-iframe"
          sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
        />
      </div>
    </div>
  );
};