import React, { useState, useEffect } from "react";
import "./probe_login_tab.css";
import { 
  Lock, 
  User, 
  KeyRound, 
  LogOut, 
  ShieldCheck, 
  Eye, 
  EyeOff, 
  CheckCircle2 
} from "lucide-react";
import { 
  getProbeToken, 
  getProbeUsername, 
  setProbeSession, 
  clearProbeSession, 
  probeLogin 
} from "../utils";
import toast from "react-hot-toast";

interface ProbeLoginTabProps {
  probeName: string;
  probeUrl: string;
  onLoginSuccess?: (token: string, username: string) => void;
  onLogoutSuccess?: () => void;
}

export const ProbeLoginTab: React.FC<ProbeLoginTabProps> = ({
  probeName,
  probeUrl,
  onLoginSuccess,
  onLogoutSuccess,
}) => {
  const [token, setToken] = useState<string>(getProbeToken());
  const [connectedUser, setConnectedUser] = useState<string>(getProbeUsername());
  
  // États du formulaire
  const [usernameInput, setUsernameInput] = useState<string>("");
  const [passwordInput, setPasswordInput] = useState<string>("");
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const isLoggedIn = Boolean(token);

  // Synchronise l'état local si l'URL de la sonde change
  useEffect(() => {
    setToken(getProbeToken());
    setConnectedUser(getProbeUsername());
  }, [probeUrl]);

  // Connexion
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!usernameInput.trim() || !passwordInput.trim()) {
      setError("Veuillez renseigner le nom d'utilisateur et le mot de passe.");
      return;
    }

    setIsLoading(true);
    setError(null);

    const res = await probeLogin(probeUrl, {
      username: usernameInput.trim(),
      password: passwordInput.trim(),
    });

    setIsLoading(false);

    if (res.success && res.access_token) {
      setProbeSession(res.access_token, res.username || usernameInput.trim());
      setToken(res.access_token);
      setConnectedUser(res.username || usernameInput.trim());
      setPasswordInput("");
      toast.success(`Connecté avec succès à : ${probeName}`);
      if (onLoginSuccess) onLoginSuccess(res.access_token, res.username || usernameInput.trim());
    } else {
      const errMsg = res.error || "Échec de l'authentification sur la sonde.";
      setError(errMsg);
      toast.error(errMsg);
    }
  };

  // Déconnexion
  const handleLogout = () => {
    clearProbeSession();
    setToken("");
    setConnectedUser("");
    toast.success(`Déconnecté de la sonde : ${probeName}`);
    if (onLogoutSuccess) onLogoutSuccess();
  };

  return (
    <div className="probe-auth-tab">
      {isLoggedIn ? (
        /* ── VUE 1 : DÉJÀ CONNECTÉ (PROPOSITION DE DÉCONNEXION) ── */
        <div className="probe-auth-card">
          <div className="probe-auth-card__header">
            <div className="probe-auth-card__icon-wrapper probe-auth-card__icon-wrapper--success">
              <ShieldCheck size={24} />
            </div>
            <div>
              <h3>Session Active sur la Sonde</h3>
              <p>Vous êtes authentifié en tant qu'administrateur sur cette sonde réseau.</p>
            </div>
          </div>

          <div className="probe-auth-details">
            <div className="probe-auth-details__row">
              <span>Sonde ciblée :</span>
              <strong>{probeName}</strong>
            </div>
            <div className="probe-auth-details__row">
              <span>Endpoint API :</span>
              <code>{probeUrl}</code>
            </div>
            <div className="probe-auth-details__row">
              <span>Utilisateur :</span>
              <span className="oh-badge oh-badge--accent">👤 {connectedUser}</span>
            </div>
            <div className="probe-auth-details__row">
              <span>Statut JWT :</span>
              <span className="oh-badge oh-badge--success">
                <CheckCircle2 size={12} /> Session Valide
              </span>
            </div>
          </div>

          <div className="probe-auth-card__actions">
            <button
              type="button"
              className="oh-btn oh-btn--ghost probe-auth-btn--logout"
              onClick={handleLogout}
            >
              <LogOut size={14} /> Se déconnecter de cette sonde
            </button>
          </div>
        </div>
      ) : (
        /* ── VUE 2 : FORMULAIRE DE CONNEXION ── */
        <div className="probe-auth-card">
          <div className="probe-auth-card__header">
            <div className="probe-auth-card__icon-wrapper">
              <KeyRound size={24} />
            </div>
            <div>
              <h3>Connexion à la Sonde Réseau</h3>
              <p>Authentifiez-vous pour débloquer les actions sensibles (règles NFTables, mode IPS, configuration).</p>
            </div>
          </div>

          {error && (
            <div className="probe-auth-error">
              <span>❌ {error}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="probe-auth-form">
            <div className="probe-auth-form__group">
              <label className="probe-auth-form__label">Nom d'utilisateur</label>
              <div className="probe-auth-input-wrapper">
                <User size={15} className="probe-auth-input-icon" />
                <input
                  type="text"
                  className="probe-auth-input"
                  placeholder="admin"
                  value={usernameInput}
                  onChange={(e) => setUsernameInput(e.target.value)}
                  disabled={isLoading}
                  autoComplete="username"
                />
              </div>
            </div>

            <div className="probe-auth-form__group">
              <label className="probe-auth-form__label">Mot de passe</label>
              <div className="probe-auth-input-wrapper">
                <Lock size={15} className="probe-auth-input-icon" />
                <input
                  type={showPassword ? "text" : "password"}
                  className="probe-auth-input"
                  placeholder="••••••••"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  disabled={isLoading}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  className="probe-auth-eye-btn"
                  onClick={() => setShowPassword(!showPassword)}
                  title={showPassword ? "Masquer" : "Afficher"}
                >
                  {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="oh-btn oh-btn--primary probe-auth-submit-btn"
              disabled={isLoading || !usernameInput.trim() || !passwordInput.trim()}
            >
              {isLoading ? (
                <>
                  <span className="oh-spin">🔄</span> Connexion en cours...
                </>
              ) : (
                <>
                  <KeyRound size={15} /> Se connecter à la sonde
                </>
              )}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};