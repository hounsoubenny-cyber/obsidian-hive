import React, { useState } from "react";
import "./help_tab.css";
import { BookOpen, Copy, Check, Terminal, Shield, KeyRound, Globe, AlertTriangle } from "lucide-react";
import toast from "react-hot-toast";

interface HelpTabProps {
  helpData: any;
}

export const HelpTab: React.FC<HelpTabProps> = ({ helpData }) => {
  const [copiedCurl, setCopiedCurl] = useState<string | null>(null);

  const handleCopy = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedCurl(key);
      toast.success("cURL copié !");
      setTimeout(() => setCopiedCurl(null), 1500);
    } catch {
      toast.error("Échec de la copie");
    }
  };

  if (!helpData) {
    return (
      <div className="help-empty">
        <BookOpen size={36} className="help-empty__icon" />
        <p>Chargement de la documentation intégrée de la sonde...</p>
      </div>
    );
  }

  const { endpoints, niveaux_decision, exemples_curl, authentification } = helpData;

  return (
    <div className="help-tab">
      {/* ── 1. BANDEAU TITRE & INFOS ── */}
      <div className="help-header-card">
        <div className="help-header-card__info">
          <h3>
            <BookOpen size={20} style={{ color: "var(--accent-strong)" }} />
            <span>{helpData.message || "Documentation API — Sonde IDS/IPS"}</span>
          </h3>
          <p>
            Référence technique des endpoints, des niveaux de décision et commandes cURL de la sonde.
          </p>
        </div>
        <div className="help-header-card__badges">
          <span className="oh-badge oh-badge--info">Version {helpData.version || "2.0.0"}</span>
          <span className="oh-badge oh-badge--accent">{helpData.rate_limit || "30 req/min"}</span>
        </div>
      </div>

      {/* ── 2. NIVEAUX DE DÉCISION & SCORING (0-300) ── */}
      {niveaux_decision && (
        <div className="help-card">
          <div className="help-card__header">
            <Shield size={18} style={{ color: "var(--accent)" }} />
            <h4>Niveaux de Décision & Actions du Scoring</h4>
          </div>
          <div className="help-decision-grid">
            {Object.entries(niveaux_decision).map(([level, info]: [string, any]) => {
              const badgeClass =
                level === "block_perm" || level === "block_temp"
                  ? "oh-badge--danger"
                  : level.startsWith("rate_limit")
                  ? "oh-badge--warning"
                  : "oh-badge--info";

              return (
                <div key={level} className="help-decision-item">
                  <div className="help-decision-item__top">
                    <span className="help-decision-item__level">{level.toUpperCase()}</span>
                    <span className={`oh-badge ${badgeClass}`}>{info.score_range}</span>
                  </div>
                  <p className="help-decision-item__action">{info.action}</p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── 3. EXEMPLES DE COMMANDES CURL ── */}
      {exemples_curl && (
        <div className="help-card">
          <div className="help-card__header">
            <Terminal size={18} style={{ color: "var(--accent)" }} />
            <h4>Exemples de Commandes cURL</h4>
          </div>
          <div className="help-curl-list">
            {Object.entries(exemples_curl).map(([name, cmd]: [string, any]) => (
              <div key={name} className="help-curl-item">
                <div className="help-curl-item__top">
                  <span className="help-curl-item__name">{name}</span>
                  <button
                    type="button"
                    className="oh-btn oh-btn--ghost help-curl-copy-btn"
                    onClick={() => handleCopy(name, cmd)}
                  >
                    {copiedCurl === name ? <Check size={12} className="help-icon-ok" /> : <Copy size={12} />}
                    <span>{copiedCurl === name ? "Copié !" : "Copier"}</span>
                  </button>
                </div>
                <pre className="help-curl-pre"><code>{cmd}</code></pre>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── 4. TABLEAUX DES ENDPOINTS ── */}
      {endpoints && (
        <div className="help-card">
          <div className="help-card__header">
            <Globe size={18} style={{ color: "var(--accent)" }} />
            <h4>Endpoints Disponibles</h4>
          </div>

          {/* Endpoints Publics */}
          {endpoints.public && endpoints.public.length > 0 && (
            <div className="help-endpoint-section">
              <span className="help-endpoint-section__title">🌐 Endpoints Publics (Sans Authentification)</span>
              <div className="help-table-wrapper">
                <table className="help-table">
                  <thead>
                    <tr>
                      <th style={{ width: "90px" }}>Méthode</th>
                      <th style={{ width: "220px" }}>Route</th>
                      <th>Description</th>
                    </tr>
                  </thead>
                  <tbody>
                    {endpoints.public.map((ep: any, idx: number) => (
                      <tr key={idx}>
                        <td>
                          <span className={`help-method-badge help-method-badge--${ep.method.toLowerCase()}`}>
                            {ep.method}
                          </span>
                        </td>
                        <td><code className="help-path">{ep.path}</code></td>
                        <td>{ep.description}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Endpoints Authentifiés */}
          {endpoints.authenticated && endpoints.authenticated.length > 0 && (
            <div className="help-endpoint-section">
              <span className="help-endpoint-section__title">🔑 Endpoints Authentifiés (Token JWT Requis)</span>
              <div className="help-table-wrapper">
                <table className="help-table">
                  <thead>
                    <tr>
                      <th style={{ width: "90px" }}>Méthode</th>
                      <th style={{ width: "220px" }}>Route</th>
                      <th>Description / Payload</th>
                    </tr>
                  </thead>
                  <tbody>
                    {endpoints.authenticated.map((ep: any, idx: number) => (
                      <tr key={idx}>
                        <td>
                          <span className={`help-method-badge help-method-badge--${ep.method.toLowerCase()}`}>
                            {ep.method}
                          </span>
                        </td>
                        <td><code className="help-path">{ep.path}</code></td>
                        <td>
                          {ep.description || (ep.body ? `Body: ${JSON.stringify(ep.body)}` : "—")}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Endpoints Critiques */}
          {endpoints.critical && endpoints.critical.length > 0 && (
            <div className="help-endpoint-section">
              <span className="help-endpoint-section__title" style={{ color: "var(--danger)" }}>
                ⚠️ Endpoints Critiques (Token + Mot de Passe Requis)
              </span>
              <div className="help-table-wrapper">
                <table className="help-table">
                  <thead>
                    <tr>
                      <th style={{ width: "90px" }}>Méthode</th>
                      <th style={{ width: "220px" }}>Route</th>
                      <th>Description</th>
                    </tr>
                  </thead>
                  <tbody>
                    {endpoints.critical.map((ep: any, idx: number) => (
                      <tr key={idx}>
                        <td>
                          <span className={`help-method-badge help-method-badge--${ep.method.toLowerCase()}`}>
                            {ep.method}
                          </span>
                        </td>
                        <td><code className="help-path">{ep.path}</code></td>
                        <td>{ep.description || (ep.body ? `Body: ${JSON.stringify(ep.body)}` : "—")}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};