import React, { useState, useEffect } from "react";
import "./health_tab.css";
import { Activity, RefreshCw, ExternalLink } from "lucide-react";
import { IdsHealthResponse } from "@/types/ids_ips/types";
import { getIdsHealth } from "../utils";

interface HealthTabProps {
  probeUrl: string;
}

export const HealthTab: React.FC<HealthTabProps> = ({ probeUrl }) => {
  const [health, setHealth] = useState<IdsHealthResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);

  const fetchHealth = () => {
    setLoading(true);
    getIdsHealth(
      probeUrl,
      (res) => {
        setHealth(res);
        setLoading(false);
      },
      () => setLoading(false),
      () => {}
    );
  };

  useEffect(() => {
    fetchHealth();
  }, [probeUrl]);

  useEffect(() => {
    if (!autoRefresh) return;
    const interval = setInterval(fetchHealth, 5000);
    return () => clearInterval(interval);
  }, [autoRefresh, probeUrl]);

  return (
    <div className="health-tab">
      <div className="health-header-card">
        <div>
          <h3><Activity size={18} style={{ color: "var(--accent)" }} /> Diagnostics & Santé de la Sonde</h3>
          <p>Surveillance en temps réel de l'API de sonde, du moteur ML et du serveur Bokeh.</p>
        </div>

        <div className="health-header-actions">
          <label className="health-autorefresh-label">
            <input
              type="checkbox"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
            />
            Auto-refresh (5s)
          </label>
          <button
            type="button"
            className="oh-btn oh-btn--ghost"
            onClick={fetchHealth}
            disabled={loading}
          >
            <RefreshCw size={14} className={loading ? "oh-spin" : ""} /> Rafraîchir
          </button>
        </div>
      </div>

      <div className="health-grid">
        {/* Statut Global */}
        <div className="health-card">
          <h4>Statut Global de l'API</h4>
          <div style={{ marginTop: 10 }}>
            <span className={`oh-badge ${health?.status === "healthy" ? "oh-badge--success" : "oh-badge--danger"}`}>
              {health?.status === "healthy" ? "✅ HEALTHY" : "⚠️ NON RÉSOLU"}
            </span>
          </div>
          <span className="health-card__subtext">
            Timestamp : {health?.timestamp ? new Date(health.timestamp).toLocaleString() : "N/A"}
          </span>
        </div>

        {/* Moteur Détecteur IA */}
        <div className="health-card">
          <h4>Moteur de Détection IA</h4>
          <div style={{ marginTop: 10 }}>
            <span className={`oh-badge ${health?.detector_ready ? "oh-badge--success" : "oh-badge--warning"}`}>
              {health?.detector_ready ? "🟢 OPÉRATIONNEL" : "🟡 EN CHARGEMENT"}
            </span>
          </div>
          <span className="health-card__subtext">
            Pipeline ML (Autoencoders + IsolationForest + LOF).
          </span>
        </div>

        {/* Port Bokeh */}
        <div className="health-card">
          <h4>Serveur Graphique Bokeh</h4>
          <div style={{ marginTop: 10 }}>
            <span className={`oh-badge ${health?.graph_port ? "oh-badge--info" : "oh-badge--warning"}`}>
              {health?.graph_port ? `Port alloué : ${health.graph_port}` : "Inactif"}
            </span>
          </div>
          {health?.graph_port && (
            <a
              href={`http://${new URL(probeUrl).hostname}:${health.graph_port}/`}
              target="_blank"
              rel="noreferrer"
              className="health-card__link"
            >
              Accéder au serveur direct <ExternalLink size={12} />
            </a>
          )}
        </div>
      </div>
    </div>
  );
};