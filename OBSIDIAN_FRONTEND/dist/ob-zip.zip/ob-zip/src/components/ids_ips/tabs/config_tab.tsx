import React, { useState, useEffect } from "react";
import "./config_tab.css";
import { Sliders, RefreshCw } from "lucide-react";
import { IdsFullConfig } from "@/types/ids_ips/types";
import { getFullIdsConfig, getDefaultConfigTemplate } from "../utils";
import JsonEditor from "@/components/utils/json_editor/json_editor";
import toast from "react-hot-toast";
import { toTitleCaseWithUnderscore } from "@/components/utils/to_lower_case";

interface ConfigTabProps {
  probeUrl: string;
  username: string;
  onSaveCategory: (key: string, data: Record<string, any>) => Promise<boolean>;
}

export const ConfigTab: React.FC<ConfigTabProps> = ({ probeUrl, username, onSaveCategory }) => {
  const [config, setConfig] = useState<IdsFullConfig | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>("SEUIL");

  const loadConfig = () => {
    setLoading(true);
    getFullIdsConfig(
      probeUrl,
      username,
      (res) => {
        if (res && res["ids/ips_config"]) {
          setConfig(res["ids/ips_config"]);
        } else {
          getDefaultConfigTemplate(probeUrl, (def) => setConfig(def), () => {}, () => {});
        }
        setLoading(false);
      },
      (err) => {
        if (err) {toast.error(`Erreur config: ${err}`);
        setLoading(false);}
      },
      () => {}
    );
  };

  useEffect(() => {
    loadConfig();
  }, [probeUrl]);

  const categories = config ? Object.keys(config) : [];

  const handleSaveCurrentCategory = async (updatedData: Record<string, any>) => {
    const ok = await onSaveCategory(activeCategory, updatedData);
    if (ok) {
      setConfig((prev) => (prev ? { ...prev, [activeCategory]: updatedData } : null));
    }
  };

  return (
    <div className="cfg-tab">
      <div className="cfg-header-card">
        <div>
          <h3><Sliders size={18} style={{ color: "var(--accent)" }} /> Éditeur de Configuration de la Sonde</h3>
          <p>Consultez et mettez à jour à chaud les paramètres de scoring, seuils ML et règles réseau.</p>
        </div>
        <button
          type="button"
          className="oh-btn oh-btn--ghost"
          onClick={loadConfig}
          disabled={loading}
        >
          <RefreshCw size={14} className={loading ? "oh-spin" : ""} /> Recharger
        </button>
      </div>

      {config ? (
        <div className="cfg-layout">
          {/* Liste latérale des catégories */}
          <div className="cfg-sidebar">
            <span className="cfg-sidebar__title">Catégories de configuration</span>
            <div className="cfg-sidebar__nav">
              {categories.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  className={`cfg-category-btn ${activeCategory === cat ? "cfg-category-btn--active" : ""}`}
                  onClick={() => setActiveCategory(cat)}
                >
                  {toTitleCaseWithUnderscore(cat)}
                </button>
              ))}
            </div>
          </div>

          {/* Éditeur JSON de la catégorie active */}
          <div className="cfg-editor-wrapper">
            <JsonEditor
              title={`⚙️ Configuration : ${activeCategory}`}
              json={config[activeCategory as keyof IdsFullConfig] || {}}
              onSave={handleSaveCurrentCategory}
              saveLabel="💾 Appliquer les modifications"
              readOnly={true}
              fileName={`${activeCategory.toLowerCase()}_config.json`}
            />
          </div>
        </div>
      ) : (
        <div className="cfg-empty">
          {loading ? "Chargement de la configuration..." : "Configuration indisponible pour le moment."}
        </div>
      )}
    </div>
  );
};