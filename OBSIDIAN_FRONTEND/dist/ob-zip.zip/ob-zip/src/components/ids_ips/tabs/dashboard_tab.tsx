import React, { useState } from "react";
import "./dashboard_tab.css";
import { 
  RefreshCw, 
  CheckCircle2, 
  Sliders, 
  Radio, 
  Zap, 
  Lock, 
  Trash2, 
  ShieldAlert,
  Terminal
} from "lucide-react";
import { 
  IdsAlertEvent, 
  BlockedIpsResponseMap, 
  IdsMode, 
  NftRuleType 
} from "@/types/ids_ips/types";
import { BlockedIpCard } from "../cards/blocked_ip_card";

interface DashboardTabProps {
  alerts: IdsAlertEvent[];
  blockedIps: BlockedIpsResponseMap;
  idsMode: IdsMode;
  seuilDecision: number;
  loadingProbeData: boolean;
  onClearAlerts: () => void;
  onRefresh: () => void;
  onUnlockIp: (ip: string, rule: string) => void;
  onUpdateSeuil: (val: number) => void;
  onModeChange: (mode: IdsMode) => void;
  onBlockIp: (ip: string, rule: NftRuleType) => void;
  onManageWhitelist: (ip: string, add: boolean) => void;
  onManageIgnoredIp: (ip: string, direction: "src" | "dst", add: boolean) => void;
}

export const DashboardTab: React.FC<DashboardTabProps> = ({
  alerts,
  blockedIps,
  idsMode,
  seuilDecision,
  loadingProbeData,
  onClearAlerts,
  onRefresh,
  onUnlockIp,
  onUpdateSeuil,
  onModeChange,
  onBlockIp,
  onManageWhitelist,
  onManageIgnoredIp
}) => {
  // États locaux des 3 panneaux du bas
  const [seuilInput, setSeuilInput] = useState<number>(seuilDecision);
  const [manualIpBlock, setManualIpBlock] = useState("");
  const [manualBlockRule, setManualBlockRule] = useState<NftRuleType>("drop");
  const [manualIpWhite, setManualIpWhite] = useState("");
  const [manualIpIgnore, setManualIpIgnore] = useState("");
  const [ignoreDirection, setIgnoreDirection] = useState<"src" | "dst">("src");

  const handleBlock = () => {
    if (!manualIpBlock.trim()) return;
    onBlockIp(manualIpBlock.trim(), manualBlockRule);
    setManualIpBlock("");
  };

  const handleWhitelist = (add: boolean) => {
    if (!manualIpWhite.trim()) return;
    onManageWhitelist(manualIpWhite.trim(), add);
    setManualIpWhite("");
  };
  

  const handleIgnoredIp = (add: boolean) => {
    if (!manualIpIgnore.trim()) return;
    onManageIgnoredIp(manualIpIgnore.trim(), ignoreDirection, add);
    setManualIpIgnore("");
  };

  return (
    <div className="dash-tab">
      {/* ── 1. BOUTON RAFRAÎCHIR TOUT EN HAUT À GAUCHE ── */}
      <div className="dash-top-bar">
        <button
          type="button"
          className="oh-btn oh-btn--ghost dash-refresh-master-btn"
          onClick={onRefresh}
          disabled={loadingProbeData}
          title="Rafraîchir l'ensemble des données de la sonde"
        >
          <RefreshCw size={14} className={loadingProbeData ? "oh-spin" : ""} />
          <span>Rafraîchir les données</span>
        </button>
      </div>

      {/* ── 2. SECTION ALERTES EN DIRECT ── */}
      <section className="dash-alerts-section">
        <div className="dash-section-header">
          <h2>⚡ Flux d'Alertes Réseau ({alerts.length})</h2>
          
          <button
            type="button"
            className="oh-btn oh-btn--ghost dash-clear-btn"
            onClick={onClearAlerts}
            title="Vider la vue locale des alertes"
          >
            <Trash2 size={13} />
            <span>Vider</span>
          </button>
        </div>

        {/* Boîte du Terminal de logs */}
        <div className="dash-terminal">
          <div className="dash-terminal__body">
            {alerts.length === 0 ? (
              <div className="dash-terminal__empty">
                <ShieldAlert size={28} className="dash-terminal__empty-icon" />
                <span>Aucune alerte suspecte détectée sur cette sonde.</span>
              </div>
            ) : (
              alerts.map((al, idx) => {
                const severityClass =
                  al.severity >= 3 ? "dash-alert--crit" :
                  al.severity === 2 ? "dash-alert--high" : "dash-alert--med";

                return (
                  <div key={idx} className={`dash-alert-row ${severityClass}`}>
                    <span className="dash-alert__time">{al.timestamp}</span>
                    <span className="dash-alert__proto">[{al.proto}]</span>
                    <span className="dash-alert__flow">
                      {al.src_ip}:{al.src_port || "?"} → {al.dest_ip}:{al.dest_port || "?"}
                    </span>
                    <span className="dash-alert__signature">
                      {al.signature || al.event_type}
                    </span>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </section>

      {/* ── 3. SECTION IPs BLOQUÉES / SURVEILLÉES ── */}
      <section className="dash-blocked-section">
        <div className="dash-section-header">
          <h2>🚫 IPs Bloquées / Surveillées ({Object.keys(blockedIps).length})</h2>
        </div>

        <div className="dash-ip-grid">
          {Object.entries(blockedIps).length === 0 ? (
            <div className="dash-ip-grid__empty">
              <CheckCircle2 size={36} style={{ color: "var(--success)", margin: "0 auto 8px" }} />
              <p className="dash-ip-grid__empty-title">🎉 Aucune IP bloquée actuellement !</p>
              <p className="dash-ip-grid__empty-subtitle">Tout va bien sur le réseau de cette sonde.</p>
            </div>
          ) : (
            Object.entries(blockedIps).map(([ip, data]) => (
              <BlockedIpCard key={ip} ip={ip} data={data} onUnlock={onUnlockIp} />
            ))
          )}
        </div>
      </section>

      {/* ── 4. LES 3 PANNEAUX INFÉRIEURS ── */}
      <div className="dash-panels-bottom">
        {/* Panneau 1 : Configuration Seuil */}
        <div className="dash-panel">
          <h3><Sliders size={18} style={{ color: "var(--accent)" }} /> ⚙️ CONFIGURATION</h3>
          <div className="dash-panel__group">
            <label className="dash-panel__label">Seuil de décision ML :</label>
            <div className="dash-panel__control">
              <input
                type="number"
                step="0.05"
                min="-1"
                max="1"
                className="dash-input"
                value={seuilInput}
                onChange={(e) => setSeuilInput(parseFloat(e.target.value))}
              />
              <button
                type="button"
                className="oh-btn oh-btn--primary"
                onClick={() => onUpdateSeuil(seuilInput)}
              >
                Valider
              </button>
            </div>
            <small className="dash-panel__hint">
              Plus le seuil est bas, plus l'IDS est sensible (-1 = très sensible, 1 = très strict).
            </small>
          </div>
        </div>

        {/* Panneau 2 : Mode IDS / IPS */}
        <div className="dash-panel">
          <h3><Radio size={18} style={{ color: "var(--accent)" }} /> 🎮 MODE IDS / IPS</h3>
          <div className="dash-mode-grid">
            <button
              type="button"
              className={`dash-mode-btn ${idsMode === "ids" ? "dash-mode-btn--active" : ""}`}
              onClick={() => onModeChange("ids")}
            >
              🕵️ IDS (Détection seule)
            </button>
            <button
              type="button"
              className={`dash-mode-btn ${idsMode === "ips" ? "dash-mode-btn--active" : ""}`}
              onClick={() => onModeChange("ips")}
            >
              🛡️ IPS (Prévention active)
            </button>
          </div>
          <div className="dash-mode-status">
            Mode actif : <strong className={idsMode === "ips" ? "oh-badge oh-badge--danger" : "oh-badge oh-badge--info"}>{idsMode.toUpperCase()}</strong>
          </div>
        </div>

        {/* Panneau 3 : Actions Manuelles */}
        <div className="dash-panel">
          <h3><Zap size={18} style={{ color: "var(--accent)" }} /> ⚡ ACTIONS MANUELLES</h3>
          
          {/* Bloquer IP */}
          <div className="dash-action-group">
            <label className="dash-panel__label">Bloquer une IP :</label>
            <div className="dash-action-control">
              <input
                type="text"
                placeholder="192.168.1.5"
                value={manualIpBlock}
                onChange={(e) => setManualIpBlock(e.target.value)}
                className="dash-input"
                style={{ flex: 1 }}
              />
              <select
                value={manualBlockRule}
                onChange={(e) => setManualBlockRule(e.target.value as NftRuleType)}
                className="dash-select"
              >
                <option value="drop">🚫 Drop</option>
                <option value="rate_limit">⏱️ Rate</option>
                <option value="rate_limit_data">📉 Data</option>
              </select>
              <button
                type="button"
                className="oh-btn oh-btn--primary"
                style={{ padding: "8px 14px" }}
                onClick={handleBlock}
                title="Appliquer le blocage"
              >
                <Lock size={13} /> Bloquer
              </button>
            </div>
          </div>

          {/* Whitelist IP */}
          <div className="dash-action-group" style={{ marginTop: "8px" }}>
            <label className="dash-panel__label">Gestion Whitelist :</label>
            <div className="dash-action-control">
              <input
                type="text"
                placeholder="IP / CIDR Whitelist..."
                value={manualIpWhite}
                onChange={(e) => setManualIpWhite(e.target.value)}
                className="dash-input"
                style={{ flex: 1 }}
              />
              <button
                type="button"
                className="oh-btn oh-btn--ghost dash-btn-circle"
                onClick={() => handleWhitelist(true)}
                title="Ajouter à la whitelist"
              >
                ➕
              </button>
              <button
                type="button"
                className="oh-btn oh-btn--ghost dash-btn-circle"
                onClick={() => handleWhitelist(false)}
                title="Retirer de la whitelist"
              >
                ➖
              </button>
            </div>
          </div>

          {/* 3. Ignorer en Capture */}
          <div className="dash-action-group" style={{ marginTop: "4px" }}>
            <label className="dash-panel__label">Ignorer en Capture (Filtre) :</label>
            <div className="dash-action-control">
              <input
                type="text"
                placeholder="IP à ignorer..."
                value={manualIpIgnore}
                onChange={(e) => setManualIpIgnore(e.target.value)}
                className="dash-input"
                style={{ flex: 1 }}
              />
              <select
                value={ignoreDirection}
                onChange={(e) => setIgnoreDirection(e.target.value as "src" | "dst")}
                className="dash-select"
                style={{ width: "85px" }}
              >
                <option value="src">Sortant</option>
                <option value="dst">Entrant</option>
              </select>
              <button
                type="button"
                className="oh-btn oh-btn--ghost dash-btn-circle"
                onClick={() => handleIgnoredIp(true)}
                title="Ajouter aux IPs ignorées"
              >
                ➕
              </button>
              <button
                type="button"
                className="oh-btn oh-btn--ghost dash-btn-circle"
                onClick={() => handleIgnoredIp(false)}
                title="Retirer des IPs ignorées"
              >
                ➖
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};