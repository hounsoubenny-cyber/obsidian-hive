import React, { useState, useEffect } from "react";
import "./probe_detail_view.css";
import { EnrichedProbe } from "./cards/probe_card";
import { 
  IdsMode, 
  IdsAlertEvent, 
  BlockedIpsResponseMap, 
  NftRuleType 
} from "@/types/ids_ips/types";
import { DashboardTab } from "./tabs/dashboard_tab";
import { ConfigTab } from "./tabs/config_tab";
import { HelpTab } from "./tabs/help_tab";
import { HealthTab } from "./tabs/health_tab";
import { BokehTab } from "./tabs/bokeh_tab";
import { ProbeLoginTab } from "./tabs/probe_login_tab";
import { 
  ArrowLeft, 
  Eye, 
  EyeOff, 
  X, 
  LayoutDashboard, 
  Sliders, 
  BookOpen, 
  Activity, 
  LineChart, 
  Search,
  KeyRound, 
  Lock
} from "lucide-react";
import { probIsLogin } from "./utils";
import { getIpGeoLocation, clearProbeSession, getProbeToken } from "./utils";
import toast from "react-hot-toast";

type TabKey = "dashboard" | "config" | "help" | "health" | "bokeh" | "auth";

interface ProbeDetailViewProps {
  probe: EnrichedProbe;
  probeUrl: string;
  username: string;
  idsMode: IdsMode;
  bokehPort: number | null;
  alerts: IdsAlertEvent[];
  blockedIps: BlockedIpsResponseMap;
  seuilDecision: number;
  helpData: any;
  loadingProbeData: boolean;
  onBackToFleet: () => void;
  onRefreshData: () => void;
  onClearAlerts: () => void;
  onUnlockIp: (ip: string, rule: string) => void;
  onUpdateSeuil: (val: number) => void;
  onModeChange: (mode: IdsMode) => void;
  onBlockIp: (ip: string, rule: NftRuleType) => void;
  onManageWhitelist: (ip: string, add: boolean) => void;
  onSaveCategoryConfig: (key: string, data: Record<string, any>) => Promise<boolean>;
  onManageIgnoredIp: (ip: string, direction: "src" | "dst", add: boolean) => void;
}

const getFlagEmoji = (countryCode?: string) => {
  if (!countryCode || countryCode === "XX") return "🌍";
  const codePoints = countryCode
    .toUpperCase()
    .split("")
    .map((char) => 127397 + char.charCodeAt(0));
  return String.fromCodePoint(...codePoints);
};

export const ProbeDetailView: React.FC<ProbeDetailViewProps> = ({
  probe,
  probeUrl,
  username,
  idsMode,
  bokehPort,
  alerts,
  blockedIps,
  seuilDecision,
  helpData,
  loadingProbeData,
  onBackToFleet,
  onRefreshData,
  onClearAlerts,
  onUnlockIp,
  onUpdateSeuil,
  onModeChange,
  onBlockIp,
  onManageWhitelist,
  onSaveCategoryConfig,
  onManageIgnoredIp
}) => {
  const [activeTab, setActiveTab] = useState<TabKey>("dashboard");
  const [isHeaderVisible, setIsHeaderVisible] = useState(true);
  const [isLoggedInOnProbe, setIsLoggedInOnProbe] = useState(Boolean(getProbeToken()));

  // Géolocalisation dans le header
  const [geoInput, setGeoInput] = useState("");
  const [geoResult, setGeoResult] = useState<{ ip: string; location: string } | null>(null);
  const [geoLoading, setGeoLoading] = useState(false);

  // Déconnexion automatique lors du changement de sonde ou fermeture de la vue.
  // Si on n'est pas connecté sur cette sonde, on ouvre directement sur le tab
  // "auth" — sinon l'utilisateur reste bloqué sans jamais voir le formulaire
  // de connexion (le tab auth étant lui-même dans le contenu protégé).
  useEffect(() => {
    const loggedIn = Boolean(getProbeToken());
    setIsLoggedInOnProbe(loggedIn);
    if (!probIsLogin()) {
      setActiveTab("auth");
    }
    return () => {
      clearProbeSession();
    };
  }, [probeUrl]);

  // Retour à la flotte avec nettoyage de session
  const handleReturnToFleet = () => {
    clearProbeSession();
    setIsLoggedInOnProbe(false);
    onBackToFleet();
  };

  const handleSearchGeo = () => {
    if (!geoInput.trim()) return;
    setGeoLoading(true);
    getIpGeoLocation(
      probeUrl,
      geoInput.trim(),
      (res) => {
        setGeoLoading(false);
        if (res?.location) setGeoResult({ ip: geoInput.trim(), location: res.location });
      },
      (err) => {
        if (err){
        setGeoLoading(false);
        toast.error("IP introuvable ou invalide");}
      }
    );
  };

  const cleanDisplayName = probe.name.replace(/0\.0\.0\.0|127\.0\.0\.1/g, "localhost");

  // Bloque uniquement le CONTENU d'un tab protégé — jamais la navigation
  // elle-même, sinon on retombe dans le piège "coincé sans pouvoir se logger".
  const renderProtectedOrContent = (content: React.ReactNode) => {
    if (!probIsLogin()) {
      return (
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            padding: "80px 20px",
            background: "var(--bg-surface)",
            border: "1px solid var(--border)",
            borderRadius: "var(--radius-xl)",
            textAlign: "center",
            gap: "16px",
            boxShadow: "var(--shadow-sm)",
          }}
        >
          <div
            style={{
              width: "56px",
              height: "56px",
              borderRadius: "var(--radius-lg)",
              background: "var(--warning-soft)",
              color: "var(--warning)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Lock size={26} />
          </div>

          <div style={{ maxWidth: "420px", display: "flex", flexDirection: "column", gap: "6px" }}>
            <h3 style={{ fontSize: "1.2rem", fontWeight: 700, margin: 0, color: "var(--text-primary)" }}>
              Authentification requise sur cette sonde
            </h3>
            <p style={{ fontSize: "0.88rem", color: "var(--text-secondary)", margin: 0, lineHeight: 1.5 }}>
              Vous devez être connecté à l'API de cette sonde réseau pour accéder au dashboard, surveiller les flux et exécuter des actions.
            </p>
          </div>

          <button
            type="button"
            className="oh-btn oh-btn--primary"
            style={{ marginTop: "8px", padding: "10px 22px" }}
            onClick={() => setActiveTab("auth")}
          >
            <KeyRound size={15} /> Se connecter à la sonde
          </button>
        </div>
      );
    }
    return content;
  };

  return (
    <div className="probe-detail-view">
      {/* ── BARRE DE CONTRÔLE SUPÉRIEURE (toujours visible) ── */}
      <div className="probe-control-bar">
        <div className="probe-control-bar__actions">
          <button type="button" className="oh-btn oh-btn--ghost" onClick={handleReturnToFleet}>
            <ArrowLeft size={14} /> Revenir à la flotte
          </button>
          <button
            type="button"
            className="oh-btn oh-btn--ghost"
            onClick={() => setIsHeaderVisible(!isHeaderVisible)}
          >
            {isHeaderVisible ? <EyeOff size={14} /> : <Eye size={14} />}
            {isHeaderVisible ? "Masquer Header" : "Afficher Header"}
          </button>
        </div>

        <button
          type="button"
          className="oh-btn oh-btn--ghost probe-control-bar__deselect-btn"
          onClick={handleReturnToFleet}
        >
          <X size={14} /> Désélectionner
        </button>
      </div>

      {/* ── HEADER SONDE (Rétractable, toujours accessible) ── */}
      {isHeaderVisible && (
        <div className="probe-header-banner">
          <div className="probe-header-banner__left">
            <h2>📌 Sonde : {cleanDisplayName}</h2>
            <div className="probe-header-banner__meta">
              <span className="probe-header-banner__endpoint">{probeUrl}</span>
              <span>•</span>
              <span className="oh-badge oh-badge--accent">
                {probe.deployment_mode?.toUpperCase() || "GATEWAY"}
              </span>
              <span>•</span>
              <span className="oh-badge oh-badge--success">🟢 EN LIGNE</span>
            </div>
          </div>

          <div className="probe-header-banner__right">
            {/* IP Locator compact */}
            <div className="probe-geo-locator">
              <Search size={14} className="probe-geo-locator__icon" />
              <input
                type="text"
                placeholder="Tester IP (ex: 8.8.8.8)..."
                value={geoInput}
                onChange={(e) => setGeoInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearchGeo()}
                className="probe-geo-locator__input"
              />
              <button
                type="button"
                onClick={handleSearchGeo}
                disabled={geoLoading}
                className="probe-geo-locator__btn"
                title="Géolocaliser"
              >
                {geoLoading ? "⏳" : "🌍"}
              </button>
              {geoResult && (
                <div className="probe-geo-locator__result">
                  <span>{getFlagEmoji(geoResult.location)}</span>
                  <span>{geoResult.location}</span>
                  <span className="probe-geo-locator__result-ip">{geoResult.ip}</span>
                </div>
              )}
            </div>

            {/* Badge Mode */}
            <span className={`probe-mode-badge ${idsMode === "ips" ? "probe-mode-badge--ips" : "probe-mode-badge--ids"}`}>
              {idsMode === "ips" ? "🛡️ IPS Actif" : "👁️ IDS Actif"}
            </span>

            {/* Port Bokeh */}
            {bokehPort && (
              <span className="probe-bokeh-badge">Bokeh: {bokehPort}</span>
            )}
          </div>
        </div>
      )}

      {/* ── BARRE DES ONGLETS (6 TABS AVEC AUTH, toujours accessible) ── */}
      <div className="probe-nav-tabs">
        <button
          type="button"
          className={`probe-tab-btn ${activeTab === "auth" ? "probe-tab-btn--active" : ""}`}
          onClick={() => setActiveTab("auth")}
        >
          <KeyRound size={15} /> 🔑 {isLoggedInOnProbe ? "Session (Connecté)" : "Connexion Sonde"}
        </button>

        <button
          type="button"
          className={`probe-tab-btn ${activeTab === "dashboard" ? "probe-tab-btn--active" : ""}`}
          onClick={() => setActiveTab("dashboard")}
        >
          <LayoutDashboard size={15} /> 📊 Dashboard
        </button>

        <button
          type="button"
          className={`probe-tab-btn ${activeTab === "config" ? "probe-tab-btn--active" : ""}`}
          onClick={() => setActiveTab("config")}
        >
          <Sliders size={15} /> ⚙️ Config
        </button>

        <button
          type="button"
          className={`probe-tab-btn ${activeTab === "help" ? "probe-tab-btn--active" : ""}`}
          onClick={() => setActiveTab("help")}
        >
          <BookOpen size={15} /> 📚 Help
        </button>

        <button
          type="button"
          className={`probe-tab-btn ${activeTab === "health" ? "probe-tab-btn--active" : ""}`}
          onClick={() => setActiveTab("health")}
        >
          <Activity size={15} /> 🩺 Health
        </button>

        <button
          type="button"
          className={`probe-tab-btn ${activeTab === "bokeh" ? "probe-tab-btn--active" : ""}`}
          onClick={() => setActiveTab("bokeh")}
        >
          <LineChart size={15} /> 📈 Bokeh
        </button>        
      </div>

      {/* ── CONTENU DE L'ONGLET ACTIF ── */}
      <div className="probe-tab-content">
        {activeTab === "dashboard" && renderProtectedOrContent(
          <DashboardTab
            alerts={alerts}
            blockedIps={blockedIps}
            idsMode={idsMode}
            seuilDecision={seuilDecision}
            loadingProbeData={loadingProbeData}
            onClearAlerts={onClearAlerts}
            onRefresh={onRefreshData}
            onUnlockIp={onUnlockIp}
            onUpdateSeuil={onUpdateSeuil}
            onModeChange={onModeChange}
            onBlockIp={onBlockIp}
            onManageWhitelist={onManageWhitelist}
            onManageIgnoredIp={onManageIgnoredIp}
          />
        )}

        {activeTab === "config" && renderProtectedOrContent(
          <ConfigTab
            probeUrl={probeUrl}
            username={username}
            onSaveCategory={onSaveCategoryConfig}
          />
        )}

        {activeTab === "help" && <HelpTab helpData={helpData} />}

        {activeTab === "health" && renderProtectedOrContent(
          <HealthTab probeUrl={probeUrl} />
        )}

        {activeTab === "bokeh" && renderProtectedOrContent(
          <BokehTab host={probe.host} bokehPort={bokehPort} />
        )}

        {activeTab === "auth" && (
          <ProbeLoginTab
            probeName={probe.name}
            probeUrl={probeUrl}
            onLoginSuccess={() => {
              setIsLoggedInOnProbe(true);
              setActiveTab("dashboard");
              onRefreshData();
            }}
            onLogoutSuccess={() => {
              setIsLoggedInOnProbe(false);
              onRefreshData();
            }}
          />
        )}
      </div>
    </div>
  );
};