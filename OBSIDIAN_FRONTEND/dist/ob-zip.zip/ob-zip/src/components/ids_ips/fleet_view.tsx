import React from "react";
import "./fleet_view.css";
import { ProbeCard, EnrichedProbe } from "./cards/probe_card";
import { Radio, CheckCircle2, XCircle, ShieldAlert } from "lucide-react";

interface FleetViewProps {
  probes: EnrichedProbe[];
  onSelectProbe: (probe: EnrichedProbe) => void;
}

export const FleetView: React.FC<FleetViewProps> = ({ probes, onSelectProbe }) => {
  const onlineCount = probes.filter((p) => p.is_open).length;
  const offlineCount = probes.length - onlineCount;

  return (
    <div className="fleet-view">
      {/* ── BANDEAU DE STATISTIQUES ── */}
      <div className="fleet-stats-grid">
        <div className="fleet-stat-card">
          <div className="fleet-stat-card__icon fleet-stat-card__icon--total">
            <Radio size={20} />
          </div>
          <div className="fleet-stat-card__content">
            <span className="fleet-stat-card__label">Total Sondes</span>
            <span className="fleet-stat-card__value">{probes.length}</span>
          </div>
        </div>

        <div className="fleet-stat-card">
          <div className="fleet-stat-card__icon fleet-stat-card__icon--online">
            <CheckCircle2 size={20} />
          </div>
          <div className="fleet-stat-card__content">
            <span className="fleet-stat-card__label">En Ligne</span>
            <span className="fleet-stat-card__value fleet-stat-card__value--online">
              {onlineCount}
            </span>
          </div>
        </div>

        <div className="fleet-stat-card">
          <div className="fleet-stat-card__icon fleet-stat-card__icon--offline">
            <XCircle size={20} />
          </div>
          <div className="fleet-stat-card__content">
            <span className="fleet-stat-card__label">Hors Ligne</span>
            <span className="fleet-stat-card__value fleet-stat-card__value--offline">
              {offlineCount}
            </span>
          </div>
        </div>
      </div>

      {/* ── GRILLE DES CARTES SONDES ── */}
      {probes.length === 0 ? (
        <div className="fleet-empty-state">
          <ShieldAlert size={44} className="fleet-empty-state__icon" />
          <h3 className="fleet-empty-state__title">Aucune sonde réseau enregistrée</h3>
          <p className="fleet-empty-state__desc">
            Créez et déployez un asset réseau (Gateway, Bridge, SPAN) pour le voir apparaître ici.
          </p>
        </div>
      ) : (
        <div className="fleet-probe-grid">
          {probes.map((probe) => (
            <ProbeCard key={probe.id} probe={probe} onSelect={onSelectProbe} />
          ))}
        </div>
      )}
    </div>
  );
};