import React from "react";
import "./probe_card.css";
import { ArrowRight, WifiOff } from "lucide-react";
import { 
  NetworkDeploymentModeMapping, 
  PRIORITY_MAPPING, 
  AssetStatusMapping 
} from "@/types/assets/types";
import { resolveProbeApiUrl } from "../probe_url";

export interface EnrichedProbe {
  id: string;
  name: string;
  host: string;
  port: number;
  is_open: boolean;
  deployment_mode?: string;
  priority?: any;
  tags?: string[];
  status?: string;
}

interface ProbeCardProps {
  probe: EnrichedProbe;
  onSelect: (probe: EnrichedProbe) => void;
}

export const ProbeCard: React.FC<ProbeCardProps> = ({ probe, onSelect }) => {
  const shortId = probe.id.length > 14 ? `${probe.id.slice(0, 10)}...` : probe.id;
  let url = new URL(resolveProbeApiUrl(probe.host, probe.port));
  let host = url.hostname;
  let port = url.port;
  return (
    <div
      className={`probe-card ${probe.is_open ? "probe-card--open" : "probe-card--closed"}`}
      onClick={() => probe.is_open && onSelect(probe)}
    >
      {/* Header : Nom + Statut */}
      <div className="probe-card__header">
        <div className="probe-card__title-group">
          <h3 className="probe-card__name">{probe.name.replace("0.0.0.0", 'localhost'.replace("127.0.0.1", "localhost"))}</h3>
          <span className="probe-card__id">ID: {shortId}</span>
        </div>
        <span className={`oh-badge ${probe.is_open ? "oh-badge--success" : "oh-badge--danger"}`}>
          {probe.is_open ? "🟢 EN LIGNE" : "🔴 HORS LIGNE"}
        </span>
      </div>

      {/* Badges : Mode de déploiement, Priorité, Statut d'asset */}
      <div className="probe-card__badges">
        {probe.deployment_mode && (
          <span className="oh-badge oh-badge--accent">
            {NetworkDeploymentModeMapping[probe.deployment_mode as keyof typeof NetworkDeploymentModeMapping] || probe.deployment_mode}
          </span>
        )}
        {probe.priority && (
          <span className="oh-badge oh-badge--warning">
            {PRIORITY_MAPPING[probe.priority as keyof typeof PRIORITY_MAPPING]}
          </span>
        )}
        <span className="oh-badge oh-badge--info">
          {AssetStatusMapping[probe.status as keyof typeof AssetStatusMapping] || probe.status}
        </span>
      </div>

      {/* Corps : Endpoint IP:Port + Tags */}
      <div className="probe-card__body">
        <div className="probe-card__row">
          <span className="probe-card__label">Endpoint :</span>
          <span className="probe-card__endpoint">{url.toString()}</span>
        </div>

        <div className="probe-card__row">
          <span className="probe-card__label">Host :</span>
          <span className="probe-card__endpoint">{host}</span>
        </div>

        <div className="probe-card__row">
          <span className="probe-card__label">Port :</span>
          <span className="probe-card__endpoint">{port}</span>
        </div>

        {probe.tags && probe.tags.length > 0 && (
          <div className="probe-card__row probe-card__row--tags">
            <span className="probe-card__label">Tags :</span>
            <div className="probe-card__tags">
              {probe.tags.map((tag, idx) => (
                <span key={idx} className="probe-card__tag-pill">{tag}</span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer / Bouton d'action */}
      <div className="probe-card__footer">
        {probe.is_open ? (
          <span className="probe-card__action-btn">
            Ouvrir la sonde <ArrowRight size={14} />
          </span>
        ) : (
          <span className="probe-card__offline-text">
            <WifiOff size={14} /> Sonde injoignable
          </span>
        )}
      </div>
    </div>
  );
};