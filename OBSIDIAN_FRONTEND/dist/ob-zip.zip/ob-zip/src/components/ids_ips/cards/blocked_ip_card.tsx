import React from "react";
import "./blocked_ip_card.css";
import { Unlock } from "lucide-react";
import { IpScoreData } from "@/types/ids_ips/types";

interface BlockedIpCardProps {
  ip: string;
  data: IpScoreData;
  onUnlock: (ip: string, rule: string) => void;
}

const getFlagEmoji = (countryCode?: string) => {
  if (!countryCode || countryCode === "XX") return "🌍";
  const codePoints = countryCode
    .toUpperCase()
    .split("")
    .map((char) => 127397 + char.charCodeAt(0));
  return String.fromCodePoint(...codePoints);
};

const getActionLabel = (action?: string) => {
  const actions: Record<string, string> = {
    "log_only": "📝 Surveillance",
    "rate_limit_data": "⏱️ Limite volume (2h)",
    "rate_limit": "🚦 Limite connexions (4h)",
    "block_temp": "🔒 Blocage temp (24h)",
    "block_perm": "⛔ Blocage permanent",
    "": "✅ Débloqué"
  };
  return actions[action || ""] || "❓ Inconnu";
};

const getScoreColor = (score: number) => {
  if (score >= 230) return "var(--danger)";
  if (score >= 180) return "#f97316";
  if (score >= 125) return "#eab308";
  if (score >= 75) return "#84cc16";
  return "var(--success)";
};

export const BlockedIpCard: React.FC<BlockedIpCardProps> = ({ ip, data, onUnlock }) => {
  const score = data?.score || 0;
  const action = data?.decision?.action || "";
  const rule = (action === "block_temp" || action === "block_perm") ? "drop" : action;

  return (
    <div className="blocked-ip-card">
      {/* En-tête : IP + Drapeau Pays */}
      <div className="blocked-ip-card__header">
        <span className="blocked-ip-card__address">{ip}</span>
        <span className="blocked-ip-card__country-badge">
          {getFlagEmoji(data?.geoloc)} {data?.geoloc || "XX"}
        </span>
      </div>

      {/* Barre de Score (0-300) */}
      <div className="blocked-ip-card__score-section">
        <div className="blocked-ip-card__score-meta">
          <span>Score : <strong style={{ color: getScoreColor(score) }}>{score}/300</strong></span>
          <span className="oh-badge oh-badge--warning">{getActionLabel(action)}</span>
        </div>
        <div className="blocked-ip-card__score-bar-bg">
          <div
            className="blocked-ip-card__score-bar-fill"
            style={{ 
              width: `${Math.min(100, (score / 300) * 100)}%`, 
              background: getScoreColor(score) 
            }}
          />
        </div>
      </div>

      {/* Détails techniques */}
      <div className="blocked-ip-card__details">
        <div className="blocked-ip-card__row">
          <span>Anomalies :</span>
          <strong>{data?.anomaly_count || 0}</strong>
        </div>
        <div className="blocked-ip-card__row">
          <span>Bloquée :</span>
          <strong>{data?.blocked_count || 0} fois</strong>
        </div>
        <div className="blocked-ip-card__row">
          <span>DNS PTR :</span>
          <span className="blocked-ip-card__dns" title={data?.resolution || ""}>
            {data?.resolution || "Non résolu"}
          </span>
        </div>
      </div>

      {/* Action : Bouton Débloquer */}
      <div className="blocked-ip-card__actions">
        <button
          type="button"
          className="oh-btn oh-btn--primary blocked-ip-card__unlock-btn"
          onClick={() => onUnlock(ip, rule || "drop")}
          disabled={!rule || rule === "log_only"}
        >
          <Unlock size={13} /> Débloquer
        </button>
      </div>
    </div>
  );
};