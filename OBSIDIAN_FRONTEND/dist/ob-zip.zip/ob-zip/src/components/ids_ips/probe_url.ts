// probe_url.ts

/**
 * Normalise l'hôte et le port pour obtenir l'URL de base de l'API de la sonde.
 * Gère les cas 0.0.0.0, 127.0.0.1, préfixes http/https existants, etc.
 * 
 * @example
 * resolveProbeApiUrl("0.0.0.0", 8080) // -> "http://localhost:8080/api"
 * resolveProbeApiUrl("192.168.1.15", 8080) // -> "http://192.168.1.15:8080/api"
 */
export function resolveProbeApiUrl(host: string, port?: number | string | null): string {
  let cleanHost = (host || "").trim();
  let protocol = "http:";

  // Si l'application tourne en HTTPS dans le navigateur, on force HTTPS
  if (typeof window !== "undefined" && window.location.protocol === "https:") {
    protocol = "https:";
  }

  // Si l'hôte contient déjà http:// ou https://
  if (cleanHost.startsWith("http://") || cleanHost.startsWith("https://")) {
    try {
      const parsed = new URL(cleanHost);
      protocol = parsed.protocol;
      cleanHost = parsed.hostname;
    } catch {
      cleanHost = cleanHost.replace(/^https?:\/\//, "");
    }
  }

  // 0.0.0.0 ou 127.0.0.1 -> localhost
  if (["0.0.0.0", "127.0.0.1"].includes(cleanHost)){
    cleanHost = "localhost"
  }

  const portSuffix = port ? `:${port}` : "";
  return `${protocol}//${cleanHost}${portSuffix}/api`;
}

/**
 * Construit l'URL du serveur graphique Bokeh de la sonde.
 * 
 * @example
 * resolveProbeBokehUrl("192.168.1.15", 5006) // -> "http://192.168.1.15:5006/"
 */
export function resolveProbeBokehUrl(host: string, bokehPort: number | string): string {
  let cleanHost = (host || "").trim();
  if (cleanHost.startsWith("http://") || cleanHost.startsWith("https://")) {
    try {
      cleanHost = new URL(cleanHost).hostname;
    } catch {
      cleanHost = cleanHost.replace(/^https?:\/\//, "");
    }
  }
  if (["0.0.0.0", "127.0.0.1"].includes(cleanHost)){
    cleanHost = "localhost"
  }
  return `http://${cleanHost}:${bokehPort}/`;
}