import { useState, useEffect, useCallback, useRef } from "react";
import "./ids_ips.css";
import { 
  NetworkEndpointsMap, 
  IdsMode, 
  IdsAlertEvent, 
  BlockedIpsResponseMap, 
  NftRuleType
} from "@/types/ids_ips/types";
import { 
  NetworkAsset, 
  NetworkDeploymentModeMapping, 
  PRIORITY_MAPPING, 
  AssetStatusMapping 
} from "@/types/assets/types";
import { 
  fetchNetworkEndpoints, 
  getIdsAlerts, 
  getBlockedIps, 
  unlockIpAddress, 
  blockIpAddress, 
  manageWhitelistIp, 
  changeIdsMode, 
  getIdsGraphPort,
  getIpGeoLocation,
  getFullIdsConfig,
  updateCategoryConfig,
  getIdsApiHelp
} from "./utils";
import { listAsset } from "@/hooks/fetch_functions";
import { getToken } from "@/hooks/get_token";
import { useNavigate } from "react-router-dom";
import { 
  Shield, 
  Radio, 
  RefreshCw, 
  ArrowLeft, 
  Unlock, 
  Lock, 
  Sliders, 
  Search, 
  CheckCircle2, 
  ExternalLink,
  BookOpen,
  Copy,
  Check,
  Zap,
  ShieldAlert,
  ShieldCheck,
  Network
} from "lucide-react";
import toast from "react-hot-toast";

// ============================================================================
// HELPERS & TYPES ENRICHIS
// ============================================================================

interface EnrichedProbe {
  id: string;
  name: string;
  host: string;
  port: number;
  is_open: boolean;
  deployment_mode?: string;
  priority?: any;
  tags?: string[];
  status?: string;
}

const getFlagEmoji = (countryCode?: string) => {
  if (!countryCode || countryCode === "XX") return "🌍";
  const codePoints = countryCode
    .toUpperCase()
    .split("")
    .map((char) => 127397 + char.charCodeAt(0));
  return String.fromCodePoint(...codePoints);
};

const getActionLabel = (action?: string) => {
  const actions: Record<string, string> = {
    "log_only": "📝 Surveillance",
    "rate_limit_data": "⏱️ Limite volume (2h)",
    "rate_limit": "🚦 Limite connexions (4h)",
    "block_temp": "🔒 Blocage temp (24h)",
    "block_perm": "⛔ Blocage permanent",
    "": "✅ Débloqué"
  };
  return actions[action || ""] || "❓ Inconnu";
};

const getScoreColor = (score: number) => {
  if (score >= 230) return "var(--danger)";
  if (score >= 180) return "#f97316";
  if (score >= 125) return "#eab308";
  if (score >= 75) return "#84cc16";
  return "var(--success)";
};

// ============================================================================
// MODALE DE MOT DE PASSE
// ============================================================================

function PasswordModal({
  isOpen,
  message,
  onConfirm,
  onCancel,
}: {
  isOpen: boolean;
  message: string;
  onConfirm: (pwd: string) => void;
  onCancel: () => void;
}) {
  const [password, setPassword] = useState("");

  if (!isOpen) return null;

  return (
    <div className="ids-modal-overlay" onClick={onCancel}>
      <div className="ids-modal-box" onClick={(e) => e.stopPropagation()}>
        <span className="ids-modal-title">
          <Lock size={18} style={{ color: "var(--accent)" }} /> Confirmation d'action sensible
        </span>
        <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", margin: 0 }}>
          {message}
        </p>

        <input
          type="password"
          className="smc-input-field"
          style={{ background: "var(--bg-surface-2)", padding: "10px 14px", borderRadius: "var(--radius-md)", border: "1px solid var(--border)" }}
          placeholder="Mot de passe administrateur"
          autoFocus
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && onConfirm(password)}
        />

        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", marginTop: 6 }}>
          <button type="button" className="oh-btn oh-btn--ghost" onClick={onCancel}>
            Annuler
          </button>
          <button type="button" className="oh-btn oh-btn--primary" onClick={() => onConfirm(password)}>
            Confirmer
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// COMPOSANT PRINCIPAL (IDS/IPS MODULE)
// ============================================================================

export function IdsIps() {
  const navigate = useNavigate();
  const username = sessionStorage.getItem("username") || "admin";

  // ── État Flotte & Fusion avec les Assets ─────────────────────────────────
  const [probesList, setProbesList] = useState<EnrichedProbe[]>([]);
  const [loadingProbes, setLoadingProbes] = useState(false);
  const [selectedProbe, setSelectedProbe] = useState<EnrichedProbe | null>(null);

  // ── Mode d'affichage (Dashboard Sonde vs Documentation Help) ─────────────
  const [probeView, setProbeView] = useState<"dashboard" | "help">("dashboard");

  // ── Données de la Sonde Active ───────────────────────────────────────────
  const [idsMode, setIdsMode] = useState<IdsMode>("ids");
  const [bokehPort, setBokehPort] = useState<number | null>(null);
  const [alerts, setAlerts] = useState<IdsAlertEvent[]>([]);
  const [blockedIps, setBlockedIps] = useState<BlockedIpsResponseMap>({});
  const [seuilDecision, setSeuilDecision] = useState<number>(-0.6);
  const [helpData, setHelpData] = useState<any>(null);
  const [loadingProbeData, setLoadingProbeData] = useState(false);

  // Géolocalisation Header
  const [geoInput, setGeoInput] = useState("");
  const [geoResult, setGeoResult] = useState<{ ip: string; location: string } | null>(null);
  const [geoLoading, setGeoLoading] = useState(false);

  // Formulaires manuels
  const [manualIpBlock, setManualIpBlock] = useState("");
  const [manualBlockRule, setManualBlockRule] = useState<NftRuleType>("drop");
  const [manualIpWhite, setManualIpWhite] = useState("");
  const [copiedCurl, setCopiedCurl] = useState<string | null>(null);

  // Modale Mot de passe
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const passwordResolveRef = useRef<((pwd: string | null) => void) | null>(null);

  const promptPassword = (msg: string): Promise<string | null> => {
    setModalMessage(msg);
    setShowPasswordModal(true);
    return new Promise((resolve) => {
      passwordResolveRef.current = resolve;
    });
  };

  // ── 1. Chargement & Fusion des Sondes et des Métadonnées Assets ──────────
  const loadFleetProbes = useCallback(async () => {
    setLoadingProbes(true);
    const token = getToken();

    try {
      // 1. Récupère les endpoints { [asset_id]: { host, port, is_open } }
      let epMap: NetworkEndpointsMap = {};
      await fetchNetworkEndpoints(
        (data) => { epMap = data || {}; },
        (err) => { if (err) toast.error(`Erreur endpoints: ${err}`); },
        () => {},
        navigate
      );

      // 2. Récupère les assets de type "network" pour avoir les vrais noms, tags, mode de déploiement
      let networkAssets: NetworkAsset[] = [];
      const assetRes = await listAsset({ type_: "network" }, token);
      if (assetRes.ok && assetRes.response?.assets) {
        networkAssets = assetRes.response.assets as NetworkAsset[];
      }

      // 3. Fusionne les deux sources
      const enriched: EnrichedProbe[] = Object.entries(epMap).map(([id, ep]) => {
        const assetMeta = networkAssets.find((a) => a.id === id || a.item_db_id?.toString() === id);
        return {
          id,
          name: assetMeta?.name || `Sonde Réseau (${ep.host})`,
          host: ep.host,
          port: ep.port,
          is_open: ep.is_open,
          deployment_mode: assetMeta?.deployment_mode,
          priority: assetMeta?.priority,
          tags: assetMeta?.tags || [],
          status: assetMeta?.status || "active",
        };
      });

      setProbesList(enriched);
    } catch (err: any) {
      toast.error(`Erreur chargement flotte: ${err?.message || err}`);
    } finally {
      setLoadingProbes(false);
    }
  }, [navigate]);

  useEffect(() => {
    loadFleetProbes();
  }, [loadFleetProbes]);

  // URL directe de la sonde active
  const activeProbeUrl = selectedProbe ? `http://${selectedProbe.host}:${selectedProbe.port}/api` : "";

  // ── 2. Chargement des données de la Sonde Active ──────────────────────────
  const refreshProbeData = useCallback(() => {
    if (!activeProbeUrl || !selectedProbe?.is_open) return;
    setLoadingProbeData(true);

    getIdsAlerts(activeProbeUrl, 25, (res) => { if (res?.alerts) setAlerts(res.alerts); }, () => {}, undefined, navigate);
    getBlockedIps(activeProbeUrl, username, (res) => { if (res?.blocked) setBlockedIps(res.blocked); }, () => {}, () => {}, navigate);
    getIdsGraphPort(activeProbeUrl, (res) => setBokehPort(res?.port || null), () => {}, () => {}, navigate);
    getIdsApiHelp(activeProbeUrl, (res) => setHelpData(res), () => {}, undefined, navigate);

    getFullIdsConfig(activeProbeUrl, username, (res) => {
      if (res && res["ids/ips_config"]?.SEUIL?.decision !== undefined) {
        setSeuilDecision(res["ids/ips_config"].SEUIL.decision);
      }
      setLoadingProbeData(false);
    }, () => setLoadingProbeData(false), () => {}, navigate);
  }, [activeProbeUrl, selectedProbe, username, navigate]);

  useEffect(() => {
    if (selectedProbe && selectedProbe.is_open) {
      refreshProbeData();
      const interval = setInterval(refreshProbeData, 8000);
      return () => clearInterval(interval);
    }
  }, [selectedProbe, refreshProbeData]);

  // ── 3. Actions Opérateur ──────────────────────────────────────────────────
  const handleUnlock = async (ip: string, rule: string) => {
    const password = await promptPassword(`Débloquer l'adresse IP ${ip} ?`);
    if (!password) return;

    const res = await unlockIpAddress(activeProbeUrl, { ip, rule, input: true, username, password }, () => {}, (err) => { if (err) toast.error(err); }, () => {}, navigate);
    if (res?.success) {
      toast.success(`IP ${ip} débloquée !`);
      refreshProbeData();
    }
  };

  const handleBlockManual = async () => {
    if (!manualIpBlock.trim()) return;
    const password = await promptPassword(`Bloquer ${manualIpBlock} (${manualBlockRule.toUpperCase()}) ?`);
    if (!password) return;

    const res = await blockIpAddress(activeProbeUrl, { ip: manualIpBlock.trim(), rule: manualBlockRule, input: true, username, password }, () => {}, (err) => { if (err) toast.error(err); }, () => {}, navigate);
    if (res?.success) {
      toast.success(`IP ${manualIpBlock} bloquée avec succès`);
      setManualIpBlock("");
      refreshProbeData();
    }
  };

  const handleWhitelistManual = async (add: boolean) => {
    if (!manualIpWhite.trim()) return;
    const password = await promptPassword(`${add ? "Ajouter" : "Retirer"} ${manualIpWhite} ${add ? "à" : "de"} la whitelist ?`);
    if (!password) return;

    const res = await manageWhitelistIp(activeProbeUrl, { ip: manualIpWhite.trim(), add, username, password }, () => {}, (err) => { if (err) toast.error(err); }, () => {}, navigate);
    if (res?.success) {
      toast.success(`Whitelist mise à jour pour ${manualIpWhite}`);
      setManualIpWhite("");
      refreshProbeData();
    }
  };

  const handleModeChange = async (newMode: IdsMode) => {
    if (newMode === idsMode) return;
    const password = await promptPassword(`Basculer la sonde en mode ${newMode.toUpperCase()} ?`);
    if (!password) return;

    const res = await changeIdsMode(activeProbeUrl, { mode: newMode, username, password }, () => {}, (err) => { if (err) toast.error(err); }, () => {}, navigate);
    if (res?.success) {
      setIdsMode(newMode);
      toast.success(`Mode basculé sur ${newMode.toUpperCase()}`);
    }
  };

  const handleUpdateSeuil = async (newSeuil: number) => {
    const password = await promptPassword(`Mettre à jour le seuil de décision à ${newSeuil} ?`);
    if (!password) return;

    const res = await updateCategoryConfig(activeProbeUrl, { key: "SEUIL", data: { decision: newSeuil }, username, password }, () => {}, (err) => { if (err) toast.error(err); }, () => {}, navigate);
    if (res?.success) {
      setSeuilDecision(newSeuil);
      toast.success(`Seuil configuré à ${newSeuil}`);
      refreshProbeData();
    }
  };

  const handleSearchGeo = () => {
    if (!geoInput.trim()) return;
    setGeoLoading(true);
    getIpGeoLocation(activeProbeUrl, geoInput.trim(), (res) => {
      setGeoLoading(false);
      if (res?.location) setGeoResult({ ip: geoInput.trim(), location: res.location });
    }, () => {
      setGeoLoading(false);
      toast.error("IP introuvable");
    }, undefined, navigate);
  };

  const handleCopyCurl = async (key: string, cmd: string) => {
    try {
      await navigator.clipboard.writeText(cmd);
      setCopiedCurl(key);
      toast.success("cURL copié !");
      setTimeout(() => setCopiedCurl(null), 1500);
    } catch {
      toast.error("Impossible de copier");
    }
  };

  const openCount = probesList.filter((p) => p.is_open).length;

  return (
    <div id="ids-container" className="ids-container">
      {/* ── HEADER SUPÉRIEUR DU DASHBOARD ── */}
      <header className="ids-header">
        <div className="ids-header-left">
          <h1>
            <Shield size={26} style={{ color: "var(--accent-strong)" }} />
            <span>SHIELD IA — IDS / IPS</span>
          </h1>
        </div>

        {/* Incrustation Géolocaliseur au centre si une sonde est active */}
        {selectedProbe && (
          <div className="ids-header-center">
            <div className="ids-geo-locator">
              <Search size={14} style={{ color: "var(--text-tertiary)" }} />
              <input
                type="text"
                placeholder="🔍 IP (ex: 8.8.8.8)"
                value={geoInput}
                onChange={(e) => setGeoInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearchGeo()}
                className="ids-geo-input"
              />
              <button type="button" onClick={handleSearchGeo} disabled={geoLoading} className="ids-geo-btn">
                {geoLoading ? "⏳" : "🌍"}
              </button>
              {geoResult && (
                <div className="ids-geo-result">
                  <span>{getFlagEmoji(geoResult.location)}</span>
                  <span>{geoResult.location}</span>
                  <span style={{ opacity: 0.7, fontFamily: "var(--font-mono)" }}>{geoResult.ip}</span>
                </div>
              )}
            </div>
          </div>
        )}

        <div className="ids-header-right">
          {selectedProbe ? (
            <>
              <span className={`ids-mode-badge ${idsMode === "ips" ? "ids-mode-badge--ips" : "ids-mode-badge--ids"}`}>
                {idsMode === "ips" ? "🛡️ IPS Actif" : "👁️ IDS Actif"}
              </span>

              {bokehPort && (
                <div className="ids-port-indicator">
                  <span>🌐 Bokeh: {bokehPort}</span>
                </div>
              )}

              <button
                type="button"
                className="oh-btn oh-btn--ghost"
                style={{ padding: "6px 14px", fontSize: "0.82rem" }}
                onClick={() => setSelectedProbe(null)}
              >
                <ArrowLeft size={13} /> Flotte de sondes
              </button>
            </>
          ) : (
            <button
              type="button"
              className="oh-btn oh-btn--primary"
              onClick={loadFleetProbes}
              disabled={loadingProbes}
            >
              <RefreshCw size={14} className={loadingProbes ? "oh-spin" : ""} /> Actualiser Flotte
            </button>
          )}

          <div className={`ids-mode-badge ${openCount > 0 ? "ids-mode-badge--ids" : "ids-mode-badge--ips"}`}>
            <span>{openCount} sonde(s) en ligne</span>
          </div>
        </div>
      </header>

      {/* ── VUE 1 : GRILLE INITIALE (CARTES DE SONDES ENRICHIES) ── */}
      {!selectedProbe ? (
        <div>
          <div className="ids-fleet-hero">
            <span className="ids-fleet-hero__title">
              <Radio size={22} style={{ color: "var(--accent)" }} /> Flotte des Sondes Réseau Déployées
            </span>
            <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem", margin: 0 }}>
              Sélectionnez une sonde en ligne pour ouvrir son dashboard de surveillance en direct.
            </p>
          </div>

          {probesList.length === 0 ? (
            <div style={{ textAlign: "center", padding: "80px 20px", background: "var(--bg-surface)", borderRadius: "var(--radius-xl)", border: "1px solid var(--border)" }}>
              <ShieldAlert size={44} style={{ color: "var(--text-tertiary)", margin: "0 auto 12px" }} />
              <h3>Aucune sonde réseau enregistrée</h3>
              <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>Créez un asset réseau depuis le panneau des assets.</p>
            </div>
          ) : (
            <div className="ids-probe-grid">
              {probesList.map((probe) => {
                const shortId = probe.id.length > 12 ? `${probe.id.slice(0, 8)}...` : probe.id;

                return (
                  <div
                    key={probe.id}
                    className={`ids-probe-card ${probe.is_open ? "ids-probe-card--open" : "ids-probe-card--closed"}`}
                    onClick={() => {
                      if (probe.is_open) {
                        setSelectedProbe(probe);
                        toast.success(`Connecté à : ${probe.name}`);
                      } else {
                        toast.error("Cette sonde est injoignable");
                      }
                    }}
                  >
                    <div className="ids-probe-card__header">
                      <div>
                        <h3 className="ids-probe-card__name">{probe.name}</h3>
                        <span style={{ fontSize: "0.72rem", color: "var(--text-tertiary)", fontFamily: "var(--font-mono)" }}>
                          ID : {shortId}
                        </span>
                      </div>
                      <span className={`oh-badge ${probe.is_open ? "oh-badge--success" : "oh-badge--danger"}`}>
                        {probe.is_open ? "🟢 EN LIGNE" : "🔴 HORS LIGNE"}
                      </span>
                    </div>

                    <div className="ids-probe-card__badges">
                      {probe.deployment_mode && (
                        <span className="oh-badge oh-badge--accent">
                          {NetworkDeploymentModeMapping[probe.deployment_mode as keyof typeof NetworkDeploymentModeMapping] || probe.deployment_mode}
                        </span>
                      )}
                      {probe.priority && (
                        <span className="oh-badge oh-badge--warning">
                          {PRIORITY_MAPPING[probe.priority as keyof typeof PRIORITY_MAPPING]}
                        </span>
                      )}
                      <span className="oh-badge oh-badge--info">
                        {AssetStatusMapping[probe.status as keyof typeof AssetStatusMapping] || probe.status}
                      </span>
                    </div>

                    <div className="ids-probe-card__body">
                      <div className="ids-probe-card__row">
                        <span>Endpoint :</span>
                        <span className="ids-probe-card__endpoint">{probe.host}:{probe.port}</span>
                      </div>

                      {probe.tags && probe.tags.length > 0 && (
                        <div className="ids-probe-card__row" style={{ alignItems: "flex-start" }}>
                          <span>Tags :</span>
                          <div className="ids-probe-card__tags">
                            {probe.tags.map((t, idx) => (
                              <span key={idx} className="ids-tag-pill">{t}</span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="ids-probe-card__footer">
                      <span style={{ fontSize: "0.82rem", fontWeight: 700, color: probe.is_open ? "var(--accent-strong)" : "var(--text-tertiary)" }}>
                        {probe.is_open ? "Ouvrir Dashboard →" : "Sonde inactive"}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* ── VUE 2 : DASHBOARD COMPLET DE LA SONDE SÉLECTIONNÉE ── */
        <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
          {/* Bascule : Dashboard vs Aide API */}
          <div className="ids-nav-tabs">
            <button
              type="button"
              className={`ids-tab-btn ${probeView === "dashboard" ? "ids-tab-btn--active" : ""}`}
              onClick={() => setProbeView("dashboard")}
            >
              <ShieldCheck size={16} /> Dashboard de Sécurité
            </button>

            <button
              type="button"
              className={`ids-tab-btn ${probeView === "help" ? "ids-tab-btn--active" : ""}`}
              onClick={() => setProbeView("help")}
            >
              <BookOpen size={16} /> 📚 Aide & Référence API
            </button>
          </div>

          {probeView === "dashboard" ? (
            <>
              {/* 1. Terminal des Alertes Temps Réel */}
              <div className="ids-alert-terminal">
                <div className="ids-alert-terminal__header">
                  <span>⚡ Flux d'Alertes Réseau en Direct ({alerts.length})</span>
                  <button type="button" className="oh-btn oh-btn--ghost" style={{ padding: "3px 10px", fontSize: "0.75rem" }} onClick={() => setAlerts([])}>
                    Vider
                  </button>
                </div>
                <div className="ids-alert-terminal__body">
                  {alerts.length === 0 ? (
                    <div style={{ padding: "30px", textAlign: "center", color: "var(--text-tertiary)" }}>
                      Aucune alerte suspecte détectée sur cette sonde.
                    </div>
                  ) : (
                    alerts.map((al, idx) => (
                      <div
                        key={idx}
                        className={`ids-alert-row ${
                          al.severity >= 3 ? "ids-alert-row--crit" : al.severity === 2 ? "ids-alert-row--high" : "ids-alert-row--med"
                        }`}
                      >
                        <span style={{ color: "var(--text-tertiary)" }}>{al.timestamp}</span>
                        <strong>[{al.proto}]</strong>
                        <span>{al.src_ip}:{al.src_port || "?"} → {al.dest_ip}:{al.dest_port || "?"}</span>
                        <span style={{ marginLeft: "auto", fontWeight: 700 }}>
                          {al.signature || al.event_type}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* 2. Section des IPs Bloquées */}
              <section className="ids-blocked-section">
                <div className="ids-section-header">
                  <h2>🚫 IPs Bloquées / Surveillées ({Object.keys(blockedIps).length})</h2>
                  <button type="button" className="oh-btn oh-btn--ghost" onClick={refreshProbeData} disabled={loadingProbeData}>
                    <RefreshCw size={13} className={loadingProbeData ? "oh-spin" : ""} /> Rafraîchir
                  </button>
                </div>

                <div className="ids-ip-grid">
                  {Object.entries(blockedIps).length === 0 ? (
                    <div style={{ gridColumn: "1 / -1", textAlign: "center", padding: "40px", color: "var(--text-secondary)" }}>
                      <CheckCircle2 size={32} style={{ color: "var(--success)", margin: "0 auto 8px" }} />
                      <p style={{ fontSize: "1.05rem", fontWeight: 600 }}>🎉 Aucune IP bloquée actuellement !</p>
                      <p style={{ fontSize: "0.85rem", color: "var(--text-tertiary)" }}>Tout va bien sur le réseau de cette sonde.</p>
                    </div>
                  ) : (
                    Object.entries(blockedIps).map(([ip, data]) => {
                      const score = data?.score || 0;
                      const action = data?.decision?.action || "";
                      const rule = (action === "block_temp" || action === "block_perm") ? "drop" : action;

                      return (
                        <div key={ip} className="ids-ip-card">
                          <div className="ids-ip-card-header">
                            <span className="ids-ip-address">{ip}</span>
                            <span style={{ background: "var(--bg-surface)", padding: "4px 10px", borderRadius: "var(--radius-full)", fontSize: "0.85rem" }}>
                              {getFlagEmoji(data?.geoloc)} {data?.geoloc || "XX"}
                            </span>
                          </div>

                          <div>
                            <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.8rem", marginBottom: "4px" }}>
                              <span>Score : <strong style={{ color: getScoreColor(score) }}>{score}/300</strong></span>
                              <span className="oh-badge oh-badge--warning">{getActionLabel(action)}</span>
                            </div>
                            <div className="ids-score-bar-container">
                              <div
                                className="ids-score-bar"
                                style={{ width: `${Math.min(100, (score / 300) * 100)}%`, background: getScoreColor(score) }}
                              />
                            </div>
                          </div>

                          <div style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
                            <div className="ids-info-row">
                              <span>Anomalies :</span>
                              <strong>{data?.anomaly_count || 0}</strong>
                            </div>
                            <div className="ids-info-row">
                              <span>Bloquée :</span>
                              <strong>{data?.blocked_count || 0} fois</strong>
                            </div>
                            <div className="ids-info-row">
                              <span>DNS :</span>
                              <span style={{ fontFamily: "var(--font-mono)", maxWidth: "180px", overflow: "hidden", textOverflow: "ellipsis" }}>
                                {data?.resolution || "Non résolu"}
                              </span>
                            </div>
                          </div>

                          <div className="ids-ip-card-actions">
                            <button
                              type="button"
                              className="oh-btn oh-btn--primary"
                              style={{ flex: 1, padding: "8px 12px", fontSize: "0.82rem" }}
                              onClick={() => handleUnlock(ip, rule || "drop")}
                              disabled={!rule || rule === "log_only"}
                            >
                              <Unlock size={13} /> Débloquer
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </section>

              {/* 3. Les 3 Panneaux Inférieurs (Configuration | Mode | Actions Manuelles) */}
              <div className="ids-dashboard-bottom">
                {/* Panneau 1 : Configuration */}
                <div className="ids-panel">
                  <h3><Sliders size={18} style={{ color: "var(--accent)" }} /> ⚙️ CONFIGURATION</h3>
                  <div>
                    <label style={{ fontSize: "0.8rem", color: "var(--text-tertiary)", fontWeight: 600, textTransform: "uppercase" }}>
                      Seuil de décision ML :
                    </label>
                    <div style={{ display: "flex", gap: "8px", marginTop: "8px" }}>
                      <input
                        type="number"
                        step="0.05"
                        min="-1"
                        max="1"
                        className="smc-input-field"
                        style={{ background: "var(--bg-surface-2)", padding: "8px 12px", borderRadius: "var(--radius-sm)" }}
                        value={seuilDecision}
                        onChange={(e) => setSeuilDecision(parseFloat(e.target.value))}
                      />
                      <button type="button" className="oh-btn oh-btn--primary" onClick={() => handleUpdateSeuil(seuilDecision)}>
                        Valider
                      </button>
                    </div>
                    <small style={{ fontSize: "0.72rem", color: "var(--text-tertiary)", marginTop: "6px", display: "block" }}>
                      Plus le seuil est bas, plus l'IDS est sensible (-1 = très sensible, 1 = très strict).
                    </small>
                  </div>
                </div>

                {/* Panneau 2 : Mode IDS/IPS */}
                <div className="ids-panel">
                  <h3><Radio size={18} style={{ color: "var(--accent)" }} /> 🎮 MODE IDS/IPS</h3>
                  <div className="ids-mode-toggle-grid">
                    <button
                      type="button"
                      className={`ids-mode-btn ${idsMode === "ids" ? "ids-mode-btn--active" : ""}`}
                      onClick={() => handleModeChange("ids")}
                    >
                      🕵️ IDS (Détection)
                    </button>
                    <button
                      type="button"
                      className={`ids-mode-btn ${idsMode === "ips" ? "ids-mode-btn--active" : ""}`}
                      onClick={() => handleModeChange("ips")}
                    >
                      🛡️ IPS (Prévention)
                    </button>
                  </div>
                  <div style={{ textAlign: "center", fontSize: "0.82rem", color: "var(--text-secondary)", marginTop: "4px" }}>
                    Mode actuel : <strong className={idsMode === "ips" ? "oh-badge oh-badge--danger" : "oh-badge oh-badge--info"}>{idsMode.toUpperCase()}</strong>
                  </div>
                </div>

                {/* Panneau 3 : Actions Manuelles */}
                <div className="ids-panel">
                  <h3><Zap size={18} style={{ color: "var(--accent)" }} /> ⚡ ACTIONS MANUELLES</h3>
                  
                  {/* Blocage */}
                  <div style={{ display: "flex", gap: "6px" }}>
                    <input
                      type="text"
                      placeholder="192.168.1.1"
                      value={manualIpBlock}
                      onChange={(e) => setManualIpBlock(e.target.value)}
                      className="smc-input-field"
                      style={{ background: "var(--bg-surface-2)", padding: "6px 10px", borderRadius: "var(--radius-sm)", flex: 1 }}
                    />
                    <select
                      value={manualBlockRule}
                      onChange={(e) => setManualBlockRule(e.target.value as NftRuleType)}
                      className="smc-select"
                      style={{ width: "95px", padding: "6px" }}
                    >
                      <option value="drop">🚫 Drop</option>
                      <option value="rate_limit">⏱️ Rate</option>
                      <option value="rate_limit_data">📉 Data</option>
                    </select>
                    <button type="button" className="oh-btn oh-btn--primary" style={{ padding: "6px 12px" }} onClick={handleBlockManual}>
                      <Lock size={12} />
                    </button>
                  </div>

                  {/* Whitelist */}
                  <div style={{ display: "flex", gap: "6px" }}>
                    <input
                      type="text"
                      placeholder="IP / CIDR Whitelist..."
                      value={manualIpWhite}
                      onChange={(e) => setManualIpWhite(e.target.value)}
                      className="smc-input-field"
                      style={{ background: "var(--bg-surface-2)", padding: "6px 10px", borderRadius: "var(--radius-sm)", flex: 1 }}
                    />
                    <button type="button" className="simatk-btn" onClick={() => handleWhitelistManual(true)}>
                      ➕
                    </button>
                    <button type="button" className="simatk-btn" onClick={() => handleWhitelistManual(false)}>
                      ➖
                    </button>
                  </div>
                </div>
              </div>

              {/* 4. Iframe Bokeh Intégré */}
              {bokehPort && (
                <div className="ids-bokeh-container">
                  <div className="ids-bokeh-header">
                    <span>📊 Visualisation Temps Réel des Flux & Anomalies (Bokeh Server)</span>
                    <a
                      href={`http://${selectedProbe.host}:${bokehPort}/`}
                      target="_blank"
                      rel="noreferrer"
                      className="oh-btn oh-btn--ghost"
                      style={{ padding: "4px 12px", fontSize: "0.8rem" }}
                    >
                      <ExternalLink size={13} /> Ouvrir en grand
                    </a>
                  </div>
                  <iframe
                    src={`http://${selectedProbe.host}:${bokehPort}/`}
                    title="Bokeh Dashboard"
                    className="ids-bokeh-iframe"
                  />
                </div>
              )}
            </>
          ) : (
            /* ── VUE DOCUMENTATION & AIDE API (HELP) ── */
            <div className="ids-help-view">
              {helpData ? (
                <>
                  <div className="ids-panel">
                    <h3>📚 {helpData.message}</h3>
                    <p style={{ fontSize: "0.9rem", color: "var(--text-secondary)" }}>
                      Version : <strong>{helpData.version}</strong> • Rate Limit : <span className="oh-badge oh-badge--accent">{helpData.rate_limit}</span>
                    </p>
                  </div>

                  <div className="ids-panel">
                    <h3>📊 Niveaux de Décision & Actions du Scoring</h3>
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 14 }}>
                      {Object.entries(helpData.niveaux_decision || {}).map(([level, info]: any) => (
                        <div key={level} style={{ padding: "14px", background: "var(--bg-surface-2)", borderRadius: "var(--radius-md)", border: "1px solid var(--border)" }}>
                          <div style={{ fontWeight: 700, color: "var(--accent-strong)", fontSize: "0.9rem" }}>{level.toUpperCase()}</div>
                          <div style={{ fontSize: "0.8rem", color: "var(--text-secondary)", marginTop: 4 }}>Score : {info.score_range}</div>
                          <div style={{ fontSize: "0.8rem", color: "var(--text-tertiary)" }}>Action : {info.action}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="ids-panel">
                    <h3>💻 Exemples de Commandes cURL Prêtes à l'Emploi</h3>
                    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                      {Object.entries(helpData.exemples_curl || {}).map(([name, cmd]: any) => (
                        <div key={name} className="ids-curl-card">
                          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                            <strong style={{ fontSize: "0.82rem", textTransform: "uppercase" }}>{name}</strong>
                            <button
                              type="button"
                              className="scl-btn-inline"
                              onClick={() => handleCopyCurl(name, cmd)}
                            >
                              {copiedCurl === name ? <Check size={12} /> : <Copy size={12} />}
                              {copiedCurl === name ? "Copié !" : "Copier"}
                            </button>
                          </div>
                          <pre className="ids-curl-pre"><code>{cmd}</code></pre>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              ) : (
                <div style={{ textAlign: "center", padding: "60px", color: "var(--text-tertiary)" }}>
                  Chargement de la documentation...
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Modale Mot de Passe */}
      <PasswordModal
        isOpen={showPasswordModal}
        message={modalMessage}
        onConfirm={(pwd) => {
          if (passwordResolveRef.current) passwordResolveRef.current(pwd);
          setShowPasswordModal(false);
        }}
        onCancel={() => {
          if (passwordResolveRef.current) passwordResolveRef.current(null);
          setShowPasswordModal(false);
        }}
      />
    </div>
  );
}

export default IdsIps;