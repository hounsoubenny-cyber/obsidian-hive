// 📁 dashboard.tsx

import "./dashboard.css";
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { isLogin } from "@/hooks/get_token";
import { getToken, getUsername } from "@/hooks/get_token";
import { listAsset } from "../assets/assets/utils";
import { listJob } from "../jobs/jobs/utils";
import { listReportsByFilter } from "../reports/utils";
import { getReportStats } from "../reports/utils";
import { Asset } from "@/types/assets/types";
import { Job } from "@/types/jobs/types";
import { Report } from "@/types/reports/types";
import { SourceMapping } from "@/types/reports/types";
import { SeverityMapping } from "@/types/assets/types";
import toast from "react-hot-toast";
import {
    Package,
    ClipboardList,
    FileBarChart,
    ShieldAlert,
    Radar,
    ShieldCheck,
    FlaskConical,
    MailWarning,
    BrainCircuit,
    Activity,
    Bot,
    Settings,
    ArrowRight,
    CheckCircle2,
    Inbox,
    Rss,
    Lock,
    Loader2,
    Zap,
    BarChart3,
    Radio,
    History,
    RefreshCw,
    type LucideIcon,
} from "lucide-react";
import { MODULES } from "@/data/modules/data";

// ============================================================================
// SALUTATION SELON L'HEURE
// ============================================================================

function getTimeGreeting(username: string | null): string {
    const hour = new Date().getHours();
    const moment = hour < 6 ? "Bonsoir" : hour < 18 ? "Bonjour" : "Bonsoir";
    return username ? `${moment}, ${username}` : moment;
}

// ============================================================================
// COMPOSANT : KPI CARD
// ============================================================================

function KPICard({
    icon: Icon,
    label,
    value,
    color,
    link,
    linkText = "Voir tout",
}: {
    icon: LucideIcon;
    label: string;
    value: number | string;
    color: string;
    link: string;
    linkText?: string;
}) {
    return (
        <Link to={link} className="dashboard_kpi_card" style={{ ["--kpi-color" as any]: color }}>
            <div className="dashboard_kpi_icon">
                <Icon size={20} />
            </div>
            <div className="dashboard_kpi_content">
                <span className="dashboard_kpi_value">{value}</span>
                <span className="dashboard_kpi_label">{label}</span>
            </div>
            <span className="dashboard_kpi_link">
                {linkText}
                <ArrowRight size={13} />
            </span>
        </Link>
    );
}

// ============================================================================
// COMPOSANT : ALERTE RECENTE
// ============================================================================

function AlertItem({
    report,
    onSelect,
}: {
    report: Report;
    onSelect: (id: number) => void;
}) {
    const severityClass = {
        low: "alert_low",
        medium: "alert_medium",
        high: "alert_high",
        critical: "alert_critical",
    }[report.severity];

    return (
        <div className={`dashboard_alert_item ${severityClass}`} onClick={() => onSelect(report.id)}>
            <span className={`dashboard_alert_dot sev_dot_${report.severity}`} />
            <div className="dashboard_alert_content">
                <span className="dashboard_alert_title">
                    {report.report?.summary || report.content?.slice(0, 60) || "Rapport"}
                </span>
                <span className="dashboard_alert_meta">
                    {SourceMapping[report.source] || report.source} · {SeverityMapping[report.severity]}
                </span>
            </div>
            <span className="dashboard_alert_date">
                {new Date(report.created_at).toLocaleDateString("fr-FR", {
                    day: "2-digit",
                    month: "short",
                    hour: "2-digit",
                    minute: "2-digit",
                })}
            </span>
        </div>
    );
}

// ============================================================================
// COMPOSANT : MODULE STATUS (AMÉLIORÉ)
// ============================================================================

function ModuleStatus({
    name,
    status,
    icon: Icon,
    onClick,
    isAvailable = true,
}: {
    name: string;
    status: "active" | "paused" | "inactive" | "unknown";
    icon: LucideIcon;
    onClick: () => void;
    isAvailable?: boolean;
}) {
    const statusMap = {
        active: { label: "Actif", class: "module_active" },
        paused: { label: "En pause", class: "module_paused" },
        inactive: { label: "Inactif", class: "module_inactive" },
        unknown: { label: "Inconnu", class: "module_unknown" },
    };

    const info = statusMap[status] || statusMap.unknown;

    return (
        <div 
            className={`dashboard_module_item ${info.class} ${!isAvailable ? "module_unavailable" : ""}`} 
            onClick={isAvailable ? onClick : undefined}
            style={!isAvailable ? { cursor: "not-allowed", opacity: 0.6 } : {}}
        >
            <span className="dashboard_module_icon">
                <Icon size={16} />
            </span>
            <span className="dashboard_module_name">{name}</span>
            <span className="dashboard_module_status">
                <span className="dashboard_module_dot" />
                {isAvailable ? info.label : "Indisponible"}
            </span>
            {!isAvailable && (
                <span className="dashboard_module_lock">🔒</span>
            )}
        </div>
    );
}

// ============================================================================
// COMPOSANT : BARRES DE SÉVÉRITÉ
// ============================================================================

function SeverityBars({ stats }: { stats: Record<string, any> | null }) {
    if (!stats) return null;

    const severityOrder = ["critical", "high", "medium", "low"];
    const severityColors = {
        critical: "var(--danger)",
        high: "var(--warning)",
        medium: "#e0b93a",
        low: "var(--success)",
    };
    const severityLabels = {
        critical: "Critique",
        high: "Haute",
        medium: "Moyenne",
        low: "Basse",
    };

    const bySeverity = stats.by_severity || {};
    const total = stats.total || 0;

    return (
        <div className="dashboard_severity_bars">
            {severityOrder.map((sev) => {
                const count = bySeverity[sev] || 0;
                const percentage = total > 0 ? Math.round((count / total) * 100) : 0;

                return (
                    <div key={sev} className="dashboard_severity_bar">
                        <div className="dashboard_severity_bar_label">
                            <span className="dashboard_severity_bar_dot" style={{ background: severityColors[sev as keyof typeof severityColors] }}></span>
                            <span>{severityLabels[sev as keyof typeof severityLabels]}</span>
                            <span className="dashboard_severity_bar_count">{count}</span>
                        </div>
                        <div className="dashboard_severity_bar_track">
                            <div
                                className="dashboard_severity_bar_fill"
                                style={{
                                    width: `${percentage}%`,
                                    background: severityColors[sev as keyof typeof severityColors],
                                }}
                            />
                        </div>
                        <span className="dashboard_severity_bar_percent">{percentage}%</span>
                    </div>
                );
            })}
        </div>
    );
}

// ============================================================================
// PAGE PRINCIPALE : DASHBOARD
// ============================================================================

function Dashboard() {
    const [assets, setAssets] = useState<Asset[] | null>(null);
    const [jobs, setJobs] = useState<Job[] | null>(null);
    const [reports, setReports] = useState<Report[] | null>(null);
    const [stats, setStats] = useState<Record<string, any> | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [isReloading, setIsReloading] = useState<boolean>(false);
    const [error, setError] = useState<string>("");
    const navigate = useNavigate();

    // =============================================
    // CHARGEMENT DES DONNÉES
    // =============================================

    const filterPendingDeletion = (asset: Asset): boolean => {
        // Si le type est "server", on vérifie pending_deletion
        if (asset.type === "server") {
        return !asset?.pending_deletion;
        }
        return true;
    }
    const onError = (val: string | null) => {
        if (val) {
            console.error("Erreur de chargement du dashboard:", val);
            toast.error("Erreur lors du chargement du dashboard");
        }
    };

    const loadDashboard = async () => {
        setLoading(true);
        const setAsset_ = (val: Asset[] | null) => {
            if (!val) return setAssets([]);
            return setAssets(val?.filter(filterPendingDeletion));
        }
        await listAsset(
            [setAsset_], onError, null, navigate,
        );

        await listJob(
            null, [setJobs], onError, null, navigate
        );

        await listReportsByFilter(
            { limit: 10, order_by: "created_at.desc" },
            [setReports], onError, null, navigate
        );

        await getReportStats(
            { asset_id: null }, setStats, onError, null, navigate
        );
        setLoading(false);
    };

    // =============================================
    // CHARGEMENT INITIAL
    // =============================================

    useEffect(() => {
        loadDashboard();
    }, []);

    // =============================================
    // RECHARGEMENT MANUEL
    // =============================================

    const handleReload = async () => {
        setIsReloading(true);
        await loadDashboard();
        setIsReloading(false);
        toast.success("✅ Tableau de bord actualisé");
    };

    // =============================================
    // NAVIGATION
    // =============================================

    const goToReports = () => navigate("/reports");
    const goToAssets = () => navigate("/assets");
    const goToJobs = () => navigate("/jobs");
    const goToChat = () => navigate("/chat");
    const goToModules = () => navigate("/modules");

    const goToReport = (id: number) => {
        navigate(`/reports?report_id=${id}`);
    };

    // =============================================
    // CALCUL DES STATS
    // =============================================

    const totalAssets = assets?.length || 0;
    const totalJobs = jobs?.length || 0;
    const totalReports = stats?.total || 0;
    const criticalReports = stats?.by_severity?.critical || 0;
    const bySource = stats?.by_source || {};
    const criticalAlerts = reports?.filter((r) => r.severity === "critical") || [];
    const highAlerts = reports?.filter((r) => r.severity === "high") || [];
    const username = getUsername();
    const greeting = getTimeGreeting(username);
    const today = new Date().toLocaleDateString("fr-FR", {
        weekday: "long",
        day: "numeric",
        month: "long",
    });

    // =============================================
    // RENDU
    // =============================================

    if (!isLogin()) {
        return (
            <div className="dashboard_locked">
                <div className="dashboard_locked_content">
                    <Lock size={28} className="dashboard_locked_icon" />
                    <h2>Accès restreint</h2>
                    <p>Veuillez vous connecter pour accéder au tableau de bord.</p>
                    <Link to="/login" className="dashboard_locked_btn">
                        Se connecter
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <div className="dashboard_page">
            {/* ===== EN-TÊTE ===== */}
            <div className="dashboard_header">
                <div>
                    <h1 className="dashboard_title">{greeting} 👋</h1>
                    <p className="dashboard_subtitle">
                        {today.charAt(0).toUpperCase() + today.slice(1)} · Voici l'état de votre surface de sécurité
                    </p>
                </div>
                <div className="dashboard_header_right">
                    <button 
                        className="dashboard_reload_btn"
                        onClick={handleReload}
                        disabled={isReloading || loading}
                    >
                        <RefreshCw size={16} />
                        {isReloading ? "Actualisation..." : "Actualiser"}
                    </button>
                    <div className={`dashboard_status_pill ${criticalReports > 0 ? "is-alert" : "is-ok"}`}>
                        {criticalReports > 0 ? (
                            <>
                                <ShieldAlert size={15} />
                                {criticalReports} alerte{criticalReports > 1 ? "s" : ""} critique{criticalReports > 1 ? "s" : ""}
                            </>
                        ) : (
                            <>
                                <CheckCircle2 size={15} />
                                Aucune alerte critique
                            </>
                        )}
                    </div>
                </div>
            </div>

            {/* ===== KPIS ===== */}
            <div className="dashboard_kpi_grid">
                <KPICard
                    icon={Package}
                    label="Actifs"
                    value={totalAssets}
                    color="var(--accent)"
                    link="/assets"
                />
                <KPICard
                    icon={ClipboardList}
                    label="Jobs planifiés"
                    value={totalJobs}
                    color="var(--success)"
                    link="/jobs"
                />
                <KPICard
                    icon={FileBarChart}
                    label="Rapports"
                    value={totalReports}
                    color="var(--warning)"
                    link="/reports"
                />
                <KPICard
                    icon={ShieldAlert}
                    label="Alertes critiques"
                    value={criticalReports}
                    color="var(--danger)"
                    link="/reports"
                    linkText="Voir les alertes"
                />
            </div>

            {/* ===== ACCÈS RAPIDE ===== */}
            <div className="dashboard_quick_actions">
                <h2 className="dashboard_section_title"><Zap size={16} /> Accès rapide</h2>
                <div className="dashboard_quick_grid">
                    <button onClick={goToAssets} className="dashboard_quick_btn">
                        <Package size={16} />
                        Assets
                    </button>
                    <button onClick={goToJobs} className="dashboard_quick_btn">
                        <ClipboardList size={16} />
                        Jobs
                    </button>
                    <button onClick={goToReports} className="dashboard_quick_btn">
                        <FileBarChart size={16} />
                        Rapports
                    </button>
                    <button onClick={goToChat} className="dashboard_quick_btn">
                        <Bot size={16} />
                        Chat Coralie
                    </button>
                    <button onClick={goToModules} className="dashboard_quick_btn">
                        <Settings size={16} />
                        Modules
                    </button>
                </div>
            </div>

            {/* ===== ALERTES + MODULES ===== */}
            <div className="dashboard_two_col">
                {/* Alertes récentes */}
                <div className="dashboard_alerts_panel">
                    <div className="dashboard_panel_header">
                        <h2 className="dashboard_section_title"><ShieldAlert size={16} /> Alertes récentes</h2>
                        <button onClick={goToReports} className="dashboard_panel_link">
                            Voir tout <ArrowRight size={12} />
                        </button>
                    </div>
                    <div className="dashboard_alerts_list">
                        {criticalAlerts.length === 0 && highAlerts.length === 0 ? (
                            <div className="dashboard_alerts_empty">
                                <CheckCircle2 size={28} className="dashboard_alerts_empty_icon" />
                                <p>Aucune alerte critique ou haute</p>
                            </div>
                        ) : (
                            [...criticalAlerts, ...highAlerts]
                                .slice(0, 5)
                                .map((report) => (
                                    <AlertItem
                                        key={report.id}
                                        report={report}
                                        onSelect={goToReport}
                                    />
                                ))
                        )}
                    </div>
                </div>

                {/* Statut des modules */}
                <div className="dashboard_modules_panel">
                    <div className="dashboard_panel_header">
                        <h2 className="dashboard_section_title"><Settings size={16} /> Statut des modules</h2>
                        <button onClick={goToModules} className="dashboard_panel_link">
                            Voir tout <ArrowRight size={12} />
                        </button>
                    </div>
                    <div className="dashboard_modules_list">
                        {MODULES.map((val, idx) => {
                            const isAvailable = val.dispo ?? false;
                            const status = isAvailable ? "active" : "inactive";
                            
                            return (
                                <ModuleStatus 
                                    key={idx}
                                    name={val.name} 
                                    status={status}
                                    icon={val.icon}
                                    isAvailable={isAvailable}
                                    onClick={() => {
                                        if (!isAvailable) {
                                            toast.error(`⚠️ Le module "${val.name}" est actuellement indisponible`);
                                            return;
                                        }
                                        navigate(val.link);
                                    }}
                                />   
                            );
                        })}
                    </div>
                </div>
            </div>

            {/* ===== DISTRIBUTION DES SÉVÉRITÉS + SOURCES ===== */}
            <div className="dashboard_stats_row">
                {/* Distribution des sévérités */}
                <div className="dashboard_stats_panel">
                    <h2 className="dashboard_section_title"><BarChart3 size={16} /> Distribution des sévérités</h2>
                    <SeverityBars stats={stats} />
                </div>

                {/* Top sources */}
                <div className="dashboard_stats_panel">
                    <h2 className="dashboard_section_title"><Radio size={16} /> Top sources</h2>
                    <div className="dashboard_source_list">
                        {Object.entries(bySource).length === 0 ? (
                            <div className="dashboard_empty_state">
                                <Rss size={20} />
                                Aucune donnée
                            </div>
                        ) : (
                            Object.entries(bySource)
                                .sort((a, b) => Number(b[1]) - Number(a[1]))
                                .slice(0, 5)
                                .map(([source, count]) => {
                                    const label = SourceMapping[source as keyof typeof SourceMapping] || source;
                                    const total = stats?.total || 1;
                                    const percentage = Math.round((Number(count) / total) * 100);
                                    return (
                                        <div key={source} className="dashboard_source_item">
                                            <span className="dashboard_source_name">{label}</span>
                                            <div className="dashboard_source_bar_track">
                                                <div
                                                    className="dashboard_source_bar_fill"
                                                    style={{ width: `${percentage}%` }}
                                                />
                                            </div>
                                            <span className="dashboard_source_count">{String(count)}</span>
                                        </div>
                                    );
                                })
                        )}
                    </div>
                </div>
            </div>

            {/* ===== RAPPORTS RÉCENTS ===== */}
            <div className="dashboard_recent_panel">
                <div className="dashboard_panel_header">
                    <h2 className="dashboard_section_title"><History size={16} /> Rapports récents</h2>
                    <button onClick={goToReports} className="dashboard_panel_link">
                        Voir tout <ArrowRight size={12} />
                    </button>
                </div>
                <div className="dashboard_recent_list">
                    {reports && reports.length > 0 ? (
                        reports.slice(0, 5).map((report) => (
                            <div
                                key={report.id}
                                className="dashboard_recent_item"
                                onClick={() => goToReport(report.id)}
                            >
                                <span className={`dashboard_recent_severity sev_dot_${report.severity}`}></span>
                                <span className="dashboard_recent_title">
                                    {report.report?.summary || report.content?.slice(0, 80) || "Rapport"}
                                </span>
                                <span className="dashboard_recent_source">
                                    {SourceMapping[report.source] || report.source}
                                </span>
                                <span className="dashboard_recent_date">
                                    {new Date(report.created_at).toLocaleDateString("fr-FR")}
                                </span>
                            </div>
                        ))
                    ) : (
                        <div className="dashboard_empty_state">
                            <Inbox size={20} />
                            Aucun rapport récent
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

export default Dashboard;