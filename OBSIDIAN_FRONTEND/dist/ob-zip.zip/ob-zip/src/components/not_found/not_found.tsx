import { Link, useNavigate } from "react-router-dom";
import "./not_found.css";
import { Home, ArrowLeft, Search, Shield, Sparkles } from "lucide-react";
import { AppConfig, getConfig } from "@/hooks/get_config";
import { useState, useEffect } from "react";
import { toTitleCaseWithUnderscore } from "../utils/to_lower_case";

function NotFound() {
  const [conf, setConf] = useState<AppConfig | null>(null);
  const navigate = useNavigate();
  useEffect(() => {
      async function load() {
          const cfg: AppConfig = await getConfig();
          setConf(cfg);
      }
      load();
  }, []);
  const productName = conf?.productName ? toTitleCaseWithUnderscore(conf.productName) : "Obsidian Hive";

  return (
    <div className="notfound-wrapper">
      {/* Dots de fond */}
      <div className="notfound-dots"></div>

      {/* Effet de lueur */}
      <div className="notfound-glow"></div>

      <div className="notfound-container">
        {/* Badge */}
        <div className="notfound-badge">
          <Shield size={14} /> {productName}
        </div>

        {/* Code 404 */}
        <div className="notfound-code">
          <span className="notfound-code__digit notfound-code__digit--1">4</span>
          <span className="notfound-code__digit notfound-code__digit--2">0</span>
          <span className="notfound-code__digit notfound-code__digit--3">4</span>
        </div>

        {/* Message */}
        <div className="notfound-content">
          <h1 className="notfound-title">Page non trouvée</h1>
          <p className="notfound-message">
            Oups ! La page que vous cherchez n'existe pas ou a été déplacée.
            <br />
            <span className="notfound-message__hint">
              Peut-être que l'URL a changé ou que la page a été supprimée.
            </span>
          </p>
        </div>

        {/* Actions */}
        <div className="notfound-actions">
          <Link to="/" className="notfound-btn notfound-btn--primary">
            <Home size={18} />
            Retour à l'accueil
          </Link>
          <button
            className="notfound-btn notfound-btn--secondary"
            onClick={() => navigate(-1)}
          >
            <ArrowLeft size={18} />
            Page précédente
          </button>
        </div>

        {/* Suggestions */}
        <div className="notfound-suggestions">
          <span className="notfound-suggestions__label">🔍 Vous cherchez peut-être :</span>
          <div className="notfound-suggestions__links">
            <Link to="/dashboard" className="notfound-suggestions__link">
              <Sparkles size={14} /> Dashboard
            </Link>
            <Link to="/assets" className="notfound-suggestions__link">
              Actifs
            </Link>
            <Link to="/reports" className="notfound-suggestions__link">
              Rapports
            </Link>
            <Link to="/modules" className="notfound-suggestions__link">
              Modules
            </Link>
          </div>
        </div>

        {/* Footer */}
        <div className="notfound-footer">
          <span className="notfound-footer__text">
            {
              `© ${new Date().getFullYear()} ${toTitleCaseWithUnderscore(productName)} — Tous droits réservés`
            }
          </span>
        </div>
      </div>
    </div>
  );
}

export default NotFound;