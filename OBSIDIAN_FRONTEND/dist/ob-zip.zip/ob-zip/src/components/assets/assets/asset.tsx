import "./assets.css";
import { useEffect, useState, useMemo, useCallback, useRef } from "react";
import { useSearchParams, useNavigate, Link } from "react-router-dom";
import {
  Asset,
  AssetStatus,
  AssetStatusMapping,
  AssetType,
  AssetTypeMapping,
  Priority,
  PRIORITY_MAPPING,
} from "@/types/assets/types";
import {
  pauseAsset as _pauseAsset,
  resumeAsset as _resumeAsset,
  deleteAsset as _deleteAsset,
} from "@/hooks/fetch_functions";
import { 
  listAsset,
  searchAsset,
  filterAsset as _filterAsset,
  updateAssetAction,
  pauseAllAssetsAction,
  resumeAllAssetsAction
} from "./utils";
import { isLogin, getToken } from "@/hooks/get_token";
import { logError } from "@/hooks/error_utils";
import AddAssetModal from "../modals/add_asset_modal";
import { AssetDetail } from "../details/asset_details";
import { AssetCard } from "./asset_card";
import { AssetFilter } from "./asset_filter";
import { ConfirmModal } from "@/components/utils/confirm_modal/confirm_modal";
import toast from "react-hot-toast";
import {
  Plus,
  RefreshCw,
  Search,
  SlidersHorizontal,
  ListFilter,
  FileText,
  Lock,
  Pause,
  Play,
  TriangleAlert,
  Delete,
} from "lucide-react";

export function AssetPage() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const assetIdFromUrl = searchParams.get("asset_id");

  // ── Données Principales ──
  const [assets, setAssets] = useState<Asset[] | null>(null);
  const [assetsCopy, setAssetsCopy] = useState<Asset[] | null>(null);
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [error, setError] = useState<string>("");
  const [actionLoading, setActionLoading] = useState<Record<string, boolean>>({});
  const [bulkLoading, setBulkLoading] = useState<boolean>(false);

  // ── Filtres ──
  const [priorityFilter, setPriorityFilter] = useState<Priority | null>(null);
  const [tagsFilter, setTagsFilter] = useState<string[]>([]);
  const [typeFilter, setTypeFilter] = useState<AssetType | null>(null);
  const [statusFilter, setStatusFilter] = useState<AssetStatus | null>(null);
  const [autoFilter, setAutoFilter] = useState<boolean>(true);

  // ── Limites d'Affichage ──
  const [listLimit, setListLimit] = useState<number>(6);
  const [localListLimit, setLocalListLimit] = useState<number>(6);
  const [listShowAll, setListShowAll] = useState<boolean>(false);
  const [searchLimit] = useState<number>(4);
  const [searchShowAll, setSearchShowAll] = useState<boolean>(false);

  // ── Toggles de visibilité ──
  const [showSearchBar, setShowSearchBar] = useState<boolean>(true);
  const [showFilters, setShowFilters] = useState<boolean>(true);
  const [showList, setShowList] = useState<boolean>(true);
  const [showDetail, setShowDetail] = useState<boolean>(true);

  // ── Recherche Avancée ──
  const [searchAssetInput, setSearchAssetInput] = useState<string>("");
  const [searchAssetResult, setSearchAssetResult] = useState<Asset[] | null>(null);
  const [searchError, setSearchError] = useState<string>("");
  const [searchLoading, setSearchLoading] = useState<boolean>(false);
  const [includeNameForResearch, setIncludeNameForResearch] = useState<boolean>(true);
  const [caseSensitiveForResearch, setCaseSensitiveForResearch] = useState<boolean>(false);
  const [partialForResearch, setPartialForResearch] = useState<boolean>(true);
  const [firstOnlyForResearch, setFirstOnlyForResearch] = useState<boolean>(false);
  const [limitForResearch, setLimitForResearch] = useState<number>(50);

  // ── Modales ──
  const [isReloading, setIsReloading] = useState<boolean>(false);
  const [showAddAssetModal, setShowAddAssetModal] = useState<boolean>(false);
  const [bulkPauseModal, setBulkPauseModal] = useState<boolean>(false);
  const [bulkResumeModal, setBulkResumeModal] = useState<boolean>(false);
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);

  const urlSyncDone = useRef(false);
  const [showPendingDeletion, setShowPendingDeletion] = useState<boolean>(false);
  
  // ── Filtre de suppression ──
  const filterPendingDeletion = useCallback((asset: Asset): boolean => {
    // Si le type est "server", on vérifie pending_deletion
    //console.log("Asset", "id", asset.id, "name", asset.name, "pending ?", asset.pending_deletion)
    if (showPendingDeletion) return true;
    if (asset.type === "server") {
      return !asset?.pending_deletion;
    }
    return true;
  }, [showPendingDeletion])

  // ── Chargement initial ──
  const reload = async () => {
    setIsReloading(true);
    const currentSelected = selectedAsset?.id;
    try {
      const result = await listAsset([setAssets, setAssetsCopy], setError, null, navigate);
      if (currentSelected){
        const match = result.assets.filter((asset) => asset?.id == currentSelected && !asset?.pending_deletion)
        setSelectedAsset(
          match?.length > 0 ? match[0] : null
        )
      }
    } finally {
      setIsReloading(false);
    }
  }

  useEffect(() => {
    reload();
  }, []);

  // ── Filtrage des assets (avec pending_deletion) ──
  const filteredAssets = useMemo(() => {
    if (!assets) return [];
    return assets.filter(filterPendingDeletion);
  }, [assets, filterPendingDeletion]);

  const filteredAssetsCopy = useMemo(() => {
    if (!assetsCopy) return [];
    return assetsCopy.filter(filterPendingDeletion);
  }, [assetsCopy, filterPendingDeletion]);

  // ── Sélection depuis l'URL ──
  useEffect(() => {
    if (urlSyncDone.current) return; 
    if (filteredAssets.length > 0 && assetIdFromUrl) {
      const found = filteredAssets.find((a) => a.id === assetIdFromUrl);
      if (found) {
        urlSyncDone.current = true;
        setSelectedAsset(found);
      }
    }
  }, [filteredAssets, assetIdFromUrl]);

  // ── Filtrage des assets (par statut, priorité, type, tags) ──
  const applyFilters = useCallback(() => {
    const filtered = _filterAsset(
      filteredAssetsCopy,
      statusFilter,
      priorityFilter,
      tagsFilter,
      typeFilter
    );
    return filtered;
  }, [filteredAssetsCopy, statusFilter, priorityFilter, tagsFilter, typeFilter]);

  const displayedFilteredAssets = useMemo(() => {
    return applyFilters();
  }, [applyFilters]);

  // ── Reset des filtres ──
  const resetFilters = useCallback(() => {
    setPriorityFilter(null);
    setTypeFilter(null);
    setStatusFilter(null);
    setTagsFilter([]);
  }, []);

  // ── Auto-filtrage ──
  useEffect(() => {
    if (autoFilter) {
      // Le filtrage se fait via le useMemo ci-dessus
    }
  }, [autoFilter, statusFilter, priorityFilter, typeFilter, tagsFilter]);

  // ── Tags ──
  const handleAddTag = useCallback((tag: string) => {
    if (tag.trim() && !tagsFilter.includes(tag.trim())) {
      setTagsFilter((prev) => [...prev, tag.trim()]);
    }
  }, [tagsFilter]);

  const handleRemoveTag = useCallback((tag: string) => {
    setTagsFilter((prev) => prev.filter((t) => t !== tag));
  }, []);

  // ── Recherche API ──
  const handleSearch = useCallback(async () => {
    await searchAsset(
      searchAssetInput,
      includeNameForResearch,
      caseSensitiveForResearch,
      partialForResearch,
      firstOnlyForResearch,
      limitForResearch,
      setSearchAssetResult,
      setSearchError,
      setSearchLoading,
      navigate
    );
  }, [searchAssetInput, includeNameForResearch, caseSensitiveForResearch, partialForResearch, firstOnlyForResearch, limitForResearch, navigate]);

  // ── Application de la limite ──
  const handleApplyLimit = useCallback((val: number) => {
    const cleanVal = isNaN(val) || val < 1 ? 1 : Math.min(val, 500);
    setLocalListLimit(cleanVal);
    setListLimit(cleanVal);
  }, []);

  // ── Actions Unitaires ──
  const handlePause = useCallback(async (id: string) => {
    setActionLoading((prev) => ({ ...prev, [id]: true }));
    try {
      const result = await _pauseAsset({ asset_id: id }, getToken());
      if (result.ok) {
        toast.success("Actif mis en pause");
        await reload();
      } else {
        toast.error(`Erreur : ${result.error}`);
      }
    } catch (err) {
      toast.error(`Erreur : ${logError(err)}`);
    } finally {
      setActionLoading((prev) => ({ ...prev, [id]: false }));
    }
  }, [reload]);

  const handleResume = useCallback(async (id: string) => {
    setActionLoading((prev) => ({ ...prev, [id]: true }));
    try {
      const result = await _resumeAsset({ asset_id: id }, getToken());
      if (result.ok) {
        toast.success("Actif repris");
        await reload();
      } else {
        toast.error(`Erreur : ${result.error}`);
      }
    } catch (err) {
      toast.error(`Erreur : ${logError(err)}`);
    } finally {
      setActionLoading((prev) => ({ ...prev, [id]: false }));
    }
  }, [reload]);

  const confirmDeleteAsset = async (targetId?: string) => {
    const id = targetId ?? deleteTargetId;
    if (!id) return;
    setDeleteTargetId(null);
    setActionLoading((prev) => ({ ...prev, [id]: true }));
    try {
      const result = await _deleteAsset({ asset_id: id }, getToken());
      if (result.ok) {
        toast.success("Actif supprimé");
        console.log(selectedAsset, id);
        if (selectedAsset?.id === id) handleDeselect();
        if (searchAssetResult) {
          setSearchAssetResult((prev) => (prev ? prev.filter((a) => a.id !== id) : null));
        }
        await reload();
      } else {
        toast.error(`Erreur : ${result.error}`);
      }
    } catch (err) {
      toast.error(`Erreur : ${logError(err)}`);
    } finally {
      setActionLoading((prev) => ({ ...prev, [id]: false }));
    }
  }

  const handleUpdateAsset = async (assetId: string, attrs: Record<string, any>, restartWorkflow = false): Promise<boolean> => {
    try {
      const res = await updateAssetAction({ asset_id: assetId, attrs, restart_workflow: restartWorkflow }, setError, null, navigate);
      if (res && res.status === "ok") {
        await reload();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }

  // ── Actions Collectives ──
  const executeBulkPause = async () => {
    setBulkPauseModal(false);
    setBulkLoading(true);
    try {
      const res = await pauseAllAssetsAction({}, setError, null, navigate);
      if (res && (res.status === "success" || res.status === "ok")) {
        toast.success("⏸️ Tous les actifs ont été mis en pause");
        await reload();
      }
    } finally {
      setBulkLoading(false);
    }
  }

  const executeBulkResume = async () => {
    setBulkResumeModal(false);
    setBulkLoading(true);
    try {
      const res = await resumeAllAssetsAction({}, setError, null, navigate);
      if (res && (res.status === "success" || res.status === "ok")) {
        toast.success("▶️ Tous les actifs ont été repris");
        await reload();
      }
    } finally {
      setBulkLoading(false);
    }
  }

  // ── Sélection & Navigation ──
  const handleSelectAsset = (asset: Asset) => {
    setSelectedAsset(asset);
    setSearchParams(
      (prev) => {
        prev.set("asset_id", asset.id!);
        return prev;
      },
      { replace: true }
    );
  }

  const handleDeselect = () => {
    setSelectedAsset(null);
    setSearchParams(
      (prev) => {
        prev.delete("asset_id");
        return prev;
      },
      { replace: true }
    );
  }

  // ── Pagination des listes ──
  const displayedAssets = useMemo(() => {
    const list = displayedFilteredAssets || [];
    if (listShowAll) return list;
    return list.slice(0, listLimit);
  }, [displayedFilteredAssets, listShowAll, listLimit]);

  const displayedSearchResults = useMemo(() => {
    if (!searchAssetResult) return [];
    if (searchShowAll) return searchAssetResult;
    return searchAssetResult.slice(0, searchLimit);
  }, [searchAssetResult, searchShowAll, searchLimit]);

  // ── Grille 3 Colonnes Dynamique ──
  const gridLayoutClass = useMemo(() => {
    const activeCount = [showFilters, showList, showDetail].filter(Boolean).length;
    if (activeCount === 3) return "asset-layout--3-cols";
    if (activeCount === 2) {
      if (showFilters && showList) return "asset-layout--filters-list";
      if (showList && showDetail) return "asset-layout--list-detail";
      if (showFilters && showDetail) return "asset-layout--filters-detail";
    }
    return "asset-layout--1-col";
  }, [showFilters, showList, showDetail]);

  // ── Stats ──
  const totalAssets = filteredAssetsCopy.length;
  const totalFiltered = displayedFilteredAssets.length;
  const totalSearchResults = searchAssetResult?.length || 0;

  // ── Rendu ──
  if (!isLogin()) {
    return (
      <div id="asset_page_locked" className="asset_page_locked">
        <div className="grid-dots" />
        <div className="not-authenticated">
          <Lock size={26} className="not-authenticated-icon" />
          <h2>Accès restreint</h2>
          <p>
            Veuillez vous connecter sur la <Link to="/login">page de connexion</Link>.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div id="asset_page" className="asset_page">
      {/* ── 1. TOOLBAR SUPÉRIEURE ── */}
      <div className="asset_toolbar">
        <div className="asset_toolbar_title">
          <h1>Gestionnaire d'Actifs</h1>
          <span className="asset_toolbar_count">{totalAssets}</span>
        </div>


        <div className="asset_toolbar_actions">
          <button
            type="button"
            className="oh-btn oh-btn--ghost"
            style={{ color: "var(--warning)" }}
            onClick={() => setBulkPauseModal(true)}
            disabled={bulkLoading || totalAssets === 0}
            title="Mettre en pause tous les actifs du système"
          >
            <Pause size={15} /> Tout suspendre
          </button>

          <button
            type="button"
            className="oh-btn oh-btn--ghost"
            style={{ color: "var(--success)" }}
            onClick={() => setBulkResumeModal(true)}
            disabled={bulkLoading || totalAssets === 0}
            title="Reprendre tous les actifs du système"
          >
            <Play size={15} /> Tout reprendre
          </button>

          <button
            type="button"
            className="oh-btn oh-btn--primary"
            onClick={() => setShowAddAssetModal(true)}
          >
            <Plus size={16} /> Ajouter un actif
          </button>

          <button
            type="button"
            className="oh-btn oh-btn--ghost"
            onClick={reload}
            disabled={isReloading}
            title="Actualiser la liste"
          >
            <RefreshCw size={15} className={isReloading ? "oh-spin" : ""} /> Actualiser
          </button>
        </div>
      </div>

      {/* ── 2. TOGGLES DE SECTIONS ── */}
      <div className="section_toggles">
        <button
          type="button"
          className={`btn_toggle_section ${showSearchBar ? "is-active" : ""}`}
          onClick={() => setShowSearchBar(!showSearchBar)}
        >
          <Search size={14} /> Recherche
        </button>
        <button
          type="button"
          className={`btn_toggle_section ${showFilters ? "is-active" : ""}`}
          onClick={() => setShowFilters(!showFilters)}
        >
          <SlidersHorizontal size={14} /> Filtres
        </button>
        <button
          type="button"
          className={`btn_toggle_section ${showList ? "is-active" : ""}`}
          onClick={() => setShowList(!showList)}
        >
          <ListFilter size={14} /> Liste ({totalFiltered})
        </button>
        <button
          type="button"
          className={`btn_toggle_section ${showDetail ? "is-active" : ""}`}
          onClick={() => setShowDetail(!showDetail)}
        >
          <FileText size={14} /> Détails
        </button>

        <button
            type="button"
            className={`btn_toggle_section ${showPendingDeletion ? "is-active" : ""}`}
            onClick={() => setShowPendingDeletion(prev => !prev)}
            title="Afficher les assets en attente de suppresion"
          >
            <Delete size={15} /> Suppression
          </button>

      </div>

      {/* ── 3. BARRE DE RECHERCHE AVANCÉE ── */}
      {showSearchBar && (
        <div className="asset_search_bar">
          <div className="search_input_group">
            <label>Identifiant ou nom</label>
            <input
              className="search_asset_input"
              value={searchAssetInput}
              onChange={(e) => setSearchAssetInput(e.target.value)}
              placeholder="ex : sh_as-123, site vitrine, prod..."
              type="text"
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              disabled={searchLoading}
            />
          </div>

          <div className="search_toggle_group">
            <label>Chercher par nom</label>
            <button
              type="button"
              className={`btn_toggle ${includeNameForResearch ? "is-on" : ""}`}
              onClick={() => setIncludeNameForResearch(!includeNameForResearch)}
              disabled={searchLoading}
            >
              <span className="btn_toggle_knob" />
            </button>
          </div>

          <div className="search_toggle_group">
            <label>Sensible à la casse</label>
            <button
              type="button"
              className={`btn_toggle ${caseSensitiveForResearch ? "is-on" : ""}`}
              onClick={() => setCaseSensitiveForResearch(!caseSensitiveForResearch)}
              disabled={searchLoading}
            >
              <span className="btn_toggle_knob" />
            </button>
          </div>

          <div className="search_toggle_group">
            <label>Recherche partielle</label>
            <button
              type="button"
              className={`btn_toggle ${partialForResearch ? "is-on" : ""}`}
              onClick={() => setPartialForResearch(!partialForResearch)}
              disabled={searchLoading}
            >
              <span className="btn_toggle_knob" />
            </button>
          </div>

          <div className="search_toggle_group">
            <label>Un seul résultat</label>
            <button
              type="button"
              className={`btn_toggle ${firstOnlyForResearch ? "is-on" : ""}`}
              onClick={() => setFirstOnlyForResearch(!firstOnlyForResearch)}
              disabled={searchLoading}
            >
              <span className="btn_toggle_knob" />
            </button>
          </div>

          {!firstOnlyForResearch && (
            <div className="search_limit_group">
              <label>Max résultats</label>
              <input
                type="number"
                min="1"
                max="500"
                value={limitForResearch}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  if (!isNaN(val) && val > 0 && val <= 500) setLimitForResearch(val);
                }}
                disabled={searchLoading}
              />
            </div>
          )}

          <button
            type="button"
            className="btn_search_asset"
            onClick={handleSearch}
            disabled={searchLoading}
          >
            <Search size={15} />
            {searchLoading ? "Recherche..." : "Rechercher"}
          </button>

          {searchError && (
            <p className="search_error_text">
              <TriangleAlert size={13} /> {searchError}
            </p>
          )}

          {/* Résultats de recherche */}
          {searchAssetResult !== null && (
            <div className="asset_search_results">
              <div className="search_results_header">
                <span className="search_results_count">
                  {totalSearchResults} résultat{totalSearchResults > 1 ? "s" : ""} trouvé{totalSearchResults > 1 ? "s" : ""}
                </span>
                <button
                  type="button"
                  className="oh-btn oh-btn--ghost btn_close_search"
                  onClick={() => setSearchAssetResult(null)}
                >
                  ✕ Fermer recherche
                </button>
              </div>

              {searchAssetResult.length === 0 ? (
                <div className="asset_empty_state">Aucun résultat trouvé</div>
              ) : (
                <>
                  <div className="search_results_grid">
                    {displayedSearchResults.map((asset, index) => (
                      <AssetCard
                        key={`search-${asset.id}-${index}`}
                        asset={asset}
                        selected={selectedAsset?.id === asset.id}
                        onSelect={() => handleSelectAsset(asset)}
                        onPause={handlePause}
                        onResume={handleResume}
                        onDelete={(id) => setDeleteTargetId(id)}
                        isActionLoading={(id) => Boolean(actionLoading[id])}
                      />
                    ))}
                  </div>

                  {totalSearchResults > searchLimit && (
                    <div className="see_more_controls">
                      <button
                        type="button"
                        onClick={() => setSearchShowAll(!searchShowAll)}
                        className="btn_see_more"
                      >
                        {searchShowAll ? "Voir moins" : `Voir tout (${totalSearchResults})`}
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      )}

      {/* ── 4. CORPS PRINCIPAL : GRILLE 3 COLONNES DYNAMIQUE ── */}
      <div className={`asset_main_content ${gridLayoutClass}`}>
        {/* COLONNE 1 : FILTRES DÉDIÉS */}
        {showFilters && (
          <aside className="asset_filters_panel">
            <AssetFilter
              statusFilter={statusFilter}
              onStatusChange={setStatusFilter}
              typeFilter={typeFilter}
              onTypeChange={setTypeFilter}
              priorityFilter={priorityFilter}
              onPriorityChange={setPriorityFilter}
              tagsFilter={tagsFilter}
              onAddTag={handleAddTag}
              onRemoveTag={handleRemoveTag}
              autoFilter={autoFilter}
              onAutoFilterChange={setAutoFilter}
              onApplyFilters={() => {
                // Les filtres sont déjà appliqués via useMemo
                // On pourrait forcer un refresh si nécessaire
              }}
              onResetFilters={resetFilters}
              totalResults={totalFiltered}
            />
          </aside>
        )}

        {/* COLONNE 2 : LISTE DES ACTIFS AVEC PAGINATION TOUJOURS VISIBLE */}
        {showList && (
          <section className="asset_list_panel">
            {error && (
              <p className="asset_list_error">
                <TriangleAlert size={13} /> {error}
              </p>
            )}
            <div className="list_header">
              <span className="list_count">{totalFiltered} actif(s) au total</span>
              <span className="list_showing_count">
                Affichés : {displayedAssets.length} / {totalFiltered}
              </span>
            </div>

            {totalFiltered === 0 ? (
              <div className="asset_empty_state">Aucun actif à afficher</div>
            ) : (
              <div className="asset_cards_stack">
                {displayedAssets.map((asset, index) => (
                  <AssetCard
                    key={`asset-${asset.id}-${index}`}
                    asset={asset}
                    selected={selectedAsset?.id === asset.id}
                    onSelect={() => handleSelectAsset(asset)}
                    onPause={handlePause}
                    onResume={handleResume}
                    onDelete={(id) => setDeleteTargetId(id)}
                    isActionLoading={(id) => Boolean(actionLoading[id])}
                  />
                ))}
              </div>
            )}

            {/* ── CONTRÔLE DE PAGINATION FIXÉ EN BAS ── */}
            <div className="see_more_controls">
              <div className="see_more_limit_setter">
                <label>Afficher par lot de :</label>
                <input
                  type="number"
                  min={1}
                  max={500}
                  value={localListLimit}
                  onChange={(e) => setLocalListLimit(parseInt(e.target.value, 10) || 1)}
                  onBlur={(e) => handleApplyLimit(parseInt(e.target.value, 10))}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      handleApplyLimit(localListLimit);
                      (e.target as HTMLInputElement).blur();
                    }
                  }}
                  title="Modifiez la valeur et cliquez ailleurs ou tapez Entrée pour appliquer"
                />
              </div>

              {totalFiltered > listLimit && (
                <button
                  type="button"
                  onClick={() => setListShowAll(!listShowAll)}
                  className="btn_see_more"
                >
                  {listShowAll ? "Voir moins" : `Voir tout (${totalFiltered})`}
                </button>
              )}
            </div>
          </section>
        )}


        {/* COLONNE 3 : PANNEAU DÉTAIL */}
        {showDetail && selectedAsset != null && (
          
          <section className="asset_detail_panel_wrapper">
            <AssetDetail
              asset={selectedAsset}
              onPause={handlePause}
              onResume={handleResume}
              onDelete={(id) => {confirmDeleteAsset(id)}}
              onDeselect={handleDeselect}
              onUpdateAsset={handleUpdateAsset}
              isActionLoading={(id) => Boolean(actionLoading[id])}
              onRefresh={reload}
            />
          </section>
        )}
      </div>

      {/* ── 5. MODALES DE CONFIRMATION ── */}
      <ConfirmModal
        isOpen={bulkPauseModal}
        title="Suspendre tous les actifs ?"
        message="Cette action mettra en pause la surveillance et les scans de tous les actifs du système."
        confirmText="Suspendre tout"
        variant="warning"
        isLoading={bulkLoading}
        onConfirm={executeBulkPause}
        onCancel={() => setBulkPauseModal(false)}
      />

      <ConfirmModal
        isOpen={bulkResumeModal}
        title="Reprendre tous les actifs ?"
        message="Cette action relancera les tâches périodiques et les workflows de tous les actifs suspendus."
        confirmText="Reprendre tout"
        variant="info"
        isLoading={bulkLoading}
        onConfirm={executeBulkResume}
        onCancel={() => setBulkResumeModal(false)}
      />

      {
      /* On décommente le ConfirmModal, inchangé (pas de bug ici, car ce clic
      arrive sur un render ULTÉRIEUR, deleteTargetId est déjà bien à jour
      */
      }
      <ConfirmModal
        isOpen={Boolean(deleteTargetId)}
        title="Supprimer définitivement l'actif ?"
        message="Cette action est irréversible. L'actif, sa configuration et ses rapports associés seront définitivement détruits."
        confirmText="Supprimer définitivement"
        variant="danger"
        isLoading={Boolean(deleteTargetId && actionLoading[deleteTargetId])}
        onConfirm={() => confirmDeleteAsset(deleteTargetId!)}
        onCancel={() => setDeleteTargetId(null)}
      />

      {/* Modale d'Ajout d'Actif */}
      {showAddAssetModal && (
        <AddAssetModal
          setShowModal={setShowAddAssetModal}
          onAssetCreated={() => {
            reload();
            setShowAddAssetModal(false);
          }}
          naviguate={navigate}
        />
      )}
    </div>
  );
}

export default AssetPage;