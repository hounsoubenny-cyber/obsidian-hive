import React, { useState } from "react";
import {
  AssetStatus,
  AssetStatusMapping,
  AssetType,
  AssetTypeMapping,
  Priority,
  PRIORITY_MAPPING,
} from "@/types/assets/types";
import { capitalize } from "./utils";
import { SlidersHorizontal, RefreshCw, X, Plus, Zap, Tag } from "lucide-react";
import "./asset_filter.css";

interface AssetFilterProps {
  statusFilter: AssetStatus | null;
  onStatusChange: (val: AssetStatus | null) => void;
  typeFilter: AssetType | null;
  onTypeChange: (val: AssetType | null) => void;
  priorityFilter: Priority | null;
  onPriorityChange: (val: Priority | null) => void;
  tagsFilter: string[];
  onAddTag: (tag: string) => void;
  onRemoveTag: (tag: string) => void;
  autoFilter: boolean;
  onAutoFilterChange: (val: boolean) => void;
  onApplyFilters: () => void;
  onResetFilters: () => void;
  totalResults: number;
}

export function AssetFilter({
  statusFilter,
  onStatusChange,
  typeFilter,
  onTypeChange,
  priorityFilter,
  onPriorityChange,
  tagsFilter,
  onAddTag,
  onRemoveTag,
  autoFilter,
  onAutoFilterChange,
  onApplyFilters,
  onResetFilters,
  totalResults,
}: AssetFilterProps) {
  const [tagInput, setTagInput] = useState<string>("");

  const handleTagSubmit = () => {
    if (tagInput.trim()) {
      onAddTag(tagInput.trim());
      setTagInput("");
    }
  };

  return (
    <div className="filter-sidebar">
      {/* ── HEADER ── */}
      <div className="filter-sidebar__header">
        <h3 className="filter-sidebar__title">
          <SlidersHorizontal size={16} /> Filtres
        </h3>
        <span className="filter-sidebar__count">{totalResults} actif(s)</span>
      </div>

      {/* ── CORPS DES FILTRES ── */}
      <div className="filter-sidebar__body">
        {/* ── AUTO-FILTRE NETTOYÉ ── */}
        <div className="filter-auto-box">
          <div className="filter-auto-label-group">
            <label className="filter-auto-label">
              <Zap size={13} /> Auto-filtre
            </label>
            <span className={`filter-auto-badge ${autoFilter ? "is-live" : "is-manual"}`}>
              {autoFilter ? "⚡ En direct" : "🖐️ Manuel"}
            </span>
          </div>

          <button
            type="button"
            className={`btn_toggle ${autoFilter ? "is-on" : ""}`}
            onClick={() => onAutoFilterChange(!autoFilter)}
            title={autoFilter ? "Désactiver le filtrage en direct" : "Activer le filtrage en direct"}
          >
            <span className="btn_toggle_knob" />
          </button>
        </div>

        {/* Priorité */}
        <div className="filter-field">
          <label>Priorité</label>
          <select
            className="filter-select"
            value={priorityFilter ?? ""}
            onChange={(e) =>
              onPriorityChange(e.target.value ? (parseInt(e.target.value, 10) as Priority) : null)
            }
          >
            <option value="">Toutes les priorités</option>
            {Object.entries(PRIORITY_MAPPING).map(([key, value]) => (
              <option key={key} value={key}>
                {capitalize(value)} ({key})
              </option>
            ))}
          </select>
        </div>

        {/* Type d'actif */}
        <div className="filter-field">
          <label>Type d'actif</label>
          <select
            className="filter-select"
            value={typeFilter ?? ""}
            onChange={(e) =>
              onTypeChange(e.target.value ? (e.target.value as AssetType) : null)
            }
          >
            <option value="">Tous les types</option>
            {Object.entries(AssetTypeMapping).map(([key, value]) => (
              <option key={key} value={key}>
                {value}
              </option>
            ))}
          </select>
        </div>

        {/* Statut opérationnel */}
        <div className="filter-field">
          <label>Statut opérationnel</label>
          <select
            className="filter-select"
            value={statusFilter ?? ""}
            onChange={(e) =>
              onStatusChange(e.target.value ? (e.target.value as AssetStatus) : null)
            }
          >
            <option value="">Tous les statuts</option>
            {Object.entries(AssetStatusMapping).map(([key, value]) => (
              <option key={key} value={key}>
                {value}
              </option>
            ))}
          </select>
        </div>

        {/* Tags */}
        <div className="filter-field">
          <label><Tag size={13} /> Tags</label>
          {tagsFilter.length > 0 && (
            <div className="filter-tags-list">
              {tagsFilter.map((tag) => (
                <span key={tag} className="filter-tag-pill" onClick={() => onRemoveTag(tag)}>
                  #{tag} <X size={11} />
                </span>
              ))}
            </div>
          )}
          <div className="filter-tag-input-row">
            <input
              type="text"
              placeholder="ex : production"
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleTagSubmit()}
            />
            <button type="button" onClick={handleTagSubmit}>
              <Plus size={14} />
            </button>
          </div>
        </div>
      </div>

      {/* ── BOUTONS D'ACTION ── */}
      <div className="filter-sidebar__footer">
        <button type="button" className="btn_apply_filters" onClick={onApplyFilters}>
          Filtrer
        </button>
        <button type="button" className="oh-btn oh-btn--ghost filter-reset-btn" onClick={onResetFilters}>
          <RefreshCw size={13} /> Réinitialiser
        </button>
      </div>
    </div>
  );
}