import {
    Asset,
    AssetStatus,
    AssetType,
    GetAssetDataRequest,
    GetAssetResponse,
    ListAssetDataRequest,
    ListAssetResponse,
    Priority,
    SearchAssetDataRequest,
    SearchAssetResponse,
    UpdateAssetDataRequest,
    ManageAssetResponse,
    PauseAssetsDataRequest,
    ResumeAssetsDataRequest,
    BulkAssetActionResponse,
    ServerAssetModel,
    AddAssetResult,
    RotateSecretResponse,
    ReactivateServerAssetResponse,
    ServerToolInfo,
    AgentCapabilities
} from "@/types/assets/types";
import {
    listAsset as _listAsset,
    getAsset as _getAsset,
    pauseAsset as _pauseAsset,
    resumeAsset as _resumeAsset,
    deleteAsset as _deleteAsset,
    searchAsset as _searchAsset,
    updateAsset as _updateAsset,
    pauseAllAssets as _pauseAllAssets,
    resumeAllAssets as _resumeAllAssets,
    createServerAsset as _createServerAsset,
    revokeServerAsset as _revokeServerAsset,
    rotateServerSecret as _rotateServerSecret,
    reactivateServerAsset as _reactivateServerAsset,
    addServerCapabilities as _addServerCapabilities,
    removeServerCapabilities as _removeServerCapabilities,
    listServerCapabilities as _listServerCapabilities,
    allowServerTools as _allowServerTools,
    revokeServerTools as _revokeServerTools,
    listServerTools as _listServerTools,
} from "@/hooks/fetch_functions";
import { refreshToken, getToken } from "@/hooks/get_token";
import { useNavigate } from "react-router-dom";
import { logError } from "@/hooks/error_utils";

export function capitalize(str: string): string {
    if (!str) return "";
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}

// ─── CRUD Actifs ─────────────────────────────────────────────────────────────

export async function listAsset(
    setResult: Function[] | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<ListAssetResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const data: ListAssetDataRequest = { status: null, type_: null, priority: null, tags: null };
        const result = await _listAsset(data, getToken());
        if (result.ok) {
            const json = result.response as ListAssetResponse;
            if (setResult) { for (const fn of setResult) fn(json.assets); }
            return json;
        }
        const json = result.response as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await listAsset(setResult, setError, setLoading, navigate);
        }
        if (setResult) { for (const fn of setResult) fn(null); }
        setError(result.error || json?.detail?.error);
        return null;
    } catch (err) {
        const msg = logError(err);
        setError(msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function getAsset(
    identifier: string,
    include_name: boolean,
    first: boolean = true,
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<GetAssetResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await _getAsset({ identifier, include_name, first }, getToken());
        if (result.ok) {
            const json = result.response as GetAssetResponse;
            if (setResult) setResult(json.assets);
            return json;
        }
        const json = result.response as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getAsset(identifier, include_name, first, setResult, setError, setLoading, navigate);
        }
        if (setResult) setResult(null);
        setError(result.error || json?.detail?.error);
        return null;
    } catch (err) {
        const msg = logError(err);
        setError(msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function updateAssetAction(
    data: UpdateAssetDataRequest,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<ManageAssetResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await _updateAsset(data, getToken());
        if (result.ok) return result.response as ManageAssetResponse;
        const json = result.response as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await updateAssetAction(data, setError, setLoading, navigate);
        }
        setError(result.error || json?.detail?.error || "Erreur lors de la mise à jour");
        return null;
    } catch (err) {
        const msg = logError(err);
        setError(msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ─── Actions ServerAsset Spécifiques ─────────────────────────────────────────


export async function revokeServerAssetAction(
    assetId: string,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<boolean> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await _revokeServerAsset({ asset_id: assetId }, getToken());
        if (result.ok) return true;
        const json = result.response as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await revokeServerAssetAction(assetId, setError, setLoading, navigate);
        }
        setError(result.error || json?.detail?.error || "Erreur lors de la révocation");
        return false;
    } catch (err) {
        setError(logError(err));
        return false;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function rotateServerSecretAction(
    assetId: string,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<RotateSecretResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await _rotateServerSecret({ asset_id: assetId }, getToken());
        if (result.ok) return result.response as RotateSecretResponse;
        const json = result.response as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await rotateServerSecretAction(assetId, setError, setLoading, navigate);
        }
        setError(result.error || json?.detail?.error || "Erreur rotation secret");
        return null;
    } catch (err) {
        setError(logError(err));
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function reactivateServerAssetAction(
    assetId: string,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<ReactivateServerAssetResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await _reactivateServerAsset({ asset_id: assetId }, getToken());
        if (result.ok) return result.response as ReactivateServerAssetResponse;
        const json = result.response as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await reactivateServerAssetAction(assetId, setError, setLoading, navigate);
        }
        setError(result.error || json?.detail?.error || "Erreur réactivation");
        return null;
    } catch (err) {
        setError(logError(err));
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function getServerToolsList(
    setResult: (tools: ServerToolInfo[]) => void,
    setError: Function,
    navigate: ReturnType<typeof useNavigate>
): Promise<ServerToolInfo[] | null> {
    try {
        const result = await _listServerTools(getToken());
        if (result.ok) {
            const list = result.response as ServerToolInfo[];
            setResult(list);
            return list;
        }
        return null;
    } catch {
        return null;
    }
}

export async function getServerCapabilitiesList(
    setResult: (caps: Record<string, string>) => void,
    setError: Function,
    navigate: ReturnType<typeof useNavigate>
): Promise<Record<string, string> | null> {
    try {
        const result = await _listServerCapabilities(getToken());
        if (result.ok) {
            const dict = result.response as Record<string, string>;
            setResult(dict);
            return dict;
        }
        return null;
    } catch {
        return null;
    }
}

export async function toggleServerTool(
    assetId: string,
    toolName: string,
    allow: boolean,
    setError: Function,
    navigate: ReturnType<typeof useNavigate>
): Promise<boolean> {
    try {
        const fn = allow ? _allowServerTools : _revokeServerTools;
        const result = await fn({ asset_id: assetId, tools: [toolName] }, getToken());
        if (result.ok) return true;
        const json = result.response as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await toggleServerTool(assetId, toolName, allow, setError, navigate);
        }
        return false;
    } catch {
        return false;
    }
}

export async function toggleServerCapability(
    assetId: string,
    capability: AgentCapabilities,
    add: boolean,
    setError: Function,
    navigate: ReturnType<typeof useNavigate>
): Promise<boolean> {
    try {
        const fn = add ? _addServerCapabilities : _removeServerCapabilities;
        const result = await fn({ asset_id: assetId, capabilities: [capability] }, getToken());
        if (result.ok) return true;
        const json = result.response as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await toggleServerCapability(assetId, capability, add, setError, navigate);
        }
        return false;
    } catch {
        return false;
    }
}

// ─── Actions Collectives ─────────────────────────────────────────────────────

export async function pauseAllAssetsAction(
    data: PauseAssetsDataRequest,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<BulkAssetActionResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await _pauseAllAssets(data, getToken());
        if (result.ok) return result.response as BulkAssetActionResponse;
        const json = result.response as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await pauseAllAssetsAction(data, setError, setLoading, navigate);
        }
        setError(result.error || json?.detail?.error || "Erreur lors de la mise en pause globale");
        return null;
    } catch (err) {
        setError(logError(err));
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function resumeAllAssetsAction(
    data: ResumeAssetsDataRequest,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<BulkAssetActionResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await _resumeAllAssets(data, getToken());
        if (result.ok) return result.response as BulkAssetActionResponse;
        const json = result.response as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await resumeAllAssetsAction(data, setError, setLoading, navigate);
        }
        setError(result.error || json?.detail?.error || "Erreur lors de la reprise globale");
        return null;
    } catch (err) {
        setError(logError(err));
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ─── Recherche & Mappings ────────────────────────────────────────────────────

export async function searchAsset(
    query: string,
    includeName: boolean,
    caseSensitive: boolean,
    partial: boolean,
    firstOnly: boolean,
    limit: number,
    setResult: Function,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<SearchAssetResponse | null> {
    if (!query.trim()) {
        setResult(null);
        setError("");
        return null;
    }

    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await _searchAsset({ query: query.trim(), include_name: includeName, case_sensitive: caseSensitive, partial, first: firstOnly, limit }, getToken());
        if (result.ok) {
            const json = result.response as SearchAssetResponse;
            setResult(json.assets || []);
            setError("");
            return json;
        }
        const json = result.response as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await searchAsset(query, includeName, caseSensitive, partial, firstOnly, limit, setResult, setError, setLoading, navigate);
        }
        setResult(null);
        setError(result.error || json?.detail?.error || "Erreur lors de la recherche");
        return null;
    } catch (err) {
        setError(logError(err));
        setResult(null);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export function filterAsset(
    assets: Asset[],
    status: AssetStatus | null,
    priority: Priority | null,
    tags: string[] | null,
    type: AssetType | null
): Asset[] {
    return assets.filter((asset) => {
        let can = true;
        if (status) can = can && asset.status === status;
        if (priority) can = can && asset.priority === priority;
        if (type) can = can && asset.type === type;
        if (tags && tags.length > 0)
            can = can && (asset.tags || []).some((value) => tags.includes(value));
        return can;
    });
}

export const assetTypeIcon: Record<AssetType, string> = {
    web_site: "🌐",
    web_app: "🧩",
    network: "📡",
    server: "🖥️",
};

export const statusDotClass: Record<AssetStatus, string> = {
    active: "status_dot_active",
    suppressed: "status_dot_suppressed",
    inactive: "status_dot_inactive",
};