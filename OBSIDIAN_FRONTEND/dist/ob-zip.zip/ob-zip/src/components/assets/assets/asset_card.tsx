import React from "react";
import {
  Asset,
  AssetStatusMapping,
  AssetTypeMapping,
  PRIORITY_MAPPING,
  AgentStatusMapping,
} from "@/types/assets/types";
import { assetTypeIcon, statusDotClass } from "./utils";
import { Pause, Play, Trash2, Loader2, TriangleAlert, Server, Globe, Radio, Clock } from "lucide-react";
import "./asset_card.css";

interface AssetCardProps {
  asset: Asset;
  selected: boolean;
  onSelect: () => void;
  onPause: (id: string) => void;
  onResume: (id: string) => void;
  onDelete: (id: string) => void;
  isActionLoading: (id: string) => boolean;
}

export function AssetCard({
  asset,
  selected,
  onSelect,
  onPause,
  onResume,
  onDelete,
  isActionLoading,
}: AssetCardProps) {
  const assetId = asset.id || "";
  const isLoading = isActionLoading(assetId);
  const isServer = asset.type === "server";
  const isPendingDeletion = asset.pending_deletion === true;

  // ── Déterminer le statut affiché ──
  const getDisplayStatus = () => {
    // Priorité 1 : pending_deletion
    if (isPendingDeletion) {
      return {
        label: "🗑️ Suppression programmée",
        dotClass: "status_dot_pending_deletion",
        statusClass: "status_pending_deletion",
      };
    }

    // Priorité 2 : serveur avec agent_status
    if (isServer) {
      const agentStatus = asset.agent_status || "pending_install";
      const statusMap = {
        connected: { label: AgentStatusMapping.connected || "Connecté", dotClass: "status_dot_active" },
        pending_install: { label: AgentStatusMapping.pending_install || "En attente d'install.", dotClass: "status_dot_suppressed" },
        offline: { label: AgentStatusMapping.offline || "Hors ligne", dotClass: "status_dot_inactive" },
        revoked: { label: AgentStatusMapping.revoked || "Révoqué", dotClass: "status_dot_inactive" },
      };
      return {
        label: statusMap[agentStatus as keyof typeof statusMap]?.label || "Inconnu",
        dotClass: statusMap[agentStatus as keyof typeof statusMap]?.dotClass || "status_dot_inactive",
      };
    }

    // Priorité 3 : asset standard
    return {
      label: AssetStatusMapping[asset.status],
      dotClass: statusDotClass[asset.status],
    };
  };

  const displayStatus = getDisplayStatus();

  // ── Déterminer si les actions sont disponibles ──
  const actionsDisabled = isPendingDeletion || isLoading || !assetId;

  return (
    <div
      className={`asset-card ${selected ? "asset-card--selected" : ""} ${isPendingDeletion ? "asset-card--pending-deletion" : ""}`}
      onClick={onSelect}
    >
      <div className="asset-card__header">
        <span className="asset-card__icon">{assetTypeIcon[asset.type]}</span>
        <div className="asset-card__title-group">
          <h4 className="asset-card__name">
            {asset.name || "Actif sans nom"}
            {isPendingDeletion && (
              <span className="asset-card__deletion-badge">
                <Clock size={12} /> Suppression
              </span>
            )}
          </h4>
          <span className="asset-card__id oh-mono">{assetId.slice(0, 14)}…</span>
        </div>
      </div>

      <div className="asset-card__meta">
        <span className="oh-badge oh-badge--accent asset-card__type">
          {AssetTypeMapping[asset.type]}
        </span>

        <span className={`asset-card__status ${displayStatus.statusClass || ""}`}>
          <span className={`status_dot ${displayStatus.dotClass}`} />
          {displayStatus.label}
        </span>

        <span className="asset-card__priority">
          <TriangleAlert size={11} />
          {PRIORITY_MAPPING[asset.priority]}
        </span>
      </div>

      {asset.tags && asset.tags.length > 0 && (
        <div className="asset-card__tags">
          {asset.tags.slice(0, 3).map((tag, i) => (
            <span key={i} className="asset-card__tag">
              #{tag}
            </span>
          ))}
          {asset.tags.length > 3 && (
            <span className="asset-card__tag-more">+{asset.tags.length - 3}</span>
          )}
        </div>
      )}

      <div className="asset-card__actions" onClick={(e) => e.stopPropagation()}>
        {!isServer && !isPendingDeletion && (
          asset.status === "active" ? (
            <button
              type="button"
              className="asset-card__action-btn asset-card__action-btn--pause"
              onClick={() => onPause(assetId)}
              disabled={actionsDisabled}
              title="Mettre en pause"
            >
              {isLoading ? <Loader2 size={13} className="oh-spin" /> : <Pause size={13} />}
            </button>
          ) : (
            <button
              type="button"
              className="asset-card__action-btn asset-card__action-btn--resume"
              onClick={() => onResume(assetId)}
              disabled={actionsDisabled}
              title="Reprendre"
            >
              {isLoading ? <Loader2 size={13} className="oh-spin" /> : <Play size={13} />}
            </button>
          )
        )}

        <button
          type="button"
          className={`asset-card__action-btn asset-card__action-btn--delete ${isPendingDeletion ? "asset-card__action-btn--disabled" : ""}`}
          onClick={() => onDelete(assetId)}
          disabled={actionsDisabled}
          title={isPendingDeletion ? "Suppression en cours..." : "Supprimer"}
        >
          {isLoading ? <Loader2 size={13} className="oh-spin" /> : <Trash2 size={13} />}
        </button>
      </div>
    </div>
  );
}