import React, { useEffect, useState } from "react";
import {
  AssetType,
  WebAssetModel,
  NetworkAssetModel,
  ServerAssetModel,
  AddAssetResult,
  PRIORITY_MAPPING,
  NetworkDeploymentModeMapping,
} from "@/types/assets/types";
import { HelpersListResponse } from "@/types/scanner/types";
import {
  createNetworkAssetAction,
  createWebAssetAction,
  createServerAssetAction,
  getIdsIpsDefaultConfig,
  getScannerDefaultConfig,
  getScannerSupportedVulns,
  listScannerHelper,
} from "./utils";
import { AddWebAsset, AddNetworkAsset, AddServerAsset } from "./add_asset_modal_utils";
import {
  Globe,
  Layers,
  Radio,
  Server,
  Terminal,
  Copy,
  Check,
  X,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import toast from "react-hot-toast";
import "./add_asset_modal.css";

interface AddAssetModalProps {
  setShowModal: (val: boolean) => void;
  onAssetCreated: () => void;
  naviguate: (val: any) => void;
}

export function AddAssetModal({
  setShowModal,
  onAssetCreated,
  naviguate,
}: AddAssetModalProps) {
  // ── ÉTATS PRINCIPAUX ──
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [assetType, setAssetType] = useState<AssetType | null>(null);
  const [formData, setFormData] = useState<
    WebAssetModel | NetworkAssetModel | ServerAssetModel | null
  >(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>("");
  const [createdResult, setCreatedResult] = useState<AddAssetResult | null>(null);
  const [copiedCmd, setCopiedCmd] = useState<boolean>(false);

  // ── CONFIGS PAR DÉFAUT (Scanner & IDS) ──
  const [scannerDefaultConfig, setScannerDefaultConfig] = useState<Record<string, any> | null>(null);
  const [scannerSupportedVulns, setScannerSupportedVulns] = useState<string[] | null>(null);
  const [idsIpsDefaultConfig, setIdsIpsDefaultConfig] = useState<Record<string, any> | null>(null);
  const [scannerHelperList, setScannerHelperList] = useState<HelpersListResponse | null>(null);

  // Chargement des dépendances
  useEffect(() => {
    getScannerDefaultConfig(setScannerDefaultConfig, () => {}, null, naviguate);
    getIdsIpsDefaultConfig(setIdsIpsDefaultConfig, () => {}, null, naviguate);
    listScannerHelper(setScannerHelperList, () => {}, null, naviguate);
    getScannerSupportedVulns(setScannerSupportedVulns, () => {}, null, naviguate);
  }, [naviguate]);

  // Fermeture et reset
  const handleClose = () => {
    setShowModal(false);
    setCurrentStep(1);
    setAssetType(null);
    setFormData(null);
    setCreatedResult(null);
    setError("");
  };

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") handleClose();
    };
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, []);

  // Navigation entre étapes
  const nextStep = () => {
    if (currentStep === 1 && !assetType) {
      setError("Veuillez sélectionner un type d'actif.");
      return;
    }
    if (currentStep === 2 && !formData) {
      setError("Veuillez valider la configuration ci-dessus avant de continuer.");
      return;
    }
    setError("");
    setCurrentStep((prev) => prev + 1);
  };

  const prevStep = () => {
    setError("");
    setCurrentStep((prev) => prev - 1);
  };

  // Soumission finale vers l'API
  const handleSubmit = async () => {
    if (!formData) return;
    setLoading(true);
    setError("");

    try {
      let result: AddAssetResult | null = null;

      if (assetType === "web_site" || assetType === "web_app") {
        result = await createWebAssetAction(
          formData as WebAssetModel,
          setError,
          setLoading,
          naviguate
        );
      } else if (assetType === "network") {
        result = await createNetworkAssetAction(
          formData as NetworkAssetModel,
          setError,
          setLoading,
          naviguate
        );
      } else if (assetType === "server") {
        result = await createServerAssetAction(
          formData as ServerAssetModel,
          setError,
          setLoading,
          naviguate
        );
      }
      if (result && (result.status === "ok" || result.status === "success")) {
        setCreatedResult(result);
        if (assetType !== "server") {
          toast.success("✅ Actif créé et intégré avec succès !");
        } else {
          toast.success("🎉 Serveur créé ! Copiez la commande d'installation a l'étape suivante.");
        }
        setTimeout(() => {onAssetCreated(); handleClose()}, assetType === "server" ? 5000 : 1000);
      } else {
        const errMsg = result?.error || "Erreur lors de la création de l'actif";
        setError(errMsg);
        toast.error(errMsg);
      }
    } catch (err: any) {
      setError(err?.message || "Erreur inattendue");
    } finally {
      setLoading(false);
    }
  };

  const handleCopyInstallCmd = async () => {
    if (createdResult?.install_command) {
      await navigator.clipboard.writeText(createdResult.install_command);
      setCopiedCmd(true);
      toast.success("Commande copiée !");
      setTimeout(() => setCopiedCmd(false), 2000);
    }
  };
  const validateServerAssetData = async (data) => {
    setFormData(data);
    //await handleSubmit();
    toast.success("Configuration serveur prête !");
  }
  // ── ÉTAPE 1 : CHOIX DU TYPE D'ACTIF ──
  const renderStep1Type = () => {
    const types = [
      {
        type: "web_site" as AssetType,
        icon: <Globe size={32} className="modal-type-card__icon modal-type-card__icon--web" />,
        label: "Site Web",
        desc: "Site vitrine, e-commerce ou API HTTP classique.",
      },
      {
        type: "web_app" as AssetType,
        icon: <Layers size={32} className="modal-type-card__icon modal-type-card__icon--app" />,
        label: "Application Web (SPA)",
        desc: "Single Page App (React, Vue, Angular) nécessitant un rendu DOM dynamique.",
      },
      {
        type: "network" as AssetType,
        icon: <Radio size={32} className="modal-type-card__icon modal-type-card__icon--net" />,
        label: "Sonde Réseau",
        desc: "Surveillance passive ou bloquante IDS/IPS via Suricata et NFTables.",
      },
      {
        type: "server" as AssetType,
        icon: <Server size={32} className="modal-type-card__icon modal-type-card__icon--server" />,
        label: "Serveur Distant (Agent)",
        desc: "Hôte distant administré via un agent autonome léger sécurisé par WebSocket.",
      },
    ];

    return (
      <div className="modal-wizard-step">
        <h3 className="modal-wizard-step__title">Sélectionnez le type d'actif</h3>
        <p className="modal-wizard-step__subtitle">
          Choisissez la cible à intégrer dans le périmètre de défense d'Obsidian Hive.
        </p>

        <div className="modal-type-grid">
          {types.map((t) => (
            <div
              key={t.type}
              className={`modal-type-card ${assetType === t.type ? "modal-type-card--selected" : ""}`}
              onClick={() => {
                setAssetType(t.type);
                setError("");
              }}
            >
              {t.icon}
              <h4 className="modal-type-card__title">{t.label}</h4>
              <p className="modal-type-card__desc">{t.desc}</p>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // ── ÉTAPE 2 : CONFIGURATION SPÉCIFIQUE ──
  const renderStep2Config = () => {
    const isWeb = assetType === "web_site" || assetType === "web_app";
    if (isWeb){
      return (
        <div className="modal-wizard-step">
            <AddWebAsset
            scannerDefaultConfig={scannerDefaultConfig || {}}
            scannerHelperList={scannerHelperList || { helpers: [], total: 0, usage: "" }}
            supportedScannerVulns={scannerSupportedVulns || []}
            isSpa={assetType === "web_app"}
            desc_limit={100}
            show_module={false}
            onValidate={(data) => {
              setFormData(data);
              toast.success("Configuration validée !");
            }}
            naviguate={naviguate}
          />
        </div>
      )
    }
    if (assetType === "network"){
      return (
        <div className="modal-wizard-step">
          <AddNetworkAsset
            idsIpsDefaultConfig={idsIpsDefaultConfig || {}}
            desc_limit={100}
            show_module={false}
            onValidate={(data) => {
              setFormData(data);
              toast.success("Configuration réseau validée !");
            }}
            naviguate={naviguate}
          />
        </div>
      )
    }
    if (assetType === "server"){
      return (
        <div className="modal-wizard-step">
          <AddServerAsset
            onValidate={validateServerAssetData}
          />
      </div>
      )
    }
    return null;
  };

  // ── ÉTAPE 3 : RÉCAPITULATIF & RÉSULTAT ENRÔLEMENT ──
  const renderStep3Validation = () => {
    const isWeb = assetType === "web_site" || assetType === "web_app";
    const typeLabel = isWeb
      ? assetType === "web_site"
        ? "Site Web"
        : "Application Web (SPA)"
      : assetType === "network"
      ? "Sonde Réseau IDS/IPS"
      : "Serveur Distant";

    return (
      <div className="modal-wizard-step">
        <h3 className="modal-wizard-step__title">Récapitulatif & Déploiement</h3>
        <p className="modal-wizard-step__subtitle">
          Vérifiez les paramètres avant l'intégration finale dans le système.
        </p>

        {/* Si l'agent serveur est créé : Affichage du Terminal d'Installation */}
        {createdResult?.install_command ? (
          <div className="modal-terminal-onboarding">
            <div className="modal-terminal-onboarding__header">
              <Terminal size={18} className="modal-terminal-onboarding__icon" />
              <span className="modal-terminal-onboarding__title">
                Commande d'installation de l'Agent Serveur
              </span>
            </div>

            <p className="modal-terminal-onboarding__desc">
              Exécutez cette commande en <strong>root (sudo)</strong> sur la machine cible. Le binaire sera automatiquement téléchargé et enregistré.
            </p>

            <div className="modal-terminal-onboarding__command-row">
              <pre className="modal-terminal-onboarding__code oh-mono">
                <code>{createdResult.install_command}</code>
              </pre>
              <button
                type="button"
                className="oh-btn oh-btn--primary modal-terminal-onboarding__btn"
                onClick={handleCopyInstallCmd}
              >
                {copiedCmd ? <Check size={14} /> : <Copy size={14} />}
                {copiedCmd ? "Copié !" : "Copier"}
              </button>
            </div>
          </div>
        ) : (
          /* Résumé Standard */
          <div className="modal-summary-card">
            <div className="modal-summary-row">
              <span className="modal-summary-label">Type d'Actif</span>
              <span className="modal-summary-value">{typeLabel}</span>
            </div>
            <div className="modal-summary-row">
              <span className="modal-summary-label">Nom</span>
              <span className="modal-summary-value">{formData?.name || "Non défini"}</span>
            </div>
            <div className="modal-summary-row">
              <span className="modal-summary-label">Niveau de Priorité</span>
              <span className="modal-summary-value">
                {PRIORITY_MAPPING[formData?.priority || 1]}
              </span>
            </div>

            {isWeb && (
              <>
                <div className="modal-summary-row">
                  <span className="modal-summary-label">URL Cible</span>
                  <span className="modal-summary-value oh-mono">
                    {(formData as WebAssetModel)?.url || "—"}
                  </span>
                </div>
                <div className="modal-summary-row">
                  <span className="modal-summary-label">Fix Automatique Alex</span>
                  <span className="modal-summary-value">
                    {(formData as WebAssetModel)?.fix_allowed ? "✅ Autorisé" : "❌ Désactivé"}
                  </span>
                </div>
              </>
            )}

            {assetType === "network" && (
              <div className="modal-summary-row">
                <span className="modal-summary-label">Mode Déploiement</span>
                <span className="modal-summary-value">
                  {NetworkDeploymentModeMapping[(formData as NetworkAssetModel)?.deployment_mode]}
                </span>
              </div>
            )}

            {assetType === "server" && (
              <div className="modal-summary-row">
                <span className="modal-summary-label">Protocole d'agent</span>
                <span className="modal-summary-value">WebSocket Chiffré (mTLS / Token)</span>
              </div>
            )}

            <div className="modal-summary-row">
              <span className="modal-summary-label">Tags</span>
              <span className="modal-summary-value">
                {formData?.tags && formData.tags.length > 0
                  ? formData.tags.map((t) => `#${t}`).join(" ")
                  : "Aucun tag"}
              </span>
            </div>
          </div>
        )}

        {error && (
          <div className="modal-error-box">
            <AlertCircle size={16} />
            <span>{error}</span>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="modal-wizard-overlay" onClick={handleClose}>
      <div className="modal-wizard-container" onClick={(e) => e.stopPropagation()}>
        {/* ── HEADER MODALE ── */}
        <header className="modal-wizard-header">
          <div className="modal-wizard-header__title">
            <Sparkles size={20} className="modal-wizard-header__icon" />
            <h2>Ajouter un Nouvel Actif</h2>
          </div>
          <button
            type="button"
            className="modal-wizard-header__close-btn"
            onClick={handleClose}
          >
            <X size={18} />
          </button>
        </header>

        {/* ── STEPS PROGRESS BAR ── */}
        <nav className="modal-wizard-steps">
          <div className={`modal-step-item ${currentStep >= 1 ? "active" : ""}`}>
            <span className="modal-step-number">1</span>
            <span>Type de cible</span>
          </div>
          <div className="modal-step-separator" />
          <div className={`modal-step-item ${currentStep >= 2 ? "active" : ""}`}>
            <span className="modal-step-number">2</span>
            <span>Configuration</span>
          </div>
          <div className="modal-step-separator" />
          <div className={`modal-step-item ${currentStep >= 3 ? "active" : ""}`}>
            <span className="modal-step-number">3</span>
            <span>Validation</span>
          </div>
        </nav>

        {/* ── CORPS DU WIZARD ── */}
        <main className="modal-wizard-body">
          {currentStep === 1 && renderStep1Type()}
          {currentStep === 2 && renderStep2Config()}
          {currentStep === 3 && renderStep3Validation()}
        </main>

        {/* ── FOOTER DE NAVIGATION ── */}
        <footer className="modal-wizard-footer">
          {currentStep > 1 && !createdResult && (
            <button
              type="button"
              className="oh-btn oh-btn--ghost"
              onClick={prevStep}
              disabled={loading}
            >
              <ArrowLeft size={14} /> Précédent
            </button>
          )}

          <div className="modal-wizard-footer__spacer" />

          {currentStep === 1 && (
            <button
              type="button"
              className="oh-btn oh-btn--primary"
              onClick={nextStep}
              disabled={!assetType || loading}
            >
              Suivant <ArrowRight size={14} />
            </button>
          )}

          {currentStep === 2 && (
            <button
              type="button"
              className="oh-btn oh-btn--primary"
              onClick={nextStep}
              disabled={!formData || loading}
            >
              Vérifier les données <ArrowRight size={14} />
            </button>
          )}

          {currentStep === 3 &&
            (createdResult?.install_command ? (
              <button
                type="button"
                className="oh-btn oh-btn--primary"
                onClick={handleClose}
              >
                Terminer et Fermer
              </button>
            ) : (
              <button
                type="button"
                className="oh-btn oh-btn--primary"
                onClick={handleSubmit}
                disabled={loading}
              >
                {loading ? "Création en cours..." : "Confirmer et Créer l'Actif"}
              </button>
            ))}
        </footer>
      </div>
    </div>
  );
}

export default AddAssetModal;