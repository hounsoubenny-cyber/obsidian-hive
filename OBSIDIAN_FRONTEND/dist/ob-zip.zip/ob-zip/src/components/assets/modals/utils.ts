import { useNavigate } from "react-router-dom";
import { getToken, refreshToken } from "@/hooks/get_token";
import {
    getScannerDefaultConfig as _getScannerDefaultConfig,
    getIdsIpsDefaultConfig as _getIdsIpsDefaultConfig,
    listScannerHelper as _listScannerHelper,
    createWebAsset, createNetworkAsset,
    checkPathExits as _checkPathExits,
    validateScannerKnowParamDir as _validateScannerKnowParamDir,
    listScannerSupportedVulns as _listScannerSupportedVulns,
    createServerAsset as _createServerAsset,
} from "@/hooks/fetch_functions";
import { logError } from "@/hooks/error_utils";
import { HelperArg, HelpersListResponse} from "@/types/scanner/types";
import { AddAssetResult, NetworkAssetModel, ServerAssetModel, WebAssetModel } from "@/types/assets/types";


// ============================================================================
// TYPES
// ============================================================================

export type ConfigType = "scanner" | "ids_ips";

export const ConfigMapper: Record<ConfigType, Function> = {
    scanner: _getScannerDefaultConfig,
    ids_ips: _getIdsIpsDefaultConfig,
};

// ============================================================================
// UTILITAIRE DE FORMATAGE
// ============================================================================

export function toTitleCaseWithUnderscore(str: string): string {
    if (!str) return "";
    
    return str
        .split("_")
        .map(word => {
            if (word.length === 0) return "";
            return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
        })
        .join(" ")
        .trim();
}

// ============================================================================
// FONCTIONS DE RÉCUPÉRATION
// ============================================================================

export async function getDefaultConfig(
    name: ConfigType,
    setResult: Function | null,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<Record<string, any> | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await ConfigMapper[name](getToken());
        const json = result.response;
        if (result.ok) {
            if (setResult) setResult(json);
            return json;
        }
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getDefaultConfig(name, setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error || json?.detail?.error || `Erreur lors du chargement de la config pour ${name} !`);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log(`❌ Erreur dans getDefaultConfig pour ${name} : ${msg}`);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function getScannerDefaultConfig(
    setResult: Function | null,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<Record<string, any> | null> {
    return await getDefaultConfig("scanner", setResult, setError, setLoading, navigate);
}

export async function getIdsIpsDefaultConfig(
    setResult: Function | null,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<Record<string, any> | null> {
    return await getDefaultConfig("ids_ips", setResult, setError, setLoading, navigate);
}

export async function listScannerHelper(
    setResult: Function | null,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<HelpersListResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await _listScannerHelper(getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as HelpersListResponse;
            if (setResult) setResult(json);
            return json;
        }
        const json = json_ as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await listScannerHelper(setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error || json?.detail?.error || `Erreur lors du chargement des helpers !`);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log(`❌ Erreur dans listScannerHelper : ${msg}`);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function getScannerSupportedVulns(
    setResult: Function | null,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<string[] | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await _listScannerSupportedVulns(getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as string[];
            if (setResult) setResult(json);
            return json;
        }
        const json = json_ as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getScannerSupportedVulns(setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error || json?.detail?.error || `Erreur lors du chargement des vulnérabilités supportés !`);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log(`❌ Erreur dans getScannerSupportedVulns : ${msg}`);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function createWebAssetAction(
    data: WebAssetModel,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<AddAssetResult | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        //console.log(data); 
        const result = await createWebAsset(data, getToken());
        //console.log(result);
        if (result.ok) return result.response as AddAssetResult;
        const json = result.response as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await createWebAssetAction(data, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        setError(result.error || json?.detail?.error || "Erreur lors de la création de l'asset web");
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans createWebAssetAction : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function createNetworkAssetAction(
    data: NetworkAssetModel,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<AddAssetResult | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        //console.log(data); 
        const result = await createNetworkAsset(data, getToken());
        //console.log(result);
        if (result.ok) return result.response as AddAssetResult;
        const json = result.response as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await createNetworkAssetAction(data, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        setError(result.error || json?.detail?.error || "Erreur lors de la création de l'asset réseau");
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans createNetworkAssetAction : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function createServerAssetAction(
    data: ServerAssetModel,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<AddAssetResult | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await _createServerAsset(data, getToken());
        if (result.ok) return result.response as AddAssetResult;
        const json = result.response as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await createServerAssetAction(data, setError, setLoading, navigate);
        }
        setError(result.error || json?.detail?.error || "Erreur création ServerAsset");
        return null;
    } catch (err) {
        const msg = logError(err);
        setError(msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function checkPathExits(path: string, navigate: ReturnType<typeof useNavigate>): Promise<boolean | null> {
    try {
        const result = await _checkPathExits(path, getToken());
        if (result.ok) return Boolean(result.response.exists);
        const json = result.response as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await checkPathExits(path, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        return false;
    } catch (err) {
        const msg: string = logError(err);
        console.log("❌ Erreur dans checkPathExits : ", msg);
        return false;
    }
}

export async function validateScannerKnowParamDir(path: string, navigate: ReturnType<typeof useNavigate>): Promise<{ can: boolean, reason: string } | null> {
    try {
        const result = await _validateScannerKnowParamDir(path, getToken());
        if (result.ok) return { can: result.response.can, reason: result.response.reason };
        const json = result.response as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await validateScannerKnowParamDir(path, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        return null;
    } catch (err) {
        const msg: string = logError(err);
        console.log("❌ Erreur dans checkPathExits : ", msg);
        return null;
    }
}

// ============================================================================
// DÉTECTION DU TYPE D'INPUT POUR UN ARGUMENT
// ============================================================================

export function detectInputType(arg: HelperArg): "text" | "number" | "float" | "boolean" | "url" | "json" | "list" {
    //console.log(arg.input_type);
    if (arg.input_type) return arg.input_type;
    const name = arg.name.toLowerCase();
    if (name.includes("url") || name.includes("uri") || name.includes("link") || name.includes("host")) return "url";
    const type = arg.type[0];
    if (type === "int") return "number";
    if (type === "float") return "float";
    if (type === "bool") return "boolean";
    if (type === "dict") return "json";
    if (type === "list") return "list";
    return "text";
}
