import {
  getScannerDefaultConfig as _getScannerDefaultConfig,
  getIdsIpsDefaultConfig as _getIdsIpsDefaultConfig,
  listScannerHelper as _listScannerHelper,
  validateScannerKnowParamDir as _validateScannerKnowParamDir,
} from "@/hooks/fetch_functions";
import React, { useEffect, useState, useMemo } from "react";
import JsonEditor from "@/components/utils/json_editor/json_editor";
import {
  HelperArg,
  HelperCall,
  HelperInfo,
  HelpersListResponse,
  ScanArgs,
  ScanInstanceArgs,
} from "@/types/scanner/types";
import {
  AssetStatus,
  AssetStatusMapping,
  AssetStatutEnum,
  NetworkAssetModel,
  NetworkDeploymentMode,
  NetworkDeploymentModeEnum,
  NetworkDeploymentModeMapping,
  Priority,
  PRIORITY_MAPPING,
  PriorityEnum,
  ServerAssetModel,
  WebAssetModel,
} from "@/types/assets/types";
import { capitalize } from "lodash";
import {
  checkPathExits,
  detectInputType,
  toTitleCaseWithUnderscore,
  validateScannerKnowParamDir,
} from "./utils";
import toast from "react-hot-toast";

// ============================================================================
// COMPOSANT : BASE ASSET (CHAMPS COMMUNS)
// ============================================================================

export function BaseAsset({
  assetName,
  setAssetName,
  priority,
  setPriority,
  statut,
  setStatut,
  tags,
  setTags,
  autoFix,
  setAutoFix,
  assetMetadata,
  setAssetMetadata,
}: {
  assetName: string | null;
  setAssetName: (val: any) => void;
  priority: Priority;
  setPriority: (val: any) => void;
  statut: AssetStatus;
  setStatut: (val: any) => void;
  tags: string[] | null;
  setTags: (val: any) => void;
  autoFix: boolean;
  setAutoFix: (val: any) => void;
  assetMetadata: Record<string, any>;
  setAssetMetadata: (val: any) => void;
}) {
  const [tagInput, setTagInput] = useState<string>("" );
  const [metaKeyInput, setMetaKeyInput] = useState<string>("");
  const [metaValueInput, setMetaValueInput] = useState<string>("");

  const handleAddTag = () => {
    if (tagInput.trim()) {
      setTags([...(tags || []), tagInput.trim()]);
      setTagInput("");
    }
  };

  const handleRemoveTag = (index: number) => {
    setTags((tags || []).filter((_, i) => i !== index));
  };

  const handleAddMetadata = () => {
    if (metaKeyInput.trim() && metaValueInput.trim()) {
      setAssetMetadata({ ...assetMetadata, [metaKeyInput.trim()]: metaValueInput.trim() });
      setMetaKeyInput("");
      setMetaValueInput("");
    }
  };

  const handleRemoveMetadata = (key: string) => {
    const newMeta = { ...assetMetadata };
    delete newMeta[key];
    setAssetMetadata(newMeta);
  };

  return (
    <div className="jam_base_asset">
      <div className="jam_form_row">
        <div className="jam_form_group">
          <label>📛 Nom (Optionnel)</label>
          <input
            className="jam_input"
            type="text"
            value={assetName || ""}
            onChange={(e) => setAssetName(e.target.value)}
            placeholder="Ex : Site vitrine, API Gateway..."
          />
        </div>
        <div className="jam_form_group">
          <label>🔺 Priorité</label>
          <select
            className="jam_select"
            value={priority}
            onChange={(e) => setPriority(Number(e.target.value) as Priority)}
          >
            {Object.entries(PRIORITY_MAPPING).map(([key, value]) => (
              <option key={key} value={Number(key)}>
                {capitalize(value)} ({key})
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="jam_form_row">
        <div className="jam_form_group">
          <label>📶 Statut</label>
          <select
            className="jam_select"
            value={statut}
            onChange={(e) => setStatut(e.target.value as AssetStatus)}
          >
            {Object.entries(AssetStatusMapping).map(([key, value]) => (
              <option key={key} value={key}>
                {value}
              </option>
            ))}
          </select>
        </div>
        <div className="jam_form_group">
          <label>🔧 Fix auto</label>
          <select
            className="jam_select"
            value={autoFix ? "true" : "false"}
            onChange={(e) => setAutoFix(e.target.value === "true")}
          >
            <option value="false">❌ Non</option>
            <option value="true">✅ Oui</option>
          </select>
        </div>
      </div>

      {/* Tags */}
      <div className="jam_form_group">
        <label>🏷️ Tags</label>
        <div className="jam_tags">
          {(tags || []).map((tag, i) => (
            <span key={i} className="jam_tag">
              #{tag}
              <button type="button" className="jam_tag_remove" onClick={() => handleRemoveTag(i)}>
                ✕
              </button>
            </span>
          ))}
        </div>
        <div className="jam_tag_input">
          <input
            className="jam_input"
            type="text"
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleAddTag()}
            placeholder="Ajouter un tag..."
          />
          <button type="button" className="jam_btn jam_btn_small" onClick={handleAddTag}>
            ➕
          </button>
        </div>
      </div>

      {/* Métadonnées */}
      <div className="jam_form_group">
        <label>📦 Métadonnées</label>
        <div className="jam_metadata">
          {Object.entries(assetMetadata || {}).map(([key, val]) => (
            <div key={key} className="jam_metadata_item">
              <span className="jam_metadata_key">{key}</span>
              <span className="jam_metadata_sep">:</span>
              <span className="jam_metadata_val">{String(val)}</span>
              <button
                type="button"
                className="jam_metadata_remove"
                onClick={() => handleRemoveMetadata(key)}
              >
                ✕
              </button>
            </div>
          ))}
        </div>
        <div className="jam_metadata_input">
          <input
            className="jam_input"
            type="text"
            value={metaKeyInput}
            onChange={(e) => setMetaKeyInput(e.target.value)}
            placeholder="Clé..."
          />
          <input
            className="jam_input"
            type="text"
            value={metaValueInput}
            onChange={(e) => setMetaValueInput(e.target.value)}
            placeholder="Valeur..."
          />
          <button type="button" className="jam_btn jam_btn_small" onClick={handleAddMetadata}>
            ➕
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// COMPOSANT : HELPER PREVIEW
// ============================================================================

export function HelperInfoPreview({
  helper_info,
  desc_limit = 100,
  show_module = false,
  isSelected = false,
  onClick,
}: {
  helper_info: HelperInfo;
  desc_limit?: number;
  show_module?: boolean;
  isSelected?: boolean;
  onClick?: () => void;
}) {
  const description = helper_info.description || "Pas de description";
  const truncatedDesc =
    description.length > desc_limit ? description.slice(0, desc_limit) + "..." : description;
  const displayName = toTitleCaseWithUnderscore(helper_info.name);

  return (
    <div className={`jam_helper_preview ${isSelected ? "selected" : ""}`} onClick={onClick}>
      <div className="jam_helper_preview_header">
        <span className="jam_helper_preview_icon">🔧</span>
        <span className="jam_helper_preview_name">{displayName}</span>
      </div>
      <div className="jam_helper_preview_desc">{truncatedDesc}</div>
      {show_module && (
        <div className="jam_helper_preview_module">
          📦 {helper_info.module.split(".").pop()}
        </div>
      )}
    </div>
  );
}

// ============================================================================
// COMPOSANT : RENDER HELPER ARG (COMPLET AVEC LISTES & DICTIONNAIRES JSON)
// ============================================================================

export function RenderHelperInfoArg({
  helper_info_arg,
  onChange,
  value,
  readOnly = false,
}: {
  helper_info_arg: HelperArg;
  onChange: (val: any) => void;
  value: any;
  readOnly: boolean;
}) {
  const isRequired = helper_info_arg.default === "REQUIRED_ARG";
  const placeholder = isRequired ? "Requis" : `Défaut: ${helper_info_arg.default}`;
  const inputType = detectInputType(helper_info_arg);

  // 1. LISTE DE VALEURS
  if (inputType === "list") {
    const items = Array.isArray(value) ? value : [];
    const [input, setInput] = useState("");

    const handleAdd = () => {
      if (input.trim()) {
        const newItems = [...items, input.trim()];
        setInput("");
        onChange(newItems);
      }
    };
    const handleRemove = (index: number) => {
      const newItems = items.filter((_, i) => i !== index);
      onChange(newItems);
    };

    return (
      <div className="jam_arg_list">
        <div className="jam_arg_list_items">
          {items.length === 0 ? (
            <span className="jam_arg_empty">Aucun élément</span>
          ) : (
            items.map((item, i) => (
              <span key={i} className="jam_arg_list_item">
                {item}
                {!readOnly && (
                  <button type="button" className="jam_arg_remove" onClick={() => handleRemove(i)}>
                    ✕
                  </button>
                )}
              </span>
            ))
          )}
        </div>
        {!readOnly && (
          <div className="jam_arg_list_add">
            <input
              className="jam_input"
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAdd()}
              placeholder="Ajouter..."
            />
            <button type="button" className="jam_btn jam_btn_small" onClick={handleAdd}>
              ➕
            </button>
          </div>
        )}
      </div>
    );
  }

  // 2. DICTIONNAIRE JSON CLÉ / VALEUR
  if (inputType === "json") {
    const pairs = typeof value === "object" && !Array.isArray(value) && value !== null ? value : {};
    const [keyInput, setKeyInput] = useState("");
    const [valInput, setValInput] = useState("");

    const handleAdd = () => {
      if (keyInput.trim() && valInput.trim()) {
        const newPairs = { ...pairs, [keyInput.trim()]: valInput.trim() };
        setKeyInput("");
        setValInput("");
        onChange(newPairs);
      }
    };
    const handleRemove = (key: string) => {
      const newPairs = { ...pairs };
      delete newPairs[key];
      onChange(newPairs);
    };

    return (
      <div className="jam_arg_json">
        <div className="jam_arg_json_pairs">
          {Object.keys(pairs).length === 0 ? (
            <span className="jam_arg_empty">Aucune clé/valeur</span>
          ) : (
            Object.entries(pairs).map(([k, v]) => (
              <div key={k} className="jam_arg_json_pair">
                <span className="jam_arg_json_key">{k}</span>
                <span className="jam_arg_json_sep">:</span>
                <span className="jam_arg_json_val">{String(v)}</span>
                {!readOnly && (
                  <button type="button" className="jam_arg_remove" onClick={() => handleRemove(k)}>
                    ✕
                  </button>
                )}
              </div>
            ))
          )}
        </div>
        {!readOnly && (
          <div className="jam_arg_json_add">
            <div className="jam_arg_json_add_row">
              <input
                className="jam_input"
                type="text"
                value={keyInput}
                onChange={(e) => setKeyInput(e.target.value)}
                placeholder="Clé..."
              />
              <input
                className="jam_input"
                type="text"
                value={valInput}
                onChange={(e) => setValInput(e.target.value)}
                placeholder="Valeur..."
              />
              <button type="button" className="jam_btn jam_btn_small" onClick={handleAdd}>
                ➕
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // 3. BOOLEAN
  if (inputType === "boolean") {
    return (
      <div className="jam_arg_input">
        <select
          className="jam_select"
          value={value ? "true" : "false"}
          onChange={(e) => onChange(e.target.value === "true")}
          disabled={readOnly}
        >
          <option value="true">✅ Vrai</option>
          <option value="false">❌ Faux</option>
        </select>
      </div>
    );
  }

  // 4. URL
  if (inputType === "url") {
    return (
      <div className="jam_arg_input">
        <input
          className="jam_input"
          type="url"
          value={value || ""}
          onChange={(e) => onChange(e.target.value)}
          onBlur={(e) => {
            let val = e.target.value.trim();
            if (!val) return onChange("");
            if (!val.startsWith("http://") && !val.startsWith("https://")) val = "https://" + val;
            onChange(val);
          }}
          placeholder={placeholder}
          disabled={readOnly}
        />
      </div>
    );
  }

  // 5. NUMBER / FLOAT
  if (inputType === "number" || inputType === "float") {
    const step = inputType === "float" ? "0.1" : "1";
    return (
      <div className="jam_arg_input">
        <input
          className="jam_input"
          type="number"
          step={step}
          min={0}
          value={value !== undefined && value !== null ? value : ""}
          onChange={(e) => {
            const val = e.target.value;
            if (val === "") return onChange("");
            const num = Number(val);
            if (!isNaN(num)) onChange(num);
          }}
          placeholder={placeholder}
          disabled={readOnly}
        />
      </div>
    );
  }

  // 6. TEXT (Fallback)
  return (
    <div className="jam_arg_input">
      <input
        className="jam_input"
        type="text"
        value={value !== undefined && value !== null ? String(value) : ""}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        disabled={readOnly}
      />
    </div>
  );
}

// ============================================================================
// COMPOSANT : HELPER DETAIL (AVEC VALIDATION DES ARGUMENTS ET RECURSIVITÉ)
// ============================================================================

const MULTI_STEP_HELPERS = new Set(["multi_step_login"]);

export function HelperInfoDetail({
  helper_info,
  show_module = false,
  readOnly = false,
  helpersList = null,
  existingValues = null,
  onDeselect,
  onAddHelper,
}: {
  helper_info: HelperInfo;
  show_module?: boolean;
  readOnly: boolean;
  helpersList?: HelpersListResponse | null;
  existingValues?: Record<string, unknown> | null;
  onDeselect: () => void;
  onAddHelper: (data: { helper: HelperCall; info: HelperInfo }) => void;
}) {
  const [args, setArgs] = useState<Record<string, any> | null>(null);
  const [showMultiStepEditor, setShowMultiStepEditor] = useState<boolean>(false);

  const isMultiStepHelper = MULTI_STEP_HELPERS.has(helper_info.name);

  const nestedHelpersList: HelpersListResponse | null = useMemo(() => {
    if (!helpersList) return null;
    const filtered = helpersList.helpers.filter((h) => !MULTI_STEP_HELPERS.has(h.name));
    return { ...helpersList, helpers: filtered, total: filtered.length };
  }, [helpersList]);

  useEffect(() => {
    const initialArgs: Record<string, any> = {};
    for (const [key, arg] of Object.entries(helper_info.args)) {
      const existingValue = existingValues?.[key];
      initialArgs[key] = {
        name: key,
        value:
          existingValue !== undefined && existingValue !== null
            ? existingValue
            : arg.default !== "REQUIRED_ARG"
            ? arg.default
            : null,
        type: arg.type,
        input_type: arg.input_type,
        default: arg.default,
        isRequired: arg.default === "REQUIRED_ARG",
      };
    }
    setArgs(initialArgs);
  }, [helper_info, existingValues]);

  const handleArgChange = (arg: HelperArg) => {
    const handleChange = (value: any) => {
      setArgs((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          [arg.name]: {
            ...prev[arg.name],
            value,
          },
        };
      });
    };

    const currentValue =
      args?.[arg.name]?.value ?? (arg.default !== "REQUIRED_ARG" ? arg.default : null);

    return { func: handleChange, value: currentValue };
  };

  const canAdd = () => {
    if (args === null) return true;
    let can = true;

    Object.values(args).forEach((arg) => {
      const value = arg.value;
      if (arg.input_type === "boolean") return;

      let isEmpty: boolean;
      if (arg.input_type === "list") {
        isEmpty = !Array.isArray(value) || value.length === 0;
      } else if (arg.input_type === "json") {
        isEmpty =
          value === null ||
          value === undefined ||
          (typeof value === "object" && Object.keys(value).length === 0);
      } else {
        isEmpty = value === null || value === undefined || value === "";
      }

      if (arg.isRequired && isEmpty) {
        can = false;
      }
    });

    return can;
  };

  const handleAdd = () => {
    const kwargs: Record<string, unknown> = {};
    if (args) {
      for (const [key, arg] of Object.entries(args)) {
        kwargs[key] = arg.value;
      }
    }

    onAddHelper({
      helper: {
        name: helper_info.name,
        args: [],
        kwargs,
      },
      info: helper_info,
    });
  };

  const displayName = toTitleCaseWithUnderscore(helper_info.name);

  return (
    <div className="jam_helper_detail">
      <div className="jam_helper_detail_header">
        <div className="jam_helper_detail_title">
          <span className="jam_helper_detail_icon">🔧</span>
          <span className="jam_helper_detail_name">{displayName}</span>
          {show_module && (
            <span className="jam_helper_detail_module">
              📦 {helper_info.module.split(".").pop()}
            </span>
          )}
        </div>
        <div className="jam_helper_detail_actions">
          <button
            type="button"
            className="jam_btn jam_btn_secondary_small"
            onClick={onDeselect}
          >
            ✕ Désélectionner
          </button>
        </div>
      </div>

      <div className="jam_helper_detail_desc">
        {helper_info.description || "Pas de description"}
      </div>

      <div className="jam_helper_detail_args">
        <h5 className="jam_helper_detail_args_title">📥 Paramètres</h5>
        {Object.entries(helper_info.args).map(([key, arg]) => {
          const isStepsArg = isMultiStepHelper && key === "steps";
          const currentSteps: HelperCall[] =
            args && Array.isArray(args[key]?.value) ? args[key].value : [];
          const { func, value } = handleArgChange(arg);

          return (
            <div key={key} className="jam_helper_detail_arg">
              <div className="jam_helper_detail_arg_label">
                <span className="jam_helper_detail_arg_name">
                  {toTitleCaseWithUnderscore(arg.name)}
                </span>
                {arg.default === "REQUIRED_ARG" && <span className="jam_required">*</span>}
                <span className="jam_helper_detail_arg_type">
                  ({isStepsArg ? "séquence de helpers" : arg.type.join(" | ")})
                </span>
                {arg.default !== "REQUIRED_ARG" && (
                  <span className="jam_helper_detail_arg_default">
                    défaut: {String(arg.default)}
                  </span>
                )}
              </div>
              <div className="jam_helper_detail_arg_input">
                {isStepsArg ? (
                  <div className="jam_steps_summary">
                    {currentSteps.length === 0 ? (
                      <div className="jam_steps_summary_empty">
                        <span className="jam_steps_summary_empty_icon">🪆</span>
                        <span>Aucune étape configurée pour l'instant</span>
                      </div>
                    ) : (
                      <div className="jam_steps_summary_list">
                        {currentSteps.map((s, i) => (
                          <span key={i} className="jam_steps_summary_chip">
                            <span className="jam_steps_summary_chip_num">{i + 1}</span>
                            {toTitleCaseWithUnderscore(s.name)}
                          </span>
                        ))}
                      </div>
                    )}
                    <button
                      type="button"
                      className="jam_btn jam_btn_primary_small jam_btn_full"
                      onClick={() => setShowMultiStepEditor(true)}
                      disabled={readOnly}
                    >
                      🧩 {currentSteps.length === 0 ? "Configurer les étapes" : "Modifier les étapes"}
                    </button>
                  </div>
                ) : (
                  <RenderHelperInfoArg
                    helper_info_arg={arg}
                    onChange={func}
                    readOnly={readOnly}
                    value={value}
                  />
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="jam_helper_detail_footer">
        {!readOnly && (
          <button
            type="button"
            className="jam_btn jam_btn_primary"
            onClick={handleAdd}
            disabled={!canAdd()}
          >
            ➕ Ajouter ce helper
          </button>
        )}
        {readOnly && (
          <button
            type="button"
            className="jam_btn jam_btn_secondary_small"
            onClick={onDeselect}
          >
            ✕ Fermer
          </button>
        )}
      </div>

      {showMultiStepEditor && (
        <MultiStepEditor
          steps={args && Array.isArray(args["steps"]?.value) ? args["steps"].value : []}
          onStepsChange={(steps) => {
            if (args) {
              setArgs({
                ...args,
                steps: {
                  ...args["steps"],
                  value: steps,
                },
              });
            }
          }}
          helpersList={nestedHelpersList}
          onClose={() => setShowMultiStepEditor(false)}
        />
      )}
    </div>
  );
}

// ============================================================================
// COMPOSANT : MULTI STEP EDITOR (SÉQUENCE RÉCURSIVE DE HELPERS)
// ============================================================================

export function MultiStepEditor({
  steps,
  onStepsChange,
  helpersList,
  onClose,
}: {
  steps: HelperCall[];
  onStepsChange: (steps: HelperCall[]) => void;
  helpersList: HelpersListResponse | null;
  onClose: () => void;
}) {
  const [localSteps, setLocalSteps] = useState<HelperCall[]>(steps);
  const [showAddStep, setShowAddStep] = useState<boolean>(false);

  const handleAddStep = (step: HelperCall) => {
    setLocalSteps([...localSteps, step]);
    setShowAddStep(false);
  };

  const handleRemoveStep = (index: number) => {
    setLocalSteps(localSteps.filter((_, i) => i !== index));
  };

  const handleMoveStep = (index: number, direction: "up" | "down") => {
    const newSteps = [...localSteps];
    const target = direction === "up" ? index - 1 : index + 1;
    if (target < 0 || target >= newSteps.length) return;
    [newSteps[index], newSteps[target]] = [newSteps[target], newSteps[index]];
    setLocalSteps(newSteps);
  };

  const handleSave = () => {
    onStepsChange(localSteps);
    onClose();
  };

  return (
    <div className="jam_sub_modal_overlay" onClick={onClose}>
      <div className="jam_sub_modal_container" onClick={(e) => e.stopPropagation()}>
        <div className="jam_sub_modal_header">
          <h4>
            🧩 Configurer multi_step_login{" "}
            {localSteps.length > 0 && `(${localSteps.length} étape${localSteps.length > 1 ? "s" : ""})`}
          </h4>
          <button type="button" className="jam_modal_close" onClick={onClose}>
            ✕
          </button>
        </div>

        <div className="jam_sub_modal_body">
          <p className="jam_sub_modal_hint">
            🔗 Ce helper enchaîne d'autres helpers dans l'ordre choisi. Utilisez les flèches ↑↓ pour réordonner.
          </p>

          <div className="jam_multi_step_list">
            {localSteps.length === 0 ? (
              <div className="jam_multi_step_empty">📭 Aucun step configuré</div>
            ) : (
              localSteps.map((step, index) => (
                <div key={index} className="jam_multi_step_item">
                  <div className="jam_multi_step_number">{index + 1}</div>
                  <div className="jam_multi_step_info">
                    <span className="jam_multi_step_name">{toTitleCaseWithUnderscore(step.name)}</span>
                    {step.kwargs && Object.keys(step.kwargs).length > 0 && (
                      <span className="jam_multi_step_kwargs">
                        {Object.entries(step.kwargs)
                          .map(([k, v]) => `${k}=${String(v)}`)
                          .join(", ")}
                      </span>
                    )}
                  </div>
                  <div className="jam_multi_step_actions">
                    <button
                      type="button"
                      className="jam_btn jam_btn_small"
                      onClick={() => handleMoveStep(index, "up")}
                      disabled={index === 0}
                    >
                      ↑
                    </button>
                    <button
                      type="button"
                      className="jam_btn jam_btn_small"
                      onClick={() => handleMoveStep(index, "down")}
                      disabled={index === localSteps.length - 1}
                    >
                      ↓
                    </button>
                    <button
                      type="button"
                      className="jam_btn jam_btn_danger_small"
                      onClick={() => handleRemoveStep(index)}
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          <button
            type="button"
            className="jam_btn jam_btn_primary_small jam_btn_full"
            onClick={() => setShowAddStep(true)}
          >
            ➕ Ajouter un step
          </button>

          {showAddStep && (
            <AddStepModal
              helpersList={helpersList}
              onAdd={handleAddStep}
              onClose={() => setShowAddStep(false)}
            />
          )}
        </div>

        <div className="jam_sub_modal_footer">
          <button type="button" className="jam_btn jam_btn_secondary" onClick={onClose}>
            ↩️ Annuler
          </button>
          <button type="button" className="jam_btn jam_btn_primary" onClick={handleSave}>
            ✅ Valider les étapes
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// COMPOSANT : ADD STEP MODAL (POUR MULTI_STEP_LOGIN)
// ============================================================================

export function AddStepModal({
  helpersList,
  onAdd,
  onClose,
}: {
  helpersList: HelpersListResponse | null;
  onAdd: (step: HelperCall) => void;
  onClose: () => void;
}) {
  const [selectedHelperInfo, setSelectedHelperInfo] = useState<HelperInfo | null>(null);
  const [stepArgs, setStepArgs] = useState<Record<string, any> | null>(null);

  useEffect(() => {
    if (selectedHelperInfo) {
      const initialArgs: Record<string, any> = {};
      for (const [key, arg] of Object.entries(selectedHelperInfo.args)) {
        initialArgs[key] = {
          name: key,
          value: arg.default !== "REQUIRED_ARG" ? arg.default : null,
          type: arg.type,
          input_type: arg.input_type,
          default: arg.default,
          isRequired: arg.default === "REQUIRED_ARG",
        };
      }
      setStepArgs(initialArgs);
    } else {
      setStepArgs(null);
    }
  }, [selectedHelperInfo]);

  const handleSelectHelper = (helper: HelperInfo) => {
    setSelectedHelperInfo(helper);
  };

  const handleArgChange = (arg: HelperArg) => {
    const handleChange = (value: any) => {
      setStepArgs((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          [arg.name]: {
            ...prev[arg.name],
            value,
          },
        };
      });
    };

    const currentValue =
      stepArgs?.[arg.name]?.value ?? (arg.default !== "REQUIRED_ARG" ? arg.default : null);

    return { func: handleChange, value: currentValue };
  };

  const canAdd = () => {
    if (stepArgs === null) return true;
    let can = true;

    Object.values(stepArgs).forEach((arg) => {
      const value = arg.value;
      if (arg.input_type === "boolean") return;

      let isEmpty: boolean;
      if (arg.input_type === "list") {
        isEmpty = !Array.isArray(value) || value.length === 0;
      } else if (arg.input_type === "json") {
        isEmpty =
          value === null ||
          value === undefined ||
          (typeof value === "object" && Object.keys(value).length === 0);
      } else {
        isEmpty = value === null || value === undefined || value === "";
      }

      if (arg.isRequired && isEmpty) {
        can = false;
      }
    });

    return can;
  };

  const handleAdd = () => {
    if (!selectedHelperInfo || !canAdd()) return;

    const kwargs: Record<string, unknown> = {};
    if (stepArgs) {
      for (const [key, arg] of Object.entries(stepArgs)) {
        kwargs[key] = arg.value;
      }
    }

    onAdd({
      name: selectedHelperInfo.name,
      args: [],
      kwargs,
    });
  };

  return (
    <div className="jam_sub_sub_modal_overlay" onClick={onClose}>
      <div className="jam_sub_sub_modal_container" onClick={(e) => e.stopPropagation()}>
        <div className="jam_sub_modal_header">
          <h4>➕ Ajouter un step</h4>
          <button type="button" className="jam_modal_close" onClick={onClose}>
            ✕
          </button>
        </div>

        <div className="jam_sub_modal_body">
          <p className="jam_sub_modal_hint">Sélectionnez un helper à ajouter :</p>

          <div className="jam_multi_step_helpers_list">
            {helpersList?.helpers.map((h) => (
              <div
                key={h.name}
                className={`jam_multi_step_helper_item ${
                  selectedHelperInfo?.name === h.name ? "selected" : ""
                }`}
                onClick={() => handleSelectHelper(h)}
              >
                <HelperInfoPreview
                  helper_info={h}
                  isSelected={selectedHelperInfo?.name === h.name}
                  desc_limit={60}
                  show_module={false}
                />
              </div>
            ))}
          </div>

          {selectedHelperInfo && (
            <div className="jam_multi_step_helper_detail">
              <div className="jam_sub_modal_args">
                <p className="jam_sub_modal_hint">Paramètres :</p>
                {Object.entries(selectedHelperInfo.args).map(([key, arg]) => {
                  const { func, value } = handleArgChange(arg);
                  return (
                    <div key={key} className="jam_form_group">
                      <label>
                        {toTitleCaseWithUnderscore(arg.name)}{" "}
                        {arg.default === "REQUIRED_ARG" && <span className="jam_required">*</span>}
                        <span className="jam_helper_arg_type">({arg.type.join(" | ")})</span>
                      </label>
                      <RenderHelperInfoArg
                        helper_info_arg={arg}
                        onChange={func}
                        value={value}
                        readOnly={false}
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <div className="jam_sub_modal_footer">
          <button type="button" className="jam_btn jam_btn_secondary" onClick={onClose}>
            Annuler
          </button>
          <button
            type="button"
            className="jam_btn jam_btn_primary"
            onClick={handleAdd}
            disabled={!canAdd()}
          >
            ➕ Ajouter
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// COMPOSANT : ADD WEB ASSET (FORMULAIRE WEB AVANCÉ COMPLET)
// ============================================================================

export function AddWebAsset({
  scannerDefaultConfig,
  scannerHelperList,
  supportedScannerVulns = [],
  isSpa,
  desc_limit = 100,
  show_module = false,
  onValidate,
  naviguate,
}: {
  scannerDefaultConfig: Record<string, any>;
  scannerHelperList: HelpersListResponse;
  supportedScannerVulns?: string[];
  naviguate: (val: any) => void;
  desc_limit: number;
  show_module: boolean;
  isSpa: boolean;
  onValidate: (data: WebAssetModel) => void;
}) {
  // ── Propriétés AssetItem ──
  const [assetName, setAssetName] = useState<string | null>(null);
  const [priority, setPriority] = useState<Priority>(PriorityEnum.LOW);
  const [statut, setStatut] = useState<AssetStatus>(AssetStatutEnum.ACTIVE);
  const [tags, setTags] = useState<string[]>([]);
  const [autoFix, setAutoFix] = useState<boolean>(false);
  const [fixAllowed, setFixAllowed] = useState<boolean>(false);
  const [manageImmediatly, setManageImmediatly] = useState<boolean>(false);
  const [assetMetadata, setAssetMetadata] = useState<Record<string, any>>({});
  const [url, setUrl] = useState<string>("");
  const [codeSourceDir, setCodeSourceDir] = useState<string | null>(null);
  const [every, setEvery] = useState<number>(36000);

  // ── Helpers ──
  const [helperCalls, setHelperCalls] = useState<HelperCall[]>([]);
  const [helperCallsInfo, setHelperCallsInfo] = useState<HelperInfo[]>([]);
  const [selectedHelper, setSelectedHelper] = useState<HelperInfo | null>(null);
  const [selectedSource, setSelectedSource] = useState<"list" | "selected" | null>(null);
  const [helperSearch, setHelperSearch] = useState<string>("");

  // ── Params d'Instance ScannerIA ──
  const [semaphore, setSemaphore] = useState<number>(50);
  const [useSemantic, setUseSemantic] = useState<boolean>(true);
  const [knownParamsDir, setKnownParamsDir] = useState<string | null>(null);
  const [config, setConfig] = useState<Record<string, any> | null>(null);
  const [useDefaultConfig, setUseDefaultConfig] = useState<boolean>(true);
  const [activeScan, setActiveScan] = useState<boolean>(true);
  const [limitPayloadEnabled, setLimitPayloadEnabled] = useState<boolean>(false);
  const [limitPayload, setLimitPayload] = useState<number | null>(null);
  const [arjunTimeout, setArjunTimeout] = useState<number>(30);

  // ── Params de Lancement ScannerIA ──
  const [fetch, setFetch] = useState<boolean>(true);
  const [filename, setFilename] = useState<string | null>(null);
  const [vulnTargetMode, setVulnTargetMode] = useState<"all" | "limit" | "custom">("all");
  const [limitVulnNumber, setLimitVulnNumber] = useState<number>(5);
  const [selectedVulns, setSelectedVulns] = useState<string[]>([]);
  const [maxTest, setMaxTest] = useState<number | null>(null);
  const [timeBetweenForFuzzer, setTimeBetweenForFuzzer] = useState<number>(0.001);
  const [dynamicTimeoutForFuzzer, setDynamicTimeoutForFuzzer] = useState<boolean>(true);
  const [allowedDomains, setAllowedDomains] = useState<string[]>([
    "http://127.0.0.1",
    "http://localhost",
  ]);
  const [threshold, setThreshold] = useState<number>(0.5);
  const [raiseOnHelperError, setRaiseOnHelperError] = useState<boolean>(true);
  const [domainInput, setDomainInput] = useState<string>("");
  const [useCache, setUsecache] = useState<boolean>(false);
  const [putResultInCache, setPutResultInCache] = useState<boolean>(true);

  const filteredHelpers =
    scannerHelperList?.helpers.filter((h) =>
      h.name.toLowerCase().includes(helperSearch.toLowerCase())
    ) || [];

  // Helpers
  const handleAddHelper = (data: { helper: HelperCall; info: HelperInfo }) => {
    setHelperCalls([...helperCalls, data.helper]);
    setHelperCallsInfo([...helperCallsInfo, data.info]);
    setSelectedHelper(null);
    setSelectedSource(null);
  };

  const handleRemoveHelper = (index: number) => {
    setHelperCalls(helperCalls.filter((_, i) => i !== index));
    setHelperCallsInfo(helperCallsInfo.filter((_, i) => i !== index));
  };

  const handleSelectHelper = (source: "list" | "selected", data: HelperInfo) => {
    setSelectedHelper(data);
    setSelectedSource(source);
  };

  // Domaines
  const handleAddDomain = () => {
    if (domainInput.trim() && !allowedDomains.includes(domainInput.trim())) {
      setAllowedDomains([...allowedDomains, domainInput.trim()]);
      setDomainInput("");
    }
  };

  const handleRemoveDomain = (index: number) => {
    setAllowedDomains(allowedDomains.filter((_, i) => i !== index));
  };

  // Vulns fuzzer
  const toggleVulnSelection = (vuln: string) => {
    setSelectedVulns((prev) =>
      prev.includes(vuln) ? prev.filter((v) => v !== vuln) : [...prev, vuln]
    );
  };

  const validatePath = async (path: string) => {
    if (!path) return setCodeSourceDir(null);
    const exists = await checkPathExits(path, naviguate);
    if (!exists) {
      setCodeSourceDir(null);
      toast.error("❌ Chemin du code source invalide");
    }
  };

  const validateKnownParamsDir = async (path: string) => {
    if (!path) return setKnownParamsDir(null);
    const result = await validateScannerKnowParamDir(path, naviguate);
    if (!result?.can) {
      setKnownParamsDir(null);
      toast.error(`❌ ${result?.reason}`);
    }
  };

  const createData = () => {
    if (!url.trim()) {
      toast.error("❌ L'URL cible est obligatoire.");
      return;
    }

    let limitVulnParam: number | string[] | null = null;
    if (vulnTargetMode === "limit") {
      limitVulnParam = limitVulnNumber;
    } else if (vulnTargetMode === "custom") {
      limitVulnParam = selectedVulns.length > 0 ? selectedVulns : null;
    }

    const scanInstanceArgs: ScanInstanceArgs = {
      config_path: null,
      active_scan: activeScan,
      use_cache: false,
      restore: false,
      debug: false,
      semaphore,
      limit_payloads: limitPayloadEnabled ? limitPayload : null,
      use_semantic: useSemantic,
      headers_sev_map: null,
      theme: null,
      use_arjun: false,
      arjun_timeout: arjunTimeout,
      known_params_dir: knownParamsDir,
      conf_content: JSON.stringify(config || structuredClone(scannerDefaultConfig)),
    };

    const scanArgs: ScanArgs = {
      url: url.trim(),
      fetch,
      use_cache: useCache,
      put_result_in_cache: putResultInCache,
      filename: filename || null,
      limit_vuln_for_fuzzer: limitVulnParam,
      time_between_for_fuzzer: timeBetweenForFuzzer,
      dynamic_timeout_for_fuzzer: dynamicTimeoutForFuzzer,
      allowed_domains: allowedDomains,
      threshold,
      helpers: helperCalls,
      raise_on_helper_error: raiseOnHelperError,
      is_spa: isSpa,
      max_test: maxTest,
    };

    const data: WebAssetModel = {
      type: isSpa ? "web_app" : "web_site",
      status: statut,
      priority,
      scan_args: scanArgs,
      scan_instance_args: scanInstanceArgs,
      fix_allowed: fixAllowed,
      auto_fix: autoFix,
      every,
      source_code_dir: codeSourceDir,
      name: assetName?.trim() || url.replace(/^https?:\/\//, "").split("/")[0],
      tags,
      metadata_: assetMetadata || null,
      manage_immediatly: manageImmediatly,
      url: url.trim(),
    };

    onValidate(data);
  };

  return (
    <div className="jam_web_form">
      {/* Base Asset */}
      <BaseAsset
        assetName={assetName}
        setAssetName={setAssetName}
        priority={priority}
        setPriority={setPriority}
        statut={statut}
        setStatut={setStatut}
        tags={tags}
        setTags={setTags}
        autoFix={autoFix}
        setAutoFix={setAutoFix}
        assetMetadata={assetMetadata}
        setAssetMetadata={setAssetMetadata}
      />

      {/* URL & Source */}
      <div className="jam_form_section">
        <h4 className="jam_section_title">🔗 Cible & Code Source</h4>
        <div className="jam_form_group">
          <label>
            URL <span className="jam_required">*</span>
          </label>
          <input
            className="jam_input"
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onBlur={(e) => {
              const v = e.target.value.trim();
              if (v && !v.startsWith("http://") && !v.startsWith("https://")) setUrl("https://" + v);
            }}
            placeholder="https://example.com"
            required
          />
        </div>

        <div className="jam_form_group">
          <label>📂 Code source (optionnel)</label>
          <input
            className="jam_input"
            type="text"
            value={codeSourceDir || ""}
            onChange={(e) => setCodeSourceDir(e.target.value)}
            onBlur={(e) => validatePath(e.target.value)}
            placeholder="/chemin/vers/code"
          />
        </div>

        <div className="jam_form_row">
          <div className="jam_form_group">
            <label>🧩 SPA</label>
            <select className="jam_select" value={isSpa ? "true" : "false"} disabled>
              <option value="true">✅ Oui</option>
              <option value="false">❌ Non</option>
            </select>
          </div>

          <div className="jam_form_group">
            <label>🔧 Fix autorisé</label>
            <select
              className="jam_select"
              value={fixAllowed ? "true" : "false"}
              onChange={(e) => setFixAllowed(e.target.value === "true")}
            >
              <option value="false">❌ Non</option>
              <option value="true">✅ Oui</option>
            </select>
          </div>
        </div>

        <div className="jam_form_row">
          <div className="jam_form_group">
            <label>⏱️ Période</label>
            <div className="jam_form_row">
              <input
                className="jam_input"
                type="number"
                min={1}
                value={every}
                onChange={(e) => {
                  const val = e.target.value;
                  if (!val) return setEvery(36000);
                  const parsed = parseFloat(val);
                  setEvery(isNaN(parsed) || parsed < 0 ? 36000 : parsed);
                }}
              />
              <span className="jam_unit_label">
                {every >= 86400
                  ? `${Math.round(every / 86400)} jour(s)`
                  : every >= 3600
                  ? `${Math.round(every / 3600)} heure(s)`
                  : every >= 60
                  ? `${Math.round(every / 60)} minute(s)`
                  : `${every} s`}
              </span>
            </div>
          </div>

          <div className="jam_form_group">
            <label>🚀 Gérer immédiatement</label>
            <select
              className="jam_select"
              value={manageImmediatly ? "true" : "false"}
              onChange={(e) => setManageImmediatly(e.target.value === "true")}
            >
              <option value="true">✅ Oui</option>
              <option value="false">❌ Non (queue)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Helpers avec barre de recherche */}
      <div className="jam_form_section">
        <h4 className="jam_section_title">🔧 Helpers d'authentification</h4>
        <div className="jam_helpers_layout">
          <div className="jam_helpers_list">
            <div className="jam_helpers_list_header">
              <h5>📋 Disponibles ({filteredHelpers.length})</h5>
              <div className="jam_helpers_search">
                <input
                  className="jam_input jam_input_small"
                  type="text"
                  value={helperSearch}
                  onChange={(e) => setHelperSearch(e.target.value)}
                  placeholder="🔍 Chercher..."
                  disabled={!scannerHelperList}
                />
              </div>
            </div>

            {filteredHelpers.length === 0 ? (
              <div className="jam_helpers_empty">
                {helperSearch ? "😕 Aucun helper trouvé" : "Aucun helper disponible"}
              </div>
            ) : (
              filteredHelpers.map((h, i) => (
                <HelperInfoPreview
                  key={i}
                  helper_info={h}
                  isSelected={selectedHelper?.name === h.name && selectedSource === "list"}
                  onClick={() => handleSelectHelper("list", h)}
                  desc_limit={desc_limit}
                  show_module={show_module}
                />
              ))
            )}
          </div>

          <div className="jam_helpers_detail">
            {selectedHelper ? (
              <HelperInfoDetail
                helper_info={selectedHelper}
                show_module={show_module}
                readOnly={selectedSource === "selected"}
                helpersList={scannerHelperList}
                onDeselect={() => {
                  setSelectedHelper(null);
                  setSelectedSource(null);
                }}
                onAddHelper={handleAddHelper}
                existingValues={
                  selectedSource === "list"
                    ? null
                    : helperCalls.find((h) => h.name === selectedHelper.name)?.kwargs
                }
              />
            ) : (
              <div className="jam_helpers_empty">👈 Sélectionnez un helper</div>
            )}
          </div>

          <div className="jam_helpers_selected">
            <h5>✅ Sélectionnés ({helperCalls.length})</h5>
            {helperCalls.length === 0 ? (
              <div className="jam_helpers_empty">Aucun helper</div>
            ) : (
              helperCallsInfo.map((h, i) => (
                <div key={i} className="jam_helper_selected_item">
                  <HelperInfoPreview
                    helper_info={h}
                    isSelected={selectedHelper?.name === h.name && selectedSource === "selected"}
                    onClick={() => handleSelectHelper("selected", h)}
                    desc_limit={desc_limit}
                    show_module={show_module}
                  />
                  <button
                    type="button"
                    className="jam_btn jam_btn_danger_small"
                    onClick={() => handleRemoveHelper(i)}
                    title="Retirer"
                  >
                    🗑️
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Scan Instance Args */}
      <div className="jam_form_section">
        <h4 className="jam_section_title">⚙️ Configuration du scanner</h4>
        <div className="jam_form_row">
          <div className="jam_form_group">
            <label>📊 Sémaphore (concurrence)</label>
            <input
              className="jam_input"
              type="number"
              min={1}
              max={200}
              value={semaphore}
              onChange={(e) => setSemaphore(Math.min(200, Math.max(1, Number(e.target.value) || 50)))}
            />
          </div>
          <div className="jam_form_group">
            <label>🧠 Sémantique</label>
            <select
              className="jam_select"
              value={useSemantic ? "true" : "false"}
              onChange={(e) => setUseSemantic(e.target.value === "true")}
            >
              <option value="true">✅ Oui</option>
              <option value="false">❌ Non</option>
            </select>
          </div>
        </div>

        <div className="jam_form_group">
          <label>📁 Paramètres connus</label>
          <input
            className="jam_input"
            type="text"
            value={knownParamsDir || ""}
            onChange={(e) => setKnownParamsDir(e.target.value)}
            onBlur={(e) => validateKnownParamsDir(e.target.value)}
            placeholder="/path/to/known_params"
          />
        </div>

        <div className="jam_form_row">
          <div className="jam_form_group">
            <label>🎯 Scan actif</label>
            <select
              className="jam_select"
              value={activeScan ? "true" : "false"}
              onChange={(e) => setActiveScan(e.target.value === "true")}
            >
              <option value="true">✅ Oui</option>
              <option value="false">❌ Non</option>
            </select>
          </div>
          <div className="jam_form_group">
            <label>⏱️ Arjun timeout</label>
            <input
              className="jam_input"
              type="number"
              min={5}
              max={120}
              value={arjunTimeout}
              onChange={(e) => setArjunTimeout(Number(e.target.value) || 30)}
            />
          </div>
        </div>

        {activeScan && (
          <div className="jam_form_group">
            <label>📦 Limite de payloads</label>
            <div className="jam_form_row">
              <select
                className="jam_select"
                value={limitPayloadEnabled ? "true" : "false"}
                onChange={(e) => setLimitPayloadEnabled(e.target.value === "true")}
              >
                <option value="false">Tous</option>
                <option value="true">Limité</option>
              </select>
              {limitPayloadEnabled && (
                <input
                  className="jam_input"
                  type="number"
                  min={1}
                  max={10000}
                  value={limitPayload || 1}
                  onChange={(e) => setLimitPayload(Number(e.target.value) || 1)}
                />
              )}
            </div>
          </div>
        )}

        <div className="jam_form_group">
          <label>📄 Configuration personnalisée</label>
          <select
            className="jam_select"
            value={useDefaultConfig ? "true" : "false"}
            onChange={(e) => setUseDefaultConfig(e.target.value === "true")}
          >
            <option value="true">📄 Défaut</option>
            <option value="false">✏️ Personnalisée</option>
          </select>
        </div>

        {!useDefaultConfig && scannerDefaultConfig && (
          <div className="jam_config_editor">
            <JsonEditor
              json={structuredClone(scannerDefaultConfig)}
              onSave={setConfig}
              readOnly={false}
              saveLabel="💾 Enregistrer"
              _forceCollapseState={false}
            />
          </div>
        )}
      </div>

      {/* Scan Args & Fuzzer */}
      <div className="jam_form_section">
        <h4 className="jam_section_title">🚀 Paramètres de scan</h4>
        <div className="jam_form_row">
          <div className="jam_form_group">
            <label>📥 Fetch JS</label>
            <select
              className="jam_select"
              value={fetch ? "true" : "false"}
              onChange={(e) => setFetch(e.target.value === "true")}
            >
              <option value="true">✅ Oui</option>
              <option value="false">❌ Non</option>
            </select>
          </div>
          <div className="jam_form_group">
            <label>📄 Fichier rapport</label>
            <input
              className="jam_input"
              type="text"
              value={filename || ""}
              onChange={(e) => setFilename(e.target.value || null)}
              placeholder="null"
            />
          </div>
        </div>

        {/* Ciblage Fuzzer */}
        <div className="jam_form_group">
          <label>🎯 Ciblage des vulnérabilités (Fuzzer)</label>
          <div className="jam_vulns_wrapper">
            <div className="jam_vulns_toggle">
              <button
                type="button"
                className={`jam_vulns_btn ${vulnTargetMode === "all" ? "active" : ""}`}
                onClick={() => setVulnTargetMode("all")}
              >
                Toutes ({supportedScannerVulns.length})
              </button>
              <button
                type="button"
                className={`jam_vulns_btn ${vulnTargetMode === "limit" ? "active" : ""}`}
                onClick={() => setVulnTargetMode("limit")}
              >
                🔢 Limiter en nombre
              </button>
              <button
                type="button"
                className={`jam_vulns_btn ${vulnTargetMode === "custom" ? "active" : ""}`}
                onClick={() => setVulnTargetMode("custom")}
              >
                📋 Sélection manuelle ({selectedVulns.length})
              </button>
            </div>

            {vulnTargetMode === "limit" && (
              <div className="jam_vulns_limit_row">
                <label className="jam_sub_label">Nombre max :</label>
                <input
                  type="number"
                  min={1}
                  max={supportedScannerVulns.length || 30}
                  className="jam_input jam_input_num_sm"
                  value={limitVulnNumber}
                  onChange={(e) => setLimitVulnNumber(Math.max(1, Number(e.target.value) || 1))}
                />
              </div>
            )}

            {vulnTargetMode === "custom" && (
              <div>
                <div className="jam_vulns_actions_row">
                  <span className="jam_sub_hint">Cliquez pour activer/désactiver</span>
                  <div className="jam_vulns_actions_btns">
                    <button
                      type="button"
                      className="jam_btn_secondary_small"
                      onClick={() => setSelectedVulns([...supportedScannerVulns])}
                    >
                      Tout cocher
                    </button>
                    <button
                      type="button"
                      className="jam_btn_secondary_small"
                      onClick={() => setSelectedVulns([])}
                    >
                      Tout décocher
                    </button>
                  </div>
                </div>

                <div className="jam_vulns_grid">
                  {supportedScannerVulns.map((vuln) => {
                    const isSelected = selectedVulns.includes(vuln);
                    return (
                      <button
                        key={vuln}
                        type="button"
                        className={`jam_vuln_chip ${isSelected ? "active" : ""}`}
                        onClick={() => toggleVulnSelection(vuln)}
                      >
                        {toTitleCaseWithUnderscore(vuln)}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Max Test */}
        <div className="jam_form_group">
          <label>🛑 Plafond global de requêtes (Max Test Fuzzer)</label>
          <input
            className="jam_input"
            type="number"
            min={1}
            value={maxTest ?? ""}
            onChange={(e) => {
              const val = e.target.value;
              if (!val) return setMaxTest(null);
              const num = Number(val);
              setMaxTest(!isNaN(num) && num > 0 ? num : null);
            }}
            placeholder="Illimité (défaut: null)"
          />
        </div>

        <div className="jam_form_row">
          <div className="jam_form_group">
            <label>⏱️ Timeout dynamique</label>
            <select
              className="jam_select"
              value={dynamicTimeoutForFuzzer ? "true" : "false"}
              onChange={(e) => setDynamicTimeoutForFuzzer(e.target.value === "true")}
            >
              <option value="true">✅ Oui</option>
              <option value="false">❌ Non</option>
            </select>
          </div>
        </div>

        {dynamicTimeoutForFuzzer && (
          <div className="jam_form_group">
            <label>⏱️ Temps entre requêtes (0-1s)</label>
            <input
              className="jam_input"
              type="number"
              step={0.001}
              min={0}
              max={1}
              value={timeBetweenForFuzzer}
              onChange={(e) =>
                setTimeBetweenForFuzzer(Math.min(1, Math.max(0, Number(e.target.value) || 0)))
              }
            />
          </div>
        )}

        <div className="jam_form_group">
          <label>🌐 Domaines autorisés</label>
          <div className="jam_tags">
            {allowedDomains.map((d, i) => (
              <span key={i} className="jam_tag">
                {d}
                <button type="button" className="jam_tag_remove" onClick={() => handleRemoveDomain(i)}>
                  ✕
                </button>
              </span>
            ))}
          </div>
          <div className="jam_tag_input">
            <input
              className="jam_input"
              type="text"
              value={domainInput}
              onChange={(e) => setDomainInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddDomain()}
              placeholder="Ajouter un domaine..."
            />
            <button type="button" className="jam_btn jam_btn_small" onClick={handleAddDomain}>
              ➕
            </button>
          </div>
        </div>

        <div className="jam_form_row">
          <div className="jam_form_group">
            <label>🎯 Seuil IA (0-1)</label>
            <input
              className="jam_input"
              type="number"
              step={0.01}
              min={0}
              max={1}
              value={threshold}
              onChange={(e) => setThreshold(Math.min(1, Math.max(0, Number(e.target.value) || 0)))}
            />
          </div>
          <div className="jam_form_group">
            <label>⚠️ Lever erreur helper</label>
            <select
              className="jam_select"
              value={raiseOnHelperError ? "true" : "false"}
              onChange={(e) => setRaiseOnHelperError(e.target.value === "true")}
            >
              <option value="true">✅ Oui</option>
              <option value="false">❌ Non</option>
            </select>
          </div>
        </div>
      </div>

      <div className="jam_form_footer">
        <button type="button" className="jam_btn jam_btn_primary" onClick={createData}>
          ✅ Valider la configuration
        </button>
      </div>
    </div>
  );
}

// ============================================================================
// COMPOSANT : ADD NETWORK ASSET
// ============================================================================

export function AddNetworkAsset({
  idsIpsDefaultConfig,
  onValidate,
}: {
  idsIpsDefaultConfig: Record<string, any>;
  desc_limit?: number;
  show_module?: boolean;
  onValidate: (data: NetworkAssetModel) => void;
  naviguate: (val: any) => void;
}) {
  const [assetName, setAssetName] = useState<string | null>(null);
  const [priority, setPriority] = useState<Priority>(PriorityEnum.LOW);
  const [statut, setStatut] = useState<AssetStatus>(AssetStatutEnum.ACTIVE);
  const [tags, setTags] = useState<string[]>([]);
  const [autoFix, setAutoFix] = useState<boolean>(false);
  const [manageImmediatly, setManageImmediatly] = useState<boolean>(true);
  const [assetMetadata, setAssetMetadata] = useState<Record<string, any>>({});
  const [config, setConfig] = useState<Record<string, any> | null>(null);
  const [useDefaultConfig, setUseDefaultConfig] = useState<boolean>(true);
  const [deploymentMode, setDeploymentMode] = useState<NetworkDeploymentMode>(
    NetworkDeploymentModeEnum.GATEWAY
  );

  const createData = () => {
    const data: NetworkAssetModel = {
      type: "network",
      status: statut,
      priority,
      every: 0,
      run_every: false,
      name: assetName?.trim() || `Sonde Réseau (${deploymentMode})`,
      tags,
      metadata_: assetMetadata || null,
      manage_immediatly: manageImmediatly,
      deployment_mode: deploymentMode,
      conf_content: JSON.stringify(config || structuredClone(idsIpsDefaultConfig)),
    };
    onValidate(data);
  };

  return (
    <div className="jam_network_form">
      <BaseAsset
        assetName={assetName}
        setAssetName={setAssetName}
        priority={priority}
        setPriority={setPriority}
        statut={statut}
        setStatut={setStatut}
        tags={tags}
        setTags={setTags}
        autoFix={autoFix}
        setAutoFix={setAutoFix}
        assetMetadata={assetMetadata}
        setAssetMetadata={setAssetMetadata}
      />

      <div className="jam_form_section">
        <h4 className="jam_section_title">🛰️ Déploiement Réseau</h4>
        <div className="jam_form_group">
          <label>
            Mode de déploiement <span className="jam_required">*</span>
          </label>
          <select
            className="jam_select"
            value={deploymentMode}
            onChange={(e) => setDeploymentMode(e.target.value as NetworkDeploymentMode)}
          >
            {Object.entries(NetworkDeploymentModeMapping).map(([key, value]) => (
              <option key={key} value={key}>
                {value}
              </option>
            ))}
          </select>
        </div>

        <div className="jam_form_group">
          <label>🚀 Gérer immédiatement</label>
          <select
            className="jam_select"
            value={manageImmediatly ? "true" : "false"}
            onChange={(e) => setManageImmediatly(e.target.value === "true")}
          >
            <option value="true">✅ Oui</option>
            <option value="false">❌ Non (queue)</option>
          </select>
        </div>
      </div>

      <div className="jam_form_section">
        <h4 className="jam_section_title">⚙️ Configuration IDS/IPS</h4>
        <div className="jam_form_group">
          <label>📄 Configuration</label>
          <select
            className="jam_select"
            value={useDefaultConfig ? "true" : "false"}
            onChange={(e) => setUseDefaultConfig(e.target.value === "true")}
          >
            <option value="true">📄 Défaut</option>
            <option value="false">✏️ Personnalisée</option>
          </select>
        </div>

        {!useDefaultConfig && idsIpsDefaultConfig && (
          <div className="jam_config_editor">
            <JsonEditor
              json={structuredClone(idsIpsDefaultConfig)}
              onSave={setConfig}
              readOnly={false}
              saveLabel="💾 Enregistrer"
              _forceCollapseState={false}
            />
          </div>
        )}
      </div>

      <div className="jam_form_footer">
        <button type="button" className="jam_btn jam_btn_primary" onClick={createData}>
          ✅ Valider la configuration
        </button>
      </div>
    </div>
  );
}

// ============================================================================
// COMPOSANT : ADD SERVER ASSET
// ============================================================================

export function AddServerAsset({
  onValidate,
}: {
  onValidate: (data: ServerAssetModel) => void;
}) {
  const [assetName, setAssetName] = useState<string | null>(null);
  const [priority, setPriority] = useState<Priority>(PriorityEnum.LOW);
  const [statut, setStatut] = useState<AssetStatus>(AssetStatutEnum.ACTIVE);
  const [tags, setTags] = useState<string[]>([]);
  const [autoFix, setAutoFix] = useState<boolean>(false);
  const [assetMetadata, setAssetMetadata] = useState<Record<string, any>>({});

  const createData = () => {
    const data: ServerAssetModel = {
      type: "server",
      status: statut,
      priority,
      name: assetName?.trim() || "Nouveau Serveur Distant",
      tags,
      metadata_: assetMetadata || {},
      auto_fix: autoFix,
      every: 0,
      run_every: false,
      agent_status: "pending_install",
      capabilities: [],
      installed_modules: [],
      system_info: {},
      allowed_tools: [],
    };
    onValidate(data);
  };

  return (
    <div className="jam_network_form">
      <BaseAsset
        assetName={assetName}
        setAssetName={setAssetName}
        priority={priority}
        setPriority={setPriority}
        statut={statut}
        setStatut={setStatut}
        tags={tags}
        setTags={setTags}
        autoFix={autoFix}
        setAutoFix={setAutoFix}
        assetMetadata={assetMetadata}
        setAssetMetadata={setAssetMetadata}
      />

      <div className="jam_form_section">
        <h4 className="jam_section_title">🖥️ Déploiement de l'Agent Serveur</h4>
        <div className="modal-info-box">
          <p>
            💡 <strong>Comment ça fonctionne ?</strong>
          </p>
          <ol>
            <li>À l'étape suivante, un <strong>token d'installation sécurisé (1 heure)</strong> sera généré.</li>
            <li>Une commande <code>curl | bash</code> prête à l'emploi vous sera fournie pour installer l'agent en root.</li>
            <li>L'agent s'enregistrera automatiquement et ouvrira son canal WebSocket sécurisé.</li>
          </ol>
        </div>
      </div>

      <div className="jam_form_footer">
        <button type="button" className="jam_btn jam_btn_primary" onClick={createData}>
          ✅ Valider et générer la commande d'installation
        </button>
      </div>
    </div>
  );
}