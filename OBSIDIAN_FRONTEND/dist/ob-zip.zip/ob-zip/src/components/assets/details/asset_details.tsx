import React, { useState, useEffect } from "react";
import {
  Asset,
  AssetStatusMapping,
  AssetTypeMapping,
  PRIORITY_MAPPING,
  Priority,
  AssetStatus,
  WebAsset,
  NetworkAsset,
  ServerAsset,
} from "@/types/assets/types";
import { assetTypeIcon, statusDotClass } from "../assets/utils";
import { WebAssetView } from "./web_asset_view";
import { NetworkAssetView } from "./network_asset_view";
import { ServerAssetView } from "./server_asset_view";
import { ConfirmModal } from "@/components/utils/confirm_modal/confirm_modal";
import JsonEditor from "@/components/utils/json_editor/json_editor";
import JSON5 from "json5";
import {
  Pause,
  Play,
  Trash2,
  X,
  Layers,
  FileCode,
  FolderOpen,
  Calendar,
  Clock,
  Edit3,
  RotateCcw,
  Save,
  Plus,
  Copy,
  Check,
} from "lucide-react";
import toast from "react-hot-toast";
import "./asset_details.css";

interface AssetDetailProps {
  asset: Asset | null;
  onPause: (id: string) => void;
  onResume: (id: string) => void;
  onDelete: (id: string) => void;
  onDeselect: () => void;
  onUpdateAsset?: (
    assetId: string,
    attrs: Record<string, any>,
    restartWorkflow?: boolean
  ) => Promise<boolean>;
  onRefresh?: () => void;
  isActionLoading: (id: string) => boolean;
}

type TabType = "overview" | "raw_json";

export function AssetDetail({
  asset,
  onPause,
  onResume,
  onDelete,
  onDeselect,
  onUpdateAsset,
  onRefresh,
  isActionLoading,
}: AssetDetailProps) {
  const [activeTab, setActiveTab] = useState<TabType>("overview");
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [showDeleteModal, setShowDeleteModal] = useState<boolean>(false);
  const [saving, setSaving] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<boolean>(false);

  // ── Formulaire d'Édition : Champs Communs AssetItem ──
  const [editName, setEditName] = useState<string>("");
  const [editPriority, setEditPriority] = useState<Priority>(1);
  const [editStatus, setEditStatus] = useState<AssetStatus>("active");
  const [editTags, setEditTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState<string>("");
  const [editRestartWorkflow, setEditRestartWorkflow] = useState<boolean>(false);

  // ── Champs Spécifiques portés par chaque View ──
  const [viewEditAttrs, setViewEditAttrs] = useState<Record<string, any>>({});

  const assetId = asset?.id || "";
  const isLoading = isActionLoading(assetId);
  const isServer = asset?.type === "server";

  // Helper pour parser JSON/JSON5 de manière sécurisée
  const parseData = (raw: any) => {
    if (typeof raw !== "string") return raw || {};
    try {
      return JSON.parse(raw);
    } catch {
      try {
        return JSON5.parse(raw);
      } catch {
        return { content: raw };
      }
    }
  };

  // Réinitialisation du mode édition quand l'actif change
  useEffect(() => {
    setIsEditing(false);
    setViewEditAttrs({});
  }, [assetId]);

  if (!asset) {
    return (
      <div className="asset-detail-empty">
        <FolderOpen size={36} className="asset-detail-empty__icon" />
        <h3 className="asset-detail-empty__title">Aucun actif sélectionné</h3>
        <p className="asset-detail-empty__desc">
          Sélectionnez un actif dans la liste pour afficher ses détails, sa configuration et ses actions.
        </p>
      </div>
    );
  }

  // Copier l'ID
  const handleCopyId = async () => {
    await navigator.clipboard.writeText(assetId);
    setCopiedId(true);
    toast.success("Identifiant copié !");
    setTimeout(() => setCopiedId(false), 2000);
  };

  // Basculer en mode édition
  const startEditing = () => {
    setEditName(asset.name || "");
    setEditPriority(asset.priority);
    setEditStatus(asset.status);
    setEditTags([...(asset.tags || [])]);
    setEditRestartWorkflow(false);
    setViewEditAttrs({});
    setIsEditing(true);
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !editTags.includes(tagInput.trim())) {
      setEditTags([...editTags, tagInput.trim()]);
      setTagInput("");
    }
  };

  const handleRemoveTag = (index: number) => {
    setEditTags(editTags.filter((_, i) => i !== index));
  };

  // Sauvegarde globale (Champs communs + Champs spécifiques de la View)
  const handleSave = async () => {
    if (!assetId || !onUpdateAsset) return;
    setSaving(true);

    const finalAttrs: Record<string, any> = {
      name: editName,
      priority: editPriority,
      status: editStatus,
      tags: editTags,
      ...viewEditAttrs,
    };

    const ok = await onUpdateAsset(assetId, finalAttrs, editRestartWorkflow);
    setSaving(false);

    if (ok) {
      setIsEditing(false);
      toast.success("✅ Actif mis à jour avec succès !");
      if (onRefresh) onRefresh();
    }
  };

  return (
    <div className="asset-detail-card">
      {/* ── 1. HEADER DU DÉTAIL ── */}
      <div className="asset-detail-header">
        <div className="asset-detail-header__main">
          <span className="asset-detail-header__icon">{assetTypeIcon[asset.type]}</span>
          <div className="asset-detail-header__info">
            <div className="asset-detail-header__title-row">
              <h2 className="asset-detail-header__title">{asset.name || "Actif sans nom"}</h2>
              <div className="asset-detail-id-badge">
                <span className="oh-mono">{asset.id}</span>
                <button
                  type="button"
                  className="asset-detail-copy-btn"
                  onClick={handleCopyId}
                  title="Copier l'identifiant complet"
                >
                  {copiedId ? <Check size={12} /> : <Copy size={12} />}
                </button>
              </div>
            </div>
            <div className="asset-detail-header__meta-row">
              <span className="oh-badge oh-badge--accent">{AssetTypeMapping[asset.type]}</span>
              <span className="asset-detail-header__status">
                <span className={`status_dot ${statusDotClass[asset.status]}`} />
                {AssetStatusMapping[asset.status]}
              </span>
              <span className="asset-detail-header__priority">
                Priorité : {PRIORITY_MAPPING[asset.priority]}
              </span>
            </div>
          </div>
        </div>

        {/* Boutons d'Action Header (Édition en haut à droite) */}
        <div className="asset-detail-header__actions">
          {!isEditing ? (
            <button
              type="button"
              className="oh-btn oh-btn--ghost asset-detail-btn"
              onClick={startEditing}
              title="Modifier les attributs de cet actif"
            >
              <Edit3 size={13} /> Éditer
            </button>
          ) : (
            <button
              type="button"
              className="oh-btn oh-btn--ghost asset-detail-btn"
              onClick={() => setIsEditing(false)}
            >
              <RotateCcw size={13} /> Annuler
            </button>
          )}

          <button
            type="button"
            className="oh-btn oh-btn--ghost asset-detail-btn"
            onClick={onDeselect}
            title="Fermer le panneau"
          >
            <X size={14} />
          </button>
        </div>
      </div>

      {/* ── 2. ONGLETS DE NAVIGATION ── */}
      <div className="asset-detail-tabs">
        <button
          type="button"
          className={`asset-detail-tab ${activeTab === "overview" ? "active" : ""}`}
          onClick={() => setActiveTab("overview")}
        >
          <Layers size={14} /> Vue d'ensemble
        </button>
        <button
          type="button"
          className={`asset-detail-tab ${activeTab === "raw_json" ? "active" : ""}`}
          onClick={() => setActiveTab("raw_json")}
        >
          <FileCode size={14} /> Format brut
        </button>
      </div>

      {/* ── 3. CORPS DU DÉTAIL ── */}
      <div className="asset-detail-body">
        {activeTab === "overview" ? (
          isEditing ? (
            /* ── FORMULAIRE D'ÉDITION INLINE ── */
            <div className="asset-edit-form">
              {/* 3.1 Champs Communs AssetItem */}
              <div className="asset_detail_row">
                <span className="asset_detail_label">📛 Nom de l'actif</span>
                <input
                  type="text"
                  className="asset-edit-input"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  placeholder="Ex : Site Vitrine, Serveur Prod-01..."
                />
              </div>

              <div className="asset_detail_row">
                <span className="asset_detail_label">🔺 Priorité</span>
                <select
                  className="asset-edit-select"
                  value={editPriority}
                  onChange={(e) => setEditPriority(Number(e.target.value) as Priority)}
                >
                  {Object.entries(PRIORITY_MAPPING).map(([k, v]) => (
                    <option key={k} value={k}>{v} ({k})</option>
                  ))}
                </select>
              </div>

              <div className="asset_detail_row">
                <span className="asset_detail_label">📶 Statut</span>
                <select
                  className="asset-edit-select"
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value as AssetStatus)}
                >
                  {Object.entries(AssetStatusMapping).map(([k, v]) => (
                    <option key={k} value={k}>{v}</option>
                  ))}
                </select>
              </div>

              {/* Tags en mode édition */}
              <div className="asset-edit-tags-block">
                <span className="asset_detail_label">🏷️ Tags</span>
                <div className="asset-edit-tags-list">
                  {editTags.map((tag, idx) => (
                    <span key={idx} className="filter-tag-pill">
                      #{tag}
                      <button type="button" onClick={() => handleRemoveTag(idx)}>✕</button>
                    </span>
                  ))}
                </div>
                <div className="asset-edit-tag-input-row">
                  <input
                    type="text"
                    value={tagInput}
                    onChange={(e) => setTagInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleAddTag()}
                    placeholder="Ajouter tag..."
                  />
                  <button type="button" onClick={handleAddTag}><Plus size={13} /></button>
                </div>
              </div>

              {!isServer && (
                <div className="asset_detail_row asset-restart-box">
                  <span className="asset_detail_label">⚡ Redémarrage</span>
                  <label className="asset-checkbox-label">
                    <input
                      type="checkbox"
                      checked={editRestartWorkflow}
                      onChange={(e) => setEditRestartWorkflow(e.target.checked)}
                    />
                    <span>Relancer le workflow après sauvegarde</span>
                  </label>
                </div>
              )}

              {/* 3.2 Champs Spécifiques gérés par chaque Vue */}
              <div className="asset-view-edit-slot">
                {asset.type === "server" && (
                  <ServerAssetView
                    asset={asset as ServerAsset}
                    isEditing={true}
                    editAttrs={viewEditAttrs}
                    onEditAttrsChange={(attrs) => setViewEditAttrs((prev) => ({ ...prev, ...attrs }))}
                    onRefresh={onRefresh || (() => {})}
                  />
                )}
                {(asset.type === "web_site" || asset.type === "web_app") && (
                  <WebAssetView
                    asset={asset as WebAsset}
                    isEditing={true}
                    editAttrs={viewEditAttrs}
                    onEditAttrsChange={(attrs) => setViewEditAttrs((prev) => ({ ...prev, ...attrs }))}
                  />
                )}
                {asset.type === "network" && (
                  <NetworkAssetView
                    asset={asset as NetworkAsset}
                    isEditing={true}
                    editAttrs={viewEditAttrs}
                    onEditAttrsChange={(attrs) => setViewEditAttrs((prev) => ({ ...prev, ...attrs }))}
                  />
                )}
              </div>

              {/* Boutons d'Enregistrement en bas */}
              <div className="asset_detail_actions asset-edit-footer">
                <button
                  type="button"
                  className="oh-btn oh-btn--primary"
                  onClick={handleSave}
                  disabled={saving}
                >
                  <Save size={14} /> {saving ? "Enregistrement..." : "Enregistrer les modifications"}
                </button>
                <button
                  type="button"
                  className="oh-btn oh-btn--ghost"
                  onClick={() => setIsEditing(false)}
                >
                  Annuler
                </button>
              </div>
            </div>
          ) : (
            /* ── MODE LECTURE (LIGNES DENSES + SOUS-VUES) ── */
            <>
              {/* Lignes Générales Communes */}
              <div className="asset_detail_row">
                <span className="asset_detail_label">🆔 Identifiant</span>
                <span className="asset_detail_value oh-mono">{asset.id}</span>
              </div>
              <div className="asset_detail_row">
                <span className="asset_detail_label">🏷️ Type d'actif</span>
                <span className="asset_detail_value">{AssetTypeMapping[asset.type]}</span>
              </div>
              <div className="asset_detail_row">
                <span className="asset_detail_label">📶 Statut</span>
                <div className="asset_detail_value">
                  <span className={`status_dot ${statusDotClass[asset.status]}`} />
                  {AssetStatusMapping[asset.status]}
                </div>
              </div>
              <div className="asset_detail_row">
                <span className="asset_detail_label">🔺 Priorité</span>
                <span className="asset_detail_value">{PRIORITY_MAPPING[asset.priority]}</span>
              </div>
            
               {/* Tags associés */}
              {asset.tags && asset.tags.length > 0 && (
                <div className="asset_detail_tags_block">
                  <span className="asset_detail_label">🏷️ Tags</span>
                  <div className="asset_detail_tags">
                    {asset.tags.map((tag) => (
                      <span key={tag} className="oh-badge oh-badge--accent">
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              {/* Rendu de la Vue Spécialisée (Lecture seule) */}
              {asset.type === "server" && (
                <ServerAssetView
                  asset={asset as ServerAsset}
                  isEditing={false}
                  onRefresh={onRefresh || (() => {})}
                />
              )}
              {(asset.type === "web_site" || asset.type === "web_app") && (
                <WebAssetView
                  asset={asset as WebAsset}
                  isEditing={false}
                />
              )}
              {asset.type === "network" && (
                <NetworkAssetView
                  asset={asset as NetworkAsset}
                  isEditing={false}
                />
              )}

              {/* Horodatages */}
              <div className="asset-metadata-table">
                <div className="asset_detail_row">
                  <span className="asset_detail_label">📅 Date de création</span>
                  <span className="asset_detail_value">
                    {asset.created_at ? new Date(asset.created_at).toLocaleString("fr-FR") : "—"}
                  </span>
                </div>
                <div className="asset_detail_row">
                  <span className="asset_detail_label">🔄 Dernière modification</span>
                  <span className="asset_detail_value">
                    {asset.updated_at ? new Date(asset.updated_at).toLocaleString("fr-FR") : "—"}
                  </span>
                </div>
                {asset.timestamp && (
                  <div className="asset_detail_row">
                    <span className="asset_detail_label">⏱️ Timestamp système</span>
                    <span className="asset_detail_value oh-mono">{asset.timestamp}</span>
                  </div>
                )}
              </div>

              {/* ── BOUTONS D'ACTION EN BAS (COMME DANS L'ANCIEN) ── */}
              <div className="asset_detail_actions">
                {!isServer && (
                  asset.status === "active" ? (
                    <button
                      type="button"
                      className="btn_action_detail btn_pause"
                      onClick={() => onPause(assetId)}
                      disabled={isLoading}
                    >
                      <Pause size={14} /> Mettre en pause
                    </button>
                  ) : (
                    <button
                      type="button"
                      className="btn_action_detail btn_resume"
                      onClick={() => onResume(assetId)}
                      disabled={isLoading}
                    >
                      <Play size={14} /> Reprendre
                    </button>
                  )
                )}

                <button
                  type="button"
                  className="btn_action_detail btn_delete"
                  onClick={() => setShowDeleteModal(true)}
                  disabled={isLoading}
                >
                  <Trash2 size={14} /> Supprimer
                </button>

                <button
                  type="button"
                  className="btn_action_detail btn_deselect"
                  onClick={onDeselect}
                  disabled={isLoading}
                >
                  <X size={14} /> Désélectionner
                </button>
              </div>
            </>
          )
        ) : (
          /* ── ONGLET 2 : FORMAT BRUT ── */
          <div className="asset-raw-format">
            <JsonEditor
              title="📦 Format brut (Enregistrement AssetItem DB)"
              json={(() => {
                const x = structuredClone(asset);
                if (x?.conf_content) {
                  x.conf_content = parseData(x.conf_content);
                }
                return x;
              })()}
              readOnly={true}
              fileName={`asset_raw_${asset.id}.json`}
              _forceCollapseState={false}
            />
          </div>
        )}
      </div>

      {/* ── MODALE DE CONFIRMATION DE SUPPRESSION ── */}
      {showDeleteModal && <ConfirmModal
        isOpen={showDeleteModal}
        title="Supprimer définitivement l'actif ?"
        message={`Êtes-vous sûr de vouloir supprimer l'actif "${asset.name || asset.id}" ? Cette action est irréversible et annulera immédiatement toutes ses tâches de surveillance.`}
        confirmText="Supprimer définitivement"
        variant="danger"
        isLoading={isLoading}
        onConfirm={() => {
          onDelete(assetId);
          onRefresh();
          setShowDeleteModal(false);
        }}
        onCancel={() => setShowDeleteModal(false)}
      />}
    </div>
  );
}

export default AssetDetail;