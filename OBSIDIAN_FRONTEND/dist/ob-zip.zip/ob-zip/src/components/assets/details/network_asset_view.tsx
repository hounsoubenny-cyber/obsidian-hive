import React, { useState, useEffect, useMemo } from "react";
import {
  NetworkAsset,
  NetworkDeploymentMode,
  NetworkDeploymentModeMapping,
  NetworkDeploymentModeEnum,
} from "@/types/assets/types";
import JsonEditor from "@/components/utils/json_editor/json_editor";
import JSON5 from "json5";
import {
  Radio,
  Network,
  Activity,
  FileCode,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import toast from "react-hot-toast";
import "./network_asset_view.css";

interface NetworkAssetViewProps {
  asset: NetworkAsset;
  isEditing?: boolean;
  editAttrs?: Record<string, any>;
  onEditAttrsChange?: (attrs: Record<string, any>) => void;
}

export function NetworkAssetView({
  asset,
  isEditing = false,
  editAttrs = {},
  onEditAttrsChange,
}: NetworkAssetViewProps) {
  // ── États Mode Lecture ──
  const [showMoreConfigs, setShowMoreConfigs] = useState<boolean>(false);
  const [copiedPath, setCopiedPath] = useState<boolean>(false);

  // ── États Mode Édition (config_path est condamné, non éditable) ──
  const [editDeploymentMode, setEditDeploymentMode] = useState<NetworkDeploymentMode>(
    asset.deployment_mode || NetworkDeploymentModeEnum.GATEWAY
  );
  const [editConfContent, setEditConfContent] = useState<any>(null);

  // Helper parsing sécurisé JSON/JSON5
  const parseData = (raw: any) => {
    if (typeof raw !== "string") return raw || {};
    try {
      return JSON.parse(raw);
    } catch {
      try {
        return JSON5.parse(raw);
      } catch {
        return { content: raw };
      }
    }
  };

  // Parsing de la configuration active
  const parsedConfig = useMemo(() => {
    if (!asset.conf_content) return null;
    return parseData(asset.conf_content);
  }, [asset.conf_content]);

  const globalConfig = parsedConfig?.GLOBAL_CONFIG || {};
  const interfaces = globalConfig.interface || [];
  const captureMode = globalConfig.mode || "ids";
  const apiConfig = globalConfig.API_CONFIG || {};

  // Initialisation du mode édition
  useEffect(() => {
    if (isEditing) {
      setEditDeploymentMode(asset.deployment_mode || NetworkDeploymentModeEnum.GATEWAY);
      try {
        setEditConfContent(asset.conf_content ? parseData(asset.conf_content) : {});
      } catch {
        setEditConfContent({});
      }
    }
  }, [isEditing, asset]);

  // Synchronisation des modifications (config_path reste inchangé côté backend)
  useEffect(() => {
    if (isEditing && onEditAttrsChange) {
      onEditAttrsChange({
        deployment_mode: editDeploymentMode,
        conf_content:
          typeof editConfContent === "string"
            ? editConfContent
            : JSON5.stringify(editConfContent || {}),
      });
    }
  }, [isEditing, editDeploymentMode, editConfContent]);

  // ── Prédicat de verrouillage des clés sensibles dans les JSON Réseau ──
  const isNetworkKeyReadOnly = (key: string | number) => {
    const keyStr = String(key).toLowerCase();
    return (
      [
        "config_path", "item_id", "id", "asset_id", "item_db_id"
      ].includes(keyStr)
    );
  };

  // Copier le chemin de config
  const handleCopyPath = async () => {
    if (!asset.config_path) return;
    await navigator.clipboard.writeText(asset.config_path);
    setCopiedPath(true);
    toast.success("Chemin de configuration copié !");
    setTimeout(() => setCopiedPath(false), 1500);
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // RENDU DU MODE ÉDITION SPÉCIFIQUE RÉSEAU (SANS MODIF DE PATH)
  // ═══════════════════════════════════════════════════════════════════════════
  if (isEditing) {
    return (
      <div className="net-edit-stack">
        <div className="asset_detail_row">
          <span className="asset_detail_label">🛰️ Mode de déploiement</span>
          <select
            className="asset-edit-select"
            value={editDeploymentMode}
            onChange={(e) => setEditDeploymentMode(e.target.value as NetworkDeploymentMode)}
          >
            {Object.entries(NetworkDeploymentModeMapping).map(([key, label]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
          </select>
        </div>

        {/* Configuration JSON éditable avec clés sensibles condamnées */}
        <div className="net-edit-json-group">
          <JsonEditor
            title="⚙️ Configuration IDS/IPS (conf_content)"
            json={editConfContent}
            onSave={setEditConfContent}
            readOnly={false}
            isKeyReadOnly={isNetworkKeyReadOnly}
            _forceCollapseState={false}
            saveLabel="Enregistrer Config IDS"
            fileName={`network_conf_${asset.id}.json`}
          />
        </div>
      </div>
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // RENDU DU MODE LECTURE
  // ═══════════════════════════════════════════════════════════════════════════
  return (
    <div className="net-view">
      {/* ── 1. LIGNES PRINCIPALES RÉSEAU ── */}
      <div className="asset_detail_row">
        <span className="asset_detail_label">🛰️ Mode de Déploiement</span>
        <span className="asset_detail_value">
          <Radio size={14} className="net-icon" />
          {NetworkDeploymentModeMapping[asset.deployment_mode] || asset.deployment_mode}
        </span>
      </div>

      <div className="asset_detail_row">
        <span className="asset_detail_label">🛡️ Mode de Détection</span>
        <span className="asset_detail_value">
          <span className={`oh-badge ${captureMode === "ips" ? "oh-badge--danger" : "oh-badge--info"}`}>
            {captureMode === "ips" ? "🛡️ Mode Bloquant (IPS)" : "👀 Mode Surveillance (IDS)"}
          </span>
        </span>
      </div>

      <div className="asset_detail_row">
        <span className="asset_detail_label">📄 Fichier de configuration</span>
        <div className="asset_detail_value">
          <span className="oh-mono">{asset.config_path}</span>
          <button
            type="button"
            className="asset-detail-copy-btn"
            onClick={handleCopyPath}
            title="Copier le chemin"
          >
            {copiedPath ? <Check size={12} /> : <Copy size={12} />}
          </button>
        </div>
      </div>

      {/* ── 2. INTERFACES ÉCOUTÉES ── */}
      <div className="asset_detail_row">
        <span className="asset_detail_label">
          <Network size={13} /> Interfaces écoutées
        </span>
        <div className="net-interfaces-list">
          {interfaces.length === 0 ? (
            <span className="oh-badge oh-badge--accent oh-mono">Toutes (any)</span>
          ) : (
            (Array.isArray(interfaces) ? interfaces : [interfaces]).map((iface: string) => (
              <span key={iface} className="oh-badge oh-badge--accent oh-mono">
                {iface}
              </span>
            ))
          )}
        </div>
      </div>

      {/* ── 3. ENDPOINT SONDE EMBARQUÉE ── */}
      {apiConfig.host && (
        <div className="asset_detail_row">
          <span className="asset_detail_label">
            <Activity size={13} /> Sonde locale
          </span>
          <span className="asset_detail_value oh-mono">
            {(() => {
              let host = String(apiConfig.host);
              if (["0.0.0.0", "127.0.0.1"].includes(host)) host = "localhost";
              if (host.startsWith("http")) {
                return apiConfig?.port ? `${host}:${apiConfig.port}` : host;
              } else {
                return apiConfig?.port ? `http://${host}:${apiConfig.port}` : host;
              }
            })()}
          </span>
        </div>
      )}

      {/* ── 4. ACCORDÉON "VOIR PLUS DE DÉTAILS & CONFIGURATIONS" ── */}
      <div className="net-configs-accordion">
        <button
          type="button"
          className="net-accordion-btn"
          onClick={() => setShowMoreConfigs(!showMoreConfigs)}
        >
          <span className="net-accordion-btn__label">
            <FileCode size={14} />
            {showMoreConfigs ? "Masquer la configuration JSON" : "Voir plus de détails & configuration brute"}
          </span>
          {showMoreConfigs ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
        </button>

        {showMoreConfigs && asset.conf_content && (
          <div className="net-accordion-body">
            <JsonEditor
              title="⚙️ Configuration Brute IDS/IPS (conf_content)"
              json={parseData(asset.conf_content)}
              readOnly={true}
              _forceCollapseState={false}
              fileName={`network_conf_${asset.id}.json`}
            />
          </div>
        )}
      </div>
    </div>
  );
}