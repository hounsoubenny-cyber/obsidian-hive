import React, { useState, useEffect, useMemo } from "react";
import {
  ServerAsset,
  AgentStatusMapping,
  AgentCapabilities,
  AgentCapabilitiesMapping,
  ServerToolInfo,
} from "@/types/assets/types";
import {
  rotateServerSecretAction,
  revokeServerAssetAction,
  reactivateServerAssetAction,
  getServerToolsList,
  getServerCapabilitiesList,
  toggleServerTool,
  toggleServerCapability,
} from "../assets/utils";
import { getConfig } from "@/hooks/get_config";
import { useNavigate } from "react-router-dom";
import { ConfirmModal } from "@/components/utils/confirm_modal/confirm_modal";
import JsonEditor from "@/components/utils/json_editor/json_editor";
import JSON5 from "json5";
import {
  Terminal,
  Copy,
  Check,
  RotateCcw,
  KeyRound,
  Ban,
  Shield,
  ShieldCheck,
  ShieldAlert,
  Server,
  Search,
  Plus,
  Trash2,
  Layers,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  FileCode,
  CheckCircle2,
  Clock,
} from "lucide-react";
import toast from "react-hot-toast";
import "./server_asset_view.css";

interface ServerAssetViewProps {
  asset: ServerAsset;
  isEditing?: boolean;
  editAttrs?: Record<string, any>;
  onEditAttrsChange?: (attrs: Record<string, any>) => void;
  onRefresh: () => void;
}

const ALL_CAPABILITIES: AgentCapabilities[] = [
  "scanner_web",
  "anti_phishing",
  "sandbox",
  "ids_ips",
  "simulator",
];

export function ServerAssetView({
  asset,
  onRefresh,
}: ServerAssetViewProps) {
  const navigate = useNavigate();

  // ── États des Sections Pliables ──
  const [showSpecs, setShowSpecs] = useState<boolean>(true);
  const [showCaps, setShowCaps] = useState<boolean>(true);
  const [showTools, setShowTools] = useState<boolean>(true);
  const [showConfigs, setShowConfigs] = useState<boolean>(false);

  // ── Données Locales (Mise à jour visuelle instantanée) ──
  const [localAllowedTools, setLocalAllowedTools] = useState<string[]>(asset.allowed_tools || []);
  const [localCapabilities, setLocalCapabilities] = useState<AgentCapabilities[]>(asset.capabilities || []);

  // ── Données Catalogue & API ──
  const [catalogTools, setCatalogTools] = useState<ServerToolInfo[]>([]);
  const [catalogCapabilities, setCatalogCapabilities] = useState<Record<string, string>>({});
  const [toolSearch, setToolSearch] = useState<string>("");
  const [apiBaseUrl, setApiBaseUrl] = useState<string>("");

  // ── Pagination des Outils Disponibles ──
  const [availableToolsLimit, setAvailableToolsLimit] = useState<number>(6);
  const [localAvailableToolsLimit, setLocalAvailableToolsLimit] = useState<number>(6);
  const [showAllAvailableTools, setShowAllAvailableTools] = useState<boolean>(false);

  // ── Pagination des Outils Autorisés ──
  const [allowedToolsLimit, setAllowedToolsLimit] = useState<number>(6);
  const [localAllowedToolsLimit, setLocalAllowedToolsLimit] = useState<number>(6);
  const [showAllAllowedTools, setShowAllAllowedTools] = useState<boolean>(false);

  // ── Pagination des Capacités ──
  const [availableCapsLimit, setAvailableCapsLimit] = useState<number>(4);
  const [localAvailableCapsLimit, setLocalAvailableCapsLimit] = useState<number>(4);
  const [showAllAvailableCaps, setShowAllAvailableCaps] = useState<boolean>(false);

  // ── Commandes copiables ──
  const [reactivationCmd, setReactivationCmd] = useState<string | null>(null);
  const [copiedInstall, setCopiedInstall] = useState<boolean>(false);
  const [copiedReactivate, setCopiedReactivate] = useState<boolean>(false);

  // ── Loaders & Modales ──
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [showRevokeModal, setShowRevokeModal] = useState<boolean>(false);
  const [showRotateModal, setShowRotateModal] = useState<boolean>(false);

  const assetId = asset.id || "";
  const isPendingDeletion = asset.pending_deletion === true;

  useEffect(() => {
    setLocalAllowedTools(asset.allowed_tools || []);
    setLocalCapabilities(asset.capabilities || []);
  }, [asset.allowed_tools, asset.capabilities]);

  useEffect(() => {
    getConfig().then((conf) => setApiBaseUrl(conf.apiBaseUrl));
    getServerToolsList((tools) => setCatalogTools(tools || []), () => {}, navigate);
    getServerCapabilitiesList((caps) => setCatalogCapabilities(caps || {}), () => {}, navigate);
  }, [navigate]);

  const parseData = (raw: any) => {
    if (typeof raw !== "string") return raw || {};
    try {
      return JSON.parse(raw);
    } catch {
      try {
        return JSON5.parse(raw);
      } catch {
        return { content: raw };
      }
    }
  };

  const pendingInstallCommand = useMemo(() => {
    if (asset.agent_status === "pending_install" && asset.install_token && apiBaseUrl) {
      return `curl -sSL -H "Authorization: Bearer ${asset.install_token}" ${apiBaseUrl}/download/agent/install.sh | bash`;
    }
    return null;
  }, [asset.agent_status, asset.install_token, apiBaseUrl]);

  const handleCopy = async (text: string, type: "install" | "reactivate") => {
    await navigator.clipboard.writeText(text);
    if (type === "install") {
      setCopiedInstall(true);
      setTimeout(() => setCopiedInstall(false), 2000);
    } else {
      setCopiedReactivate(true);
      setTimeout(() => setCopiedReactivate(false), 2000);
    }
    toast.success("Commande copiée !");
  };

  // ── Actions Sécurité ──
  const executeRotateSecret = async () => {
    setShowRotateModal(false);
    setActionLoading("rotate");
    try {
      const res = await rotateServerSecretAction(assetId, () => {}, null, navigate);
      if (res?.status === "success") {
        toast.success("🔑 Secret renouvelé et synchronisé avec l'agent.");
        onRefresh();
      }
    } finally {
      setActionLoading(null);
    }
  };

  const executeRevoke = async () => {
    setShowRevokeModal(false);
    setActionLoading("revoke");
    try {
      const ok = await revokeServerAssetAction(assetId, () => {}, null, navigate);
      if (ok) {
        toast.success("⛔ Agent serveur révoqué.");
        onRefresh();
      }
    } finally {
      setActionLoading(null);
    }
  };

  const handleReactivate = async () => {
    setActionLoading("reactivate");
    try {
      const res = await reactivateServerAssetAction(assetId, () => {}, null, navigate);
      if (res?.status === "success" && res.install_command) {
        setReactivationCmd(res.install_command);
        toast.success("Nouvelle commande prête !");
        onRefresh();
      }
    } finally {
      setActionLoading(null);
    }
  };

  // ── Bascule Outils ──
  const handleToggleTool = async (toolName: string, allow: boolean) => {
    setActionLoading(`tool-${toolName}`);
    const previous = [...localAllowedTools];
    const updated = allow
      ? [...localAllowedTools, toolName]
      : localAllowedTools.filter((t) => t !== toolName);
    setLocalAllowedTools(updated);

    try {
      const ok = await toggleServerTool(assetId, toolName, allow, () => {}, navigate);
      if (ok) {
        toast.success(allow ? `Outil "${toolName}" autorisé` : `Outil "${toolName}" révoqué`);
        onRefresh();
      } else {
        setLocalAllowedTools(previous);
      }
    } catch {
      setLocalAllowedTools(previous);
    } finally {
      setActionLoading(null);
    }
  };

  // ── Bascule Capacités ──
  const handleToggleCapability = async (cap: AgentCapabilities, enable: boolean) => {
    setActionLoading(`cap-${cap}`);
    const previous = [...localCapabilities];
    const updated = enable
      ? [...localCapabilities, cap]
      : localCapabilities.filter((c) => c !== cap);
    setLocalCapabilities(updated);

    try {
      const ok = await toggleServerCapability(assetId, cap, enable, () => {}, navigate);
      if (ok) {
        toast.success(enable ? `Capacité "${cap}" activée` : `Capacité "${cap}" désactivée`);
        onRefresh();
      } else {
        setLocalCapabilities(previous);
      }
    } catch {
      setLocalCapabilities(previous);
    } finally {
      setActionLoading(null);
    }
  };

  // ── Handlers Auto-Apply Pagination ──
  const applyAvailableToolsLimit = (val: number) => {
    const clean = isNaN(val) || val < 1 ? 1 : Math.min(val, 200);
    setLocalAvailableToolsLimit(clean);
    setAvailableToolsLimit(clean);
  };

  const applyAllowedToolsLimit = (val: number) => {
    const clean = isNaN(val) || val < 1 ? 1 : Math.min(val, 200);
    setLocalAllowedToolsLimit(clean);
    setAllowedToolsLimit(clean);
  };

  const applyAvailableCapsLimit = (val: number) => {
    const clean = isNaN(val) || val < 1 ? 1 : Math.min(val, 200);
    setLocalAvailableCapsLimit(clean);
    setAvailableCapsLimit(clean);
  };

  // Listes filtrées
  const allowedToolsSet = useMemo(() => new Set(localAllowedTools), [localAllowedTools]);
  const activeCapabilitiesSet = useMemo(() => new Set(localCapabilities), [localCapabilities]);

  const allowedToolsList = useMemo(() => {
    return catalogTools.filter((t) => allowedToolsSet.has(t.name));
  }, [catalogTools, allowedToolsSet]);

  const availableToolsList = useMemo(() => {
    return catalogTools
      .filter((t) => !allowedToolsSet.has(t.name))
      .filter(
        (t) =>
          t.name.toLowerCase().includes(toolSearch.toLowerCase()) ||
          t.description.toLowerCase().includes(toolSearch.toLowerCase())
      );
  }, [catalogTools, allowedToolsSet, toolSearch]);

  const activeCapabilitiesList = useMemo(() => {
    return ALL_CAPABILITIES.filter((c) => activeCapabilitiesSet.has(c));
  }, [activeCapabilitiesSet]);

  const availableCapabilitiesList = useMemo(() => {
    return ALL_CAPABILITIES.filter((c) => !activeCapabilitiesSet.has(c));
  }, [activeCapabilitiesSet]);

  // Listes découpées
  const displayedAllowedTools = showAllAllowedTools
    ? allowedToolsList
    : allowedToolsList.slice(0, allowedToolsLimit);

  const displayedAvailableTools = showAllAvailableTools
    ? availableToolsList
    : availableToolsList.slice(0, availableToolsLimit);

  const displayedAvailableCaps = showAllAvailableCaps
    ? availableCapabilitiesList
    : availableCapabilitiesList.slice(0, availableCapsLimit);

  const isServerKeyReadOnly = (key: string | number) => {
    const k = String(key).toLowerCase();
    return ["id", "item_db_id", "agent_status", "item_id", "asset_id"].includes(k);
  };

  // ── Déterminer le statut principal pour l'affichage ──
  const getDisplayStatus = () => {
    // Si pending_deletion est true, on affiche "Suppression programmée" en priorité
    if (isPendingDeletion) {
      return {
        status: "pending_deletion",
        label: "🗑️ Suppression programmée",
        dotClass: "pending_deletion",
        borderClass: "pending_deletion",
        subtitle: "Cet agent sera supprimé lors du prochain cycle de nettoyage",
        showActions: false,
      };
    }

    // Sinon, on utilise le statut normal
    const agentStatus = asset.agent_status || "pending_install";
    const statusMap = {
      connected: {
        label: AgentStatusMapping.connected || "Connecté",
        dotClass: "connected",
        borderClass: "connected",
        subtitle: asset.last_heartbeat
          ? `Dernier ping : ${new Date(asset.last_heartbeat).toLocaleString("fr-FR")}`
          : "En ligne",
        showActions: true,
      },
      pending_install: {
        label: AgentStatusMapping.pending_install || "En attente d'installation",
        dotClass: "pending_install",
        borderClass: "pending_install",
        subtitle: "En attente du premier signe de l'agent",
        showActions: true,
      },
      offline: {
        label: AgentStatusMapping.offline || "Hors ligne",
        dotClass: "offline",
        borderClass: "offline",
        subtitle: asset.last_heartbeat
          ? `Dernier ping : ${new Date(asset.last_heartbeat).toLocaleString("fr-FR")}`
          : "Déconnecté",
        showActions: true,
      },
      revoked: {
        label: AgentStatusMapping.revoked || "Révoqué",
        dotClass: "revoked",
        borderClass: "revoked",
        subtitle: "Accès révoqué",
        showActions: false,
      },
    };

    return {
      ...statusMap[agentStatus as keyof typeof statusMap],
      status: agentStatus,
    };
  };

  const displayStatus = getDisplayStatus();

  return (
    <div className="server-view">
      {/* ── 1. BANDEAU DE STATUT ── */}
      <div className={`server-banner server-banner--${displayStatus.borderClass}`}>
        <div className="server-banner__status">
          <span className={`server-banner__dot server-banner__dot--${displayStatus.dotClass}`} />
          <div className="server-banner__info">
            <span className="server-banner__title">
              {isPendingDeletion && (
                <span className="server-banner__deletion-badge">
                  <Clock size={14} /> {displayStatus.label}
                </span>
              )}
            </span>
            <span className="server-banner__subtitle">{displayStatus.subtitle}</span>
          </div>
        </div>

        {displayStatus.showActions && !isPendingDeletion && (
          <div className="server-banner__actions">
            <button
              type="button"
              className="oh-btn oh-btn--ghost server-btn-action"
              onClick={() => setShowRotateModal(true)}
              disabled={actionLoading === "rotate" || asset.agent_status === "revoked"}
            >
              <KeyRound size={14} /> Rotation Secret
            </button>
            <button
              type="button"
              className="oh-btn oh-btn--ghost server-btn-action"
              onClick={handleReactivate}
              disabled={actionLoading === "reactivate"}
            >
              <RotateCcw size={14} /> Réenregistrer
            </button>
            {asset.agent_status !== "revoked" && (
              <button
                type="button"
                className="oh-btn oh-btn--ghost server-btn-action server-btn-action--danger"
                onClick={() => setShowRevokeModal(true)}
                disabled={actionLoading === "revoke"}
              >
                <Ban size={14} /> Révoquer
              </button>
            )}
          </div>
        )}

        {isPendingDeletion && (
          <div className="server-banner__actions">
            <button
              type="button"
              className="oh-btn oh-btn--ghost server-btn-action server-btn-action--disabled"
              disabled
            >
              <Clock size={14} /> En attente de suppression
            </button>
          </div>
        )}
      </div>

      {/* ── 2. COMMANDES TERMINAL ── */}
      {pendingInstallCommand && !isPendingDeletion && (
        <div className="server-terminal-box">
          <div className="server-terminal-box__header">
            <span className="server-terminal-box__title">
              <Terminal size={15} /> Commande d'installation (Token valide 1h)
            </span>
            <button
              type="button"
              className="oh-btn oh-btn--primary server-btn-copy"
              onClick={() => handleCopy(pendingInstallCommand, "install")}
            >
              {copiedInstall ? <Check size={13} /> : <Copy size={13} />}
              {copiedInstall ? "Copié !" : "Copier"}
            </button>
          </div>
          <p className="server-terminal-box__desc">
            Exécutez cette commande en <strong>root (sudo)</strong> sur la machine cible pour démarrer l'agent.
          </p>
          <pre className="server-terminal-box__code oh-mono">
            <code>{pendingInstallCommand}</code>
          </pre>
        </div>
      )}

      {reactivationCmd && !isPendingDeletion && (
        <div className="server-terminal-box server-terminal-box--reconnect">
          <div className="server-terminal-box__header">
            <span className="server-terminal-box__title">
              <RotateCcw size={15} /> Nouvelle commande d'enrôlement
            </span>
            <button
              type="button"
              className="oh-btn oh-btn--primary server-btn-copy"
              onClick={() => handleCopy(reactivationCmd, "reactivate")}
            >
              {copiedReactivate ? <Check size={13} /> : <Copy size={13} />}
              {copiedReactivate ? "Copié !" : "Copier"}
            </button>
          </div>
          <pre className="server-terminal-box__code oh-mono">
            <code>{reactivationCmd}</code>
          </pre>
        </div>
      )}

      {/* ── 3. SPÉCIFICATIONS MACHINE ── */}
      <div className="server-section">
        <div className="server-section__header-toggle" onClick={() => setShowSpecs(!showSpecs)}>
          <h4 className="server-section__title">
            <Server size={15} /> Fiche d'Identité Machine
          </h4>
          <button type="button" className="server-toggle-btn">
            {showSpecs ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
          </button>
        </div>

        {showSpecs && (
          asset.system_info && Object.keys(asset.system_info).length > 0 ? (
            <div className="server-specs-grid">
              <div className="server-spec-card">
                <span className="server-spec-card__label">Système d'exploitation</span>
                <span className="server-spec-card__value">
                  {asset.system_info.os} {asset.system_info.os_release || ""}
                </span>
              </div>
              <div className="server-spec-card">
                <span className="server-spec-card__label">Architecture & CPU</span>
                <span className="server-spec-card__value">
                  {asset.system_info.architecture} ({asset.system_info.cpu_count || "?"} cœurs)
                </span>
              </div>
              <div className="server-spec-card">
                <span className="server-spec-card__label">Nom d'hôte</span>
                <span className="server-spec-card__value oh-mono">
                  {asset.system_info.hostname || "—"}
                </span>
              </div>
              <div className="server-spec-card">
                <span className="server-spec-card__label">Python Runtime</span>
                <span className="server-spec-card__value oh-mono">
                  {asset.system_info.python_version || "—"}
                </span>
              </div>
              {asset.system_info.ip_addresses && asset.system_info.ip_addresses.length > 0 && (
                <div className="server-spec-card server-spec-card--full">
                  <span className="server-spec-card__label">Adresses IP Détectées</span>
                  <div className="server-ips-list">
                    {asset.system_info.ip_addresses.map((ip: string) => (
                      <span key={ip} className="oh-badge oh-badge--accent oh-mono">
                        {ip}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="server-empty-hint">
              ⏳ En attente de la première connexion de l'agent pour récupérer la télémétrie.
            </div>
          )
        )}
      </div>

      {/* ── 4. GOUVERNANCE DES CAPACITÉS ── */}
      <div className="server-section">
        <div className="server-section__header-toggle" onClick={() => setShowCaps(!showCaps)}>
          <h4 className="server-section__title">
            <Layers size={15} /> Capacités & Modules ({activeCapabilitiesList.length} activée(s))
          </h4>
          <button type="button" className="server-toggle-btn">
            {showCaps ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
          </button>
        </div>

        {showCaps && !isPendingDeletion && (
          <div className="server-subset-wrapper">
            {/* 4.1 Activées */}
            <div className="server-subset-block">
              <span className="server-subset-title">
                <CheckCircle2 size={14} color="var(--success)" /> Modules Activés ({activeCapabilitiesList.length})
              </span>

              {activeCapabilitiesList.length === 0 ? (
                <div className="server-empty-hint">
                  Aucun module majeur activé sur cet agent.
                </div>
              ) : (
                <div className="server-caps-grid">
                  {activeCapabilitiesList.map((cap) => (
                    <div key={cap} className="server-cap-card server-cap-card--active">
                      <div className="server-cap-card__header">
                        <span className="server-cap-card__name">{AgentCapabilitiesMapping[cap]}</span>
                        <button
                          type="button"
                          className="server-tool-btn server-tool-btn--revoke"
                          onClick={() => handleToggleCapability(cap, false)}
                          disabled={actionLoading === `cap-${cap}`}
                        >
                          <Trash2 size={12} /> Désactiver
                        </button>
                      </div>
                      <span className="server-cap-card__desc">
                        {catalogCapabilities[cap] || AgentCapabilitiesMapping[cap]}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 4.2 Disponibles avec Pagination */}
            {availableCapabilitiesList.length > 0 && (
              <div className="server-subset-block">
                <span className="server-subset-title">
                  <Plus size={14} color="var(--accent)" /> Modules Disponibles ({availableCapabilitiesList.length})
                </span>

                <div className="server-caps-grid">
                  {displayedAvailableCaps.map((cap) => (
                    <div key={cap} className="server-cap-card">
                      <div className="server-cap-card__header">
                        <span className="server-cap-card__name">{AgentCapabilitiesMapping[cap]}</span>
                        <button
                          type="button"
                          className="server-tool-btn server-tool-btn--allow"
                          onClick={() => handleToggleCapability(cap, true)}
                          disabled={actionLoading === `cap-${cap}`}
                        >
                          <Plus size={12} /> Activer
                        </button>
                      </div>
                      <span className="server-cap-card__desc">
                        {catalogCapabilities[cap] || AgentCapabilitiesMapping[cap]}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Contrôle de lot pour capacités */}
                <div className="server-pagination-controls">
                  <div className="server-limit-setter">
                    <label>Afficher par lot :</label>
                    <input
                      type="number"
                      min={1}
                      max={20}
                      value={localAvailableCapsLimit}
                      onChange={(e) => setLocalAvailableCapsLimit(parseInt(e.target.value, 10) || 1)}
                      onBlur={(e) => applyAvailableCapsLimit(parseInt(e.target.value, 10))}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          applyAvailableCapsLimit(localAvailableCapsLimit);
                          (e.target as HTMLInputElement).blur();
                        }
                      }}
                    />
                  </div>
                  {availableCapabilitiesList.length > availableCapsLimit && (
                    <button
                      type="button"
                      className="server-see-more-btn"
                      onClick={() => setShowAllAvailableCaps(!showAllAvailableCaps)}
                    >
                      {showAllAvailableCaps ? "Voir moins" : `Voir tout (${availableCapabilitiesList.length})`}
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {showCaps && isPendingDeletion && (
          <div className="server-empty-hint">
            ⏳ Les capacités ne peuvent pas être modifiées pendant la suppression programmée.
          </div>
        )}
      </div>

      {/* ── 5. POLITIQUE DES OUTILS ── */}
      <div className="server-section">
        <div className="server-section__header-toggle" onClick={() => setShowTools(!showTools)}>
          <h4 className="server-section__title">
            <Shield size={15} /> Outils & Politiques Fail-Closed ({allowedToolsList.length} autorisé(s))
          </h4>
          <button type="button" className="server-toggle-btn">
            {showTools ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
          </button>
        </div>

        {showTools && !isPendingDeletion && (
          <div className="server-subset-wrapper">
            {/* 5.1 Outils Autorisés */}
            <div className="server-subset-block">
              <span className="server-subset-title">
                <ShieldCheck size={14} color="var(--success)" /> Outils Autorisés sur ce Serveur ({allowedToolsList.length})
              </span>

              {allowedToolsList.length === 0 ? (
                <div className="server-empty-callout">
                  <AlertTriangle size={15} />
                  <span>Aucun outil autorisé. La machine est protégée en mode lecture restreinte.</span>
                </div>
              ) : (
                <>
                  <div className="server-tools-grid">
                    {displayedAllowedTools.map((tool) => (
                      <div key={tool.name} className="server-tool-card server-tool-card--allowed">
                        <div className="server-tool-card__header">
                          <span className="server-tool-card__name oh-mono">{tool.name}</span>
                          <button
                            type="button"
                            className="server-tool-btn server-tool-btn--revoke"
                            onClick={() => handleToggleTool(tool.name, false)}
                            disabled={actionLoading === `tool-${tool.name}`}
                          >
                            <Trash2 size={12} /> Révoquer
                          </button>
                        </div>
                        <span className="server-tool-card__desc">{tool.description}</span>
                      </div>
                    ))}
                  </div>

                  {/* Contrôle de lot pour outils autorisés */}
                  <div className="server-pagination-controls">
                    <div className="server-limit-setter">
                      <label>Afficher par lot :</label>
                      <input
                        type="number"
                        min={1}
                        max={100}
                        value={localAllowedToolsLimit}
                        onChange={(e) => setLocalAllowedToolsLimit(parseInt(e.target.value, 10) || 1)}
                        onBlur={(e) => applyAllowedToolsLimit(parseInt(e.target.value, 10))}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            applyAllowedToolsLimit(localAllowedToolsLimit);
                            (e.target as HTMLInputElement).blur();
                          }
                        }}
                      />
                    </div>
                    {allowedToolsList.length > allowedToolsLimit && (
                      <button
                        type="button"
                        className="server-see-more-btn"
                        onClick={() => setShowAllAllowedTools(!showAllAllowedTools)}
                      >
                        {showAllAllowedTools ? "Voir moins" : `Voir tout (${allowedToolsList.length})`}
                      </button>
                    )}
                  </div>
                </>
              )}
            </div>

            {/* 5.2 Catalogue Disponible avec Recherche & Pagination */}
            <div className="server-subset-block">
              <div className="server-subset-header-row">
                <span className="server-subset-title">
                  <ShieldAlert size={14} color="var(--text-tertiary)" /> Catalogue Disponible ({availableToolsList.length})
                </span>
                <div className="server-tools-search">
                  <Search size={13} />
                  <input
                    type="text"
                    placeholder="Filtrer les outils..."
                    value={toolSearch}
                    onChange={(e) => setToolSearch(e.target.value)}
                  />
                </div>
              </div>

              <div className="server-tools-grid">
                {displayedAvailableTools.map((tool) => (
                  <div key={tool.name} className="server-tool-card">
                    <div className="server-tool-card__header">
                      <span className="server-tool-card__name oh-mono">{tool.name}</span>
                      <button
                        type="button"
                        className="server-tool-btn server-tool-btn--allow"
                        onClick={() => handleToggleTool(tool.name, true)}
                        disabled={actionLoading === `tool-${tool.name}`}
                      >
                        <Plus size={12} /> Autoriser
                      </button>
                    </div>
                    <span className="server-tool-card__desc">{tool.description}</span>
                  </div>
                ))}
              </div>

              {/* Contrôle de lot pour catalogue disponible */}
              <div className="server-pagination-controls">
                <div className="server-limit-setter">
                  <label>Afficher par lot :</label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={localAvailableToolsLimit}
                    onChange={(e) => setLocalAvailableToolsLimit(parseInt(e.target.value, 10) || 1)}
                    onBlur={(e) => applyAvailableToolsLimit(parseInt(e.target.value, 10))}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        applyAvailableToolsLimit(localAvailableToolsLimit);
                        (e.target as HTMLInputElement).blur();
                      }
                    }}
                  />
                </div>
                {availableToolsList.length > availableToolsLimit && (
                  <button
                    type="button"
                    className="server-see-more-btn"
                    onClick={() => setShowAllAvailableTools(!showAllAvailableTools)}
                  >
                    {showAllAvailableTools ? "Voir moins" : `Voir tout (${availableToolsList.length})`}
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {showTools && isPendingDeletion && (
          <div className="server-empty-hint">
            ⏳ Les outils ne peuvent pas être modifiés pendant la suppression programmée.
          </div>
        )}
      </div>

      {/* ── 6. CONFIGURATIONS & RAW JSON ── */}
      <div className="server-section">
        <div className="server-section__header-toggle" onClick={() => setShowConfigs(!showConfigs)}>
          <h4 className="server-section__title">
            <FileCode size={15} /> Configurations & Fichiers
          </h4>
          <button type="button" className="server-toggle-btn">
            {showConfigs ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
          </button>
        </div>

        {showConfigs && (
          <div className="server-configs-panel">
            {asset.conf_content && (
              <JsonEditor
                title="⚙️ Configuration JSON (conf_content)"
                json={parseData(asset.conf_content)}
                readOnly={true}
                _forceCollapseState={false}
                fileName={`server_conf_${asset.id}.json`}
                isKeyReadOnly={isServerKeyReadOnly}
              />
            )}
            <JsonEditor
              title="📦 Métadonnées AssetItem Complètes"
              json={asset}
              readOnly={true}
              _forceCollapseState={false}
              fileName={`server_asset_${asset.id}.json`}
              isKeyReadOnly={isServerKeyReadOnly}
            />
          </div>
        )}
      </div>

      {/* ── MODALES DE CONFIRMATION ── */}
      <ConfirmModal
        isOpen={showRevokeModal}
        title="Révoquer l'Agent Serveur ?"
        message={`Êtes-vous sûr de vouloir révoquer "${asset.name || asset.id}" ? La connexion sera rompue et son secret invalidé.`}
        confirmText="Révoquer l'accès"
        variant="danger"
        isLoading={actionLoading === "revoke"}
        onConfirm={executeRevoke}
        onCancel={() => setShowRevokeModal(false)}
      />

      <ConfirmModal
        isOpen={showRotateModal}
        title="Renouveler le Secret ?"
        message="Un nouveau secret sera généré et synchronisé avec l'agent connecté."
        confirmText="Renouveler"
        variant="warning"
        isLoading={actionLoading === "rotate"}
        onConfirm={executeRotateSecret}
        onCancel={() => setShowRotateModal(false)}
      />
    </div>
  );
}

export default ServerAssetView;