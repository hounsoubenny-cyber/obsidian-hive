import React, { useState, useEffect } from "react";
import { WebAsset } from "@/types/assets/types";
import JsonEditor from "@/components/utils/json_editor/json_editor";
import { checkPathExits } from "../modals/utils";
import { useNavigate } from "react-router-dom";
import JSON5 from "json5";
import {
  ExternalLink,
  Code2,
  CheckCircle2,
  XCircle,
  KeyRound,
  Copy,
  Check,
  Eye,
  EyeOff,
  FileCode,
  ChevronDown,
  ChevronUp,
  FolderSearch,
} from "lucide-react";
import toast from "react-hot-toast";
import "./web_asset_view.css";

interface WebAssetViewProps {
  asset: WebAsset;
  isEditing?: boolean;
  editAttrs?: Record<string, any>;
  onEditAttrsChange?: (attrs: Record<string, any>) => void;
}

export function WebAssetView({
  asset,
  isEditing = false,
  editAttrs = {},
  onEditAttrsChange,
}: WebAssetViewProps) {
  const navigate = useNavigate();

  // ── États Mode Lecture ──
  const [showMoreConfigs, setShowMoreConfigs] = useState<boolean>(false);
  const [showHelpers, setShowHelpers] = useState<boolean>(true);
  const [revealedPasswords, setRevealedPasswords] = useState<Record<string, boolean>>({});
  const [copiedUrl, setCopiedUrl] = useState<boolean>(false);
  const [copiedPath, setCopiedPath] = useState<boolean>(false);
  const [copiedHelperIdx, setCopiedHelperIdx] = useState<number | null>(null);

  // ── États Mode Édition ──
  const [editUrl, setEditUrl] = useState<string>(asset.url || "");
  const [editSourceCodeDir, setEditSourceCodeDir] = useState<string>(asset.source_code_dir || "");
  const [editFixAllowed, setEditFixAllowed] = useState<boolean>(Boolean(asset.fix_allowed));
  const [editInitConfig, setEditInitConfig] = useState<any>(asset.init_config || {});
  const [editRunConfig, setEditRunConfig] = useState<any>(asset.run_config || {});
  const [editConfContent, setEditConfContent] = useState<any>(null);

  const helpers = asset.run_config?.helpers || [];
  const allowedDomains = asset.run_config?.allowed_domains || [];

  // Helper parsing sécurisé JSON/JSON5
  const parseData = (raw: any) => {
    if (typeof raw !== "string") return raw || {};
    try {
      return JSON.parse(raw);
    } catch {
      try {
        return JSON5.parse(raw);
      } catch {
        return { content: raw };
      }
    }
  };

  // Initialisation du mode édition
  useEffect(() => {
    if (isEditing) {
      setEditUrl(asset.url || "");
      setEditSourceCodeDir(asset.source_code_dir || "");
      setEditFixAllowed(Boolean(asset.fix_allowed));
      setEditInitConfig(asset.init_config || {});
      setEditRunConfig(asset.run_config || {});
      try {
        setEditConfContent(asset.conf_content ? parseData(asset.conf_content) : {});
      } catch {
        setEditConfContent({});
      }
    }
  }, [isEditing, asset]);

  // Synchronisation des modifications vers le parent (config_path reste intouchable)
  useEffect(() => {
    if (isEditing && onEditAttrsChange) {
      onEditAttrsChange({
        url: editUrl,
        source_code_dir: editSourceCodeDir || null,
        fix_allowed: editFixAllowed,
        init_config: editInitConfig,
        run_config: editRunConfig,
        conf_content:
          typeof editConfContent === "string"
            ? editConfContent
            : JSON5.stringify(editConfContent || {}),
      });
    }
  }, [
    isEditing,
    editUrl,
    editSourceCodeDir,
    editFixAllowed,
    editInitConfig,
    editRunConfig,
    editConfContent,
  ]);

  // ── Prédicat de verrouillage des clés sensibles dans les JSON ──
  const isWebKeyReadOnly = (key: string | number, path: (string | number)[]) => {
    const keyStr = String(key).toLowerCase();
    return (
      [
          "config_path", "id", "item_id", "asset_id", "model_dir", 
          "known_params_dir", "cache_dir", "report_dir", "item_db_id"
      ].includes(keyStr)
    );
  };

  // Copier dans le presse-papier
  const handleCopy = async (text: string, type: "url" | "path") => {
    await navigator.clipboard.writeText(text);
    if (type === "url") {
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 1500);
    } else {
      setCopiedPath(true);
      setTimeout(() => setCopiedPath(false), 1500);
    }
    toast.success("Copié dans le presse-papier !");
  };

  const handleCopyHelper = async (helperObj: any, index: number) => {
    await navigator.clipboard.writeText(JSON.stringify(helperObj, null, 2));
    setCopiedHelperIdx(index);
    toast.success(`Configuration de ${helperObj.name} copiée !`);
    setTimeout(() => setCopiedHelperIdx(null), 1500);
  };

  const togglePassword = (keyId: string) => {
    setRevealedPasswords((prev) => ({ ...prev, [keyId]: !prev[keyId] }));
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // RENDU DU MODE ÉDITION SPÉCIFIQUE WEB
  // ═══════════════════════════════════════════════════════════════════════════
  if (isEditing) {
    return (
      <div className="web-edit-stack">
        <div className="asset_detail_row">
          <span className="asset_detail_label">🔗 URL Cible</span>
          <input
            type="url"
            className="asset-edit-input"
            value={editUrl}
            onChange={(e) => setEditUrl(e.target.value)}
            placeholder="https://example.com"
          />
        </div>

        <div className="asset_detail_row">
          <span className="asset_detail_label">🔧 Fix automatique</span>
          <label className="asset-checkbox-label">
            <input
              type="checkbox"
              checked={editFixAllowed}
              onChange={(e) => setEditFixAllowed(e.target.checked)}
            />
            <span>Autoriser Alex à corriger le code source</span>
          </label>
        </div>

        {/* Configurations JSON avec clés protégées (config_path, id verrouillés) */}
        <div className="web-edit-json-group">
          <JsonEditor
            title="⚙️ Init Config (ScannerIA)"
            json={editInitConfig}
            onSave={setEditInitConfig}
            readOnly={false}
            isKeyReadOnly={isWebKeyReadOnly}
            _forceCollapseState={false}
            saveLabel="Enregistrer Init Config"
            fileName={`init_config_${asset.id}.json`}
          />

          <JsonEditor
            title="⚙️ Run Config (ScannerIA)"
            json={editRunConfig}
            onSave={setEditRunConfig}
            readOnly={false}
            isKeyReadOnly={isWebKeyReadOnly}
            _forceCollapseState={false}
            saveLabel="Enregistrer Run Config"
            fileName={`run_config_${asset.id}.json`}
          />

          <JsonEditor
            title="⚙️ Configuration Brute (conf_content)"
            json={editConfContent}
            onSave={setEditConfContent}
            readOnly={false}
            isKeyReadOnly={isWebKeyReadOnly}
            _forceCollapseState={false}
            saveLabel="Enregistrer Config Brut"
            fileName={`conf_content_${asset.id}.json`}
          />
        </div>
      </div>
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // RENDU DU MODE LECTURE DENSE & STRUCTURÉ
  // ═══════════════════════════════════════════════════════════════════════════
  return (
    <div className="web-view">
      {/* ── 1. LIGNES PRINCIPALES ── */}
      <div className="asset_detail_row">
        <span className="asset_detail_label">🔗 URL Cible</span>
        <div className="asset_detail_value">
          <a
            href={asset.url}
            target="_blank"
            rel="noreferrer"
            className="web-target-link oh-mono"
          >
            {asset.url} <ExternalLink size={12} />
          </a>
          <button
            type="button"
            className="asset-detail-copy-btn"
            onClick={() => handleCopy(asset.url, "url")}
            title="Copier l'URL cible"
          >
            {copiedUrl ? <Check size={12} /> : <Copy size={12} />}
          </button>
        </div>
      </div>

      <div className="asset_detail_row">
        <span className="asset_detail_label">📂 Code source (Sandbox)</span>
        <div className="asset_detail_value">
          <span className="oh-mono">
            {asset.source_code_dir ? asset.source_code_dir : "Aucun dossier lié"}
          </span>
          {asset.source_code_dir && (
            <button
              type="button"
              className="asset-detail-copy-btn"
              onClick={() => handleCopy(asset.source_code_dir!, "path")}
              title="Copier le chemin du code source"
            >
              {copiedPath ? <Check size={12} /> : <Copy size={12} />}
            </button>
          )}
        </div>
      </div>

      <div className="asset_detail_row">
        <span className="asset_detail_label">🔧 Fix automatique</span>
        <span className="asset_detail_value">
          {asset.fix_allowed ? (
            <span className="oh-badge oh-badge--success">
              <CheckCircle2 size={12} /> Activé (Alex autorisé)
            </span>
          ) : (
            <span className="oh-badge oh-badge--warning">
              <XCircle size={12} /> Désactivé
            </span>
          )}
        </span>
      </div>

      {/* ── 2. HELPERS D'AUTHENTIFICATION ── */}
      {helpers.length > 0 && (
        <div className="web-helpers-section">
          <div className="web-helpers-header-row">
            <span className="asset_detail_label">
              <KeyRound size={13} /> Helpers d'Authentification ({helpers.length})
            </span>
            <button
              type="button"
              className="web-helpers-toggle-btn"
              onClick={() => setShowHelpers(!showHelpers)}
            >
              <span>{showHelpers ? "Masquer" : "Afficher"}</span>
              {showHelpers ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
            </button>
          </div>

          {showHelpers && (
            <div className="web-helpers-stack">
              {helpers.map((h: any, i: number) => (
                <div key={i} className="web-helper-item">
                  <div className="web-helper-item__header">
                    <div className="web-helper-item__title-group">
                      <span className="web-helper-item__name oh-mono">🔧 {h.name}</span>
                      <span className="oh-badge oh-badge--accent">Étape {i + 1}</span>
                    </div>
                    <button
                      type="button"
                      className="asset-detail-copy-btn"
                      onClick={() => handleCopyHelper(h, i)}
                      title="Copier la configuration du helper"
                    >
                      {copiedHelperIdx === i ? <Check size={12} /> : <Copy size={12} />}
                    </button>
                  </div>

                  {h.kwargs && Object.keys(h.kwargs).length > 0 && (
                    <div className="web-helper-item__params">
                      {Object.entries(h.kwargs).map(([k, v]) => {
                        const isSecret =
                          k.toLowerCase().includes("pass") ||
                          k.toLowerCase().includes("secret") ||
                          k.toLowerCase().includes("token");
                        const keyId = `${i}-${k}`;
                        const isRevealed = Boolean(revealedPasswords[keyId]);

                        return (
                          <div key={k} className="web-helper-param-row oh-mono">
                            <span className="param-key">{k}:</span>
                            <div className="param-val-group">
                              <span className="param-val">
                                {isSecret && !isRevealed ? "••••••••" : String(v)}
                              </span>
                              {isSecret && (
                                <button
                                  type="button"
                                  className="param-eye-btn"
                                  onClick={() => togglePassword(keyId)}
                                  title={isRevealed ? "Masquer" : "Afficher"}
                                >
                                  {isRevealed ? <EyeOff size={12} /> : <Eye size={12} />}
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── 3. DOMAINES AUTORISÉS ── */}
      {allowedDomains.length > 0 && (
        <div className="asset_detail_row">
          <span className="asset_detail_label">
            <FolderSearch size={13} /> Domaines autorisés
          </span>
          <div className="web-domains-chips">
            {allowedDomains.map((d: string) => (
              <span key={d} className="oh-badge oh-badge--info oh-mono">
                {d}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* ── 4. ACCORDÉON "VOIR PLUS DE DÉTAILS & CONFIGURATIONS" ── */}
      <div className="web-configs-accordion">
        <button
          type="button"
          className="web-accordion-btn"
          onClick={() => setShowMoreConfigs(!showMoreConfigs)}
        >
          <span className="web-accordion-btn__label">
            <FileCode size={14} />
            {showMoreConfigs ? "Masquer les configurations JSON" : "Voir plus de détails & configurations"}
          </span>
          {showMoreConfigs ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
        </button>

        {showMoreConfigs && (
          <div className="web-accordion-body">
            <JsonEditor
              title="⚙️ Init Config (ScannerIA)"
              json={asset.init_config}
              readOnly={true}
              _forceCollapseState={false}
              fileName={`init_config_${asset.id}.json`}
            />

            <JsonEditor
              title="⚙️ Run Config (ScannerIA)"
              json={asset.run_config}
              readOnly={true}
              _forceCollapseState={false}
              fileName={`run_config_${asset.id}.json`}
            />

            {asset.conf_content && (
              <JsonEditor
                title="⚙️ Configuration Brute (conf_content)"
                json={parseData(asset.conf_content)}
                readOnly={true}
                _forceCollapseState={false}
                fileName={`conf_content_${asset.id}.json`}
              />
            )}
          </div>
        )}
      </div>
    </div>
  );
}