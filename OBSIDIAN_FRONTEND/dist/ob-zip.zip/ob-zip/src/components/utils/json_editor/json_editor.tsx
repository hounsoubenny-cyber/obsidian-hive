import React, { useState, useEffect } from "react";
import "./json_editor.css";
import JSON5 from "json5";
import {
  Plus,
  Copy,
  Download,
  RotateCcw,
  ChevronRight,
  ChevronDown,
  Lock,
} from "lucide-react";
import toast from "react-hot-toast";

export type IsKeyReadOnlyPredicate = (
  key: string | number,
  path: (string | number)[],
  value?: any
) => boolean;

export interface JsonEditorProps {
  /** Titre affiché dans le header */
  title?: string;
  /** Le JSON (ou objet) à afficher et modifier */
  json: Record<string, any> | any[] | null;
  /** Callback déclenché à la sauvegarde */
  onSave?: (updatedJson: Record<string, any>) => void;
  /** Mode lecture seule global */
  readOnly?: boolean;
  /** Prédicat optionnel pour verrouiller des clés spécifiques */
  isKeyReadOnly?: IsKeyReadOnlyPredicate;
  /** Label personnalisé pour le bouton de sauvegarde */
  saveLabel?: string;
  /** Nom du fichier pour le téléchargement .json */
  fileName?: string;
  /** État global du pliage initial */
  _forceCollapseState?: boolean | null;
}

interface PrimitiveInputProps {
  value: string | number | boolean | null;
  type: "string" | "number" | "boolean" | "null";
  onChange: (val: any) => void;
  readOnly: boolean;
}

function PrimitiveInput({ value, type, onChange, readOnly }: PrimitiveInputProps) {
  if (type === "null") {
    return (
      <div className="json-null-wrapper">
        <span className="json-null-text">null</span>
        {!readOnly && (
          <button
            type="button"
            className="je-btn je-btn-xs"
            onClick={() => onChange("")}
          >
            Définir
          </button>
        )}
      </div>
    );
  }

  if (type === "number") {
    return (
      <input
        type="number"
        disabled={readOnly}
        className="json-input json-input-number"
        value={typeof value === "number" ? value : ""}
        onChange={(e) => {
          const val = e.target.value;
          if (val === "") return onChange(0);
          const parsed = Number(val);
          if (!isNaN(parsed)) onChange(parsed);
        }}
      />
    );
  }

  if (type === "boolean") {
    const boolVal = Boolean(value);
    return (
      <label className="json-boolean-wrapper">
        <input
          type="checkbox"
          disabled={readOnly}
          checked={boolVal}
          onChange={(e) => onChange(e.target.checked)}
        />
        <span className={`json-boolean-badge ${boolVal ? "true" : "false"}`}>
          {boolVal ? "true" : "false"}
        </span>
      </label>
    );
  }

  return (
    <input
      type="text"
      disabled={readOnly}
      className="json-input json-input-string"
      value={String(value ?? "")}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}

function JsonNode({
  label,
  value,
  onChange,
  readOnly,
  level,
  forceCollapseState,
  currentPath,
  isKeyReadOnly,
}: {
  label: string | number;
  value: any;
  onChange: (newValue: any) => void;
  readOnly: boolean;
  level: number;
  forceCollapseState: boolean | null;
  currentPath: (string | number)[];
  isKeyReadOnly?: IsKeyReadOnlyPredicate;
}) {
  const [isOpen, setIsOpen] = useState<boolean>(true);
  const [newArrayItem, setNewArrayItem] = useState<string>("");

  useEffect(() => {
    if (forceCollapseState !== null) setIsOpen(forceCollapseState);
  }, [forceCollapseState]);

  const isObject = typeof value === "object" && value !== null && !Array.isArray(value);
  const isArray = Array.isArray(value);
  const isComplex = isObject || isArray;

  const isLocked = isKeyReadOnly ? isKeyReadOnly(label, currentPath, value) : false;
  const nodeReadOnly = readOnly || isLocked;

  let primitiveType: "string" | "number" | "boolean" | "null" = "string";
  if (value === null) primitiveType = "null";
  else if (typeof value === "number") primitiveType = "number";
  else if (typeof value === "boolean") primitiveType = "boolean";

  const handleAddToArray = () => {
    if (!newArrayItem.trim() || !isArray) return;
    let parsed: any = newArrayItem.trim();
    if (parsed === "true") parsed = true;
    else if (parsed === "false") parsed = false;
    else if (!isNaN(Number(parsed)) && parsed !== "") parsed = Number(parsed);

    onChange([...value, parsed]);
    setNewArrayItem("");
  };

  return (
    <div className="json-node" style={{ marginLeft: `${level * 10}px` }}>
      <div className="json-node-row">
        {isComplex ? (
          <button
            type="button"
            className={`json-toggle-btn ${!isOpen ? "collapsed" : ""}`}
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
          </button>
        ) : (
          <span className="json-toggle-spacer" />
        )}

        <span className={typeof label === "number" ? "json-index-key" : "json-key"}>
          {typeof label === "number" ? `[${label}]` : `"${label}":`}
        </span>

        {isLocked && (
          <span className="json-lock-badge" title="Paramètre verrouillé (lecture seule)">
            <Lock size={10} />
          </span>
        )}

        {!isComplex && (
          <PrimitiveInput
            value={value}
            type={primitiveType}
            onChange={onChange}
            readOnly={nodeReadOnly}
          />
        )}

        {isComplex && (
          <span className="json-badge">
            {isArray ? `Array[${value.length}]` : "{...}"}
          </span>
        )}
      </div>

      {isComplex && isOpen && (
        <div className="json-node-children">
          {isArray ? (
            <>
              {value.map((item: any, idx: number) => (
                <JsonNode
                  key={idx}
                  label={idx}
                  value={item}
                  readOnly={nodeReadOnly}
                  level={1}
                  forceCollapseState={forceCollapseState}
                  currentPath={[...currentPath, idx]}
                  isKeyReadOnly={isKeyReadOnly}
                  onChange={(updatedItem) => {
                    const next = [...value];
                    next[idx] = updatedItem;
                    onChange(next);
                  }}
                />
              ))}

              {!nodeReadOnly && (
                <div className="json-array-actions">
                  <input
                    type="text"
                    className="json-input json-array-add-input"
                    placeholder="Nouvelle valeur..."
                    value={newArrayItem}
                    onChange={(e) => setNewArrayItem(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleAddToArray()}
                  />
                  <button
                    type="button"
                    className="je-btn je-btn-xs"
                    onClick={handleAddToArray}
                  >
                    <Plus size={11} /> Ajouter
                  </button>
                </div>
              )}
            </>
          ) : (
            Object.entries(value).map(([childKey, childValue]) => (
              <JsonNode
                key={childKey}
                label={childKey}
                value={childValue}
                readOnly={nodeReadOnly}
                level={1}
                forceCollapseState={forceCollapseState}
                currentPath={[...currentPath, childKey]}
                isKeyReadOnly={isKeyReadOnly}
                onChange={(updatedChildValue) => {
                  onChange({ ...value, [childKey]: updatedChildValue });
                }}
              />
            ))
          )}
        </div>
      )}
    </div>
  );
}

export function JsonEditor({
  title = "⚙️ Configuration JSON",
  json,
  onSave,
  readOnly = false,
  isKeyReadOnly,
  saveLabel = "💾 Enregistrer",
  fileName = "config.json",
  _forceCollapseState = null,
}: JsonEditorProps) {
  const [data, setData] = useState<Record<string, any>>(json || {});
  const [forceCollapseState, setForceCollapseState] = useState<boolean | null>(_forceCollapseState);

  useEffect(() => {
    if (json !== undefined && json !== null) {
      setData(parseData(json));
    } else {
      setData({});
    }
  }, [json]);

  const handleCopy = () => {
    navigator.clipboard.writeText(JSON.stringify(data, null, 2));
    toast.success("JSON copié !");
  };

  const handleExport = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName.endsWith(".json") ? fileName : `${fileName}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const isDataEmpty = !data || Object.keys(data).length === 0;

  return (
    <div className="json-editor-container">
      <div className="json-editor-header">
        <div className="json-editor-title">
          <span>{title}</span>
          {readOnly && <span className="json-badge">Lecture Seule</span>}
        </div>

        <div className="json-editor-actions">
          <button
            type="button"
            className="je-btn"
            onClick={() => setForceCollapseState(true)}
            title="Tout déplier"
          >
            Déplier
          </button>
          <button
            type="button"
            className="je-btn"
            onClick={() => setForceCollapseState(false)}
            title="Tout réduire"
          >
            Réduire
          </button>

          {!readOnly && (
            <button
              type="button"
              className="je-btn"
              onClick={() => setData(json || {})}
              title="Réinitialiser"
            >
              <RotateCcw size={11} /> Réinitialiser
            </button>
          )}

          <button type="button" className="je-btn" onClick={handleCopy} title="Copier le JSON">
            <Copy size={11} /> Copier
          </button>

          <button type="button" className="je-btn" onClick={handleExport} title="Télécharger .json">
            <Download size={11} /> Exporter
          </button>

          {!readOnly && onSave && (
            <button
              type="button"
              className="je-btn je-btn-primary"
              onClick={() => {
                onSave(data);
                toast.success("Configuration enregistrée !");
              }}
            >
              {saveLabel}
            </button>
          )}
        </div>
      </div>

      <div className="json-editor-body">
        {isDataEmpty ? (
          <div className="json-empty-hint">(Structure JSON vide)</div>
        ) : (
          Object.entries(data).map(([key, val]) => (
            <JsonNode
              key={key}
              label={key}
              value={val}
              readOnly={readOnly}
              level={0}
              forceCollapseState={forceCollapseState}
              currentPath={[key]}
              isKeyReadOnly={isKeyReadOnly}
              onChange={(newVal) => setData((prev) => ({ ...prev, [key]: newVal }))}
            />
          ))
        )}
      </div>
    </div>
  );
}

export default JsonEditor;

export const parseData = (raw: any) => {
    if (typeof raw !== "string") return raw || {};
    try {
      return JSON.parse(raw);
    } catch {
      try {
        return JSON5.parse(raw);
      } catch {
        return { content: raw };
      }
    }
  };