// ============================================================================
// GREETINGS — phrases d'accueil dynamiques pour l'écran "aucune conversation
// sélectionnée". Choisit au hasard une phrase adaptée selon que le nom du
// user et/ou le nom du projet sont disponibles, puis remplace les
// placeholders {username} / {projectName}.
// ============================================================================

import { sample } from "lodash";

// ============================================================================
// GREETINGS — phrases d'accueil dynamiques pour l'écran "aucune conversation
// sélectionnée". Les phrases sont réparties en plusieurs listes ci-dessous
// UNIQUEMENT pour la lisibilité du fichier (regrouper par thème) — au moment
// de choisir, on pioche dans l'UNION de toutes les listes, filtrée pour ne
// garder que les phrases dont tous les placeholders utilisés sont
// effectivement disponibles (pas de trou du style "Salut , prêt pour ?").
// ============================================================================

export type Greeting = {
    title: string;
    subtitle: string;
};

// {assistantName} n'entre jamais dans ce filtre : il a toujours un fallback
// ("l'assistant"), donc une phrase qui l'utilise est toujours valide.
const ALWAYS_AVAILABLE = new Set(["assistantName"]);

// ---- listes de phrases, groupées par thème pour la lisibilité --------------
// Chaque phrase peut utiliser n'importe quelle combinaison de placeholders
// parmi {username}, {projectName}, {assistantName} — pas besoin qu'elle
// corresponde au nom de la liste dans laquelle elle est rangée.

const GREETINGS_PERSO: Greeting[] = [
    { title: "Salut {username}, prêt pour {projectName} ?", subtitle: "Pose une question à {assistantName} pour commencer 🚀" },
    { title: "Hey {username} 👋 On attaque {projectName} ?", subtitle: "Dis-moi ce qu'il te faut." },
    { title: "{username}, {projectName} t'attend.", subtitle: "Lance la conversation quand tu veux." },
    { title: "Prêt à avancer sur {projectName}, {username} ?", subtitle: "{assistantName} est à l'écoute 🛡️" },
    { title: "Re {username} ! {projectName} au programme ?", subtitle: "Écris ton premier message pour démarrer." },
    { title: "Salut {username}, prêt à commencer ?", subtitle: "Pose une question à {assistantName} pour démarrer 🚀" },
    { title: "Hey {username} 👋", subtitle: "Dis-moi ce qu'il te faut aujourd'hui." },
    { title: "Content de te revoir, {username}.", subtitle: "Lance la conversation quand tu veux." },
];

const GREETINGS_PROJET: Greeting[] = [
    { title: "Prêt pour {projectName} ?", subtitle: "Pose une question à {assistantName} pour commencer 🚀" },
    { title: "{projectName} au programme ?", subtitle: "Écris ton premier message pour démarrer." },
    { title: "On attaque {projectName} ?", subtitle: "{assistantName} est à l'écoute 🛡️" },
];

const GREETINGS_GENERIQUES: Greeting[] = [
    { title: "Prêt à commencer ?", subtitle: "Pose une question à {assistantName} pour démarrer 🚀" },
    { title: "Salut 👋", subtitle: "Écris ton premier message pour lancer la conversation." },
    { title: "Une nouvelle conversation t'attend.", subtitle: "{assistantName} est prête quand tu l'es 🛡️" },
];

// Phrases qui utilisent les trois infos à la fois (username + projectName +
// assistantName) — ne sortiront du filtre que si les trois sont disponibles.
const GREETINGS_COMPLET: Greeting[] = [
    { title: "Salut {username}, {assistantName} est prête pour {projectName}.", subtitle: "Pose ta première question pour démarrer 🚀" },
    { title: "Re {username} 👋", subtitle: "{assistantName} t'attend sur {projectName}." },
    { title: "{username}, on reprend {projectName} ?", subtitle: "{assistantName} est à l'écoute 🛡️" },
    { title: "Prêt à avancer sur {projectName}, {username} ?", subtitle: "{assistantName} est branchée et attend ton message." },
];
 
// Union de toutes les listes ci-dessus : c'est LE pool dans lequel on pioche.
const ALL_GREETINGS: Greeting[] = [
    ...GREETINGS_PERSO,
    ...GREETINGS_PROJET,
    ...GREETINGS_GENERIQUES,
    ...GREETINGS_COMPLET,
];


// ---- helpers ----------------------------------------------------------------

function pick<T>(arr: T[]): T {
    return arr[Math.floor(Math.random() * arr.length)];
}

function fill(str: string, vars: Record<string, string>): string {
    return str.replace(/\{(\w+)\}/g, (_, key) => vars[key] ?? "");
}

function isFilled(value?: string | null): value is string {
    return Boolean(value && value.trim().length > 0);
}

// Extrait les noms de placeholders {xxx} présents dans une phrase.
function extractPlaceholders(str: string): string[] {
    const matches = str.matchAll(/\{(\w+)\}/g);
    return [...matches].map((m) => m[1]);
}

// Une phrase est éligible si TOUS ses placeholders sont soit toujours
// disponibles (assistantName), soit marqués comme disponibles dans `available`.
function isEligible(greeting: Greeting, available: Set<string>): boolean {
    const placeholders = [...extractPlaceholders(greeting.title), ...extractPlaceholders(greeting.subtitle)];
    return placeholders.every((p) => ALWAYS_AVAILABLE.has(p) || available.has(p));
}

// ---- API publique -----------------------------------------------------------

/**
 * Choisit une phrase d'accueil aléatoire parmi celles compatibles avec les
 * infos disponibles (pioche dans l'union de toutes les listes, filtrée pour
 * ne jamais laisser un placeholder sans valeur). Appeler une seule fois par
 * montage (ex. dans un useMemo) pour éviter que la phrase change à chaque
 * re-render.
 *
 * `assistantName` est laissé configurable (plutôt qu'en dur dans les
 * templates) pour que ce module reste réutilisable avec d'autres agents
 * que Coralie. Si absent, on retombe sur un terme générique.
 */
export function getGreeting(
    username?: string | null,
    projectName?: string | null,
    assistantName?: string | null
): Greeting {
    const available = new Set<string>();
    if (isFilled(username)) available.add("username");
    if (isFilled(projectName)) available.add("projectName");

    const candidates = ALL_GREETINGS.filter((g) => isEligible(g, available));
    // filet de sécurité : ne devrait jamais se vider (GREETINGS_GENERIQUES
    // n'utilise que assistantName, toujours disponible), mais au cas où.
    const greeting = pick(candidates.length > 0 ? candidates : GREETINGS_GENERIQUES);

    const vars = {
        username: username || "",
        projectName: projectName || "",
        assistantName: isFilled(assistantName) ? assistantName : "l'assistant",
    };
    return {
        title: fill(greeting.title, vars),
        subtitle: fill(greeting.subtitle, vars),
    };
}