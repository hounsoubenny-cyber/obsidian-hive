import { useEffect, useRef } from 'react';
import { X } from 'lucide-react';
import './input_modal.css';

interface InputModalProps {
  isOpen: boolean;
  onClose: () => void;
  onValidate: (value: string) => void;
  value: string;
  setValue: (value: string) => void;
  title?: string;
  placeholder?: string;
  confirmLabel?: string;
  cancelLabel?: string;
}

export function InputModal({
  isOpen,
  onClose,
  onValidate,
  value,
  setValue,
  title = 'Modifier',
  placeholder = 'Entrez une valeur...',
  confirmLabel = 'Valider',
  cancelLabel = 'Annuler',
}: InputModalProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  const handleValidate = () => {
    if (value.trim()) {
      onValidate(value);
      onClose();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && value.trim()) {
      handleValidate();
    }
    if (e.key === 'Escape') {
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="modal-overlay" onClick={onClose} />
      <div className="modal-container">
        <div className="modal-header">
          <h2 className="modal-title">{title}</h2>
          <button className="modal-close-btn" onClick={onClose}>
            <X size={20} />
          </button>
        </div>

        <div className="modal-body">
          <input
            ref={inputRef}
            type="text"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={placeholder}
            className="modal-input"
          />
        </div>

        <div className="modal-footer">
          <button className="modal-btn modal-btn-cancel" onClick={onClose}>
            {cancelLabel}
          </button>
          <button
            className="modal-btn modal-btn-confirm"
            onClick={handleValidate}
            disabled={!value.trim()}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </>
  );
}