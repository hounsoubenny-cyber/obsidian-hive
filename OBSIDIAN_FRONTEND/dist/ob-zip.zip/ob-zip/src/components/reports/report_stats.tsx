import { SeverityMapping } from '@/types/assets/types';
import { toTitleCaseWithUnderscore } from '../utils/to_lower_case';
import './report_stats.css'
import { BarChart3, Wrench, ShieldAlert, TriangleAlert, Loader2, Inbox, Calendar, Clock, Rss } from 'lucide-react';
function ReportStats({
    stats,
    error,
    loading = false,
    title = "Statistiques des rapports",
}: {
    stats: Record<string, any> | null;
    error?: string;
    loading?: boolean;
    title?: string;
}) {
    /*if (loading) {
        return (
            <div className="report_stats_loading">
                <Loader2 size={22} className="spin" />
                <p>Chargement des statistiques...</p>
            </div>
        );
    }*/

    if (error) {
        return (
            <div className="report_stats_error">
                <TriangleAlert size={20} />
                <p>{error}</p>
            </div>
        );
    }

    if (!stats || Object.keys(stats).length === 0) {
        return (
            <div className="report_stats_empty">
                <Inbox size={20} />
                <p>Aucune statistique disponible</p>
            </div>
        );
    }

    // Extraire les données
    const total = stats.total || 0;
    const hasFix = stats.has_fix || 0;
    const bySeverity = stats.by_severity || {};
    const bySource = stats.by_source || {};
    const latest = stats.latest;
    const oldest = stats.oldest;

    // Calcul du pourcentage de rapports avec fix
    const fixPercentage = total > 0 ? Math.round((hasFix / total) * 100) : 0;

    // Ordre des sévérités pour l'affichage
    const severityOrder = ["critical", "high", "medium", "low"];
    return (
        <div className="report_stats">
            <div className="report_stats_header">
                <h3 className="report_stats_title">{title}</h3>
                <span className="report_stats_total">
                    {total} rapport{total > 1 ? "s" : ""}
                </span>
            </div>

            <div className="report_stats_grid">
                {/* ===== CARTE TOTAL ===== */}
                <div className="report_stats_card report_stats_card_total">
                    <div className="report_stats_card_icon"><BarChart3 size={18} /></div>
                    <div className="report_stats_card_content">
                        <span className="report_stats_card_label">Total</span>
                        <span className="report_stats_card_value">{total}</span>
                    </div>
                </div>

                {/* ===== CARTE AVEC FIX ===== */}
                <div className="report_stats_card report_stats_card_fix">
                    <div className="report_stats_card_icon"><Wrench size={18} /></div>
                    <div className="report_stats_card_content">
                        <span className="report_stats_card_label">Avec fix</span>
                        <span className="report_stats_card_value">
                            {hasFix}
                            <span className="report_stats_card_sub">
                                ({fixPercentage}%)
                            </span>
                        </span>
                    </div>
                </div>

                {/* ===== CARTE CRITIQUES ===== */}
                <div className="report_stats_card report_stats_card_critical">
                    <div className="report_stats_card_icon"><ShieldAlert size={18} /></div>
                    <div className="report_stats_card_content">
                        <span className="report_stats_card_label">Critiques</span>
                        <span className="report_stats_card_value">
                            {bySeverity.critical || 0}
                        </span>
                    </div>
                </div>

                {/* ===== CARTE HAUTES ===== */}
                <div className="report_stats_card report_stats_card_high">
                    <div className="report_stats_card_icon"><TriangleAlert size={18} /></div>
                    <div className="report_stats_card_content">
                        <span className="report_stats_card_label">Hautes</span>
                        <span className="report_stats_card_value">
                            {bySeverity.high || 0}
                        </span>
                    </div>
                </div>
            </div>

            {/* ===== DÉTAIL PAR SÉVÉRITÉ ===== */}
            <div className="report_stats_detail">
                <div className="report_stats_detail_section">
                    <h4 className="report_stats_detail_title"><ShieldAlert size={14} /> Par sévérité</h4>
                    <div className="report_stats_bars">
                        {severityOrder.map((sev) => {
                            const count = bySeverity[sev] || 0;
                            const percentage = total > 0 ? Math.round((count / total) * 100) : 0;
                            const label = SeverityMapping[sev] || sev;

                            return (
                                <div key={sev} className="report_stats_bar">
                                    <div className="report_stats_bar_label">
                                        <span className={`report_stats_bar_dot sev_dot_${sev}`}></span>
                                        {label}
                                        <span className="report_stats_bar_count">{count}</span>
                                    </div>
                                    <div className="report_stats_bar_track">
                                        <div
                                            className={`report_stats_bar_fill sev_bar_${sev}`}
                                            style={{ width: `${percentage}%` }}
                                        />
                                    </div>
                                    <span className="report_stats_bar_percent">{percentage}%</span>
                                </div>
                            );
                        })}
                    </div>
                </div>

                {/* ===== DÉTAIL PAR SOURCE ===== */}
                {Object.keys(bySource).length > 0 && (
                    <div className="report_stats_detail_section">
                        <h4 className="report_stats_detail_title"><Rss size={14} /> Par source</h4>
                        <div className="report_stats_source_list">
                            {Object.entries(bySource).map(([source, count]) => {
                                const percentage = total > 0 ? Math.round((Number(count) / total) * 100) : 0;
                                return (
                                    <div key={source} className="report_stats_source_item">
                                        <span className="report_stats_source_name">{`${toTitleCaseWithUnderscore(source)} (${source})`}</span>
                                        <span className="report_stats_source_count">{String(count)}</span>
                                        <span className="report_stats_source_percent">{percentage}%</span>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )}

                {/* ===== DATES ===== */}
                {(latest || oldest) && (
                    <div className="report_stats_detail_section">
                        <h4 className="report_stats_detail_title"><Calendar size={14} /> Période</h4>
                        <div className="report_stats_dates">
                            {oldest && (
                                <div className="report_stats_date">
                                    <span className="report_stats_date_label"><Calendar size={12} /> Plus vieux</span>
                                    <span className="report_stats_date_value">
                                        {new Date(oldest).toLocaleString("fr-FR")}
                                    </span>
                                </div>
                            )}
                            {latest && (
                                <div className="report_stats_date">
                                    <span className="report_stats_date_label"><Clock size={12} /> Plus récent</span>
                                    <span className="report_stats_date_value">
                                        {new Date(latest).toLocaleString("fr-FR")}
                                    </span>
                                </div>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}

export default ReportStats;