import "./reports.css";
import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import {
    Report,
    ListReportsByFilterDataRequest,
    UpdateReportSeverityDataRequest,
    ReportIdDataRequest,
    DeleteOldReportsDataRequest,
    SourceMapping,
} from "@/types/reports/types";
import {
    updateReportSeverity as _updateReportSeverity,
    deleteReport as _deleteReport,
    deleteOldReports as _deleteOldReports,
} from "@/hooks/fetch_functions";
import { Severity, Source, SeverityMapping } from "@/types/assets/types";
import { isLogin, getToken } from "@/hooks/get_token";
import { Link, useNavigate } from "react-router-dom";
import { logError } from "@/hooks/error_utils";
import toast from "react-hot-toast";
import ReportStats from "./report_stats";
import { getReportStats, listCriticalReports, listReportsByFilter } from "./utils";
import { ReportPreview, ReportDetail } from "./report_detail_and_preview";
import { scrollToElement } from "../utils/sroll_utils";
import {
    RefreshCw,
    BarChart3,
    SlidersHorizontal,
    ListFilter,
    FileText,
    Trash2,
    TriangleAlert,
    Lock,
    Search,
} from "lucide-react";

// ============================================================================
// FILTRE LOCAL (affinage côté client)
// ============================================================================

function _filterReports(
    reports: Report[],
    query: string
): Report[] {
    if (!query.trim()) return reports;
    const q = query.trim().toLowerCase();
    return reports.filter((r) =>
        (r.asset_id || "").toLowerCase().includes(q) ||
        (r.content || "").toLowerCase().includes(q) ||
        String(r.id).includes(q)
    );
}

// ============================================================================
// PAGE PRINCIPALE : REPORT PAGE
// ============================================================================

function ReportPage() {
    const [searchParams, setSearchParams] = useSearchParams();
    const reportIdFromUrl = searchParams.get("report_id");
    
    const [reports, setReports] = useState<Report[] | null>(null);
    const [selectedReport, setSelectedReport] = useState<Report | null>(null);
    const [error, setError] = useState<string>("");
    const [loading, setLoading] = useState<boolean>(false);
    const [actionLoading, setActionLoading] = useState<Record<number, boolean>>({});
    const naviguate = useNavigate();

    // ── Pagination ──
    const [listLimit, setListLimit] = useState<number>(10);
    const [localListLimit, setLocalListLimit] = useState<number>(10);
    const [listShowAll, setListShowAll] = useState<boolean>(false);

    // Filtres serveur
    const [assetIdFilter, setAssetIdFilter] = useState<string>("");
    const [sourceFilter, setSourceFilter] = useState<Source | null>(null);
    const [useExactSeverity, setUseExactSeverity] = useState<boolean>(false);
    const [severityFilter, setSeverityFilter] = useState<Severity | null>(null);
    const [minSeverityFilter, setMinSeverityFilter] = useState<Severity | null>(null);
    const [startDateFilter, setStartDateFilter] = useState<string>("");
    const [endDateFilter, setEndDateFilter] = useState<string>("");
    const [orderBy, setOrderBy] = useState<"created_at.desc" | "created_at.asc">("created_at.desc");
    const [limit, setLimit] = useState<number>(100);

    // Affinage local
    const [localQuery, setLocalQuery] = useState<string>("");

    // Toggles
    const [showFilters, setShowFilters] = useState<boolean>(true);
    const [showList, setShowList] = useState<boolean>(true);
    const [showDetail, setShowDetail] = useState<boolean>(true);

    // Vue "critiques uniquement"
    const [criticalOnly, setCriticalOnly] = useState<boolean>(false);

    // Stats
    const [stats, setStats] = useState<Record<string, any> | null>(null);
    const [statsError, setStatsError] = useState<string>("");
    const [showStats, setShowStats] = useState<boolean>(true);

    // Nettoyage
    const [showCleanup, setShowCleanup] = useState<boolean>(false);
    const [cleanupDays, setCleanupDays] = useState<number>(90);
    const [cleanupLoading, setCleanupLoading] = useState<boolean>(false);
    const [cleanupResult, setCleanupResult] = useState<string>("");

    // ── Chargement ──
    const listCriticalReportsFunc = async () => {
        return await listCriticalReports(limit, setReports, setError, setLoading, naviguate);
    };
    
    const filterReportFunc = async () => {
        const filters: ListReportsByFilterDataRequest = {
            asset_id: assetIdFilter.trim() || null,
            source: sourceFilter,
            severity: severityFilter,
            min_severity: minSeverityFilter,
            start_date: startDateFilter || null,
            end_date: endDateFilter || null,
            limit: limit,
            order_by: orderBy,
        };
        await listReportsByFilter(filters, [setReports], setError, setLoading, naviguate);
    };

    const fetchReports = async () => {
        if (criticalOnly) {
            await listCriticalReportsFunc();
            return;
        }
        await filterReportFunc();
    };

    const fetchStats = async () => {
        await getReportStats(
            { asset_id: assetIdFilter.trim() || null },
            setStats,
            setStatsError,
            null,
            naviguate
        );
    };

    useEffect(() => {
        fetchReports();
        fetchStats();
    }, [criticalOnly]);

    useEffect(() => {
        if (useExactSeverity) setMinSeverityFilter(null);
        else setSeverityFilter(null);
    }, [useExactSeverity]);

    useEffect(() => {
        if (reports && reportIdFromUrl) {
            const found = reports.find((r) => String(r.id) === reportIdFromUrl);
            if (found) {
                setSelectedReport(found);
                setTimeout(() => {
                    scrollToElement("report_detail_panel_wrapper", 90);
                }, 300);
            }
        }
    }, [reports, reportIdFromUrl]);

    // ── Sélection ──
    const handleSelectReport = (report: Report) => {
        setSelectedReport(report);
        setSearchParams(prev => {
            prev.set("report_id", String(report.id));
            return prev;
        }, { replace: true });
    };

    const handleDeselect = () => {
        setSelectedReport(null);
        setSearchParams(prev => {
            prev.delete("report_id");
            return prev;
        }, { replace: true });
    };

    // ── Filtres ──
    const applyFilters = async () => {
        await fetchReports();
        await fetchStats();
        toast("✅ Filtres appliqués");
    };

    const resetFilters = async () => {
        setAssetIdFilter("");
        setSourceFilter(null);
        setSeverityFilter(null);
        setMinSeverityFilter(null);
        setStartDateFilter("");
        setEndDateFilter("");
        setOrderBy("created_at.desc");
        setLocalQuery("");
        setCriticalOnly(false);
        await listReportsByFilter(
            { limit, order_by: "created_at.desc" },
            [setReports],
            setError,
            setLoading,
            naviguate
        );
        toast("🔄 Filtres réinitialisés");
    };

    // ── Actions ──
    const handleUpdateSeverity = async (report_id: number, severity: Severity, has_fix?: boolean) => {
        setActionLoading((prev) => ({ ...prev, [report_id]: true }));
        try {
            const data: UpdateReportSeverityDataRequest = { report_id, severity, has_fix: has_fix ?? null };
            const result = await _updateReportSeverity(data, getToken());
            if (result.ok) {
                const updated = (reports || []).map((r) =>
                    r.id === report_id ? { ...r, severity, has_fix: has_fix ?? r.has_fix } : r
                );
                setReports(updated);
                if (selectedReport?.id === report_id) {
                    setSelectedReport((prev) => (prev ? { ...prev, severity, has_fix: has_fix ?? prev.has_fix } : null));
                }
                toast.success(`✅ Sévérité mise à jour pour le rapport #${report_id}`);
                await reloadAll();
            } else {
                toast.error(`❌ ${result.error || "Erreur lors de la mise à jour"}`);
            }
        } catch (err) {
            toast.error(`❌ ${logError(err)}`);
        } finally {
            setActionLoading((prev) => ({ ...prev, [report_id]: false }));
        }
    };

    const handleDelete = async (report_id: number) => {
        if (!confirm("Supprimer définitivement ce rapport ?")) return;

        setActionLoading((prev) => ({ ...prev, [report_id]: true }));
        try {
            const data: ReportIdDataRequest = { report_id };
            const result = await _deleteReport(data, getToken());
            if (result.ok) {
                const updated = (reports || []).filter((r) => r.id !== report_id);
                setReports(updated);
                if (selectedReport?.id === report_id) setSelectedReport(null);
                toast.success(`✅ Rapport #${report_id} supprimé`);
                await reloadAll();
            } else {
                toast.error(`❌ ${result.error || "Erreur lors de la suppression"}`);
            }
        } catch (err) {
            toast.error(`❌ ${logError(err)}`);
        } finally {
            setActionLoading((prev) => ({ ...prev, [report_id]: false }));
        }
    };

    const handleCleanup = async () => {
        if (!confirm(`⚠️ Supprimer TOUS les rapports de plus de ${cleanupDays} jour(s) ?`)) return;

        setCleanupLoading(true);
        setCleanupResult("");
        try {
            const data: DeleteOldReportsDataRequest = { days: cleanupDays };
            const result = await _deleteOldReports(data, getToken());
            if (result.ok) {
                const json = result.response as { success: boolean; deleted_count: number };
                setCleanupResult(`✅ ${json.deleted_count} rapport(s) supprimé(s)`);
                await reloadAll();
                toast.success(`✅ ${json.deleted_count} rapport(s) supprimé(s)`);
            } else {
                setCleanupResult(`❌ Erreur : ${result.error}`);
                toast.error(`❌ ${result.error}`);
            }
        } catch (err) {
            setCleanupResult(`❌ Erreur : ${logError(err)}`);
            toast.error(`❌ ${logError(err)}`);
        } finally {
            setCleanupLoading(false);
        }
    };

    const reloadAll = async () => {
        await fetchReports();
        await fetchStats();
        toast.success("🔄 Rapports rechargés");
    };

    const isActionLoading = (report_id: number) => !!actionLoading[report_id];

    // ── Application automatique de la limite ──
    const handleApplyLimit = (val: number) => {
        const cleanVal = isNaN(val) || val < 1 ? 1 : Math.min(val, 500);
        setLocalListLimit(cleanVal);
        setListLimit(cleanVal);
    };

    // ── Rendu ──
    if (!isLogin()) {
        return (
            <div id="report_page_locked" className="report_page_locked">
                <div className="grid-dots"></div>
                <div className="not-authenticated">
                    <Lock size={26} className="not-authenticated-icon" />
                    <h2>Accès restreint</h2>
                    <p>
                        Veuillez d'abord vous connecter à la <Link to="/login">page de connexion</Link>.
                    </p>
                </div>
            </div>
        );
    }

    const filteredReports = _filterReports(reports || [], localQuery);
    const total = filteredReports.length;
    const displayedReports = listShowAll ? filteredReports : filteredReports.slice(0, listLimit);

    return (
        <div id="report_page" className="report_page">
            <div className="report_toolbar">
                <h1 className="report_page_title">Rapports</h1>

                <button
                    id="btn_reload_reports"
                    className={`btn_reload_reports ${loading ? "spinning" : ""}`}
                    onClick={() => { reloadAll(); }}
                    disabled={loading}
                    title="Recharger les rapports"
                >
                    <RefreshCw size={16} className={loading ? "spin" : ""} />
                    {loading ? "Chargement..." : "Recharger"}
                </button>
            </div>

            {/* Toggles */}
            <div className="section_toggles">
                <button className={`btn_toggle_section ${showStats ? "is-active" : ""}`} onClick={() => setShowStats(!showStats)}>
                    <BarChart3 size={14} /> Stats
                </button>
                <button className={`btn_toggle_section ${showFilters ? "is-active" : ""}`} onClick={() => setShowFilters(!showFilters)}>
                    <SlidersHorizontal size={14} /> Filtres
                </button>
                <button className={`btn_toggle_section ${showList ? "is-active" : ""}`} onClick={() => setShowList(!showList)}>
                    <ListFilter size={14} /> Liste
                </button>
                <button className={`btn_toggle_section ${showDetail ? "is-active" : ""}`} onClick={() => setShowDetail(!showDetail)}>
                    <FileText size={14} /> Détail
                </button>
                <button className={`btn_toggle_section ${showCleanup ? "is-active" : ""}`} onClick={() => setShowCleanup(!showCleanup)}>
                    <Trash2 size={14} /> Nettoyage
                </button>
            </div>

            {/* Stats */}
            {showStats && (
                <ReportStats
                    stats={stats}
                    error={statsError || undefined}
                    loading={loading}
                    title="Statistiques des rapports"
                />
            )}

            {/* Cleanup */}
            {showCleanup && (
                <div className="report_cleanup_panel">
                    <h4><Trash2 size={15} /> Supprimer les vieux rapports</h4>
                    <p className="report_cleanup_hint"><TriangleAlert size={13} /> Action irréversible, impacte tous les assets.</p>
                    <div className="report_cleanup_row">
                        <label htmlFor="cleanup_days_input">Âge (jours) :</label>
                        <input
                            id="cleanup_days_input"
                            type="number"
                            min={1}
                            value={cleanupDays}
                            onChange={(e) => setCleanupDays(parseInt(e.target.value) || 1)}
                        />
                        <button className="btn_cleanup" onClick={handleCleanup} disabled={cleanupLoading}>
                            {cleanupLoading ? "Suppression..." : "Supprimer"}
                        </button>
                    </div>
                    {cleanupResult && <p className="report_cleanup_result">{cleanupResult}</p>}
                </div>
            )}

            {/* Filtres */}
            {showFilters && (
                <div className="report_filters_panel">
                    <div className="report_filters_grid">
                        <div className="filter_group">
                            <label htmlFor="report_asset_id_input">Asset ID</label>
                            <input
                                id="report_asset_id_input"
                                type="text"
                                value={assetIdFilter}
                                onChange={(e) => setAssetIdFilter(e.target.value)}
                                placeholder="ex : sh_as-..."
                            />
                        </div>

                        <div className="filter_group">
                            <label htmlFor="report_source_select">Source</label>
                            <select
                                id="report_source_select"
                                value={sourceFilter ?? ""}
                                onChange={(e) => setSourceFilter(e.target.value ? (e.target.value as Source) : null)}
                            >
                                <option value="">Toutes</option>
                                {Object.entries(SourceMapping).map(([key, value]) => (
                                    <option value={key} key={key}>{value}</option>
                                ))}
                            </select>
                        </div>

                        <div className="filter_group filter_severity_block">
                            <label>Filtre de sévérité</label>
                            <div className="filter_severity_toggle_row">
                                <label className="filter_switch_label" htmlFor="report_exact_severity_toggle">
                                    <input
                                        id="report_exact_severity_toggle"
                                        type="checkbox"
                                        checked={useExactSeverity}
                                        onChange={(e) => setUseExactSeverity(e.target.checked)}
                                    />
                                    <span>Sévérité exacte</span>
                                </label>
                                <span className="filter_severity_mode_badge">
                                    {useExactSeverity ? "Exacte" : "Minimum"}
                                </span>
                            </div>
                            <div className="filter_severity_select_row">
                                {useExactSeverity ? (
                                    <select
                                        id="report_severity_select"
                                        value={severityFilter ?? ""}
                                        onChange={(e) => setSeverityFilter(e.target.value ? (e.target.value as Severity) : null)}
                                    >
                                        <option value="">Toutes</option>
                                        {Object.entries(SeverityMapping).map(([key, value]) => (
                                            <option value={key} key={key}>{value}</option>
                                        ))}
                                    </select>
                                ) : (
                                    <select
                                        id="report_min_severity_select"
                                        value={minSeverityFilter ?? ""}
                                        onChange={(e) => setMinSeverityFilter(e.target.value ? (e.target.value as Severity) : null)}
                                    >
                                        <option value="">Aucune</option>
                                        {Object.entries(SeverityMapping).map(([key, value]) => (
                                            <option value={key} key={key}>{value}</option>
                                        ))}
                                    </select>
                                )}
                            </div>
                        </div>

                        <div className="filter_group">
                            <label htmlFor="report_start_date_input">Depuis</label>
                            <input
                                id="report_start_date_input"
                                type="datetime-local"
                                value={startDateFilter}
                                onChange={(e) => setStartDateFilter(e.target.value)}
                            />
                        </div>

                        <div className="filter_group">
                            <label htmlFor="report_end_date_input">Jusqu'à</label>
                            <input
                                id="report_end_date_input"
                                type="datetime-local"
                                value={endDateFilter}
                                onChange={(e) => setEndDateFilter(e.target.value)}
                            />
                        </div>

                        <div className="filter_group">
                            <label htmlFor="report_order_select">Ordre</label>
                            <select
                                id="report_order_select"
                                value={orderBy}
                                onChange={(e) => setOrderBy(e.target.value as "created_at.desc" | "created_at.asc")}
                            >
                                <option value="created_at.desc">Plus récent d'abord</option>
                                <option value="created_at.asc">Plus ancien d'abord</option>
                            </select>
                        </div>

                        <div className="filter_group">
                            <label htmlFor="report_limit_input">Limite</label>
                            <input
                                id="report_limit_input"
                                type="number"
                                min={1}
                                max={1000}
                                value={limit}
                                onChange={(e) => setLimit(parseInt(e.target.value) || 100)}
                            />
                        </div>

                        <div className="filter_actions">
                            <button id="btn_apply_report_filters" className="btn_apply_filters" onClick={applyFilters}>
                                Filtrer
                            </button>
                            <button id="btn_reset_report_filters" className="btn_reset_filters" onClick={resetFilters}>
                                Réinitialiser
                            </button>
                        </div>
                    </div>

                    {/* Vue rapide "Critiques uniquement" */}
                    <div className="report_filter_quick_bar">
                        <label htmlFor="report_critical_only" className="report_filter_quick_label">
                            <input
                                id="report_critical_only"
                                type="checkbox"
                                checked={criticalOnly}
                                onChange={(e) => { setCriticalOnly(e.target.checked); }}
                            />
                            <span>Vue rapide : Critiques uniquement</span>
                        </label>
                        <span className="report_filter_quick_hint">
                            {criticalOnly ? "Filtres serveur désactivés le temps de cette vue" : "Ignore les filtres serveur ci-dessus"}
                        </span>
                    </div>

                    {/* Recherche locale */}
                    <div className="report_filter_local_bar">
                        <label htmlFor="report_local_query_input" className="report_filter_local_label">
                            Recherche locale
                        </label>
                        <input
                            id="report_local_query_input"
                            type="text"
                            value={localQuery}
                            onChange={(e) => setLocalQuery(e.target.value)}
                            placeholder="Filtrer dans les résultats déjà chargés (ID, asset, contenu)..."
                        />
                    </div>
                </div>
            )}

            {/* Body */}
            <div className="report_page_body">
                {/* Liste */}
                {showList && (
                    <div id="report_list_panel" className="report_list_panel">
                        {error && <p className="report_list_error"><TriangleAlert size={13} /> {error}</p>}
                        <div className="list_header">
                            <span className="list_count">
                                {total} rapport{total > 1 ? "s" : ""} affiché{total > 1 ? "s" : ""}
                            </span>
                            <span className="list_showing_count">
                                Affichés : {displayedReports.length} / {total}
                            </span>
                        </div>

                        {displayedReports.length === 0 ? (
                            <div className="report_empty_state">Aucun rapport à afficher</div>
                        ) : (
                            <div className="report_cards_stack">
                                {displayedReports.map((report) => (
                                    <ReportPreview
                                        key={report.id}
                                        report={report}
                                        selected={selectedReport?.id === report.id}
                                        onSelect={() => handleSelectReport(report)}
                                    />
                                ))}
                            </div>
                        )}

                        {/* ── PAGINATION FIXE ── */}
                        <div className="see_more_controls">
                            <div className="see_more_limit_setter">
                                <label>Afficher par lot de :</label>
                                <input
                                    type="number"
                                    min={1}
                                    max={500}
                                    value={localListLimit}
                                    onChange={(e) => setLocalListLimit(parseInt(e.target.value, 10) || 1)}
                                    onBlur={(e) => handleApplyLimit(parseInt(e.target.value, 10))}
                                    onKeyDown={(e) => {
                                        if (e.key === "Enter") {
                                            handleApplyLimit(localListLimit);
                                            (e.target as HTMLInputElement).blur();
                                        }
                                    }}
                                    title="Modifiez la valeur et cliquez ailleurs ou tapez Entrée pour appliquer"
                                />
                            </div>

                            {total > listLimit && (
                                <button
                                    type="button"
                                    onClick={() => setListShowAll(!listShowAll)}
                                    className="btn_see_more"
                                >
                                    {listShowAll ? "Voir moins" : `Voir tout (${total})`}
                                </button>
                            )}
                        </div>
                    </div>
                )}

                {/* Détail */}
                {showDetail && (
                    <div id="report_detail_panel_wrapper" className="report_detail_panel_wrapper">
                        <ReportDetail
                            report={selectedReport}
                            onDeselect={handleDeselect}
                            onUpdateSeverity={handleUpdateSeverity}
                            onDelete={handleDelete}
                            isActionLoading={isActionLoading}
                        />
                    </div>
                )}
            </div>
        </div>
    );
}

export default ReportPage;