import "./report_detail_and_preview.css";
import { SourceMapping } from "@/types/reports/types";
import { formatDate, severityDotClass } from "./utils";
import { Severity, SeverityMapping } from "@/types/assets/types";
import { Report } from "@/types/reports/types";
import { useState, useRef, useEffect } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { markdownComponents, rehypePlugins } from "../utils/markdown_renderer/markdown_renderer";
import {
    Wrench,
    Target,
    Clock,
    ChevronDown,
    ChevronUp,
    FileText,
    Copy,
    Check,
    Lightbulb,
    ShieldAlert,
    ShieldCheck,
    Loader2,
    Trash2,
    X,
    BrainCircuit,
} from "lucide-react";

// ============================================================================
// COMPOSANT : REPORT PREVIEW
// ============================================================================

export function ReportPreview({
    report,
    selected,
    onSelect,
}: {
    report: Report;
    selected: boolean;
    onSelect: () => void;
}) {
    const summary = report.report?.summary || report.content || "Pas de résumé";
    const truncatedSummary = summary.length > 140 ? summary.slice(0, 140) + "…" : summary;

    return (
        <div
            className={`report_preview_card ${selected ? "report_preview_selected" : ""}`}
            onClick={onSelect}
        >
            <div className="report_preview_header">
                <div className="report_preview_header_left">
                    <span className={`sev_dot ${severityDotClass[report.severity]}`}></span>
                    <span className="report_preview_id">#{report.id}</span>
                </div>
                <div className="report_preview_header_right">
                    {report.has_fix && <span className="report_preview_badge_fix"><Wrench size={11} /> Fix</span>}
                    <span className="report_preview_source">{SourceMapping[report.source]}</span>
                </div>
            </div>

            <div className="report_preview_body">
                <div className="report_preview_desc">{truncatedSummary}</div>
            </div>

            <div className="report_preview_footer">
                <span className={`report_preview_severity sev_label_${report.severity}`}>
                    {SeverityMapping[report.severity]}
                </span>
                {report.asset_id && (
                    <span className="report_preview_asset" title={report.asset_id}>
                        <Target size={11} /> {report.asset_id.slice(0, 20)}
                    </span>
                )}
                <span className="report_preview_date"><Clock size={11} /> {formatDate(report.created_at)}</span>
            </div>
        </div>
    );
}

// ============================================================================
// SOUS-COMPOSANT : SECTION MARKDOWN AVEC "VOIR PLUS/MOINS" FIXÉ
// ============================================================================

function MarkdownSection({ content, label }: { content: string; label: string }) {
    const [showFullContent, setShowFullContent] = useState<boolean>(false);
    const [needsTruncation, setNeedsTruncation] = useState<boolean>(false);
    const contentRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (contentRef.current) {
            const height = contentRef.current.scrollHeight;
            const maxHeight = 160;
            setNeedsTruncation(content.length > 300 || height > maxHeight);
        }
    }, [content]);

    if (!content) return null;

    const displayContent = showFullContent ? content : content.slice(0, 300);

    return (
        <div className="report_detail_markdown_wrapper">
            <span className="report_detail_label">{label}</span>
            <div className="report_detail_markdown_container">
                <div 
                    className={`report_detail_markdown ${showFullContent ? "expanded" : ""}`}
                    style={!showFullContent && needsTruncation ? { maxHeight: "160px", overflow: "hidden" } : {}}
                >
                    <div ref={contentRef}>
                        <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={rehypePlugins} components={markdownComponents}>
                            {displayContent}
                        </ReactMarkdown>
                    </div>
                </div>
            </div>
            <div>
                {needsTruncation && (
                    <div className="report_detail_toggle_wrapper">
                        <button
                            className="report_detail_toggle_btn"
                            onClick={() => setShowFullContent(!showFullContent)}
                        >
                            {showFullContent ? (
                                <>Voir moins <ChevronUp size={13} /></>
                            ) : (
                                <>Voir plus <ChevronDown size={13} /></>
                            )}
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}

// ============================================================================
// COMPOSANT : REPORT DETAIL
// ============================================================================

export function ReportDetail({
    report,
    onDeselect,
    onUpdateSeverity,
    onDelete,
    isActionLoading,
}: {
    report: Report | null;
    onDeselect: () => void;
    onUpdateSeverity: (report_id: number, severity: Severity, has_fix?: boolean) => void;
    onDelete: (report_id: number) => void;
    isActionLoading: (report_id: number) => boolean;
}) {
    const [editSeverity, setEditSeverity] = useState<Severity | null>(null);
    const [copied, setCopied] = useState<boolean>(false);

    if (!report) {
        return (
            <div className="report_detail_empty">
                <FileText size={30} className="report_detail_empty_icon" />
                <p>Sélectionne un rapport dans la liste pour voir ses détails ici.</p>
            </div>
        );
    }

    const isLoading = isActionLoading(report.id);
    const currentEdit = editSeverity ?? report.severity;
    const alexReport = report.report;

    const copyAssetId = async () => {
        if (!report.asset_id) return;
        try {
            await navigator.clipboard.writeText(report.asset_id);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        } catch (err) {
            console.error("Erreur de copie:", err);
        }
    };

    return (
        <div className="report_detail_panel">
            {/* Header */}
            <div className="report_detail_header">
                <div className="report_detail_header_left">
                    <span className={`sev_dot ${severityDotClass[report.severity]}`}></span>
                    <h2 className="report_detail_title">Rapport #{report.id}</h2>
                </div>
                <div className="report_detail_header_right">
                    {report.has_fix && <span className="report_detail_badge_fix"><Wrench size={12} /> Fix</span>}
                    <span className="report_detail_source">{SourceMapping[report.source]}</span>
                </div>
            </div>

            {/* Infos */}
            <div className="report_detail_info_grid">
                <div className="report_detail_info_item report_detail_info_severity">
                    <span className="report_detail_info_label">Sévérité</span>
                    <span className={`report_detail_info_value sev_value_${report.severity}`}>
                        {SeverityMapping[report.severity]}
                    </span>
                </div>

                {report.asset_id && (
                    <div className="report_detail_info_item report_detail_info_asset">
                        <span className="report_detail_info_label">Actif lié</span>
                        <div className="report_detail_asset_copy" onClick={copyAssetId} title="Cliquer pour copier">
                            <span className="report_detail_info_value report_detail_mono">
                                {report.asset_id}
                            </span>
                            <span className="report_detail_copy_icon">
                                {copied ? <Check size={13} /> : <Copy size={13} />}
                            </span>
                            {copied && <span className="report_detail_copy_tooltip">Copié !</span>}
                        </div>
                    </div>
                )}

                <div className="report_detail_info_item">
                    <span className="report_detail_info_label">Fix disponible</span>
                    <span className={`report_detail_info_value ${report.has_fix ? "report_detail_fix_true" : "report_detail_fix_false"}`}>
                        {report.has_fix ? "Oui" : "Non"}
                    </span>
                </div>

                <div className="report_detail_info_item">
                    <span className="report_detail_info_label">Créé le</span>
                    <span className="report_detail_info_value">{formatDate(report.created_at)}</span>
                </div>
            </div>

            {/* Détails Alex */}
            <div className="report_detail_alex_section">
                <h3 className="report_detail_section_title"><BrainCircuit size={15} /> Analyse Alex</h3>

                {alexReport?.summary && <MarkdownSection content={alexReport.summary} label="Résumé" />}
                {alexReport?.natural_explanation && <MarkdownSection content={alexReport.natural_explanation} label="Explication" />}
                {alexReport?.technical_explanation && <MarkdownSection content={alexReport.technical_explanation} label="Détails techniques" />}
                {alexReport?.comment && <MarkdownSection content={alexReport.comment} label="Commentaire" />}

                <div className="report_detail_alex_meta">
                    {alexReport?.have_proposed_fix !== undefined && (
                        <span className={`report_detail_meta_tag ${alexReport.have_proposed_fix ? "tag_fix" : "tag_no_fix"}`}>
                            {alexReport.have_proposed_fix ? <><Lightbulb size={12} /> Fix proposé</> : "Pas de fix"}
                        </span>
                    )}
                    {alexReport?.prompt_injection_detected !== undefined && (
                        <span className={`report_detail_meta_tag ${alexReport.prompt_injection_detected ? "tag_injection" : "tag_clean"}`}>
                            {alexReport.prompt_injection_detected ? <><ShieldAlert size={12} /> Injection détectée</> : <><ShieldCheck size={12} /> Prompt propre</>}
                        </span>
                    )}
                </div>
            </div>

            {/* Contenu brut */}
            <div className="report_detail_raw_section">
                <h3 className="report_detail_section_title">Contenu brut</h3>
                <pre className="report_detail_raw_content">{report.content || "—"}</pre>
            </div>

            {/* Édition */}
            <div className="report_detail_edit_section">
                <h3 className="report_detail_section_title">Édition</h3>
                <div className="report_detail_edit_row">
                    <select
                        value={currentEdit}
                        onChange={(e) => setEditSeverity(e.target.value as Severity)}
                    >
                        {Object.entries(SeverityMapping).map(([key, label]) => (
                            <option value={key} key={key}>{label}</option>
                        ))}
                    </select>
                    <button
                        className="btn_action_detail btn_update"
                        disabled={isLoading || (currentEdit === report.severity)}
                        onClick={() => {
                            onUpdateSeverity(report.id, currentEdit, report.has_fix);
                            setEditSeverity(null);
                        }}
                    >
                        {isLoading ? <Loader2 size={14} className="spin" /> : "Appliquer"}
                    </button>
                </div>
            </div>

            {/* Actions */}
            <div className="report_detail_actions">
                <button
                    className="btn_action_detail btn_delete"
                    onClick={() => onDelete(report.id)}
                    disabled={isLoading}
                >
                    {isLoading ? <Loader2 size={14} className="spin" /> : <Trash2 size={14} />}
                    {isLoading ? "Suppression..." : "Supprimer"}
                </button>
                <button className="btn_action_detail btn_deselect" onClick={onDeselect} disabled={isLoading}>
                    <X size={14} />
                    Désélectionner
                </button>
            </div>
        </div>
    );
}