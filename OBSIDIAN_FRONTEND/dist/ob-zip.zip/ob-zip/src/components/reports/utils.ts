import {
    ListReportsByFilterDataRequest,
    ListReportsByFilterResponse,
    ListCriticalReportsResponse,
    ReportStatsDataRequest,
    ReportStatsResponse
} from "@/types/reports/types";

import { Severity } from "@/types/assets/types";
import {
    listReportsByFilter as _listReportsByFilter,
    listCriticalReports as _listCriticalReports,
    getReportStats as _getReportStats,
    updateReportSeverity as _updateReportSeverity,
    deleteReport as _deleteReport,
    deleteOldReports as _deleteOldReports,
} from "@/hooks/fetch_functions";
import { refreshToken, getToken } from "@/hooks/get_token";
import { useNavigate } from "react-router-dom";
import { logError } from "@/hooks/error_utils";

// ============================================================================
// UTILITAIRES
// ============================================================================

export function formatDate(iso?: string): string {
    if (!iso) return "—";
    try {
        return new Date(iso).toLocaleString("fr-FR");
    } catch {
        return iso;
    }
}

export const severityDotClass: Record<Severity, string> = {
    low: "sev_dot_low",
    medium: "sev_dot_medium",
    high: "sev_dot_high",
    critical: "sev_dot_critical",
};

// ============================================================================
// FONCTIONS DE RÉCUPÉRATION
// ============================================================================

export async function listReportsByFilter(
    filters: ListReportsByFilterDataRequest,
    setResult: Function[] | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<ListReportsByFilterResponse | null> {
    try {
        if (setLoading) setLoading(true);
        const result = await _listReportsByFilter(filters, getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as ListReportsByFilterResponse;
            if (setResult) {
                for (const fn of setResult) fn(json.reports);
            }
            return json;
        }
        const json = json_ as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await listReportsByFilter(filters, setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) {
            for (const fn of setResult) fn(null);
        }
        setError(result.error || json?.detail?.error || "Erreur lors de la récupération des rapports");
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans listReportsByFilter : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function listCriticalReports(
    limit: number,
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<ListCriticalReportsResponse | null> {
    try {
        if (setLoading) setLoading(true);
        const result = await _listCriticalReports({limit: limit}, getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as ListCriticalReportsResponse;
            if (setResult) setResult(json.reports);
            return json;
        }
        const json = json_ as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await listCriticalReports(limit, setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error || json?.detail?.error || "Erreur lors de la récupération des rapports critiques");
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans listCriticalReports : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function getReportStats(
    data: ReportStatsDataRequest,
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<ReportStatsResponse | null> {
    try {
        if (setLoading) setLoading(true);
        const result = await _getReportStats(data, getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as ReportStatsResponse;
            if (setResult) setResult(json.stats);
            return json;
        }
        const json = json_ as Record<string, any>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getReportStats(data, setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error || json?.detail?.error || "Erreur lors de la récupération des statistiques");
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getReportStats : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}
