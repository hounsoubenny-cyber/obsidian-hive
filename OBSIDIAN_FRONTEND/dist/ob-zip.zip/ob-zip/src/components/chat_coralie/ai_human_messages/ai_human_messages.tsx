import "./ai_human_messages.css";
import { useState } from "react";
import {
    Bot,
    User,
    Brain,
    ChevronDown,
    ChevronRight,
    Wrench,
    CheckCircle2,
    AlertTriangle,
    XCircle,
    Loader2,
    Clock,
    Copy,
    Check,
    Sparkles,
} from "lucide-react";
import { AgentStep, Message, ToolCallDetail } from "@/types/chat_coralie/types";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { markdownComponents, rehypePlugins } from "@/components/utils/markdown_renderer/markdown_renderer";

// ============================================================================
// HELPERS
// ============================================================================

function formatDuration(seconds: number | null | undefined): string {
    if (seconds === null || seconds === undefined || isNaN(seconds)) return "";
    if (seconds < 1) return `${Math.max(0, Math.round(seconds * 1000))}ms`;
    if (seconds < 60) return `${seconds.toFixed(1)}s`;
    const m = Math.floor(seconds / 60);
    const s = Math.round(seconds % 60);
    return `${m}m ${s}s`;
}

function formatTime(iso?: string | null): string {
    if (!iso) return "";
    try {
        return new Date(iso).toLocaleString(
            "fr-FR", {
                dateStyle: "full",
                timeStyle: "medium"
            }
        )
        //return new Date(iso).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
    } catch {
        return "";
    }
}

function statusOf(call: ToolCallDetail): "planned" | "executing" | "done" {
    if (call.status) return call.status;
    if (call.success === true || call.success === false) return "done";
    return "planned";
}

// ============================================================================
// TOOL CALL — carte repliable par outil
// ============================================================================

function ToolCallItem({ call }: { call: ToolCallDetail }) {
    const [open, setOpen] = useState(false);
    const [resultCopied, setResultCopied] = useState(false);
    const status = statusOf(call);
    const isError = call.success === false;

    const handleCopyResult = async (e: React.MouseEvent) => {
        e.stopPropagation();
        const text = typeof call.result === "string" ? call.result : JSON.stringify(call.result, null, 2);
        try {
            await navigator.clipboard.writeText(text || "");
            setResultCopied(true);
            setTimeout(() => setResultCopied(false), 1200);
        } catch {
            // pas critique
        }
    };

    const StatusIcon = () => {
        if (status === "planned") return <Clock size={13} className="tc-icon tc-icon-planned" />;
        if (status === "executing") return <Loader2 size={13} className="tc-icon tc-icon-executing spin" />;
        if (isError) return <XCircle size={13} className="tc-icon tc-icon-error" />;
        return <CheckCircle2 size={13} className="tc-icon tc-icon-success" />;
    };

    const hasArgs = call.args && Object.keys(call.args).length > 0;
    const hasResult = call.result !== null && call.result !== undefined && call.result !== "";
    const canExpand = hasArgs || hasResult;

    return (
        <div className={`tool-call tool-call--${status}${isError ? " tool-call--error" : ""}`}>
            <button
                className="tool-call-header"
                onClick={() => canExpand && setOpen((p) => !p)}
                disabled={!canExpand}
            >
                <Wrench size={13} className="tc-wrench" />
                <span className="tc-name">{call.name}</span>
                <StatusIcon />
                {status === "executing" && <span className="tc-label">en cours…</span>}
                {status === "planned" && <span className="tc-label">planifié</span>}
                {call.duration ? <span className="tc-duration">{formatDuration(call.duration)}</span> : null}
                {canExpand && (
                    <span className="tc-chevron">
                        {open ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
                    </span>
                )}
            </button>

            {open && canExpand && (
                <div className="tool-call-body">
                    {hasArgs && (
                        <div className="tc-section">
                            <div className="tc-section-label">Arguments</div>
                            <pre className="tc-pre">
                                <SyntaxHighlighter
                                    language="json"
                                    style={oneDark}
                                    customStyle={{ background: 'transparent' }}
                                >
                                    {JSON.stringify(call.args, null, 2)}
                                </SyntaxHighlighter>
                            </pre>
                        </div>
                    )}
                    {hasResult && (
                        <div className="tc-section">
                            <div className="tc-section-label-row">
                                <span className="tc-section-label">Résultat</span>
                                <button className="tc-copy-btn" onClick={handleCopyResult} title="Copier le résultat">
                                    {resultCopied ? <Check size={11} /> : <Copy size={11} />}
                                </button>
                            </div>
                            <pre className="tc-pre">
                                {
                                    typeof call.result === "string" ? (
                                        call.result
                                    ) : (
                                        <SyntaxHighlighter
                                            language="json"
                                            style={oneDark}
                                            customStyle={{ background: 'transparent' }}
                                        >
                                            {JSON.stringify(call.result, null, 2)}
                                        </SyntaxHighlighter>
                                    )
                                }
                            </pre>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}

// ============================================================================
// GROUPEMENT — appels consécutifs au même outil (ex: 7x update_asset à la
// suite) regroupés visuellement, pour ne pas noyer le fil sur un run avec
// beaucoup de tool calls. Seuls les appels CONSÉCUTIFS de même nom sont
// groupés (si l'ordre est update_asset, scan, update_asset, on garde 3
// entrées séparées — pas de réordonnancement, l'ordre chronologique reste
// la source de vérité).
// ============================================================================

type ToolEntry = [string, ToolCallDetail];

function groupConsecutiveByName(entries: ToolEntry[]): ToolEntry[][] {
    const groups: ToolEntry[][] = [];
    for (const entry of entries) {
        const [, call] = entry;
        const lastGroup = groups[groups.length - 1];
        if (lastGroup && lastGroup[0][1].name === call.name) {
            lastGroup.push(entry);
        } else {
            groups.push([entry]);
        }
    }
    return groups;
}

function ToolCallGroup({ entries }: { entries: ToolEntry[] }) {
    const [open, setOpen] = useState(false);
    const name = entries[0][1].name;
    const statuses = entries.map(([, call]) => statusOf(call));
    const anyError = entries.some(([, call]) => call.success === false);
    const anyExecuting = statuses.includes("executing");
    const anyPlanned = statuses.includes("planned");
    const allDone = statuses.every((s) => s === "done");
    const totalDuration = entries.reduce((sum, [, call]) => sum + (call.duration || 0), 0);

    const GroupStatusIcon = () => {
        if (anyExecuting) return <Loader2 size={13} className="tc-icon tc-icon-executing spin" />;
        if (anyPlanned) return <Clock size={13} className="tc-icon tc-icon-planned" />;
        if (anyError) return <XCircle size={13} className="tc-icon tc-icon-error" />;
        return <CheckCircle2 size={13} className="tc-icon tc-icon-success" />;
    };

    return (
        <div className={`tool-call-group${anyError ? " tool-call-group--error" : ""}`}>
            <button className="tool-call-group-header" onClick={() => setOpen((p) => !p)}>
                <Wrench size={13} className="tc-wrench" />
                <span className="tc-name">{name}</span>
                <span className="tc-group-count">×{entries.length}</span>
                <GroupStatusIcon />
                {allDone && totalDuration > 0 && (
                    <span className="tc-duration">Σ {formatDuration(totalDuration)}</span>
                )}
                <span className="tc-chevron">
                    {open ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
                </span>
            </button>

            {open && (
                <div className="tool-call-group-body">
                    {entries.map(([id, call]) => (
                        <ToolCallItem key={id} call={call} />
                    ))}
                </div>
            )}
        </div>
    );
}

// ============================================================================
// STEP — une itération de la boucle agent (think + tool_calls, jamais de
// réponse finale : elle vit à part dans message.content, cf. discussion).
// ============================================================================

function StepBlock({
    step,
    isLast,
    isStreaming,
}: {
    step: AgentStep;
    isLast: boolean;
    isStreaming: boolean;
}) {
    const [thinkOpen, setThinkOpen] = useState(isLast && isStreaming);
    const hasThink = Boolean(step?.think && step.think.trim().length > 0);
    const hasContent = Boolean(step?.content && step.content.trim().length > 0);
    const toolEntries = Object.entries(step?.tool_calls || {});
    const hasTools = toolEntries.length > 0;

    if (!hasThink && !hasContent && !hasTools) return null;

    const thinkIsLive = isStreaming && isLast && !step.ended_at;
    // Le texte de cette itération est "en train de s'écrire" tant que le
    // step est le dernier, qu'on stream encore, et qu'on n'a pas déjà des
    // tool_calls dessus (une fois les tools connus, le texte qui précédait
    // est figé — le live passe aux tool calls eux-mêmes).
    const contentIsLive = isStreaming && isLast && !hasTools && !step.ended_at;

    return (
        <div className="agent-step">
            {hasThink && (
                <div className="think-block">
                    <button className="think-header" onClick={() => setThinkOpen((p) => !p)}>
                        <Brain size={13} className={`think-icon${thinkIsLive ? " pulse" : ""}`} />
                        <span className="think-label">Réflexion</span>
                        {step.duration ? <span className="think-duration">{formatDuration(step.duration)}</span> : null}
                        <span className="think-chevron">
                            {thinkOpen ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
                        </span>
                    </button>
                    {
                        thinkOpen && (
                            <div className="think-content">
                                <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={rehypePlugins} components={markdownComponents}>
                                    {step.think}
                                </ReactMarkdown>
                            </div>
                        )
                    }
                </div>
            )}

            {hasContent && (
                <div className="step-content">
                    <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={rehypePlugins} components={markdownComponents}>
                        {step.content as string}
                    </ReactMarkdown>
                    {contentIsLive && <span className="stream-cursor" />}
                </div>
            )}

            {hasTools && (
                <div className="tool-calls-list">
                    {groupConsecutiveByName(toolEntries as ToolEntry[]).map((group, idx) =>
                        group.length > 1 ? (
                            <ToolCallGroup key={`group-${idx}`} entries={group} />
                        ) : (
                            <ToolCallItem key={group[0][0]} call={group[0][1] as ToolCallDetail} />
                        )
                    )}
                </div>
            )}
        </div>
    );
}

// ============================================================================
// AI MESSAGE
// ============================================================================

export function AIMessage({
    message,
    isStreaming = false,
}: {
    message: Message;
    isStreaming?: boolean;
}) {
    const [copied, setCopied] = useState(false);
    const steps = message.steps || [];
    const hasContent = Boolean(message.content && message.content.trim().length > 0 && !message.max_iter_reached);
    const hasFooterStats =
        !isStreaming && (hasContent || steps.length > 0);

    // Le texte final est normalement déjà visible dans le dernier step
    // (step.content, affiché par StepBlock) — le run_agent backend le
    // remplit désormais à chaque itération. On ne réaffiche le bloc du bas
    // que si ce texte n'y est PAS déjà (vieux messages sauvegardés avant ce
    // changement, qui n'ont que `content` au niveau du message et aucun
    // `step.content`), pour ne jamais montrer la même réponse deux fois.
    const lastStep = steps[steps.length - 1];
    const lastStepContent = (lastStep?.content || "").trim();
    const contentAlreadyShownInLastStep =
        lastStepContent.length > 0 && lastStepContent === (message.content || "").trim();
    const showBottomContent = (hasContent && !contentAlreadyShownInLastStep) || (isStreaming && steps.length === 0);

    const handleCopy = async () => {
        try {
            await navigator.clipboard.writeText(message.content || "");
            setCopied(true);
            setTimeout(() => setCopied(false), 1500);
        } catch {
            // pas critique si le clipboard n'est pas dispo
        }
    };

    return (
        <div className="msg-row msg-row-ai">
            <div className="msg-avatar msg-avatar-ai">
                <img src="/public/images/coralie/coralie.svg" alt="Coralie" width={15} height={15} />
            </div>

            <div className="msg-body">
                {steps.map((step, i) => (
                    <div key={i}>
                        {i > 0 && (
                            <div className="step-separator">
                                <span className="step-separator-label">Itération {i + 1}</span>
                            </div>
                        )}
                        <StepBlock step={step} isLast={i === steps.length - 1} isStreaming={isStreaming} />
                    </div>
                ))}

                {showBottomContent && (
                    <div className="msg-content">
                        <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={rehypePlugins} components={markdownComponents}>
                            {message.content}
                        </ReactMarkdown>
                        {isStreaming && steps.length === 0 && <span className="stream-cursor" />}
                    </div>
                )}

                {!hasContent && !isStreaming && steps.length === 0 && (
                    <div className="msg-content msg-content-empty">…</div>
                )}

                {hasFooterStats && (
                    <div className="msg-footer">
                        <button className="msg-footer-btn" onClick={handleCopy} title="Copier la réponse">
                            {copied ? <Check size={13} /> : <Copy size={13} />}
                            {copied ? "Copié" : "Copier"}
                        </button>

                        {message.total_time != null && (
                            <span className="msg-footer-stat" title="Temps total">
                                <Clock size={12} />
                                {formatDuration(message.total_time)}
                            </span>
                        )}

                        {message.iterations != null && message.iterations > 0 && (
                            <span className="msg-footer-stat" title="Itérations de la boucle agent">
                                {message.iterations} itér.
                            </span>
                        )}

                        {message.tool_calls_count != null && message.tool_calls_count > 0 && (
                            <span className="msg-footer-stat" title="Outils appelés">
                                <Wrench size={12} />
                                {message.tool_calls_count}
                            </span>
                        )}

                        {message?.max_iter_reached ? (
                            <span
                                className="msg-footer-stat msg-footer-status msg-footer-status--warning"
                                title="La limite d'itérations a été atteinte avant la conclusion de l'agent"
                            >
                                <AlertTriangle size={12} />
                                Max itér. atteint
                            </span>
                        ) : (
                            <span
                                className="msg-footer-stat msg-footer-status msg-footer-status--success"
                                title="L'agent a conclu normalement"
                            >
                                <CheckCircle2 size={12} />
                                Terminé
                            </span>
                        )}

                        {message.created_at && (
                            <span className="msg-footer-stat msg-footer-time">{formatTime(message.created_at)}</span>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}

// ============================================================================
// HUMAN MESSAGE
// ============================================================================

export function HumanMessage({ message }: { message: Message }) {
    return (
        <div className="msg-row msg-row-human">
            <div className="msg-bubble-human">
                <div className="msg-content-human">
                    <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={rehypePlugins} components={markdownComponents}>
                        {message.content}
                    </ReactMarkdown>
                </div>
                {message.created_at && <div className="msg-time-human">{formatTime(message.created_at)}</div>}
            </div>
            {/*<div className="msg-avatar msg-avatar-human">
                <User size={15} />
            </div>*/}
        </div>
    );
}