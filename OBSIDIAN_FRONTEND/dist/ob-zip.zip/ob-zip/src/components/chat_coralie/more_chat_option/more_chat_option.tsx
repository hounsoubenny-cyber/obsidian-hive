import { useState, useRef, useEffect } from 'react';
import { MoreVertical, Star, StarOff, Archive, ArchiveRestore, Pencil, Trash2 } from 'lucide-react';
import './more_chat_option.css';
import { InputModal } from '@/components/utils/input_modal/input_modal';
import { Conversation } from '@/types/chat_coralie/types';
import { createPortal } from 'react-dom';

interface MoreChatOptionProps {
  conversation: Conversation;
  handleDelete: (conv: Conversation) => void;
  handleSetFavorite: (conv: Conversation, favorite: boolean) => void;
  handleSetArchived: (conv: Conversation, archived: boolean) => void;
  handleRename: (conv: Conversation, name: string) => void;
}

export function MoreChatOption({
  conversation,
  handleDelete,
  handleSetFavorite,
  handleSetArchived,
  handleRename,
}: MoreChatOptionProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [position, setPosition] = useState({ top: 0, left: 0 });
  const [isRenaming, setIsRenaming] = useState(false);
  const [newName, setNewName] = useState('');
  const buttonRef = useRef<HTMLButtonElement>(null);

  const handleMenuClick = () => {
    if (buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      // Largeur/hauteur estimées du menu — doivent rester cohérentes avec
      // more_chat_option.css (.more-option-menu min-width + padding total).
      const MENU_WIDTH = 200;
      const MENU_HEIGHT_ESTIMATE = 190;
      const MARGIN = 8;

      let left = rect.left + window.scrollX - 100;
      let top = rect.bottom + window.scrollY + 4;

      // Ne jamais sortir de l'écran à gauche ou à droite.
      const minLeft = window.scrollX + MARGIN;
      const maxLeft = window.scrollX + window.innerWidth - MENU_WIDTH - MARGIN;
      left = Math.min(Math.max(left, minLeft), Math.max(maxLeft, minLeft));

      // Pas assez de place en dessous (ex: bouton tout en bas de la
      // sidebar) -> on ouvre le menu vers le HAUT à la place.
      const spaceBelow = window.innerHeight - rect.bottom;
      if (spaceBelow < MENU_HEIGHT_ESTIMATE) {
        top = rect.top + window.scrollY - MENU_HEIGHT_ESTIMATE - 4;
      }

      setPosition({ top, left });
    }
    setIsOpen(!isOpen);
  };

  // Ferme le menu si la fenêtre est redimensionnée / scrollée pendant qu'il
  // est ouvert plutôt que de laisser un menu mal positionné à l'écran.
  useEffect(() => {
    if (!isOpen) return;
    const close = () => setIsOpen(false);
    window.addEventListener('resize', close);
    window.addEventListener('scroll', close, true);
    return () => {
      window.removeEventListener('resize', close);
      window.removeEventListener('scroll', close, true);
    };
  }, [isOpen]);

  const handleRenameClick = () => {
    setNewName(conversation.title);
    setIsRenaming(true);
    setIsOpen(false);
  };

  const handleRenameValidate = (name: string) => {
    handleRename(conversation, name);
    setIsRenaming(false);
  };

  const handleFavoriteToggle = () => {
    handleSetFavorite(conversation, !conversation.is_favorite);
    setIsOpen(false);
  };

  const handleArchiveToggle = () => {
    handleSetArchived(conversation, !conversation.archived);
    setIsOpen(false);
  };

  const handleDeleteClick = () => {
    handleDelete(conversation);
    setIsOpen(false);
  };

  return (
    <>
      <button
        ref={buttonRef}
        onClick={handleMenuClick}
        className="more-option-btn"
        title="Plus d'options"
      >
        <MoreVertical size={18} />
      </button>

      {isOpen && createPortal(
        <>
          <div className="more-option-overlay" onClick={() => setIsOpen(false)} />
          <div
            className="more-option-menu"
            style={{
              top: position.top,
              left: position.left,
            }}
          >
            <button
              className="menu-item"
              onClick={handleFavoriteToggle}
            >
              {conversation.is_favorite ? (
                <>
                  <StarOff size={16} />
                  Retirer des favoris
                </>
              ) : (
                <>
                  <Star size={16} />
                  Ajouter aux favoris
                </>
              )}
            </button>

            <button
              className="menu-item"
              onClick={handleArchiveToggle}
            >
              {conversation.archived ? (
                <>
                  <ArchiveRestore size={16} />
                  Désarchiver
                </>
              ) : (
                <>
                  <Archive size={16} />
                  Archiver
                </>
              )}
            </button>

            <button
              className="menu-item"
              onClick={handleRenameClick}
            >
              <Pencil size={16} />
              Renommer
            </button>

            <hr className="menu-divider" />

            <button
              className="menu-item menu-item-danger"
              onClick={handleDeleteClick}
            >
              <Trash2 size={16} />
              Supprimer
            </button>
          </div>
        </>
      , document.body)}

      <InputModal
        isOpen={isRenaming}
        onClose={() => setIsRenaming(false)}
        onValidate={handleRenameValidate}
        value={newName}
        setValue={setNewName}
        title="Renommer la conversation"
        placeholder="Entrez le nouveau nom"
        confirmLabel="Renommer"
        cancelLabel="Annuler"
      />
    </>
  );
}