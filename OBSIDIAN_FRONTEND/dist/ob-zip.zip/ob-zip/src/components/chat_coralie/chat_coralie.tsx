import "./chat_coralie.css";
import { AgentStep, Conversation, Message, RiskMapping } from "@/types/chat_coralie/types";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AIMessage, HumanMessage } from "./ai_human_messages/ai_human_messages";

import {
    Bell,
    Check,
    Loader2,
    Pencil,
    PlusCircle,
    Search,
    SendHorizontal,
    ShieldAlert,
    Sparkles,
    SidebarClose,
    SidebarOpen,
    X,
    XCircle,
} from "lucide-react";
import {
    conversationSortOptions,
    conversationSortOptionsValues,
    deleteConversation,
    getMessages,
    listConversations,
    setArchived,
    setFavorite,
    sortConversations,
    updateConversationTitle,
} from "./utils";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { getToken, getUsername, isLogin, refreshToken } from "@/hooks/get_token";
import toast from "react-hot-toast";
import { ConversationPreview } from "./conversation_preview/conversation_preview";
import { useWSStore } from "@/store/websocket_store";
import { AppConfig, getConfig } from "@/hooks/get_config";
import ChatSideBar from "./chat_sidebar/chat_sidebar";
import {
    ConfirmationRequestData,
    WSConfirmationRequestEvent,
    WSConversationBusyEvent,
    WSConversationCreatedEvent,
    WSErrorEvent,
    WSEventType,
    WSEventTypeVals,
    WSFinishEvent,
    WSServerEvent,
    WSStreamStartEvent,
    WSStreamTokenEvent,
    WSToolCallsPlannedEvent,
    WSToolExecEvent,
} from "@/types/websockets/types";
import { getGreeting } from "../utils/greeting";

// ============================================================
// FILTRE
// ============================================================

function filterConversations(conversations: Conversation[], query: string): Conversation[] {
    if (!query.trim()) return conversations;
    const searchTerm = query.trim().toLowerCase();
    return conversations.filter((conv) => conv.title.toLowerCase().includes(searchTerm));
}

// ============================================================
// SEARCH COMPONENT
// ============================================================

function SearchConversationComponant({
    conversations,
    onSelectConversation,
    handleDelete,
    handleSetFavorite,
    handleSetArchived,
    handleRename,
    onClose,
}: {
    conversations: Conversation[] | null;
    onSelectConversation: (conv: Conversation) => void;
    handleSetFavorite: (conv: Conversation, favorite: boolean) => void;
    handleSetArchived: (conv: Conversation, archived: boolean) => void;
    handleRename: (conv: Conversation, name: string) => void;
    handleDelete: (conv: Conversation) => void;
    onClose: () => void;
}) {
    const haveConv = Boolean(conversations);
    const [query, setQuery] = useState<string>("");

    if (!haveConv) {
        return (
            <div className="chat-search">
                <div className="chat-search-header">
                    <button className="chat-search-close" title="Fermer" onClick={onClose}>
                        <X size={18} /> Fermer
                    </button>
                </div>
                <div className="chat-search-empty">Pas de conversations pour filtrer !</div>
            </div>
        );
    }

    const filtered: Conversation[] = filterConversations(conversations as Conversation[], query) || [];
    const filteredLength = filtered?.length || 0;

    return (
        <div id="chat-search" className="chat-search">
            <div className="chat-search-header">
                <button className="chat-search-close" title="Fermer" onClick={onClose}>
                    <X size={18} /> Fermer
                </button>
            </div>

            <div className="chat-search-input-wrapper">
                <Search size={15} className="chat-search-icon" />
                <input
                    type="text"
                    className="chat-search-input"
                    placeholder="Rechercher une conversation..."
                    value={query}
                    autoFocus
                    onChange={(e) => setQuery(e.target.value)}
                />
            </div>

            <div className="chat-search-results">
                {filteredLength === 0 ? (
                    <div className="chat-search-no-result">Aucun match pour « {query} »</div>
                ) : (
                    <div>
                        <div className="chat-search-count">
                            {filteredLength >= 2 ? `${filteredLength} chats` : `${filteredLength} chat`}
                        </div>
                        <div className="chat-search-list">
                            {filtered.map((conv, key) => (
                                <div
                                    key={`${key}-${conv.conversation_id}`}
                                    className="chat-search-item"
                                    onClick={(e) => e.stopPropagation()}
                                >
                                    <ConversationPreview
                                        conv={conv}
                                        onSelectConversation={onSelectConversation}
                                        handleDelete={handleDelete}
                                        handleRename={handleRename}
                                        handleSetArchived={handleSetArchived}
                                        handleSetFavorite={handleSetFavorite}
                                    />
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}

// ============================================================
// TITRE ÉDITABLE (clic pour renommer)
// ============================================================

function EditableTitle({
    conversation,
    onRename,
}: {
    conversation: Conversation;
    onRename: (conv: Conversation, name: string) => void;
}) {
    const [editing, setEditing] = useState(false);
    const [value, setValue] = useState(conversation.title);
    const inputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        if (!editing) setValue(conversation.title);
    }, [conversation.title, editing]);

    useEffect(() => {
        if (editing) {
            inputRef.current?.focus();
            inputRef.current?.select();
        }
    }, [editing]);

    const commit = () => {
        setEditing(false);
        const trimmed = value.trim();
        if (trimmed && trimmed !== conversation.title) {
            onRename(conversation, trimmed);
        } else {
            setValue(conversation.title);
        }
    };

    if (editing) {
        return (
            <input
                ref={inputRef}
                className="chat-title-input"
                value={value}
                maxLength={100}
                onChange={(e) => setValue(e.target.value)}
                onBlur={commit}
                onKeyDown={(e) => {
                    if (e.key === "Enter") commit();
                    if (e.key === "Escape") {
                        setValue(conversation.title);
                        setEditing(false);
                    }
                }}
            />
        );
    }

    return (
        <button className="chat-title-display" onClick={() => setEditing(true)} title="Cliquer pour renommer">
            <span className="chat-title-text">{conversation.title}</span>
            <Pencil size={13} className="chat-title-edit-icon" />
        </button>
    );
}

// ============================================================
// ZONE DE CHAT (liste des messages + input)
// ============================================================

function ChatComponant({
    wsIsConnected,
    sendMessage,
    currentConversation,
    currentConversationMessages,
    responseIsLoading,
    currentMessage,
    handleRename,
    projectName,
}: {
    wsIsConnected: boolean;
    sendMessage: (text: string) => void;
    currentConversation: Conversation | null;
    currentConversationMessages: Message[] | null;
    responseIsLoading: boolean;
    currentMessage: Message | null;
    handleRename: (conv: Conversation, name: string) => void;
    projectName?: string | null;
}) {
    const [input, setInput] = useState("");
    const bottomRef = useRef<HTMLDivElement>(null);
    const scrollContainerRef = useRef<HTMLDivElement>(null);
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    // Reste collé en bas tant que l'utilisateur n'a pas remonté manuellement
    // dans l'historique. Dès qu'il scrolle loin du bas, on arrête de le
    // "ramener" de force à chaque nouveau token — sinon impossible de relire
    // un message précédent pendant que Coralie répond encore.
    const stickToBottomRef = useRef(true);
    const SCROLL_BOTTOM_THRESHOLD = 96;

    const handleMessagesScroll = () => {
        const el = scrollContainerRef.current;
        if (!el) return;
        const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
        stickToBottomRef.current = distanceFromBottom < SCROLL_BOTTOM_THRESHOLD;
    };

    const username = getUsername();

    // useMemo pour ne piocher la phrase qu'une fois (pas à chaque re-render,
    // sinon ça changerait de phrase à chaque frappe dans le textarea).
    const greeting = useMemo(() => getGreeting(username, projectName, "Coralie"), [username, projectName]);

    const allMessages: Message[] = [
        ...(currentConversationMessages || []),
        ...(currentMessage ? [currentMessage] : []),
    ];

    useEffect(() => {
        if (!stickToBottomRef.current) return;
        bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [allMessages.length, currentMessage?.content, currentMessage?.steps]);

    // Nouvelle conversation ouverte : on repart toujours collé en bas, même
    // si on avait remonté dans l'historique de la conversation précédente.
    useEffect(() => {
        stickToBottomRef.current = true;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [currentConversation?.conversation_id]);

    const autoGrow = () => {
        const el = textareaRef.current;
        if (!el) return;
        el.style.height = "auto";
        el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
    };

    const handleSend = () => {
        const text = input.trim();
        if (!text || responseIsLoading || !wsIsConnected) return;
        stickToBottomRef.current = true;
        sendMessage(text);
        setInput("");
        requestAnimationFrame(autoGrow);
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    return (
        <div className="chat-main-wrapper">
            <div className="chat-main-header">
                {currentConversation ? (
                    <EditableTitle conversation={currentConversation} onRename={handleRename} />
                ) : (
                    <span className="chat-title-text chat-title-new">✨ Nouvelle conversation</span>
                )}

                <span className={`chat-connection-badge ${wsIsConnected ? "is-online" : "is-offline"}`}>
                    <span className="dot" />
                    {wsIsConnected ? "Connecté" : "Hors ligne"}
                </span>
            </div>

            <div className="chat-messages-scroll" ref={scrollContainerRef} onScroll={handleMessagesScroll}>
                {allMessages.length === 0 ? (
                    <div className="chat-empty-state">
                        <div className="chat-empty-icon">🛡️</div>
                        <h3>{greeting.title}</h3>
                        <p>{greeting.subtitle}</p>
                    </div>
                ) : (
                    <div className="chat-messages-list">
                        {allMessages.map((msg, i) => {
                            const isTheStreamingOne = Boolean(currentMessage) && msg === currentMessage;

                            if (msg.role === "user") {
                                return <HumanMessage key={i} message={msg} />;
                            }

                            // Le message assistant existe déjà (créé dès STREAM_START)
                            // mais tant que genStart est false, aucun token (think ou
                            // content) n'est encore arrivé : il n'y a rien à afficher
                            // pour ce message, le typing indicator prend le relai
                            // juste en dessous plutôt que de montrer une bulle vide.
                            if (isTheStreamingOne && responseIsLoading && !msg.genStart) {
                                return null;
                            }

                            return (
                                <AIMessage
                                    key={i}
                                    message={msg}
                                    isStreaming={isTheStreamingOne && responseIsLoading}
                                />
                            );
                        })}
                        
                        {/* genStart */}

                        {responseIsLoading && (!currentMessage || !currentMessage?.genEnd) && ( 
                            <div className="msg-row msg-row-ai">
                                <div className="msg-avatar msg-avatar-ai">
                                    <img src="/public/images/coralie/coralie.svg" alt="Coralie" width={15} height={15} />
                                </div>
                                <div className="typing-indicator">
                                    <span />
                                    <span />
                                    <span />
                                </div>
                            </div>
                        )}

                        <div ref={bottomRef} />
                    </div>
                )}
            </div>

            <div className="chat-input-bar">
                <textarea
                    ref={textareaRef}
                    className="chat-input-textarea"
                    placeholder={
                        wsIsConnected
                            ? "Écris ton message à Coralie... (Entrée pour envoyer, Maj+Entrée pour une nouvelle ligne)"
                            : "En attente de connexion..."
                    }
                    value={input}
                    disabled={!wsIsConnected}
                    rows={1}
                    onChange={(e) => {
                        setInput(e.target.value);
                        autoGrow();
                    }}
                    onKeyDown={handleKeyDown}
                />
                <button
                    className="chat-send-btn"
                    onClick={handleSend}
                    disabled={!input.trim() || responseIsLoading || !wsIsConnected}
                    title="Envoyer"
                >
                    {responseIsLoading ? <Loader2 size={18} className="spin" /> : <SendHorizontal size={18} />}
                </button>
            </div>
        </div>
    );
}

// ============================================================
// PANNEAU DE CONFIRMATIONS
// ============================================================

function ConfirmationComponant({
    confirmations,
    respondToConfirmation,
    onClose,
}: {
    confirmations: ConfirmationRequestData[];
    onClose: () => void;
    respondToConfirmation: (req_id: string, response: boolean) => void;
}) {
    const renderArgs = (args: Record<string, any>) => {
        if (!args) return "";
        const entries = Object.entries(args);
        return entries.map(([key, value], idx) => (
            <span key={key}>
                <span className="confirm-arg-key">{key}</span>=
                <span className="confirm-arg-val">{String(value)}</span>
                {idx !== entries.length - 1 ? ", " : ""}
            </span>
        ));
    };

    return (
        <div className="confirmation-panel">
            <div className="confirmation-panel-header">
                <span className="confirmation-panel-title">
                    <ShieldAlert size={15} /> Confirmations
                </span>
                <button className="confirmation-panel-close" title="Fermer" onClick={onClose}>
                    <X size={16} />
                </button>
            </div>

            {(confirmations?.length || 0) === 0 ? (
                <div className="confirmation-panel-empty">Pas de confirmation en attente ✅</div>
            ) : (
                <>
                    <div className="confirmation-panel-bulk">
                        <button
                            className="confirm-btn confirm-btn-deny"
                            onClick={() => confirmations.forEach((val) => {respondToConfirmation(val.req_id, false); onClose();})}
                        >
                            <XCircle size={14} /> Tout refuser
                        </button>
                        <button
                            className="confirm-btn confirm-btn-approve"
                            onClick={() => confirmations.forEach((val) => {respondToConfirmation(val.req_id, true); onClose();})}
                        >
                            <Check size={14} /> Tout accepter
                        </button>
                    </div>

                    <div className="confirmation-panel-list">
                        {confirmations.map((confirmation) => (
                            <div key={confirmation.req_id} className={`confirmation-card risk-${confirmation.risk}`}>
                                <div className="confirmation-card-title">
                                    <span className="confirmation-tool-name">{confirmation.tool}</span>
                                    <span className={`confirmation-risk-badge risk-${confirmation.risk}`}>
                                        {RiskMapping[confirmation.risk] || "Faible"}
                                    </span>
                                </div>
                                <div className="confirmation-card-args">{renderArgs(confirmation.args)}</div>
                                <div className="confirmation-card-actions">
                                    <button
                                        className="confirm-btn confirm-btn-deny"
                                        onClick={() => respondToConfirmation(confirmation.req_id, false)}
                                    >
                                        <XCircle size={14} /> Refuser
                                    </button>
                                    <button
                                        className="confirm-btn confirm-btn-approve"
                                        onClick={() => respondToConfirmation(confirmation.req_id, true)}
                                    >
                                        <Check size={14} /> Valider
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </>
            )}
        </div>
    );
}

// ============================================================
// PAGE PRINCIPALE
// ============================================================

function ChatCoraliePage() {
    const naviguate = useNavigate();
    const [searchParams, setSearchParams] = useSearchParams();
    const conversationIdFromUrl = searchParams.get("conversation_id");

    // Conversations
    const [conversations, setConversations] = useState<Conversation[] | null>(null);
    const [_conversations, _setConversations] = useState<Conversation[] | null>(null);
    const [conversationsLoading, setConversationsLoading] = useState<boolean>(false);
    const [conversationsError, setConversationsError] = useState<string | null>(null);

    const [opOnConvError, setOpOnConvError] = useState<string | null>(null);
    const [opOnConvLoading, setOpOnConvLoading] = useState<boolean>(false);

    // SideBar
    const [showSideBar, setShowSideBar] = useState<boolean>(true);
    const [sortBy, setSortBy] = useState<conversationSortOptionsValues>("updated_at.desc");

    // Search
    const [searchIsOpen, setSearchIsOpen] = useState<boolean>(false);

    // Chat
    const [currentConv, setCurrentConv] = useState<Conversation | null>(null);
    const [currentConvMsgs, setCurrentConvMsgs] = useState<Message[] | null>(null);
    const [currentConvMsgsLoading, setCurrentConvMsgsLoading] = useState<boolean>(false);
    const [currentConvMsgsError, setCurrentConvMsgsError] = useState<string | null>(null);
    const [responseIsLoading, setResponseisLoading] = useState<boolean>(false);
    const [config, setConfig] = useState<AppConfig | null>(null);
    const [wsUrl, setWsUrl] = useState<string | null>(null);
    const [projectName, setProjectName] = useState<string | null>(null);
    const { ws, connect, isConnected, sendMessage } = useWSStore();

    const currentMessageRef = useRef<Message | null>(null);
    const [streamingMessage, setStreamingMessage] = useState<Message | null>(null);
    const currentStep = useRef<AgentStep | null>(null);
    const currentIteration = useRef<number | null>(null);

    // Message user ajouté de façon optimiste (avant confirmation serveur) —
    // gardé en ref pour pouvoir le retirer précisément si le serveur répond
    // "conversation_busy" (il ne sera jamais traité par ce run-là).
    const lastOptimisticUserMessageRef = useRef<Message | null>(null);

    // Timeout du cooldown affiché après un conversation_busy — annulé dès
    // que STREAM_START confirme que le run réel s'est manifesté (voir les
    // cases CONVERSATION_BUSY / STREAM_START plus bas).
    const busyCooldownRef = useRef<ReturnType<typeof setTimeout> | null>(null);

    const [confirmations, setConfirmations] = useState<ConfirmationRequestData[]>([]);
    const [showConfirmationComponant, setShowConfirmationComponant] = useState<boolean>(false);

    const currentConvRef = useRef<Conversation | null>(null);
    // Garantit qu'on appelle connect() une seule fois pour de bon, dès que
    // wsUrl est dispo — évite la boucle "connect() -> ws change -> effet
    // re-tourne -> connect() encore" (ws faisait partie des deps avant).
    const hasConnectedRef = useRef<boolean>(false);

    // Évite de retenter un refresh token en boucle si le refresh lui-même
    // échoue (refreshToken() redirige déjà vers /login dans ce cas) —
    // remis à false dès qu'une connexion s'ouvre avec succès.
    const hasRetriedAuthRef = useRef<boolean>(false);

    // ---- Helpers de synchro ref <-> state (React ne re-render jamais sur
    // une simple mutation de useRef — on mute le ref librement pendant
    // onMessage, puis on "publie" un clone vers le useState correspondant
    // pour déclencher le re-render). ----

    const setCurrentConvRef = (conv: Conversation | null) => {
        currentConvRef.current = conv;
    };

    const syncConv = () => {
        setCurrentConv(currentConvRef.current ? (structuredClone(currentConvRef.current) as Conversation) : null);
    };

    const updateCurrentConv = (conv: Conversation | null) => {
        setCurrentConvRef(conv);
        syncConv();
    };

    const syncStreamingMessage = () => {
        setStreamingMessage(
            currentMessageRef.current ? (structuredClone(currentMessageRef.current) as Message) : null
        );
    };

    const closeConfirmationComponant = () => setShowConfirmationComponant(false);
    const openConfirmationComponant = () => setShowConfirmationComponant(true);

    const reload = async () => {
        const listData = {
            include_archived: true,
            favorites_only: false,
            limit: null,
            offset: 0,
        };
        await listConversations(listData, _setConversations, setConversationsError, setConversationsLoading, naviguate);
    };

    const loadConfig = async () => {
        const conf = await getConfig();
        setConfig(conf);
        setWsUrl(conf.wsUrl);
        setProjectName(conf.productName)
    };

    useEffect(() => {
        reload();
        loadConfig();
    }, []);

    // Attache le token courant à l'URL WS (gère aussi le cas où wsUrl
    // contiendrait déjà une query string).
    const buildWsUrl = (base: string) => {
        const sep = base.includes("?") ? "&" : "?";
        return `${base}${sep}token=${encodeURIComponent(getToken() || "")}`;
    };

    // Le backend ferme la WS avec le code 1008 (policy violation) quand le
    // token est invalide ou expiré, AVANT même d'accepter la connexion —
    // donc jamais d'onopen dans ce cas, juste un onclose avec ce code.
    const handleWsClose = async (event: CloseEvent) => {
        if (event.code !== 1008) return; // coupure réseau normale, rien à faire ici

        if (hasRetriedAuthRef.current) {
            toast.error("❌ Session expirée, reconnecte-toi");
            naviguate("/login");
            return;
        }
        hasRetriedAuthRef.current = true;

        const token = getToken();
        const ok = token ? await refreshToken(token, naviguate) : false;
        // Si refreshToken a échoué, il vide déjà sessionStorage et redirige
        // vers /login lui-même — pas besoin de le refaire ici.
        if (ok && wsUrl) {
            hasConnectedRef.current = false; // on va reconnecter explicitement
            connect(buildWsUrl(wsUrl), { onOpen: () => (hasRetriedAuthRef.current = false), onClose: handleWsClose });
        }
    };

    // Effet 1 : se connecter — une seule fois, dès que wsUrl est dispo. Ne
    // dépend PAS de `ws` (sinon : connect() -> le store met ws à jour ->
    // effet re-tourne parce que ws a changé -> connect() encore...).
    useEffect(() => {
        if (!wsUrl || hasConnectedRef.current) return;
        hasConnectedRef.current = true;
        connect(buildWsUrl(wsUrl), {
            onOpen: () => { hasRetriedAuthRef.current = false; },
            onClose: handleWsClose,
        });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [wsUrl]);

    // Effet 2 : attacher/détacher le listener de messages — dépend
    // UNIQUEMENT de `ws`. React exécute automatiquement le cleanup de
    // l'effet précédent (sur l'ancien ws) avant de relancer celui-ci sur le
    // nouveau ws : jamais de doublon, jamais d'oubli, plus besoin d'un flag
    // manuel type "messageListenerAttached".
    useEffect(() => {
        if (!ws) return;
        ws.addEventListener("message", onMessage);
        return () => ws.removeEventListener("message", onMessage);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [ws]);

    useEffect(() => {
        if (_conversations) {
            setConversations(sortConversations(_conversations, sortBy) || _conversations);
        }
    }, [_conversations, sortBy]);

    // Ouvre directement la conversation passée en ?conversation_id=... au
    // premier chargement de la liste, si aucune conversation n'est déjà
    // sélectionnée.
    useEffect(() => {
        if (conversationIdFromUrl && _conversations && !currentConvRef.current) {
            const found = _conversations.find((c) => c.conversation_id === conversationIdFromUrl);
            if (found) handleSelectConversation(found);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [_conversations]);

    const resetStep = () => {
        currentStep.current = {
            think: "",
            content: "",
            tool_calls: {},
            attempts: null,
            started_at: null,
            ended_at: null,
            duration: null,
            attempts_error: {},
        } as AgentStep;
        return currentStep.current;
    };

    const openSearchComponant = () => setSearchIsOpen(true);
    const closeSearchComponant = () => setSearchIsOpen(false);

    const getMessagesOfConv = async (conv: Conversation | null) => {
        if (!conv) {
            setCurrentConvMsgs([]);
            return;
        }
        const data = { conversation_id: conv.conversation_id, id: conv.id };
        const params = { limit: null, offset: 0 };
        await getMessages(data, params, setCurrentConvMsgs, setCurrentConvMsgsError, setCurrentConvMsgsLoading, naviguate);
    };

    const handleSelectConversation = async (conv: Conversation | null) => {
        if (responseIsLoading) {
            toast("⏳ Attends la fin de la réponse en cours avant de changer de conversation");
            return;
        }
        closeSearchComponant();
        updateCurrentConv(conv);
        currentMessageRef.current = null;
        setStreamingMessage(null);
        //setSearchParams(conv ? { conversation_id: conv.conversation_id } : {}, { replace: true });
        setSearchParams(prev => {
            if (!!conv){
                prev.set("conversation_id", conv.conversation_id);
            }
            else {
                prev.delete("conversation_id");
            }
            return prev;
        }, { replace: true });
        await getMessagesOfConv(conv);
    };

    const handleSetArchived = async (conv: Conversation, archived: boolean) => {
        if (conv.is_favorite) {
            toast("ℹ️ La conversation est déjà favorite, pour l'archiver, retirez-la des favoris");
            return;
        }
        const data = { conversation_id: conv.conversation_id, id: conv.id };
        const success = await setArchived(data, archived, setOpOnConvError, setOpOnConvLoading, naviguate);
        if (success) {
            toast.success(`Conversation ${archived ? "archivée" : "désarchivée"}`);
            await reload();
        } else {
            toast.error("Échec de l'opération !");
        }
    };

    const handleSetFavorite = async (conv: Conversation, favorite: boolean) => {
        if (conv.archived) {
            toast("ℹ️ La conversation est déjà archivée, pour la mettre en favoris, retirez-la des archives");
            return;
        }
        const data = { conversation_id: conv.conversation_id, id: conv.id };
        const success = await setFavorite(data, favorite, setOpOnConvError, setOpOnConvLoading, naviguate);
        if (success) {
            toast.success(`Conversation ${favorite ? "ajoutée aux favoris" : "retirée des favoris"}`);
            await reload();
        } else {
            toast.error("Échec de l'opération !");
        }
    };

    const handleRename = async (conv: Conversation, name: string) => {
        if (!name.trim()) return;
        const data = { conversation_id: conv.conversation_id, id: conv.id };
        const success = await updateConversationTitle(data, name.trim(), setOpOnConvError, setOpOnConvLoading, naviguate);
        if (success) {
            toast.success(`Conversation renommée en "${name.trim()}"`);
            if (currentConvRef.current?.conversation_id === conv.conversation_id) {
                updateCurrentConv({ ...currentConvRef.current, title: name.trim() } as Conversation);
            }
            await reload();
        } else {
            toast.error("Échec de l'opération !");
        }
    };

    const handleDelete = async (conv: Conversation) => {
        if (!confirm("Supprimer la conversation ? L'opération est irréversible !")) {
            toast("ℹ️ Suppression annulée !");
            return;
        }
        const data = { conversation_id: conv.conversation_id, id: conv.id };
        const success = await deleteConversation(data, setOpOnConvError, setOpOnConvLoading, naviguate);
        if (success) {
            toast.success("Conversation supprimée avec succès !");
            if (currentConvRef.current?.conversation_id === conv.conversation_id) {
                updateCurrentConv(null);
                setCurrentConvMsgs(null);
            }
            await reload();
        } else {
            toast.error("Échec de la suppression !");
        }
    };

    // Appelé quand un run (chat) se termine, en succès ou en erreur : on
    // recharge l'historique officiel depuis la DB, on rafraîchit la sidebar
    // (nouveau titre auto-généré, updated_at...) et on vide l'état de
    // streaming en cours. On NE touche jamais à currentConvRef ici — la
    // conversation reste sélectionnée après la réponse.
    const onGenerationEnd = async () => {
        await getMessagesOfConv(currentConvRef.current);
        await reload();
        currentMessageRef.current = null;
        currentIteration.current = null;
        lastOptimisticUserMessageRef.current = null;
        syncStreamingMessage();
    };

    const sendMessageFunc = (text: string) => {
        if (!(text || "").trim() || responseIsLoading) return;
        const msg = text.trim();
        const data = {
            type: "chat",
            message: msg,
            conversation_id: currentConvRef.current?.conversation_id || null,
        };
        const message: Message = {
            content: msg,
            role: "user",
            conversation_pk: currentConvRef.current?.id,
            created_at: new Date().toISOString(),
        };
        // gardé pour pouvoir le retirer précisément si le serveur répond
        // "conversation_busy" (voir onMessage)
        lastOptimisticUserMessageRef.current = message;
        setCurrentConvMsgs((prev) => [...(prev || []), message]);
        sendMessage(data);
    };

    const onConfirmation = (data: ConfirmationRequestData) => {
        setConfirmations((prev) => [...prev, data]);
        setShowConfirmationComponant(true);
    };

    const respondToConfirmation = (req_id: string, approved: boolean) => {
        if (!isConnected || ws?.readyState !== WebSocket.OPEN) {
            toast.error("❌ WebSocket non connecté");
            return;
        }
        const response = { type: "confirmation_response", req_id, approved };
        sendMessage(response);
        setConfirmations((prev) => prev.filter((c) => c.req_id !== req_id));
        toast.success(approved ? "✅ Confirmé" : "❌ Refusé");
    };

    const onMessage = (event: MessageEvent) => {
        const data_: WSServerEvent = JSON.parse(event.data);
        const type: WSEventTypeVals = data_.type;

        switch (type) {
            case WSEventType.CONVERSATION_CREATED: {
                const data = data_ as WSConversationCreatedEvent;
                updateCurrentConv({
                    ...(currentConvRef.current || {}),
                    conversation_id: data.conversation_id,
                } as Conversation);
                //setSearchParams({ conversation_id: data.conversation_id }, { replace: true });
                setSearchParams(prev => {
                    prev.set("conversation_id", data.conversation_id);
                    return prev;
                }, { replace: true });
                break;
            }

            case WSEventType.CONVERSATION_BUSY: {
                const data = data_ as WSConversationBusyEvent;
                toast(`⏳ ${data.message || "Un run est déjà en cours pour cette conversation, patiente."}`);

                // On retire le message optimiste ajouté localement au clic
                // sur Envoyer : le serveur ne va JAMAIS le traiter, ce n'est
                // pas notre message qui a été refusé mais un run réel
                // (parfois lancé depuis un autre onglet, ou une ancienne
                // connexion pas encore totalement fermée après un reload)
                // qui tourne déjà sur cette conversation.
                const stale = lastOptimisticUserMessageRef.current;
                if (stale) {
                    setCurrentConvMsgs((prev) => (prev || []).filter((m) => m !== stale));
                    lastOptimisticUserMessageRef.current = null;
                }

                if (currentMessageRef.current) {
                    currentMessageRef.current.genStart = false;
                    currentMessageRef.current.genEnd = true;
                }

                // Cooldown de courte durée : on affiche "en cours" un
                // instant pour éviter que l'utilisateur ne spamme Envoyer,
                // MAIS on l'annule dès que le run réel se manifeste (voir
                // STREAM_START ci-dessous) pour ne jamais bloquer l'UI en
                // pleine génération active si jamais le run répond vite.
                setResponseisLoading(true);
                if (busyCooldownRef.current) clearTimeout(busyCooldownRef.current);
                busyCooldownRef.current = setTimeout(() => {
                    setResponseisLoading(false);
                    busyCooldownRef.current = null;
                }, 2000);
                break;
            }

            case WSEventType.STREAM_START: {
                // Annule le cooldown de conversation_busy s'il est encore
                // actif : le run réel vient de se manifester, plus besoin
                // du filet de sécurité — la suite (FINISH/ERROR) gérera
                // responseIsLoading normalement.
                if (busyCooldownRef.current) {
                    clearTimeout(busyCooldownRef.current);
                    busyCooldownRef.current = null;
                }
                setResponseisLoading(true);
                const data = data_ as WSStreamStartEvent;

                if (currentIteration.current === null) {
                    currentIteration.current = data.iteration;
                    resetStep();
                    currentMessageRef.current = {
                        role: "assistant",
                        content: "",
                        conversation_pk: currentConvRef.current?.id,
                        iterations: data.iteration,
                        steps: [currentStep.current as AgentStep],
                        tool_calls_count: 0,
                        total_time: null,
                        created_at: new Date().toISOString(),
                        genStart: false,
                        genEnd: true,
                    };
                } else if (currentIteration.current !== data.iteration && currentMessageRef.current) {
                    resetStep();
                    currentIteration.current = data.iteration;
                    currentMessageRef.current.iterations = data.iteration;
                    currentMessageRef.current.steps = [
                        ...(currentMessageRef.current.steps || []),
                        currentStep.current as AgentStep,
                    ];
                }
                syncStreamingMessage();
                break;
            }

            case WSEventType.REASONING_TOKEN: {
                const data = data_ as WSStreamTokenEvent;
                if (currentMessageRef.current) {
                    currentMessageRef.current.genStart = true;
                    currentMessageRef.current.genEnd = false;
                    const steps = [...(currentMessageRef.current.steps || [])];
                    const last = { ...(steps[steps.length - 1] || {}) } as AgentStep;
                    last.think = (last.think || "") + data.text;
                    steps[steps.length - 1] = last;
                    currentMessageRef.current.steps = steps;
                    syncStreamingMessage();
                }
                break;
            }

            case WSEventType.TOKEN: {
                const data = data_ as WSStreamTokenEvent;
                if (currentMessageRef.current) {
                    currentMessageRef.current.genStart = true;
                    currentMessageRef.current.genEnd = false;
                    // Le texte va dans le step courant (steps[last].content),
                    // PAS dans message.content directement — comme ça il
                    // s'affiche "à sa place" dans l'itération qui l'a
                    // produit, plutôt que de s'accumuler tout en bas peu
                    // importe quand il a été dit. message.content, lui,
                    // n'est renseigné qu'au FINISH avec la vraie réponse
                    // finale officielle (voir case FINISH plus bas).
                    const steps = [...(currentMessageRef.current.steps || [])];
                    const last = { ...(steps[steps.length - 1] || {}) } as AgentStep;
                    last.content = (last.content || "") + data.text;
                    steps[steps.length - 1] = last;
                    currentMessageRef.current.steps = steps;
                    syncStreamingMessage();
                }
                break;
            }

            case WSEventType.TOOL_CALLS_PLANNED: {
                const data = data_ as WSToolCallsPlannedEvent;
                if (currentMessageRef.current) {
                    const steps = [...(currentMessageRef.current.steps || [])];
                    const last = { ...(steps[steps.length - 1] || {}) } as AgentStep;
                    const toolCalls: Record<string, any> = {};
                    (data.tool_calls || []).forEach((tc) => {
                        toolCalls[tc.id] = {
                            name: tc.name,
                            args: null,
                            args_str: null,
                            started_at: null,
                            ended_at: null,
                            duration: null,
                            success: null,
                            result: null,
                            status: "planned",
                        };
                    });
                    last.tool_calls = toolCalls;
                    steps[steps.length - 1] = last;
                    currentMessageRef.current.steps = steps;
                    currentMessageRef.current.tool_calls_count = data.tool_calls?.length || 0;
                    syncStreamingMessage();
                }
                break;
            }

            case WSEventType.TOOL_EXEC_START: {
                const data = data_ as WSToolExecEvent;
                if (currentMessageRef.current) {
                    const steps = [...(currentMessageRef.current.steps || [])];
                    const last = { ...(steps[steps.length - 1] || {}) } as AgentStep;
                    // Matching par id exact (clé du dict tool_calls, déjà
                    // posée par TOOL_CALLS_PLANNED) — indispensable dès que
                    // plusieurs appels du MÊME outil sont "planned" en même
                    // temps (exécution parallèle backend). Fallback sur
                    // l'ancien matching par nom si jamais data.id est absent
                    // (backend pas encore patché, ou id non fourni par le
                    // provider) — filet de sécurité, pas le chemin normal.
                    const id = data.id && last.tool_calls?.[data.id] ? data.id : null;
                    const fallbackEntry = !id
                        ? Object.entries(last.tool_calls || {}).find(
                              ([, v]: [string, any]) => v.name === data.tool && v.status === "planned"
                          )
                        : null;
                    const matchedId = id || (fallbackEntry ? fallbackEntry[0] : null);
                    const call = matchedId ? (last.tool_calls || {})[matchedId] : null;

                    if (matchedId && call) {
                        last.tool_calls = {
                            ...last.tool_calls,
                            [matchedId]: {
                                ...call,
                                args: data.args,
                                args_str: JSON.stringify(data.args || {}),
                                status: "executing",
                                started_at: Date.now(),
                            },
                        };
                    }
                    steps[steps.length - 1] = last;
                    currentMessageRef.current.steps = steps;
                    syncStreamingMessage();
                }
                break;
            }

            case WSEventType.TOOL_EXEC_END: {
                const data = data_ as WSToolExecEvent;
                if (currentMessageRef.current) {
                    const steps = [...(currentMessageRef.current.steps || [])];
                    const last = { ...(steps[steps.length - 1] || {}) } as AgentStep;
                    const id = data.id && last.tool_calls?.[data.id] ? data.id : null;
                    const fallbackEntry = !id
                        ? Object.entries(last.tool_calls || {}).find(
                              ([, v]: [string, any]) => v.name === data.tool && v.status === "executing"
                          )
                        : null;
                    const matchedId = id || (fallbackEntry ? fallbackEntry[0] : null);
                    const call = matchedId ? (last.tool_calls || {})[matchedId] : null;

                    if (matchedId && call) {
                        const endedAt = Date.now();
                        last.tool_calls = {
                            ...last.tool_calls,
                            [matchedId]: {
                                ...call,
                                status: "done",
                                result: data.result,
                                success: true,
                                ended_at: endedAt,
                                duration: (endedAt - (call.started_at || endedAt)) / 1000,
                            },
                        };
                    }
                    steps[steps.length - 1] = last;
                    currentMessageRef.current.steps = steps;
                    syncStreamingMessage();
                }
                break;
            }

            case WSEventType.TOOL_EXEC_ERROR: {
                const data = data_ as WSToolExecEvent;
                if (currentMessageRef.current) {
                    const steps = [...(currentMessageRef.current.steps || [])];
                    const last = { ...(steps[steps.length - 1] || {}) } as AgentStep;
                    const id = data.id && last.tool_calls?.[data.id] ? data.id : null;
                    const fallbackEntry = !id
                        ? Object.entries(last.tool_calls || {}).find(
                              ([, v]: [string, any]) => v.name === data.tool && (v.status === "executing" || v.status === "planned")
                          )
                        : null;
                    const matchedId = id || (fallbackEntry ? fallbackEntry[0] : null);
                    const call = matchedId ? (last.tool_calls || {})[matchedId] : null;

                    if (matchedId && call) {
                        const endedAt = Date.now();
                        last.tool_calls = {
                            ...last.tool_calls,
                            [matchedId]: {
                                ...call,
                                status: "done",
                                success: false,
                                result: `❌ Erreur outil ${data.tool}: ${data.error}`,
                                ended_at: endedAt,
                                duration: (endedAt - (call.started_at || endedAt)) / 1000,
                            },
                        };
                    }
                    steps[steps.length - 1] = last;
                    currentMessageRef.current.steps = steps;
                    syncStreamingMessage();
                }
                break;
            }

            case WSEventType.CONFIRMATION_REQUEST: {
                const data = data_ as WSConfirmationRequestEvent;
                onConfirmation({
                    req_id: data.req_id,
                    tool: data.tool,
                    risk: data.risk,
                    args: data.args || {},
                });
                toast(`🔔 Confirmation requise pour ${data.tool} (${data.risk})`);
                break;
            }

            case WSEventType.FINISH: {
                const data = data_ as WSFinishEvent;
                setResponseisLoading(false);
                if (currentMessageRef.current) {
                    currentMessageRef.current.content = data.response;
                    currentMessageRef.current.iterations = data.iterations;
                    currentMessageRef.current.total_time = data.total_time;
                    currentMessageRef.current.tool_calls_count = data.tool_calls;
                    currentMessageRef.current.genEnd = true;
                }
                onGenerationEnd();
                break;
            }

            case WSEventType.ERROR: {
                const data = data_ as WSErrorEvent;
                toast.error(`❌ Erreur: ${data.error}`);
                setResponseisLoading(false);
                onGenerationEnd();
                break;
            }

            case WSEventType.PERSIST_ERROR: {
                const data = data_ as WSErrorEvent;
                toast.error(`❌ Erreur de sauvegarde du tour: ${data.error}`);
                setResponseisLoading(false);
                onGenerationEnd();
                break;
            }

            case WSEventType.ACK_ERROR: {
                const data = data_ as WSErrorEvent;
                toast.error(`❌ ${data.error}`);
                setResponseisLoading(false);
                currentIteration.current = null;
                break;
            }

            default:
                console.log("ℹ️ Type de message non géré:", type);
        }
    };

    const renderComponant = () => {
        if (searchIsOpen) {
            return (
                <SearchConversationComponant
                    handleDelete={handleDelete}
                    handleRename={handleRename}
                    handleSetFavorite={handleSetFavorite}
                    handleSetArchived={handleSetArchived}
                    conversations={conversations}
                    onSelectConversation={handleSelectConversation}
                    onClose={closeSearchComponant}
                />
            );
        }
        return (
            <ChatComponant
                currentConversation={currentConv}
                sendMessage={sendMessageFunc}
                wsIsConnected={isConnected}
                currentConversationMessages={currentConvMsgs}
                responseIsLoading={responseIsLoading}
                currentMessage={streamingMessage}
                handleRename={handleRename}
                projectName={projectName}
            />
        );
    };

    if (!isLogin()) {
        return (
            <div id="chat_page_locked" className="chat_page_locked">
                <div className="grid-dots"></div>
                <div className="not-authenticated">
                    <h2>🔒 Accès restreint</h2>
                    <p>
                        Veuillez d'abord vous connecter à la <Link to="/login">page de connexion</Link>.
                    </p>
                </div>
            </div>
        );
    }

    return (
        <div id="chat-coralie-page" className="chat-coralie-page">
            {/* HEADER */}
            <header id="chat-header" className="chat-header">
                <div className="chat-header-left">
                    <div className="msg-avatar msg-avatar-ai">
                        <img src="/public/images/coralie/coralie.svg" alt="Coralie" width={15} height={15} />
                    </div>
                    <span className="chat-header-logo" onClick={() => handleSelectConversation(null)}>
                        Coralie
                    </span>
                </div>

                <div className="chat-header-center">
                    <button
                        className="chat-header-btn chat-header-btn-primary"
                        title="Nouvelle conversation"
                        onClick={() => handleSelectConversation(null)}
                        disabled={responseIsLoading}
                    >
                        <PlusCircle size={16} />
                        Nouvelle conversation
                    </button>

                    <div className="chat-header-sort">
                        <label htmlFor="chat-sort-select">Ordonner par :</label>
                        <select
                            id="chat-sort-select"
                            className="chat-sort-select"
                            value={sortBy}
                            onChange={(e) => setSortBy((e.target.value || "updated_at.desc") as conversationSortOptionsValues)}
                        >
                            {conversationSortOptions.map((option, index) => (
                                <option value={option.value} key={index}>
                                    {option.label}
                                </option>
                            ))}
                        </select>
                    </div>
                </div>

                <div className="chat-header-right">
                    <button
                        className="chat-header-btn"
                        title="Rechercher dans les conversations"
                        onClick={() => (searchIsOpen ? closeSearchComponant() : openSearchComponant())}
                        disabled={responseIsLoading}
                    >
                        <Search size={17} />
                    </button>

                    <button
                        className="chat-header-btn chat-header-btn-bell"
                        title={showConfirmationComponant ? "Fermer les confirmations" : "Voir les confirmations"}
                        onClick={() => (showConfirmationComponant ? closeConfirmationComponant() : openConfirmationComponant())}
                    >
                        <Bell size={17} />
                        {confirmations.length > 0 && <span className="chat-header-badge">{confirmations.length}</span>}
                    </button>

                    <button
                        className="chat-header-btn"
                        title={showSideBar ? "Fermer" : "Ouvrir"}
                        onClick={() => setShowSideBar((prev) => !prev)}
                    >
                        {showSideBar ? <SidebarClose size={17} /> : <SidebarOpen size={17} />}
                    </button>
                </div>
            </header>

            {/* BODY */}
            <div id="chat-body" className="chat-body">
                {showSideBar && (
                    <aside id="chat-sidebar-wrapper" className="chat-sidebar-wrapper">
                        <ChatSideBar
                            handleDelete={handleDelete}
                            handleRename={handleRename}
                            handleSetFavorite={handleSetFavorite}
                            handleSetArchived={handleSetArchived}
                            conversations={conversations}
                            onSelectConversation={handleSelectConversation}
                            sortBy={sortBy}
                            selectedConversationID={currentConv?.conversation_id ?? null}
                        />
                    </aside>
                )}

                <main id="chat-main" className="chat-main">
                    {renderComponant()}
                </main>

                {showConfirmationComponant && (
                    <div className="confirmation-panel-wrapper">
                        <ConfirmationComponant
                            confirmations={confirmations}
                            respondToConfirmation={respondToConfirmation}
                            onClose={closeConfirmationComponant}
                        />
                    </div>
                )}
            </div>
        </div>
    );
}

export default ChatCoraliePage;