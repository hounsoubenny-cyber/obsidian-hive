import {
    CreateConversationRequest,
    CreateConversationResponse,
    ListConversationsRequest,
    ListConversationsResponse,
    GetConversationRequest,
    GetConversationResponse,
    DeleteConversationRequest,
    DeleteConversationResponse,
    UpdateConversationTitleRequest,
    UpdateConversationTitleResponse,
    SetFavoriteRequest,
    SetFavoriteResponse,
    SetArchivedRequest,
    SetArchivedResponse,
    SearchConversationsRequest,
    SearchConversationsResponse,
    GetMessagesRequest,
    GetMessagesResponse,
    GetLastMessageRequest,
    GetLastMessageResponse,
    UpdateMessageContentRequest,
    UpdateMessageContentResponse,
    DeleteMessageRequest,
    DeleteMessageResponse,
    Conversation,
    Message,
    AgentStep,
    StepSummary,
    ToolCallDetail,
} from "@/types/chat_coralie/types";

import {
    createConversation as _createConversation,
    listConversations as _listConversations,
    getConversation as _getConversation,
    deleteConversation as _deleteConversation,
    updateConversationTitle as _updateConversationTitle,
    setFavorite as _setFavorite,
    setArchived as _setArchived,
    searchConversations as _searchConversations,
    getMessages as _getMessages,
    getLastMessage as _getLastMessage,
    updateMessageContent as _updateMessageContent,
    deleteMessage as _deleteMessage,
} from "@/hooks/fetch_functions";

import { refreshToken, getToken } from "@/hooks/get_token";
import { useNavigate } from "react-router-dom";
import { logError } from "@/hooks/error_utils";

// ============================================================================
// CONVERSATIONS — FONCTIONS DE RÉCUPÉRATION
// ============================================================================

// ---- CREATE CONVERSATION ----

export async function createConversation(
    title: string | null | undefined,
    setResult: Function | null,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<CreateConversationResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const data: CreateConversationRequest = { title: title || null };
        const result = await _createConversation(data, getToken());
        const json_ = result.response;

        if (result.ok) {
            const json = json_ as CreateConversationResponse;
            if (setResult) setResult(json);
            return json;
        }

        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) {
                return await createConversation(title, setResult, setError, setLoading, navigate);
            }
            throw new Error("Impossible de rafraîchir le token");
        }

        if (setResult) setResult(null);
        setError(result.error || "Erreur lors de la création de la conversation");
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans createConversation : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ---- LIST CONVERSATIONS ----

export async function listConversations(
    params: {
        include_archived?: boolean;
        favorites_only?: boolean;
        limit?: number | null;
        offset?: number;
    },
    setResult: Function | null,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<ListConversationsResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const data: ListConversationsRequest = {
            include_archived: params.include_archived ?? false,
            favorites_only: params.favorites_only ?? false,
            limit: params.limit ?? 50,
            offset: params.offset ?? 0,
        };
        const result = await _listConversations(data, getToken());
        const json_ = result.response;

        if (result.ok) {
            const json = json_ as ListConversationsResponse;
            if (setResult) setResult(json.conversations);
            return json;
        }

        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) {
                return await listConversations(params, setResult, setError, setLoading, navigate);
            }
            throw new Error("Impossible de rafraîchir le token");
        }

        if (setResult) setResult(null);
        setError(result.error || "Erreur lors du chargement des conversations");
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans listConversations : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ---- GET CONVERSATION ----

export async function getConversation(
    ref: { conversation_id?: string | null; id?: number | null },
    setResult: Function | null,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<GetConversationResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const data: GetConversationRequest = {
            conversation_id: ref.conversation_id || null,
            id: ref.id || null,
        };

        const result = await _getConversation(data, getToken());
        const json_ = result.response;

        if (result.ok) {
            const json = json_ as GetConversationResponse;
            if (setResult) setResult(json);
            return json;
        }

        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) {
                return await getConversation(ref, setResult, setError, setLoading, navigate);
            }
            throw new Error("Impossible de rafraîchir le token");
        }

        if (setResult) setResult(null);
        setError(result.error || "Erreur lors du chargement de la conversation");
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getConversation : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ---- DELETE CONVERSATION ----

export async function deleteConversation(
    ref: { conversation_id?: string | null; id?: number | null },
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<boolean> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const data: DeleteConversationRequest = {
            conversation_id: ref.conversation_id || null,
            id: ref.id || null,
        };

        const result = await _deleteConversation(data, getToken());

        if (result.ok) {
            return true;
        }

        const json = result.response as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) {
                return await deleteConversation(ref, setError, setLoading, navigate);
            }
            throw new Error("Impossible de rafraîchir le token");
        }

        setError(result.error || "Erreur lors de la suppression de la conversation");
        return false;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans deleteConversation : ", msg);
        return false;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ---- UPDATE CONVERSATION TITLE ----

export async function updateConversationTitle(
    ref: { conversation_id?: string | null; id?: number | null },
    title: string,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<boolean> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const data: UpdateConversationTitleRequest = {
            conversation_id: ref.conversation_id || null,
            id: ref.id || null,
            title: title,
        };

        const result = await _updateConversationTitle(data, getToken());

        if (result.ok) {
            return true;
        }

        const json = result.response as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) {
                return await updateConversationTitle(ref, title, setError, setLoading, navigate);
            }
            throw new Error("Impossible de rafraîchir le token");
        }

        setError(result.error || "Erreur lors de la mise à jour du titre");
        return false;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans updateConversationTitle : ", msg);
        return false;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ---- SET FAVORITE ----

export async function setFavorite(
    ref: { conversation_id?: string | null; id?: number | null },
    favorite: boolean,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<boolean> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const data: SetFavoriteRequest = {
            conversation_id: ref.conversation_id || null,
            id: ref.id || null,
            favorite: favorite,
        };

        const result = await _setFavorite(data, getToken());

        if (result.ok) {
            return true;
        }

        const json = result.response as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) {
                return await setFavorite(ref, favorite, setError, setLoading, navigate);
            }
            throw new Error("Impossible de rafraîchir le token");
        }

        setError(result.error || "Erreur lors de la mise à jour du favori");
        return false;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans setFavorite : ", msg);
        return false;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ---- SET ARCHIVED ----

export async function setArchived(
    ref: { conversation_id?: string | null; id?: number | null },
    archived: boolean,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<boolean> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const data: SetArchivedRequest = {
            conversation_id: ref.conversation_id || null,
            id: ref.id || null,
            archived: archived,
        };

        const result = await _setArchived(data, getToken());

        if (result.ok) {
            return true;
        }

        const json = result.response as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) {
                return await setArchived(ref, archived, setError, setLoading, navigate);
            }
            throw new Error("Impossible de rafraîchir le token");
        }

        setError(result.error || "Erreur lors de l'archivage");
        return false;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans setArchived : ", msg);
        return false;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ---- SEARCH CONVERSATIONS ----

export async function searchConversations(
    query: string,
    limit: number | undefined,
    setResult: Function | null,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<SearchConversationsResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        if (!query.trim()) {
            if (setResult) setResult(null);
            setError("");
            return null;
        }

        const data: SearchConversationsRequest = {
            query: query.trim(),
            limit: limit ?? 20,
        };

        const result = await _searchConversations(data, getToken());
        const json_ = result.response;

        if (result.ok) {
            const json = json_ as SearchConversationsResponse;
            if (setResult) setResult(json.conversations);
            return json;
        }

        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) {
                return await searchConversations(query, limit, setResult, setError, setLoading, navigate);
            }
            throw new Error("Impossible de rafraîchir le token");
        }

        if (setResult) setResult(null);
        setError(result.error || "Erreur lors de la recherche");
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans searchConversations : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ============================================================================
// MESSAGES — FONCTIONS DE RÉCUPÉRATION
// ============================================================================

// ---- GET MESSAGES ----

export async function getMessages(
    ref: { conversation_id?: string | null; id?: number | null },
    params: { limit?: number | null; offset?: number },
    setResult: Function | null,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<GetMessagesResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const data: GetMessagesRequest = {
            conversation_id: ref.conversation_id || null,
            id: ref.id || null,
            limit: params.limit ?? null,
            offset: params.offset ?? 0,
        };

        const result = await _getMessages(data, getToken());
        const json_ = result.response;

        if (result.ok) {
            const json = json_ as GetMessagesResponse;
            if (setResult) setResult(json.messages);
            return json;
        }

        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) {
                return await getMessages(ref, params, setResult, setError, setLoading, navigate);
            }
            throw new Error("Impossible de rafraîchir le token");
        }

        if (setResult) setResult(null);
        setError(result.error || "Erreur lors du chargement des messages");
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getMessages : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ---- GET LAST MESSAGE ----

export async function getLastMessage(
    ref: { conversation_id?: string | null; id?: number | null },
    role: 'user' | 'assistant' | null | undefined,
    setResult: Function | null,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<GetLastMessageResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const data: GetLastMessageRequest = {
            conversation_id: ref.conversation_id || null,
            id: ref.id || null,
            role: role || null,
        };

        const result = await _getLastMessage(data, getToken());
        const json_ = result.response;

        if (result.ok) {
            const json = json_ as GetLastMessageResponse;
            if (setResult) setResult(json.message);
            return json;
        }

        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) {
                return await getLastMessage(ref, role, setResult, setError, setLoading, navigate);
            }
            throw new Error("Impossible de rafraîchir le token");
        }

        if (setResult) setResult(null);
        setError(result.error || "Erreur lors du chargement du dernier message");
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getLastMessage : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ---- UPDATE MESSAGE CONTENT ----

export async function updateMessageContent(
    messageId: number,
    content: string,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<boolean> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const data: UpdateMessageContentRequest = {
            message_id: messageId,
            content: content,
        };

        const result = await _updateMessageContent(data, getToken());

        if (result.ok) {
            return true;
        }

        const json = result.response as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) {
                return await updateMessageContent(messageId, content, setError, setLoading, navigate);
            }
            throw new Error("Impossible de rafraîchir le token");
        }

        setError(result.error || "Erreur lors de la mise à jour du message");
        return false;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans updateMessageContent : ", msg);
        return false;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ---- DELETE MESSAGE ----

export async function deleteMessage(
    messageId: number,
    setError: Function,
    setLoading: ((v: boolean) => void) | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<boolean> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const data: DeleteMessageRequest = {
            message_id: messageId,
        };

        const result = await _deleteMessage(data, getToken());

        if (result.ok) {
            return true;
        }

        const json = result.response as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) {
                return await deleteMessage(messageId, setError, setLoading, navigate);
            }
            throw new Error("Impossible de rafraîchir le token");
        }

        setError(result.error || "Erreur lors de la suppression du message");
        return false;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans deleteMessage : ", msg);
        return false;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ============================================================================
// MAPPINGS D'AFFICHAGE
// ============================================================================

export const conversationSortOptions: Array<{ value: conversationSortOptionsValues, label: string }> = [
    { value: "updated_at.desc", label: "📅 Plus récentes" },
    { value: "updated_at.asc", label: "📅 Plus anciennes" },
    { value: "created_at.desc", label: "🆕 Créées récemment" },
    { value: "created_at.asc", label: "🕰️ Créées en premier" },
    { value: "title.asc", label: "🔤 Titre A→Z" },
    { value: "title.desc", label: "🔤 Titre Z→A" },
];

export type conversationSortOptionsValues =
    "updated_at.desc"
    | "updated_at.asc"
    | "created_at.desc"
    | "created_at.asc"
    | "title.asc"
    | "title.desc";

export function sortConversations(
    conversations: Conversation[],
    sortBy: conversationSortOptionsValues
): Conversation[] {
    const copy = [...conversations];

    switch (sortBy) {
        case "updated_at.desc":
            return copy.sort((a, b) =>
                new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
            );
        case "updated_at.asc":
            return copy.sort((a, b) =>
                new Date(a.updated_at).getTime() - new Date(b.updated_at).getTime()
            );
        case "created_at.desc":
            return copy.sort((a, b) =>
                new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
            );
        case "created_at.asc":
            return copy.sort((a, b) =>
                new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
            );
        case "title.asc":
            return copy.sort((a, b) => a.title.localeCompare(b.title));
        case "title.desc":
            return copy.sort((a, b) => b.title.localeCompare(a.title));
        default:
            return copy;
    }
}
export function getConversationDisplayName(
    conversation: Conversation | GetConversationResponse | null | undefined
): string {
    if (!conversation) return "Conversation sans titre";
    return conversation.title || "Conversation sans titre";
}

export function getConversationShortId(conversation: Conversation | GetConversationResponse | null | undefined): string {
    if (!conversation?.conversation_id) return "???";
    const parts = conversation.conversation_id.split("-");
    return parts.length > 1 ? parts[1]?.slice(0, 8) || conversation.conversation_id.slice(0, 8) : conversation.conversation_id.slice(0, 8);
}

export function formatConversationDate(dateStr: string | undefined | null): string {
    if (!dateStr) return "Date inconnue";
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return "Date invalide";

    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMin = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMin < 1) return "À l'instant";
    if (diffMin < 60) return `Il y a ${diffMin}m`;
    if (diffHours < 24) return `Il y a ${diffHours}h`;
    if (diffDays < 7) return `Il y a ${diffDays}j`;

    return date.toLocaleDateString("fr-FR", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
    });
}

export function getMessagePreview(message: Message | null | undefined, maxLength: number = 60): string {
    if (!message?.content) return "";
    const content = message.content.trim();
    if (content.length <= maxLength) return content;
    return content.slice(0, maxLength) + "...";
}

// ============================================================================
// UTILITAIRE : résumer un step pour l'UI
// ============================================================================

export function summarizeStep(step: AgentStep, index: number): StepSummary {
    const toolCallsList = Object.values(step.tool_calls);
    const toolSuccess = toolCallsList.filter(tc => tc.success).length;
    const hasError = Object.values(step.attempts_error).some(err => err !== null);
    const firstError = Object.values(step.attempts_error).find(err => err !== null) || null;

    return {
        index,
        raw: step,
        toolTotal: toolCallsList.length,
        toolSuccess,
        hasTools: toolCallsList.length > 0,
        hasThinking: step.think && step.think.trim().length > 0,
        hasError,
        firstError,
        durationFormatted: `${step.duration.toFixed(2)}s`,
        toolCallsList,
    };
}

/**
 * Extrait le message d'erreur d'un step (s'il y en a un)
 */
export function getStepErrorMessage(step: AgentStep): string | null {
    for (const err of Object.values(step.attempts_error)) {
        if (err) return err;
    }
    return null;
}

/**
 * Extrait le résultat final d'un tool call (formaté pour l'affichage)
 */
export function formatToolResult(toolCall: ToolCallDetail, maxLength: number = 200): string {
    const result = toolCall.result || '';
    if (result.length <= maxLength) return result;
    return result.slice(0, maxLength) + '…';
}
