export const renderArgs = (args: Record<string, any>) => {
        if (!args) return "";
        const entries = Object.entries(args);
        return entries.map(([key, value], idx) => (
            <span key={key}>
                <span className="confirm-arg-key">{key}</span>=
                <span className="confirm-arg-val">{String(value)}</span>
                {idx !== entries.length - 1 ? ", " : ""}
            </span>
        ));
    };