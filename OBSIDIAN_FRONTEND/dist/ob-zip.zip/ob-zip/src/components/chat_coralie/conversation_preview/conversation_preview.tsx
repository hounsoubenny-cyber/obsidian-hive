// ConversationPreview.tsx
import { MessageSquareDotIcon } from 'lucide-react';
import './conversation_preview.css';
import { Conversation } from '@/types/chat_coralie/types';
import { MoreChatOption } from '../more_chat_option/more_chat_option';
import { formatConversationDate } from '../utils';

interface ConversationPreviewProps {
  conv: Conversation;
  isSelected?: boolean;
  onSelectConversation: (conv: Conversation) => void;
  handleSetFavorite: (conv: Conversation, favorite: boolean) => void;
  handleSetArchived: (conv: Conversation, archived: boolean) => void;
  handleRename: (conv: Conversation, name: string) => void;
  handleDelete: (conv: Conversation) => void;
}

export function ConversationPreview({
  conv,
  isSelected,
  handleDelete,
  handleSetFavorite,
  handleSetArchived,
  handleRename,
  onSelectConversation,
}: ConversationPreviewProps) {
  return (
    <div
      id={`conversation-preview-${conv.conversation_id}`}
      className={`conversation-preview ${isSelected ? 'active' : ''}`}
      onClick={(e) => e.stopPropagation()}
    >
      <div
        className="conversation-preview-main"
        onClick={() => onSelectConversation(conv)}
      >
        <h4 className="conversation-preview-title">
          <span className="conversation-preview-icon">
                {/* <MessageSquareDotIcon size={16} /> */}
          </span>
          {conv.title}
          {conv.owner && (
            <span className="conversation-preview-owner">{conv.owner}</span>
          )}
        </h4>

        <div className="conversation-preview-meta">
          <span className="conversation-preview-date">
            Création: {formatConversationDate(conv.created_at)} ({new Date(conv.created_at).toLocaleString("fr-FR")})
          </span>
          <span className="conversation-preview-date">
            Mise à jour: {formatConversationDate(conv.updated_at)} ({new Date(conv.updated_at).toLocaleString("fr-FR")})
          </span>
        </div>

      </div>

      <div className="conversation-preview-actions">
        <MoreChatOption
          conversation={conv}
          handleDelete={handleDelete}
          handleRename={handleRename}
          handleSetArchived={handleSetArchived}
          handleSetFavorite={handleSetFavorite}
        />
      </div>
    </div>
  );
}