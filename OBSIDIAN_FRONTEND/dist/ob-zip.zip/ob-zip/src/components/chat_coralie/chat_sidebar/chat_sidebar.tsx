// ============================================================
// SIDEBAR
// ============================================================

import "./chat_sidebar.css"
import { Conversation } from "@/types/chat_coralie/types";
import { ChevronUp, ChevronDown } from "lucide-react";
import { useState, useEffect } from "react";
import { ConversationPreview } from "../conversation_preview/conversation_preview";
import { conversationSortOptionsValues, sortConversations } from "../utils";

export default function ChatSideBar({
    conversations,
    selectedConversationID,
    onSelectConversation,
    sortBy,
    handleDelete,
    handleSetFavorite,
    handleSetArchived,
    handleRename,
}: {
    conversations: Conversation[] | null;
    selectedConversationID: string | null;
    onSelectConversation: (conv: Conversation | null) => void;
    sortBy: conversationSortOptionsValues;
    handleSetFavorite: (conv: Conversation, favorite: boolean) => void;
    handleSetArchived: (conv: Conversation, archived: boolean) => void;
    handleRename: (conv: Conversation, name: string) => void;
    handleDelete: (conv: Conversation) => void;
}) {
    const [filteredData, setFilteredData] = useState({
        totalConv: 0,
        archived: [] as Conversation[],
        totalArchived: 0,
        favorite: [] as Conversation[],
        totalFavorite: 0,
    });

    useEffect(() => {
        if (!conversations || conversations.length === 0) {
            setFilteredData({
                totalConv: 0,
                archived: [],
                totalArchived: 0,
                favorite: [],
                totalFavorite: 0,
            });
            return;
        }

        const totalConv = conversations.length;
        const archived = sortConversations(
            conversations.filter((conv) => conv.archived),
            sortBy
        );
        const archivedIds = archived.map((c) => c.conversation_id);

        const favorite = sortConversations(
            conversations.filter(
                (conv) => conv.is_favorite && !archivedIds.includes(conv.conversation_id)
            ),
            sortBy
        );

        setFilteredData({
            totalConv,
            archived,
            totalArchived: archived.length,
            favorite,
            totalFavorite: favorite.length,
        });
    }, [conversations, sortBy]);

    const { totalConv, archived, totalArchived, favorite, totalFavorite } = filteredData;

    const [showArchived, setShowArchived] = useState<boolean>(false);
    const [showFavorite, setShowFavorite] = useState<boolean>(true);
    const [showConvs, setShowConvs] = useState<boolean>(true);

    return (
        <div id="chat-sidebar" className="chat-sidebar">
            {/* ARCHIVÉ */}
            <div id="chat-sidebar-archived" className="chat-sidebar-section">
                {totalArchived === 0 ? (
                    <div className="chat-sidebar-empty">Pas de conversation archivée</div>
                ) : (
                    <div>
                        <div className="chat-sidebar-section-header">
                            <button
                                className="chat-sidebar-toggle"
                                title={showArchived ? "Masquer" : "Afficher"}
                                onClick={() => setShowArchived((prev) => !prev)}
                            >
                                <span className="chat-sidebar-toggle-label">
                                    {totalArchived >= 2
                                        ? `Archivés ${totalArchived} chats`
                                        : `Archivé ${totalArchived} chat`}
                                </span>
                                <span className="chat-sidebar-toggle-icon">
                                    {showArchived ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                                </span>
                            </button>
                        </div>

                        {showArchived && (
                            <div className="chat-sidebar-list">
                                {archived.map((conv, key) => (
                                    <div
                                        key={`${key}-${conv.conversation_id}`}
                                        className="chat-sidebar-item"
                                        onClick={(e) => e.stopPropagation()}
                                    >
                                        <ConversationPreview
                                            conv={conv}
                                            onSelectConversation={onSelectConversation}
                                            isSelected={selectedConversationID === conv.conversation_id}
                                            handleDelete={handleDelete}
                                            handleRename={handleRename}
                                            handleSetArchived={handleSetArchived}
                                            handleSetFavorite={handleSetFavorite}
                                        />
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </div>

            {/* FAVORIS */}
            <div id="chat-sidebar-favorites" className="chat-sidebar-section">
                {totalFavorite === 0 ? (
                    <div className="chat-sidebar-empty">Pas de conversation favorite !</div>
                ) : (
                    <div>
                        <div className="chat-sidebar-section-header">
                            <button
                                className="chat-sidebar-toggle"
                                title={showFavorite ? "Masquer" : "Afficher"}
                                onClick={() => setShowFavorite((prev) => !prev)}
                            >
                                <span className="chat-sidebar-toggle-label">
                                    {totalFavorite >= 2
                                        ? `Favoris ${totalFavorite} chats`
                                        : `Favoris ${totalFavorite} chat`}
                                </span>
                                <span className="chat-sidebar-toggle-icon">
                                    {showFavorite ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                                </span>
                            </button>
                        </div>

                        {showFavorite && (
                            <div className="chat-sidebar-list">
                                {favorite.map((conv, key) => (
                                    <div
                                        key={`${key}-${conv.conversation_id}`}
                                        className="chat-sidebar-item"
                                        onClick={(e) => e.stopPropagation()}
                                    >
                                        <ConversationPreview
                                            conv={conv}
                                            onSelectConversation={onSelectConversation}
                                            isSelected={selectedConversationID === conv.conversation_id}
                                            handleDelete={handleDelete}
                                            handleRename={handleRename}
                                            handleSetArchived={handleSetArchived}
                                            handleSetFavorite={handleSetFavorite}
                                        />
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </div>

            {/* TOUTES LES CONVERSATIONS */}
            <div id="chat-sidebar-all" className="chat-sidebar-section">
                {totalConv === 0 ? (
                    <div className="chat-sidebar-empty">Pas de conversations !</div>
                ) : (
                    <div>
                        <div className="chat-sidebar-section-header">
                            <button
                                className="chat-sidebar-toggle"
                                title={showConvs ? "Masquer" : "Afficher"}
                                onClick={() => setShowConvs((prev) => !prev)}
                            >
                                <span className="chat-sidebar-toggle-label">
                                    {totalConv >= 2 ? `${totalConv} chats` : `${totalConv} chat`}
                                </span>
                                <span className="chat-sidebar-toggle-icon">
                                    {showConvs ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                                </span>
                            </button>
                        </div>

                        {showConvs && (
                            <div className="chat-sidebar-list">
                                {conversations.map((conv, key) => (
                                    <div
                                        key={`${key}-${conv.conversation_id}`}
                                        className="chat-sidebar-item"
                                        onClick={(e) => e.stopPropagation()}
                                    >
                                        <ConversationPreview
                                            conv={conv}
                                            onSelectConversation={onSelectConversation}
                                            handleDelete={handleDelete}
                                            handleRename={handleRename}
                                            isSelected={selectedConversationID === conv.conversation_id}
                                            handleSetArchived={handleSetArchived}
                                            handleSetFavorite={handleSetFavorite}
                                        />
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}