import { logError } from "@/hooks/error_utils";
import { getToken, refreshToken } from "@/hooks/get_token";
import { 
    AnalyzeCodeFormDataRequest,
    AnalyzeCodeResponse,
    EstimateRiskFormDataRequest,
    EstimateRiskResponse,
    SupportedLanguagesResponse,
    SandboxDefaultConfigResponse,
    ContainerStatusResponse,
    SandboxHealthResponse
} from "@/types/sandbox/types";
import { 
    sbAnalyzeCode,
    sbEstimateRisk,
    sbLanguages,
    sbConfig,
    sbContainersStatus,
    sbHealth
} from "@/hooks/fetch_functions";
import { useNavigate } from "react-router-dom";

// ============================================================================
// 1. ANALYSE DYNAMIQUE DE CODE
// ============================================================================

export async function analyzeCode(
    data: AnalyzeCodeFormDataRequest,
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<AnalyzeCodeResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const formData = new FormData();
        if (data.code) formData.append("code", data.code);
        if (data.file) formData.append("file", data.file);
        if (data.language) formData.append("language", data.language);
        if (data.config_str) formData.append("config_str", data.config_str);
        if (data.use_cache !== undefined) formData.append("use_cache", String(data.use_cache));

        const result = await sbAnalyzeCode(formData, getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as AnalyzeCodeResponse;
            if (setResult) setResult(json_);
            return json;
        }
        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await analyzeCode(data, setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans analyzeCode : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ============================================================================
// 2. ESTIMATION STATIQUE DU RISQUE
// ============================================================================

export async function estimateRisk(
    data: EstimateRiskFormDataRequest,
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<EstimateRiskResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);

        const formData = new FormData();
        if (data.code) formData.append("code", data.code);
        if (data.file) formData.append("file", data.file);

        const result = await sbEstimateRisk(formData, getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as EstimateRiskResponse;
            if (setResult) setResult(json_);
            return json;
        }
        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await estimateRisk(data, setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans estimateRisk : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ============================================================================
// 3. LANGAGES SUPPORTÉS
// ============================================================================

export async function getSupportedLanguages(
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<SupportedLanguagesResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await sbLanguages(getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as SupportedLanguagesResponse;
            if (setResult) setResult(json_);
            return json;
        }
        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getSupportedLanguages(setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getSupportedLanguages : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ============================================================================
// 4. CONFIGURATION PAR DÉFAUT DU SANDBOX
// ============================================================================

export async function getSandboxConfig(
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<SandboxDefaultConfigResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await sbConfig(getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as SandboxDefaultConfigResponse;
            if (setResult) setResult(json_);
            return json;
        }
        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getSandboxConfig(setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getSandboxConfig : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ============================================================================
// 5. MONITORING DES CONTAINERS ACTIFS
// ============================================================================

export async function getContainersStatus(
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<ContainerStatusResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await sbContainersStatus(getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as ContainerStatusResponse;
            if (setResult) setResult(json_);
            return json;
        }
        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getContainersStatus(setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getContainersStatus : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

// ============================================================================
// 6. SANTÉ SYSTÈME SANDBOX
// ============================================================================

export async function getSandboxHealth(
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<SandboxHealthResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await sbHealth(getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as SandboxHealthResponse;
            if (setResult) setResult(json_);
            return json;
        }
        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getSandboxHealth(setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getSandboxHealth : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}