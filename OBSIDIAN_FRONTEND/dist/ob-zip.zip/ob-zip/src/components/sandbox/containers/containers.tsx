import "./containers.css";
import { useEffect, useState } from "react";
import { ContainerStatusResponse } from "@/types/sandbox/types";
import { useNavigate } from "react-router-dom";
import { getContainersStatus } from "../utils";
import { 
    Box, 
    RefreshCw, 
    AlertTriangle, 
    Activity, 
    Clock, 
    Server, 
    ShieldAlert, 
    CheckCircle2, 
    XCircle 
} from "lucide-react";

function SbContainersComponent({ navigate }: { navigate?: ReturnType<typeof useNavigate> }) {
    const defaultNavigate = useNavigate();
    const nav = navigate || defaultNavigate;

    const [containers, setContainers] = useState<ContainerStatusResponse | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [lastRefresh, setLastRefresh] = useState<Date>(new Date());

    const fetchStatus = () => {
        getContainersStatus(setContainers, setError, setLoading, nav).then(() => {
            setLastRefresh(new Date());
        });
    };

    useEffect(() => {
        fetchStatus();
    }, []);

    const activeCount = containers?.filter(c => c.status === "running").length || 0;

    return (
        <div id="sb-containers" className="sb-containers">
            {/* Header */}
            <div className="sb-containers__header">
                <div>
                    <h2 className="sb-containers__title">
                        <Box size={24} /> Supervision des Containers Docker
                    </h2>
                    <p className="sb-containers__subtitle">Surveillez en temps réel les environnements isolés hébergeant les détonations en cours.</p>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <span style={{ fontSize: '0.78rem', color: 'var(--text-tertiary)' }}>
                        <Clock size={14} /> Ping : {lastRefresh.toLocaleTimeString()}
                    </span>
                    <button type="button" className="sb-btn sb-btn--secondary" onClick={fetchStatus} disabled={loading}>
                        <RefreshCw size={14} className={loading ? "oh-spin" : ""} /> Actualiser
                    </button>
                </div>
            </div>

            {/* Erreur */}
            {error && (
                <div className="apu-error">
                    <AlertTriangle size={20} className="apu-error__icon" />
                    <div className="apu-error__content">
                        <span className="apu-error__title">❌ Erreur Docker Daemon</span>
                        <p className="apu-error__text">{error}</p>
                    </div>
                </div>
            )}

            {/* Cartes Résumé */}
            <div className="sb-containers__summary-grid">
                <div className="sb-containers__summary-card">
                    <Activity size={22} style={{ color: 'var(--accent)' }} />
                    <span><strong>{activeCount}</strong> container(s) en cours d'exécution</span>
                </div>
                <div className="sb-containers__summary-card">
                    <Server size={22} style={{ color: 'var(--info)' }} />
                    <span><strong>{containers?.length || 0}</strong> container(s) alloué(s) au total</span>
                </div>
            </div>

            {/* Tableau */}
            <div className="sb-containers__table-wrapper">
                {containers && containers.length > 0 ? (
                    <table className="sb-containers__table">
                        <thead>
                            <tr>
                                <th>Session ID</th>
                                <th>État Docker</th>
                                <th>Santé Hôte</th>
                                <th>PID (Hôte)</th>
                                <th>Image</th>
                            </tr>
                        </thead>
                        <tbody>
                            {containers.map((c, idx) => (
                                <tr key={idx}>
                                    <td><strong style={{ color: 'var(--text-primary)', fontFamily: 'var(--font-mono)' }}>{c.session_id}</strong></td>
                                    <td>
                                        <span className={`oh-badge ${c.status === "running" ? "oh-badge--success" : "oh-badge--info"}`}>
                                            {c.status.toUpperCase()}
                                        </span>
                                    </td>
                                    <td>
                                        {c.healthy ? (
                                            <span className="oh-badge oh-badge--success"><CheckCircle2 size={12} /> Sain</span>
                                        ) : c.status === "running" ? (
                                            <span className="oh-badge oh-badge--danger"><ShieldAlert size={12} /> Gelé</span>
                                        ) : (
                                            <span className="oh-badge oh-badge--info"><XCircle size={12} /> N/A</span>
                                        )}
                                    </td>
                                    <td style={{ fontFamily: 'var(--font-mono)' }}>{c.pid || "---"}</td>
                                    <td>{c.image_name}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <div style={{ textAlign: 'center', padding: '48px', color: 'var(--text-tertiary)' }}>
                        <Box size={32} style={{ opacity: 0.5, marginBottom: '8px' }} />
                        <p>Aucun container Sandbox n'est actuellement instancié.</p>
                    </div>
                )}
            </div>
        </div>
    );
}

export default SbContainersComponent;