import "./health.css";
import { useEffect, useState } from "react";
import { SandboxHealthResponse, SandboxDefaultConfigResponse, SupportedLanguagesResponse } from "@/types/sandbox/types";
import { useNavigate } from "react-router-dom";
import { getSandboxHealth, getSandboxConfig, getSupportedLanguages } from "../utils";
import { 
    Activity, ShieldAlert, CheckCircle2, AlertTriangle, 
    RefreshCw, Server, Code2 
} from "lucide-react";

function SbHealthComponent({ navigate }: { navigate?: ReturnType<typeof useNavigate> }) {
    const defaultNavigate = useNavigate();
    const nav = navigate || defaultNavigate;

    const [health, setHealth] = useState<SandboxHealthResponse | null>(null);
    const [config, setConfig] = useState<SandboxDefaultConfigResponse | null>(null);
    const [langs, setLangs] = useState<SupportedLanguagesResponse | null>(null);

    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const fetchAll = async () => {
        setLoading(true);
        setError(null);
        await Promise.all([
            getSandboxHealth(setHealth, setError, null, nav),
            getSandboxConfig(setConfig, setError, null, nav),
            getSupportedLanguages(setLangs, setError, null, nav)
        ]);
        setLoading(false);
    };

    useEffect(() => {
        fetchAll();
    }, []);

    const isHealthy = health?.status === "healthy" && !error;

    return (
        <div id="sb-health" className="sb-health">
            {/* Header */}
            <div className="sb-health__header">
                <div>
                    <h2 className="sb-health__title"><Activity size={24} /> 🩺 Santé & Configuration Sandbox</h2>
                    <p className="sb-health__subtitle">Vérifiez la disponibilité de l'isolation Docker et les règles de détonation par défaut.</p>
                </div>
                <button type="button" className="sb-btn sb-btn--secondary" onClick={fetchAll} disabled={loading}>
                    <RefreshCw size={14} className={loading ? "oh-spin" : ""} /> Actualiser
                </button>
            </div>

            {/* Bannière Santé */}
            {health && (
                <div className={`sb-health__banner ${isHealthy ? "sb-health__banner--ok" : "sb-health__banner--err"}`}>
                    <div>
                        {isHealthy ? <CheckCircle2 size={32} style={{ color: 'var(--success)' }} /> : <AlertTriangle size={32} style={{ color: 'var(--warning)' }} />}
                    </div>
                    <div>
                        <h3 style={{ margin: 0, fontSize: '1.1rem', fontWeight: 700 }}>
                            {isHealthy ? "🟢 API Sandbox Opérationnelle" : "🟡 API Sandbox Dégradée"}
                        </h3>
                        <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                            Orchestrateur asynchrone prêt • Horodatage : {new Date(health.timestamp).toLocaleString()}
                        </p>
                    </div>
                </div>
            )}

            {/* Profils Docker & Scoring */}
            {config && (
                <div className="sb-health__profiles-grid">
                    <div className="sb-health__card">
                        <h4><Server size={18} /> Profil d'Isolation Docker</h4>
                        <ul>
                            <li>Image de Base : <strong>{config.image_name}</strong></li>
                            <li>Réseau : <strong>{config.network_disabled ? "❌ Coupé (Air-gapped)" : "🟢 Actif"}</strong></li>
                            <li>Limite Mémoire : <strong>{config.mem_limit}</strong></li>
                            <li>Limite Processus (PIDs) : <strong>{config.pids_limit} max</strong></li>
                            <li>Timeout d'Exécution : <strong>{config.exec_timeout} secondes</strong></li>
                        </ul>
                    </div>

                    <div className="sb-health__card">
                        <h4><ShieldAlert size={18} /> Profil de Détection & Kill</h4>
                        <ul>
                            <li>Seuil Critique (Kill) : <strong>Score ≥ {config.alert_threshold} / 100</strong></li>
                            <li>Traceur Noyau : <strong>Actif (`strace`)</strong></li>
                            <li>Sonde Filesystem : <strong>Active (`inotify`)</strong></li>
                            <li>Honeypots Actifs : <strong>.env, id_rsa, /etc/shadow...</strong></li>
                        </ul>
                    </div>
                </div>
            )}

            {/* Langages Supportés */}
            {langs && (
                <div className="sb-health__card">
                    <h4><Code2 size={18} /> {langs.count} Langages de Programmation Pris en Charge</h4>
                    <p style={{ fontSize: '0.88rem', color: 'var(--text-secondary)' }}>
                        Détection automatique des runtimes et compilateurs embarqués (C, C++, Rust, Java, Go, Python...).
                    </p>
                    <div className="sb-health__langs-cloud">
                        {langs.languages.map((lang, idx) => (
                            <span key={idx} className="sb-health__lang-badge">
                                {lang.toUpperCase()}
                            </span>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

export default SbHealthComponent;