import "./estimate_risk.css";
import { useEffect, useState } from "react";
import { 
    EstimateRiskFormDataRequest, 
    EstimateRiskResponse,
    SupportedLanguage,
    ThreatLevelEnum 
} from "@/types/sandbox/types";
import { estimateRisk, getSupportedLanguages } from "../utils";
import { useNavigate } from "react-router-dom";
import { CodeEditor } from "../code_editor/code_editor";
import { buildLanguageOptions, LanguageOption } from "./constant";
import toast from "react-hot-toast";
import { 
    Zap, 
    UploadCloud, 
    ShieldAlert, 
    ShieldCheck, 
    ShieldX, 
    AlertTriangle, 
    RotateCcw, 
    Search, 
    Copy,
    Trash2 
} from "lucide-react";

function ShowEstimateRiskReport({
    result,
    onClear,
}: {
    result: EstimateRiskResponse;
    onClear: () => void;
}) {
    if (!result) return null;

    const isCritical = result.risk_level === ThreatLevelEnum.CRITICAL;
    const isHigh = result.risk_level === ThreatLevelEnum.HIGH;
    const isMedium = result.risk_level === ThreatLevelEnum.MEDIUM;

    let verdictClass = "sb-estimate-report__verdict--low";
    if (isCritical || isHigh) verdictClass = "sb-estimate-report__verdict--critical";
    else if (isMedium) verdictClass = "sb-estimate-report__verdict--high";

    return (
        <div id="sb-estimate-report" className="sb-estimate-report">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h4 style={{ margin: 0, fontWeight: 700 }}>📊 Diagnostic Statique Rapide</h4>
                <div style={{ display: 'flex', gap: '8px' }}>
                    <button type="button" className="sb-btn sb-btn--secondary" onClick={() => {
                        navigator.clipboard.writeText(JSON.stringify(result, null, 2));
                        toast.success("📋 Résultat copié !");
                    }}>
                        <Copy size={14} /> Copier
                    </button>
                    <button type="button" className="sb-btn sb-btn--secondary" onClick={onClear}>
                        <Trash2 size={14} /> Effacer
                    </button>
                </div>
            </div>

            {/* Verdict */}
            <div className={`sb-estimate-report__verdict ${verdictClass}`}>
                <div>
                    {isCritical && <ShieldX size={36} />}
                    {isHigh && <ShieldAlert size={36} />}
                    {isMedium && <AlertTriangle size={36} />}
                    {!isCritical && !isHigh && !isMedium && <ShieldCheck size={36} />}
                </div>

                <div>
                    <div style={{ fontSize: '1.1rem', fontWeight: 700 }}>
                        {isCritical && "🔴 RISQUE CRITIQUE DÉTECTÉ"}
                        {isHigh && "🟠 RISQUE ÉLEVÉ"}
                        {isMedium && "🟡 RISQUE MODÉRÉ"}
                        {!isCritical && !isHigh && !isMedium && "🟢 CODE PROBABLEMENT BÉNIN"}
                    </div>
                    <p style={{ fontSize: '0.88rem', color: 'var(--text-secondary)' }}>
                        Score statique : <strong>{result.risk_score} / 100</strong> • Langage : <strong>{result.language_detected || "Inconnu"}</strong>
                    </p>
                </div>
            </div>

            {/* Drapeaux / Signatures */}
            <div className="sb-estimate-report__flags">
                <h5>🚩 Patterns & Signatures Repérées ({result.flags?.length || 0})</h5>
                {result.flags && result.flags.length > 0 ? (
                    result.flags.map((flag, idx) => (
                        <div key={idx} className="sb-estimate-report__flag-item">
                            ⚠️ {flag}
                        </div>
                    ))
                ) : (
                    <p style={{ color: 'var(--text-tertiary)', fontSize: '0.85rem' }}>✅ Aucun motif textuel suspect trouvé.</p>
                )}
            </div>
        </div>
    );
}

export function EstimateRiskComponent({ navigate }: { navigate?: ReturnType<typeof useNavigate> }) {
    const defaultNavigate = useNavigate();
    const nav = navigate || defaultNavigate;

    const [inputMode, setInputMode] = useState<"editor" | "file">("editor");
    const [code, setCode] = useState<string>("");
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const [selectedLang, setSelectedLang] = useState<SupportedLanguage | "auto">("auto");
    const [languageOptions, setLanguageOptions] = useState<LanguageOption[]>([
        { val: "auto", label: "✨ Détection Automatique" }
    ]);

    const [estimateResult, setEstimateResult] = useState<EstimateRiskResponse | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        getSupportedLanguages(
            (data: { languages: string[] }) => {
                if (data?.languages) {
                    setLanguageOptions(buildLanguageOptions(data.languages));
                }
            },
            () => {},
            null,
            nav
        );
    }, []);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            setSelectedFile(e.target.files[0]);
            toast.success(`📁 Fichier "${e.target.files[0].name}" sélectionné !`);
        }
    };

    const handleEstimate = async () => {
        if (inputMode === "editor" && !code.trim()) {
            toast.error("⚠️ Veuillez saisir du code source !");
            return;
        }
        if (inputMode === "file" && !selectedFile) {
            toast.error("⚠️ Veuillez sélectionner un fichier !");
            return;
        }

        const payload: EstimateRiskFormDataRequest = {
            code: inputMode === "editor" ? code : undefined,
            file: inputMode === "file" ? (selectedFile as File) : undefined,
        };

        const res = await estimateRisk(payload, setEstimateResult, setError, setLoading, nav);
        if (res) {
            toast.success("⚡ Estimation statique terminée !");
        }
    };

    return (
        <div id="sb-estimate-container" className="sb-estimate-container">
            {/* Header */}
            <div className="sb-estimate-header">
                <h3 className="sb-estimate-header__title">⚡ Estimation Statique du Risque (Instantané)</h3>
                <p className="sb-estimate-header__subtitle">
                    Passez le code au crible de signatures suspectes en moins d'une seconde sans lancer Docker.
                </p>
            </div>

            {/* Input Box */}
            <div className="sb-detonate-box">
                <div className="sb-detonate-mode-toggle">
                    <button
                        type="button"
                        className={`sb-detonate-mode-btn ${inputMode === "editor" ? "sb-detonate-mode-btn--active" : ""}`}
                        onClick={() => setInputMode("editor")}
                        disabled={inputMode === "editor"}
                    >
                        ✍️ Éditeur de Code
                    </button>
                    <button
                        type="button"
                        className={`sb-detonate-mode-btn ${inputMode === "file" ? "sb-detonate-mode-btn--active" : ""}`}
                        onClick={() => setInputMode("file")}
                        disabled={inputMode === "file"}
                    >
                        📁 Importer Fichier
                    </button>
                </div>

                {inputMode === "editor" ? (
                    <CodeEditor
                        value={code}
                        onChange={setCode}
                        language={selectedLang}
                        onLanguageChange={setSelectedLang}
                        languages={languageOptions}
                        disabled={loading}
                    />
                ) : (
                    <label className="sb-detonate-upload">
                        <UploadCloud size={36} className="sb-detonate-upload__icon" />
                        <span className="sb-detonate-upload__text">Sélectionner un script (.py, .sh, .c, .js...)</span>
                        <input
                            type="file"
                            style={{ display: 'none' }}
                            onChange={handleFileChange}
                            disabled={loading}
                        />
                        {selectedFile && (
                            <span className="sb-detonate-upload__file-info">
                                📄 {selectedFile.name} ({(selectedFile.size / 1024).toFixed(1)} Ko)
                            </span>
                        )}
                    </label>
                )}

                {/* Actions */}
                <div className="sb-detonate-actions">
                    <button
                        id="sb-btn-estimate"
                        type="button"
                        className="sb-btn sb-btn--primary"
                        disabled={loading || (inputMode === "editor" ? !code.trim() : !selectedFile)}
                        onClick={handleEstimate}
                    >
                        <Search size={16} /> {loading ? "⏳ Scan en cours..." : "⚡ Estimer le Risque"}
                    </button>

                    <button
                        type="button"
                        className="sb-btn sb-btn--secondary"
                        disabled={loading}
                        onClick={() => {
                            setCode("");
                            setSelectedFile(null);
                            setEstimateResult(null);
                            setError(null);
                        }}
                    >
                        <RotateCcw size={16} /> Réinitialiser
                    </button>
                </div>
            </div>

            {/* Rapport */}
            {estimateResult && (
                <ShowEstimateRiskReport
                    result={estimateResult}
                    onClear={() => setEstimateResult(null)}
                />
            )}
        </div>
    );
}

export default EstimateRiskComponent;