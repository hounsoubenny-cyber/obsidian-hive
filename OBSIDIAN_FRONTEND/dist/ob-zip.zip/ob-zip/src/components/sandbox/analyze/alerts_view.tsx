import React, { useState } from "react";
import { ThreatAlertReport, ThreatLevel } from "@/types/sandbox/types";
import { 
    ShieldAlert, 
    ShieldX, 
    AlertTriangle, 
    Clock, 
    Calendar, 
    Target, 
    Terminal, 
    Copy, 
    ChevronDown, 
    ChevronUp, 
    Flame, 
    Info, 
    Sparkles,
    ExternalLink
} from "lucide-react";
import toast from "react-hot-toast";

// ============================================================================
// 1. CARTE INDIVIDUELLE D'ALERTE (Exploite 100% des champs)
// ============================================================================

export function ThreatAlertCard({ alert, index }: { alert: ThreatAlertReport; index?: number }) {
    const [isEventExpanded, setIsEventExpanded] = useState<boolean>(false);

    const handleCopyEvent = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (alert.trigger_event) {
            navigator.clipboard.writeText(alert.trigger_event);
            toast.success("📋 Événement noyau copié dans le presse-papier !");
        }
    };

    const isCritical = alert.threat_level === "CRITICAL" || alert.threat_score >= 80;
    const isHigh = alert.threat_level === "HIGH";
    const isMedium = alert.threat_level === "MEDIUM";

    let borderColor = "var(--success)";
    let badgeBg = "var(--success-soft)";
    if (isCritical) {
        borderColor = "var(--danger)";
        badgeBg = "var(--danger-soft)";
    } else if (isHigh) {
        borderColor = "var(--warning)";
        badgeBg = "var(--warning-soft)";
    } else if (isMedium) {
        borderColor = "var(--info)";
        badgeBg = "var(--info-soft)";
    }

    return (
        <div
            style={{
                background: "var(--bg-surface-2)",
                border: "1px solid var(--border)",
                borderLeft: `5px solid ${borderColor}`,
                borderRadius: "var(--radius-md)",
                padding: "16px 20px",
                display: "flex",
                flexDirection: "column",
                gap: "10px",
            }}
        >
            {/* Ligne 1 : Titre du Pattern, Sévérité, Score & MITRE */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "10px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "10px", flexWrap: "wrap" }}>
                    {isCritical && <ShieldX size={20} style={{ color: "var(--danger)" }} />}
                    {isHigh && <ShieldAlert size={20} style={{ color: "var(--warning)" }} />}
                    {isMedium && <AlertTriangle size={20} style={{ color: "var(--info)" }} />}
                    {!isCritical && !isHigh && !isMedium && <Sparkles size={20} style={{ color: "var(--success)" }} />}

                    <span style={{ fontSize: "0.95rem", fontWeight: 700, color: "var(--text-primary)" }}>
                        {alert.pattern_detected
                            ? `🎯 ${alert.pattern_detected.replace(/_/g, " ").toUpperCase()}`
                            : `🚨 Alerte Comportementale (Score : +${alert.threat_score})`}
                    </span>

                    {/* Badge Sévérité & Score */}
                    <span
                        className="oh-badge"
                        style={{
                            background: badgeBg,
                            color: borderColor,
                            fontWeight: 700,
                        }}
                    >
                        {alert.threat_level} • +{alert.threat_score} pts
                    </span>
                </div>

                {/* Badges Spéciaux : MITRE ATT&CK & Honeypot */}
                <div style={{ display: "flex", gap: "8px", alignItems: "center", flexWrap: "wrap" }}>
                    {alert.canary_triggered && (
                        <span
                            className="oh-badge"
                            style={{
                                background: "var(--danger-soft)",
                                color: "var(--danger)",
                                fontWeight: 700,
                            }}
                        >
                            🍯 HONEYPOT TOUCHÉ
                        </span>
                    )}

                    {alert.mitre && (
                        <a
                            href={`https://attack.mitre.org/techniques/${alert.mitre.replace(/\./g, "/")}/`}
                            target="_blank"
                            rel="noreferrer"
                            className="oh-badge"
                            style={{
                                background: "var(--accent-soft)",
                                color: "var(--accent-strong)",
                                textDecoration: "none",
                                display: "inline-flex",
                                alignItems: "center",
                                gap: "4px",
                            }}
                            title="Consulter la matrice MITRE ATT&CK"
                        >
                            🎯 MITRE {alert.mitre} <ExternalLink size={10} />
                        </a>
                    )}
                </div>
            </div>

            {/* Ligne 2 : Description en langage clair */}
            <p style={{ margin: 0, fontSize: "0.88rem", color: "var(--text-secondary)", lineHeight: 1.5 }}>
                {alert.description || "Élévation significative du niveau de menace suite à une séquence d'appels système anormale."}
            </p>

            {/* Ligne 3 : Métadonnées Temporelles Complètes */}
            <div style={{ display: "flex", gap: "16px", fontSize: "0.76rem", color: "var(--text-tertiary)", flexWrap: "wrap" }}>
                <span style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                    <Clock size={12} /> Déclenché à <strong>{alert.session_duration}s</strong> de session
                </span>
                <span style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                    <Calendar size={12} /> {new Date(alert.timestamp).toLocaleTimeString()} ({new Date(alert.timestamp).toLocaleDateString()})
                </span>
            </div>

            {/* Ligne 4 : Preuve Technique Noyau (trigger_event) */}
            {alert.trigger_event && (
                <div
                    style={{
                        background: "var(--bg-surface)",
                        border: "1px solid var(--border)",
                        borderRadius: "var(--radius-sm)",
                        overflow: "hidden",
                        marginTop: "4px",
                    }}
                >
                    <div
                        onClick={() => setIsEventExpanded(!isEventExpanded)}
                        style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            padding: "8px 12px",
                            cursor: "pointer",
                            userSelect: "none",
                            background: isEventExpanded ? "var(--bg-hover)" : "transparent",
                        }}
                    >
                        <span style={{ fontSize: "0.78rem", fontWeight: 600, color: "var(--accent-strong)", display: "flex", alignItems: "center", gap: "6px" }}>
                            <Terminal size={14} /> Preuve Matérielle (Appel Système / Fichier Déclencheur)
                        </span>

                        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                            <button
                                type="button"
                                onClick={handleCopyEvent}
                                title="Copier l'événement brut"
                                style={{
                                    background: "transparent",
                                    border: "none",
                                    color: "var(--text-tertiary)",
                                    cursor: "pointer",
                                    padding: "2px",
                                }}
                            >
                                <Copy size={12} />
                            </button>
                            {isEventExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                        </div>
                    </div>

                    {isEventExpanded && (
                        <pre
                            style={{
                                margin: 0,
                                padding: "10px 14px",
                                background: "#05070a",
                                borderTop: "1px solid var(--border)",
                                fontFamily: "var(--font-mono)",
                                fontSize: "0.75rem",
                                color: "#4ade80",
                                overflowX: "auto",
                                whiteSpace: "pre-wrap",
                                wordBreak: "break-all",
                                lineHeight: 1.5,
                            }}
                        >
                            {alert.trigger_event}
                        </pre>
                    )}
                </div>
            )}
        </div>
    );
}

// ============================================================================
// 2. VUE LISTE COMPLÈTE DES ALERTES (Avec Filtres + Accordéon Dynamique)
// ============================================================================

export function ThreatAlertsView({ alerts = [] }: { alerts: ThreatAlertReport[] }) {
    const [alertFilter, setAlertFilter] = useState<"ALL" | "CRITICAL" | "HIGH" | "MEDIUM" | "CANARY">("ALL");
    const [isExpanded, setIsExpanded] = useState<boolean>(false);

    // Compteurs en temps réel
    const criticalCount = alerts.filter((a) => a.threat_level === "CRITICAL").length;
    const highCount = alerts.filter((a) => a.threat_level === "HIGH").length;
    const mediumCount = alerts.filter((a) => a.threat_level === "MEDIUM").length;
    const canaryCount = alerts.filter((a) => a.canary_triggered).length;

    // Filtrage
    const filteredAlerts = alerts.filter((a) => {
        if (alertFilter === "CRITICAL") return a.threat_level === "CRITICAL";
        if (alertFilter === "HIGH") return a.threat_level === "HIGH";
        if (alertFilter === "MEDIUM") return a.threat_level === "MEDIUM";
        if (alertFilter === "CANARY") return a.canary_triggered;
        return true;
    });

    const INITIAL_LIMIT = 3;
    const displayedAlerts = isExpanded ? filteredAlerts : filteredAlerts.slice(0, INITIAL_LIMIT);

    return (
        <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            {/* Header des Alertes & Filtres */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
                <h5 style={{ margin: 0, fontSize: "1rem", fontWeight: 700, display: "flex", alignItems: "center", gap: "8px" }}>
                    <Flame size={18} style={{ color: "var(--danger)" }} /> Alertes de Menace Détectées ({alerts.length})
                </h5>

                {/* Filtres Rapides */}
                {alerts.length > 0 && (
                    <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
                        <button
                            type="button"
                            className={`aph-filter-btn ${alertFilter === "ALL" ? "aph-filter-btn--active" : ""}`}
                            onClick={() => setAlertFilter("ALL")}
                        >
                            Tous ({alerts.length})
                        </button>

                        {criticalCount > 0 && (
                            <button
                                type="button"
                                className={`aph-filter-btn ${alertFilter === "CRITICAL" ? "aph-filter-btn--active" : ""}`}
                                onClick={() => setAlertFilter("CRITICAL")}
                            >
                                🔴 Critiques ({criticalCount})
                            </button>
                        )}

                        {highCount > 0 && (
                            <button
                                type="button"
                                className={`aph-filter-btn ${alertFilter === "HIGH" ? "aph-filter-btn--active" : ""}`}
                                onClick={() => setAlertFilter("HIGH")}
                            >
                                🟠 Élevées ({highCount})
                            </button>
                        )}

                        {mediumCount > 0 && (
                            <button
                                type="button"
                                className={`aph-filter-btn ${alertFilter === "MEDIUM" ? "aph-filter-btn--active" : ""}`}
                                onClick={() => setAlertFilter("MEDIUM")}
                            >
                                🟡 Moyennes ({mediumCount})
                            </button>
                        )}

                        {canaryCount > 0 && (
                            <button
                                type="button"
                                className={`aph-filter-btn ${alertFilter === "CANARY" ? "aph-filter-btn--active" : ""}`}
                                onClick={() => setAlertFilter("CANARY")}
                            >
                                🍯 Canaris ({canaryCount})
                            </button>
                        )}
                    </div>
                )}
            </div>

            {/* Conteneur Défilant des Cartes */}
            {displayedAlerts.length > 0 ? (
                <div
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        gap: "12px",
                        maxHeight: isExpanded ? "440px" : "none",
                        overflowY: isExpanded ? "auto" : "visible",
                        paddingRight: isExpanded ? "6px" : "0",
                    }}
                >
                    {displayedAlerts.map((alert, idx) => (
                        <ThreatAlertCard key={idx} alert={alert} index={idx} />
                    ))}
                </div>
            ) : (
                <div style={{ padding: "20px", background: "var(--bg-surface-2)", borderRadius: "var(--radius-md)", textAlign: "center", color: "var(--text-tertiary)", fontSize: "0.88rem" }}>
                    {alerts.length === 0 ? "✅ Aucun comportement suspect n'a été détecté lors de la détonation." : "ℹ️ Aucune alerte ne correspond à ce filtre."}
                </div>
            )}

            {/* Bouton Afficher Plus / Réduire */}
            {filteredAlerts.length > INITIAL_LIMIT && (
                <button
                    type="button"
                    className="sb-btn sb-btn--secondary"
                    onClick={() => setIsExpanded(!isExpanded)}
                    style={{ width: "100%", justifyContent: "center" }}
                >
                    {isExpanded ? "🔼 Réduire l'affichage (Top 3)" : `🔽 Afficher les ${filteredAlerts.length - INITIAL_LIMIT} autres alertes (${alertFilter.toLowerCase()})`}
                </button>
            )}
        </div>
    );
}

export default ThreatAlertsView;