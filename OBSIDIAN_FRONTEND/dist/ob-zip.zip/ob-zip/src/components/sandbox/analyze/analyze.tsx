import "./analyze.css";
import { useState } from "react";
import AnalyzeCodeComponent from "./analyze_code";
import EstimateRiskComponent from "./estimate_risk";
import { Bomb, Zap, Sparkles, CheckCircle2 } from "lucide-react";
import { useNavigate } from "react-router-dom";

type SandboxAnalyzeMode = "detonation" | "estimate";

function SbAnalyzeComponent({ navigate }: { navigate?: ReturnType<typeof useNavigate> }) {
    const [activeMode, setActiveMode] = useState<SandboxAnalyzeMode>("detonation");

    return (
        <div id="sba-container" className="sba-container">
            {/* Header */}
            <div className="sba-header">
                <h2 className="sba-header__title">
                    🛡️ Centre d'Inspection de Code Sandbox
                </h2>
                <p className="sba-header__subtitle">
                    Choisissez votre méthode d'évaluation : faites détoner le script en isolation totale Docker ou effectuez un pré-scan statique instantané.
                </p>
            </div>

            {/* Sélecteur de Mode */}
            <div id="sba-mode-grid" className="sba-mode-grid">
                {/* Option 1 : Détonation */}
                <button
                    id="sba-mode-detonation"
                    type="button"
                    className={`sba-mode-card ${activeMode === "detonation" ? "sba-mode-card--active" : ""}`}
                    onClick={() => setActiveMode("detonation")}
                    disabled={activeMode === "detonation"}
                >
                    <div className="sba-mode-card__top">
                        <div className="sba-mode-card__title-group">
                            <Bomb size={24} style={{ color: 'var(--accent-strong)' }} />
                            <span className="sba-mode-card__title">💣 Détonation Dynamique en Sandbox</span>
                        </div>
                        {activeMode === "detonation" && (
                            <span className="oh-badge oh-badge--accent">
                                <CheckCircle2 size={14} /> Actif
                            </span>
                        )}
                    </div>
                    <p className="sba-mode-card__desc">
                        Exécution réelle sous surveillance noyau (`strace` + `inotify`), scoring MITRE ATT&CK, Deep Learning et kill d'urgence.
                    </p>
                </button>

                {/* Option 2 : Estimation Rapide */}
                <button
                    id="sba-mode-estimate"
                    type="button"
                    className={`sba-mode-card ${activeMode === "estimate" ? "sba-mode-card--active" : ""}`}
                    onClick={() => setActiveMode("estimate")}
                    disabled={activeMode === "estimate"}
                >
                    <div className="sba-mode-card__top">
                        <div className="sba-mode-card__title-group">
                            <Zap size={24} style={{ color: 'var(--warning)' }} />
                            <span className="sba-mode-card__title">⚡ Estimation Statique Rapide (&lt; 1s)</span>
                        </div>
                        {activeMode === "estimate" && (
                            <span className="oh-badge oh-badge--accent">
                                <CheckCircle2 size={14} /> Actif
                            </span>
                        )}
                    </div>
                    <p className="sba-mode-card__desc">
                        Scan heuristique instantané sans instancier de container pour détecter les signatures textuelles suspectes.
                    </p>
                </button>
            </div>

            <hr className="sba-divider" />

            {/* Vue Active */}
            <div>
                {activeMode === "detonation" && <AnalyzeCodeComponent navigate={navigate} />}
                {activeMode === "estimate" && <EstimateRiskComponent navigate={navigate} />}
            </div>
        </div>
    );
}

export default SbAnalyzeComponent;