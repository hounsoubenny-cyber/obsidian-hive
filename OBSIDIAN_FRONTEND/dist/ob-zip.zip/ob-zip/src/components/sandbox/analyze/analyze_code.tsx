import "./analyze_code.css";
import { useEffect, useState } from "react";
import { 
    AnalyzeCodeFormDataRequest, 
    AnalyzeCodeResponse, 
    SupportedLanguage,
    ThreatLevelEnum,
    SandboxConfigOverrides 
} from "@/types/sandbox/types";
import { analyzeCode, getSupportedLanguages } from "../utils";
import { useNavigate } from "react-router-dom";
import { CodeEditor } from "../code_editor/code_editor";
import { buildLanguageOptions, LanguageOption } from "./constant";
import toast from "react-hot-toast";
import { 
    Bomb, 
    UploadCloud, 
    Sliders, 
    Copy, 
    Trash2, 
    RotateCcw, 
    ShieldAlert, 
    ShieldCheck, 
    ShieldX, 
    AlertTriangle, 
    TerminalSquare 
} from "lucide-react";
import ThreatAlertsView from "./alerts_view";

// ============================================================================
// SOUS-COMPOSANT : Rapport Complet de Détonation (Fusion Filtres + Déroulement)
// ============================================================================

export function ShowSandboxReport({
    report,
    onClear,
}: {
    report: AnalyzeCodeResponse;
    onClear: () => void;
}) {
    if (!report) return null;

    const [activeConsoleTab, setActiveConsoleTab] = useState<"stdout" | "stderr">("stdout");

    // Copie globale du rapport JSON
    const handleCopy = () => {
        navigator.clipboard.writeText(JSON.stringify(report, null, 2));
        toast.success("📋 Rapport de détonation copié !");
    };

    // Copie spécifique de la console
    const handleCopyConsoleOutput = () => {
        const textToCopy = activeConsoleTab === "stdout" 
            ? (report.exec_result?.stdout || "") 
            : (report.exec_result?.stderr || "");

        if (!textToCopy.trim()) {
            toast(`ℹ️ La sortie ${activeConsoleTab} est vide.`);
            return;
        }

        navigator.clipboard.writeText(textToCopy);
        toast.success(`📋 Sortie ${activeConsoleTab} copiée dans le presse-papier !`);
    };

    const isCritical = report.final_level === ThreatLevelEnum.CRITICAL || report.final_score >= 80;
    const isHigh = report.final_level === ThreatLevelEnum.HIGH;
    const isMedium = report.final_level === ThreatLevelEnum.MEDIUM;

    let verdictModifier = "sb-report__verdict--low";
    if (isCritical) verdictModifier = "sb-report__verdict--critical";
    else if (isHigh) verdictModifier = "sb-report__verdict--high";
    else if (isMedium) verdictModifier = "sb-report__verdict--medium";

    return (
        <div id="sb-report" className="sb-report">
            {/* Header du Rapport */}
            <div className="sb-report__header">
                <div>
                    <div className="sb-report__title">📊 Rapport de Détonation Sandbox</div>
                    <span className="sb-report__meta">Session : <strong>{report.session_id}</strong> (⏱️ {report.session_duration}s)</span>
                </div>
                <div className="sb-report__actions">
                    <button type="button" className="sb-btn sb-btn--secondary" onClick={handleCopy}>
                        <Copy size={14} /> Copier JSON
                    </button>
                    <button type="button" className="sb-btn sb-btn--secondary" onClick={onClear}>
                        <Trash2 size={14} /> Effacer
                    </button>
                </div>
            </div>

            {/* Verdict & Jauge de Menace */}
            <div className={`sb-report__verdict ${verdictModifier}`}>
                <div>
                    {isCritical && <ShieldX size={40} />}
                    {isHigh && <ShieldAlert size={40} />}
                    {isMedium && <AlertTriangle size={40} />}
                    {!isCritical && !isHigh && !isMedium && <ShieldCheck size={40} />}
                </div>

                <div>
                    <div className="sb-report__verdict-title">
                        {isCritical && "🔴 MENACE CRITIQUE DÉTECTÉE"}
                        {isHigh && "🟠 NIVEAU DE MENACE ÉLEVÉ"}
                        {isMedium && "🟡 COMPORTEMENT SUSPECT"}
                        {!isCritical && !isHigh && !isMedium && "🟢 CODE BÉNIN / SAIN"}
                    </div>
                    <p style={{ margin: "4px 0 0", color: "var(--text-secondary)" }}>
                        Score global : <strong>{report.final_score} / 100</strong> [{report.final_level}]
                    </p>
                    
                    <div style={{ marginTop: "8px" }}>
                        {report.killed ? (
                            <span className="sb-report__kill-badge sb-report__kill-badge--killed">
                                🛑 CONTAINER TUÉ EN URGENCE (SIGKILL)
                            </span>
                        ) : (
                            <span className="sb-report__kill-badge sb-report__kill-badge--clean">
                                🟢 Exécution Normale
                            </span>
                        )}
                    </div>
                </div>
            </div>

            {/* Zone Complète des Alertes & MITRE ATT&CK */}
            <ThreatAlertsView alerts={report.alerts || []} />

            {/* Console Terminal */}
            <div className="sb-terminal">
                <div className="sb-terminal__header">
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "0.85rem", color: "var(--text-primary)" }}>
                        <TerminalSquare size={14} /> Console d'Exécution
                    </div>
                    <div className="sb-terminal__tabs" style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                        <button
                            type="button"
                            className={`sb-terminal__tab-btn ${activeConsoleTab === "stdout" ? "sb-terminal__tab-btn--active" : ""}`}
                            onClick={() => setActiveConsoleTab("stdout")}
                        >
                            stdout
                        </button>
                        <button
                            type="button"
                            className={`sb-terminal__tab-btn ${activeConsoleTab === "stderr" ? "sb-terminal__tab-btn--active" : ""}`}
                            onClick={() => setActiveConsoleTab("stderr")}
                        >
                            stderr
                        </button>

                        <button
                            type="button"
                            className="sb-terminal__tab-btn"
                            onClick={handleCopyConsoleOutput}
                            title={`Copier la sortie ${activeConsoleTab}`}
                            style={{ marginLeft: "8px", border: "1px solid var(--border)" }}
                        >
                            <Copy size={12} /> Copier {activeConsoleTab}
                        </button>
                    </div>
                </div>

                <pre className={`sb-terminal__body ${activeConsoleTab === "stderr" ? "sb-terminal__body--error" : ""}`}>
                    {activeConsoleTab === "stdout" 
                        ? (report.exec_result?.stdout || "(Aucune sortie standard émise)") 
                        : (report.exec_result?.stderr || "(Aucune erreur émise)")}
                </pre>
            </div>

            {/* Spécifications de la Session */}
            <div style={{ fontSize: "0.82rem", color: "var(--text-tertiary)", borderTop: "1px solid var(--border)", paddingTop: "14px", display: "flex", gap: "16px", flexWrap: "wrap" }}>
                <span>🔬 <strong>Langage :</strong> {report.exec_result?.language?.toUpperCase() || "N/A"}</span>
                <span>⚙️ <strong>Exit Code :</strong> {report.exec_result?.exit_code ?? "N/A"}</span>
                <span>⚡ <strong>Événements tracés :</strong> {report.stats?.events_processed || 0}</span>
                {report.stats?.container_pid && <span>🐳 <strong>PID Hôte :</strong> {report.stats.container_pid}</span>}
            </div>
        </div>
    );
}

// ============================================================================
// COMPOSANT PRINCIPAL : Détonation
// ============================================================================

export function AnalyzeCodeComponent({ navigate }: { navigate?: ReturnType<typeof useNavigate> }) {
    const defaultNavigate = useNavigate();
    const nav = navigate || defaultNavigate;

    const [inputMode, setInputMode] = useState<"editor" | "file">("editor");
    const [code, setCode] = useState<string>("");
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const [selectedLang, setSelectedLang] = useState<SupportedLanguage | "auto">("auto");
    const [languageOptions, setLanguageOptions] = useState<LanguageOption[]>([
        { val: "auto", label: "✨ Détection Automatique" }
    ]);

    const [showAdvanced, setShowAdvanced] = useState<boolean>(false);
    const [config, setConfig] = useState<SandboxConfigOverrides>({
        mem_limit: "256m",
        exec_timeout: 30,
        alert_threshold: 60,
        enable_strace: true,
        enable_fs_monitor: true,
    });
    
    // ⚡ Option Cache (activable / désactivable facilement)
    const [useCache, setUseCache] = useState<boolean>(true);

    const [report, setReport] = useState<AnalyzeCodeResponse | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        getSupportedLanguages(
            (data: { languages: string[] }) => {
                if (data?.languages) {
                    setLanguageOptions(buildLanguageOptions(data.languages));
                }
            },
            () => {},
            null,
            nav
        );
    }, []);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            setSelectedFile(e.target.files[0]);
            toast.success(`📁 Fichier "${e.target.files[0].name}" sélectionné !`);
        }
    };

    const handleAnalyze = async () => {
        if (inputMode === "editor" && !code.trim()) {
            toast.error("⚠️ Veuillez saisir du code source !");
            return;
        }
        if (inputMode === "file" && !selectedFile) {
            toast.error("⚠️ Veuillez sélectionner un fichier !");
            return;
        }

        const payload: AnalyzeCodeFormDataRequest = {
            code: inputMode === "editor" ? code : undefined,
            file: inputMode === "file" ? (selectedFile as File) : undefined,
            language: selectedLang !== "auto" ? selectedLang : undefined,
            config_str: JSON.stringify(config),
            use_cache: useCache ? 1 : 0,
        };

        const res = await analyzeCode(payload, setReport, setError, setLoading, nav);
        if (res) {
            toast.success("💣 Détonation terminée !");
        }
    };

    return (
        <div id="sb-detonate-container" className="sb-detonate-container">
            {/* Header */}
            <div className="sb-detonate-header">
                <h3 className="sb-detonate-header__title">💣 Détonation Dynamique en Sandbox Docker</h3>
                <p className="sb-detonate-header__subtitle">
                    Exécutez le code suspect dans un container étanche et observez en direct les appels système (`strace`) et les accès aux fichiers (`inotify`).
                </p>
            </div>

            {/* Input Zone */}
            <div id="sb-detonate-box" className="sb-detonate-box">
                <div className="sb-detonate-mode-toggle">
                    <button
                        type="button"
                        className={`sb-detonate-mode-btn ${inputMode === "editor" ? "sb-detonate-mode-btn--active" : ""}`}
                        onClick={() => setInputMode("editor")}
                        disabled={inputMode === "editor"}
                    >
                        ✍️ Éditeur de Code
                    </button>
                    <button
                        type="button"
                        className={`sb-detonate-mode-btn ${inputMode === "file" ? "sb-detonate-mode-btn--active" : ""}`}
                        onClick={() => setInputMode("file")}
                        disabled={inputMode === "file"}
                    >
                        📁 Fichier Script
                    </button>
                </div>

                {inputMode === "editor" ? (
                    <CodeEditor
                        value={code}
                        onChange={setCode}
                        language={selectedLang}
                        onLanguageChange={setSelectedLang}
                        languages={languageOptions}
                        disabled={loading}
                    />
                ) : (
                    <label className="sb-detonate-upload">
                        <UploadCloud size={36} className="sb-detonate-upload__icon" />
                        <span className="sb-detonate-upload__text">Cliquez pour sélectionner un script (.py, .sh, .c, .js...)</span>
                        <input
                            type="file"
                            style={{ display: 'none' }}
                            onChange={handleFileChange}
                            disabled={loading}
                        />
                        {selectedFile && (
                            <span className="sb-detonate-upload__file-info">
                                📄 {selectedFile.name} ({(selectedFile.size / 1024).toFixed(1)} Ko)
                            </span>
                        )}
                    </label>
                )}

                {/* Option Rapide Cache */}
                <div className="sb-detonate-options">
                    <label className="sb-detonate-option">
                        <input
                            id="sb-check-cache"
                            type="checkbox"
                            className="sb-detonate-checkbox"
                            checked={useCache}
                            onChange={(e) => setUseCache(e.target.checked)}
                        />
                        <span>
                            ⚡ <strong>Utiliser le cache de détonation</strong> (réponse instantanée si ce code a déjà été analysé)
                        </span>
                    </label>
                </div>

                {/* Paramètres avancés */}
                <div className="sb-detonate-advanced">
                    <button
                        type="button"
                        className="sb-detonate-advanced__toggle"
                        onClick={() => setShowAdvanced(!showAdvanced)}
                    >
                        <Sliders size={16} /> {showAdvanced ? "Masquer les options de détonation" : "⚙️ Paramètres avancés de la Sandbox"}
                    </button>

                    {showAdvanced && (
                        <div className="sb-detonate-advanced__grid">
                            <div className="sb-detonate-advanced__field">
                                <label>⏱️ Timeout Max (s)</label>
                                <input
                                    type="number"
                                    min={5}
                                    max={120}
                                    className="sb-detonate-advanced__input"
                                    value={config.exec_timeout}
                                    onChange={(e) => setConfig({ ...config, exec_timeout: Number(e.target.value) })}
                                />
                            </div>

                            <div className="sb-detonate-advanced__field">
                                <label>🧠 Limite RAM</label>
                                <select
                                    className="sb-detonate-advanced__select"
                                    value={config.mem_limit}
                                    onChange={(e) => setConfig({ ...config, mem_limit: e.target.value })}
                                >
                                    <option value="128m">128 Mo</option>
                                    <option value="256m">256 Mo</option>
                                    <option value="512m">512 Mo</option>
                                    <option value="1g">1 Go</option>
                                </select>
                            </div>

                            <div className="sb-detonate-advanced__field">
                                <label>🚨 Seuil Kill (Score)</label>
                                <input
                                    type="number"
                                    min={10}
                                    max={100}
                                    className="sb-detonate-advanced__input"
                                    value={config.alert_threshold}
                                    onChange={(e) => setConfig({ ...config, alert_threshold: Number(e.target.value) })}
                                />
                            </div>
                        </div>
                    )}
                </div>

                {/* Boutons d'Action */}
                <div className="sb-detonate-actions">
                    <button
                        id="sb-btn-detonate"
                        type="button"
                        className="sb-btn sb-btn--primary"
                        disabled={loading || (inputMode === "editor" ? !code.trim() : !selectedFile)}
                        onClick={handleAnalyze}
                    >
                        <Bomb size={16} /> {loading ? "⏳ Détonation en cours..." : "🚀 Lancer la Détonation"}
                    </button>

                    <button
                        type="button"
                        className="sb-btn sb-btn--secondary"
                        disabled={loading}
                        onClick={() => {
                            setCode("");
                            setSelectedFile(null);
                            setReport(null);
                            setError(null);
                        }}
                    >
                        <RotateCcw size={16} /> Réinitialiser
                    </button>
                </div>
            </div>

            {/* Rapport de Détonation */}
            {report && (
                <ShowSandboxReport
                    report={report}
                    onClear={() => setReport(null)}
                />
            )}
        </div>
    );
}

export default AnalyzeCodeComponent;