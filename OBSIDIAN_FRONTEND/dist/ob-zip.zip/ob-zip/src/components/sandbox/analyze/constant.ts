import { SupportedLanguage } from "@/types/sandbox/types";
export type LanguageOption = {
    val: SupportedLanguage | "auto";
    label: string;
};

// Mapping complet avec émojis
export const LANGUAGE_LABEL_MAP: Record<string, string> = {
    auto: "✨ Détection Automatique",
    python: "🐍 Python",
    bash: "🐚 Bash / Shell",
    sh: "🐚 Shell",
    javascript: "🟨 JavaScript",
    js: "🟨 JavaScript",
    c: "⚙️ C",
    cpp: "⚙️ C++",
    rust: "🦀 Rust",
    go: "🐹 Go",
    ruby: "💎 Ruby",
    php: "🐘 PHP",
    java: "☕ Java",
    perl: "🐪 Perl",
    lua: "🌙 Lua",
    r: "📊 R",
    powershell: "💙 PowerShell",
    ps1: "💙 PowerShell",
};

/**
 * Retourne le label formaté avec émoji ou un fallback générique
 */
export function getLanguageLabel(lang: string): string {
    const key = lang.toLowerCase();
    return LANGUAGE_LABEL_MAP[key] || `📄 ${lang.toUpperCase()}`;
}

/**
 * Construit la liste d'options à partir du tableau renvoyé par le backend
 * en injectant automatiquement "auto" en premier choix.
 */
export function buildLanguageOptions(backendLanguages: string[] = []): LanguageOption[] {
    const options: LanguageOption[] = [
        { val: "auto", label: "✨ Détection Automatique" }
    ];

    backendLanguages.forEach((lang) => {
        // Évite les doublons avec "auto"
        if (lang.toLowerCase() !== "auto") {
            options.push({
                val: lang as SupportedLanguage,
                label: getLanguageLabel(lang)
            });
        }
    });

    return options;
}