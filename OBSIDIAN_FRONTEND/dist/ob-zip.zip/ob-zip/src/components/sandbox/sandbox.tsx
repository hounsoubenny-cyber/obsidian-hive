import "./sandbox.css";
import React, { useEffect, useState } from "react";
import SbAnalyzeComponent from "./analyze/analyze";
import SbContainersComponent from "./containers/containers";
import SbHealthComponent from "./health/health";
import { SandboxHealthResponse, ContainerStatusResponse } from "@/types/sandbox/types";
import { getSandboxHealth, getContainersStatus } from "./utils";
import { Link, useNavigate } from "react-router-dom";
import { 
    Shield, 
    Bomb, 
    Box, 
    Activity, 
    XCircle, 
    CheckCircle2, 
    AlertTriangle, 
    Pin, 
    Sparkles,
    RefreshCw,
    Lock 
} from "lucide-react";
import toast from "react-hot-toast";
import { isLogin } from "@/hooks/get_token";

export type SandboxTabType = "analyze" | "containers" | "health";

function Sandbox() {
    const navigate = useNavigate();

    const [defaultTab, setDefaultTab] = useState<SandboxTabType>(() => {
        const saved = localStorage.getItem("sb_default_tab");
        return (saved as SandboxTabType) || "analyze";
    });

    const [activeTab, setActiveTab] = useState<SandboxTabType | null>(() => {
        const saved = localStorage.getItem("sb_default_tab");
        return (saved as SandboxTabType) || "analyze";
    });

    const [health, setHealth] = useState<SandboxHealthResponse | null>(null);
    const [healthLoading, setHealthLoading] = useState<boolean>(false);
    const [healthError, setHealthError] = useState<string | null>(null);

    // 🐳 État pour surveiller le nombre de containers actifs en continu
    const [containers, setContainers] = useState<ContainerStatusResponse | null>(null);

    const checkSystem = () => {
        getSandboxHealth(setHealth, setHealthError, setHealthLoading, navigate);
        getContainersStatus(setContainers, () => {}, null, navigate);
    };

    useEffect(() => {
        checkSystem();
        const interval = setInterval(checkSystem, 30000); // Polling toutes les 30
        return () => clearInterval(interval);
    }, []);

    const handleSetDefaultTab = (tab: SandboxTabType) => {
        setDefaultTab(tab);
        localStorage.setItem("sb_default_tab", tab);
        toast.success(`📌 Onglet par défaut défini sur : ${getTabLabel(tab)}`);
    };

    function getTabLabel(tab: SandboxTabType): string {
        switch (tab) {
            case "analyze": return "💣 Analyse & Détonation";
            case "containers": return "🐳 Containers Actifs";
            case "health": return "🩺 Santé & Configuration";
            default: return "";
        }
    }
    const isHealthy = health?.status === "healthy" && !healthError;
    const activeContainersCount = containers?.filter(c => c.status === "running").length || 0;

    if (!isLogin()) {
        return (
            <div id="sb-locked-screen" className="simatk-module">
                <div className="simatk-auth-locked">
                    <Lock size={36} style={{ color: "var(--accent)" }} />
                    <h2>Accès Restreint à la Sandbox</h2>
                    <p>
                        Une session authentifiée est requise pour analyser des fichier potentiellement malveillants.
                    </p>
                    <Link to="/login" className="oh-btn oh-btn--primary" style={{ marginTop: 12 }}>
                        Se Connecter
                    </Link>
                </div>
            </div>
        );
    }
    
    return (
        <div id="sb-module" className="sb-module">
            {/* Header Fixe */}
            <header id="sb-header" className="sb-header">
                <div className="sb-header__top">
                    <div className="sb-header__left">
                        <Shield size={28} style={{ color: 'var(--accent)' }} />
                        <h1 className="sb-header__title">Sandbox</h1>
                        <span className="sb-header__version">v2.0</span>
                    </div>

                    <div className="sb-header__right">
                        {/* 🐳 BADGE DE CONTAINERS ACTIFS (Temps Réel) */}
                        <div 
                            className="oh-badge" 
                            style={{ 
                                background: activeContainersCount > 0 ? 'var(--accent-soft)' : 'var(--bg-surface-2)',
                                color: activeContainersCount > 0 ? 'var(--accent-strong)' : 'var(--text-tertiary)',
                                border: '1px solid var(--border)',
                                cursor: 'pointer'
                            }}
                            onClick={() => setActiveTab("containers")}
                            title="Cliquez pour voir les containers Docker actifs"
                        >
                            <Box size={14} />
                            <strong>{activeContainersCount}</strong> container{activeContainersCount > 1 ? "s" : ""} actif{activeContainersCount > 1 ? "s" : ""}
                        </div>

                        {/* Sélecteur Onglet par défaut */}
                        <div className="ap-default-selector">
                            <span className="ap-default-selector__label">
                                <Pin size={13} /> Défaut :
                            </span>
                            <select
                                className="ap-default-selector__select"
                                value={defaultTab}
                                onChange={(e) => handleSetDefaultTab(e.target.value as SandboxTabType)}
                            >
                                <option value="analyze">💣 Détonation</option>
                                <option value="containers">🐳 Containers</option>
                                <option value="health">🩺 Santé</option>
                            </select>
                        </div>

                        {/* Pastille Pulse Santé */}
                        <div className={`sb-pulse ${isHealthy ? "sb-pulse--ok" : "sb-pulse--err"}`}>
                            {healthLoading ? (
                                <span><RefreshCw size={14} className="oh-spin" /> Vérification...</span>
                            ) : isHealthy ? (
                                <span><CheckCircle2 size={14} /> 🟢 Sandbox Prête</span>
                            ) : (
                                <span><AlertTriangle size={14} /> 🔴 Sandbox Déconnectée</span>
                            )}
                        </div>
                    </div>
                </div>

                {/* Navigation des Onglets */}
                <nav id="sb-nav" className="sb-nav">
                    <button
                        id="sb-nav-analyze"
                        type="button"
                        className={`sb-nav__btn ${activeTab === "analyze" ? "sb-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("analyze")}
                    >
                        <Bomb size={16} /> 💣 Analyse & Détonation
                    </button>

                    <button
                        id="sb-nav-containers"
                        type="button"
                        className={`sb-nav__btn ${activeTab === "containers" ? "sb-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("containers")}
                    >
                        <Box size={16} /> 🐳 Containers Actifs {activeContainersCount > 0 && `(${activeContainersCount})`}
                    </button>

                    <button
                        id="sb-nav-health"
                        type="button"
                        className={`sb-nav__btn ${activeTab === "health" ? "sb-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("health")}
                    >
                        <Activity size={16} /> 🩺 Santé & Profils
                    </button>

                    {activeTab !== null && (
                        <button
                            id="sb-nav-close"
                            type="button"
                            className="sb-nav__btn sb-nav__btn--close"
                            onClick={() => setActiveTab(null)}
                        >
                            ✖️ Fermer
                        </button>
                    )}
                </nav>
            </header>

            <hr id="sb-divider" className="sb-divider" />

            {/* Contenu Principal : GARDÉ EN MÉMOIRE avec display: none pour ne rien perdre ! */}
            <main id="sb-content">
                <section style={{ display: activeTab === "analyze" ? "block" : "none" }}>
                    <SbAnalyzeComponent navigate={navigate} />
                </section>

                <section style={{ display: activeTab === "containers" ? "block" : "none" }}>
                    <SbContainersComponent navigate={navigate} />
                </section>

                <section style={{ display: activeTab === "health" ? "block" : "none" }}>
                    <SbHealthComponent navigate={navigate} />
                </section>

                {/* État Désélectionné (Si activeTab === null) */}
                {activeTab === null && (
                    <div id="sb-empty" className="sb-empty">
                        <Sparkles size={40} style={{ color: 'var(--accent)' }} />
                        <h2 style={{ fontSize: '1.3rem', fontWeight: 700 }}>🛡️ Environnement Sandbox</h2>
                        <p style={{ fontSize: '0.92rem', color: 'var(--text-secondary)' }}>
                            Sélectionnez un outil ci-dessus ou lancez directement une action :
                        </p>

                        <div className="sb-empty__actions">
                            <button className="sb-btn sb-btn--primary" type="button" onClick={() => setActiveTab("analyze")}>
                                <Bomb size={16} /> 💣 Détoner un Script Suspect
                            </button>
                            <button className="sb-btn sb-btn--secondary" type="button" onClick={() => setActiveTab("containers")}>
                                <Box size={16} /> 🐳 Superviser les Containers ({activeContainersCount})
                            </button>
                            <button className="sb-btn sb-btn--secondary" type="button" onClick={() => setActiveTab("health")}>
                                <Activity size={16} /> 🩺 Examiner les Spécifications
                            </button>
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
}

export default Sandbox;