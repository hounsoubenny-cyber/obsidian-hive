import "./naviguation.css";
import { Link, Route, Routes, useLocation } from "react-router-dom";
import { createPortal } from "react-dom";
import Login from "./login/login";
import NotFound from "./not_found/not_found";
import Home from "./home";
import AssetPage from "./assets/assets/asset";
import JobPage from "./jobs/jobs/jobs";
import ReportPage from "./reports/reports";
import Dashboard from "./dashbord/dashboard";
import ChatCoraliePage from "@/components/chat_coralie/chat_coralie";
import ModulePage from "./modules_page/module_page/module_page";
import ModulePageModal from "./modules_page/module_page_modal/module_page_modal";
import { useState, useEffect, useRef } from "react";
import {
  Menu,
  X,
  LayoutDashboard,
  Monitor,
  Clock,
  FileText,
  MessageSquare,
  Shield,
  LogIn,
  LogOut,
  PanelLeftClose,
  PanelLeftOpen,
  Home as HomeIcon,
  Package,
  ChevronDown,
} from "lucide-react";
import { isLogin } from "@/hooks/get_token";
import { MODULES } from "@/data/modules/data";
import AntiPhishing from "./anti_phishing/anti_phishing";
import Sandbox from "./sandbox/sandbox";
import Scanner from "./scanner/scanner";
import SimulateurAttaque from "./simulateur_attaque/simulateur_attaque";
import IdsIps from "./ids_ips/ids_ips";
import LogoutPage from "./logout/logout";

function Naviguation() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [showModuleDropdown, setShowModuleDropdown] = useState(false);
  const [showModuleModal, setShowModuleModal] = useState(false);
  const [dropdownPos, setDropdownPos] = useState({ top: 0, left: 0 });
  const moduleItemRef = useRef<HTMLLIElement>(null);
  const location = useLocation();
  const loggedIn = isLogin();

  useEffect(() => {
    setMenuOpen(false);
    setShowModuleDropdown(false);
  }, [location.pathname]);

  const authItems = loggedIn
    ? { path: "/logout", name: "Déconnexion", icon: LogOut }
    : { path: "/login", name: "Connexion", icon: LogIn };

  const toggleMenu = () => setMenuOpen(!menuOpen);
  const toggleCollapse = () => setIsCollapsed(!isCollapsed);

  const handleModuleEnter = () => {
    if (moduleItemRef.current) {
      const rect = moduleItemRef.current.getBoundingClientRect();
      setDropdownPos({ top: rect.top, left: rect.right + 8 });
    }
    if (!isCollapsed) setShowModuleDropdown(true);
  };

  return (
    <div className="nav-container">
      {/* Bouton burger pour mobile */}
      <button className="burger-btn" onClick={toggleMenu} aria-label="Menu">
        {menuOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Overlay pour mobile */}
      {menuOpen && <div className="nav-overlay" onClick={toggleMenu} />}

      {/* Navigation latérale */}
      <nav className={`vertical-nav ${menuOpen ? 'open' : ''} ${isCollapsed ? 'collapsed' : ''}`}>
        {/* Header */}
        <div className="nav-header">
          <div className="nav-logo">
            <Shield className="logo-icon" size={28} />
            {!isCollapsed && <span className="logo-text">Obsidian Hive</span>}
          </div>
          {!isCollapsed && <div className="nav-subtitle">v1.0.0</div>}
        </div>

        {/* Menu */}
        <ul className="nav-menu">
          {/* Accueil */}
          <li>
            <Link to="/" className={location.pathname === '/' ? 'active' : ''}>
              <HomeIcon size={20} className="nav-icon" />
              {!isCollapsed && <span className="nav-name">Accueil</span>}
              {isCollapsed && <span className="nav-tooltip">Accueil</span>}
            </Link>
          </li>

          {/* Dashboard */}
          <li>
            <Link to="/dashboard" className={location.pathname === '/dashboard' ? 'active' : ''}>
              <LayoutDashboard size={20} className="nav-icon" />
              {!isCollapsed && <span className="nav-name">Dashboard</span>}
              {isCollapsed && <span className="nav-tooltip">Dashboard</span>}
            </Link>
          </li>

          {/* Modules dropdown rendu via Portal */}
          <li
            ref={moduleItemRef}
            className="nav-module-item"
            onMouseEnter={handleModuleEnter}
            onMouseLeave={() => !isCollapsed && setShowModuleDropdown(false)}
          >
            <button
              className={`nav-module-btn ${location.pathname === '/modules' ? 'active' : ''}`}
              onClick={() => setShowModuleModal(true)}
            >
              <Package size={20} className="nav-icon" />
              {!isCollapsed && <span className="nav-name">Modules</span>}
              {isCollapsed && <span className="nav-tooltip">Modules</span>}
              {!isCollapsed && <ChevronDown size={14} className="nav-chevron" />}
            </button>
          </li>

          {/* Assets */}
          <li>
            <Link to="/assets" className={location.pathname === '/assets' ? 'active' : ''}>
              <Monitor size={20} className="nav-icon" />
              {!isCollapsed && <span className="nav-name">Assets</span>}
              {isCollapsed && <span className="nav-tooltip">Assets</span>}
            </Link>
          </li>

          {/* Jobs */}
          <li>
            <Link to="/jobs" className={location.pathname === '/jobs' ? 'active' : ''}>
              <Clock size={20} className="nav-icon" />
              {!isCollapsed && <span className="nav-name">Jobs</span>}
              {isCollapsed && <span className="nav-tooltip">Jobs</span>}
            </Link>
          </li>

          {/* Rapports */}
          <li>
            <Link to="/reports" className={location.pathname === '/reports' ? 'active' : ''}>
              <FileText size={20} className="nav-icon" />
              {!isCollapsed && <span className="nav-name">Rapports</span>}
              {isCollapsed && <span className="nav-tooltip">Rapports</span>}
            </Link>
          </li>

          {/* Chat */}
          <li>
            <Link to="/chat" className={location.pathname === '/chat' ? 'active' : ''}>
              <MessageSquare size={20} className="nav-icon" />
              {!isCollapsed && <span className="nav-name">Chat</span>}
              {isCollapsed && <span className="nav-tooltip">Chat</span>}
            </Link>
          </li>
        </ul>

        {/* Footer avec bouton collapse + auth */}
        <div className="nav-footer">
          {/* Bouton collapse dans le footer */}
          <button
            className="nav-collapse-btn-footer"
            onClick={toggleCollapse}
            aria-label={isCollapsed ? "Agrandir" : "Réduire"}
            title={isCollapsed ? "Agrandir" : "Réduire"}
          >
            {isCollapsed ? <PanelLeftOpen size={18} /> : <PanelLeftClose size={18} />}
            {!isCollapsed && <span>Réduire</span>}
          </button>

          <div className="nav-status">
            <div className="status-dot"></div>
            {!isCollapsed && <span>Système actif</span>}
          </div>

          <Link to={authItems.path} className="nav-auth-link">
            <authItems.icon size={18} className="nav-auth-icon" />
            {!isCollapsed && <span>{authItems.name}</span>}
          </Link>

          {!isCollapsed && (
            <div className="nav-version">
              <span>🔒 Sécurisé</span>
            </div>
          )}
        </div>
      </nav>

      {/* Contenu principal */}
      <div className={`content-wrapper ${isCollapsed ? 'collapsed' : ''}`}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/logout" element={<LogoutPage />} />
          <Route path="/assets" element={<AssetPage />} />
          <Route path="/jobs" element={<JobPage />} />
          <Route path="/reports" element={<ReportPage />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/chat" element={<ChatCoraliePage />} />
          <Route path="/modules" element={<ModulePage />} />
          <Route path="/modules/anti-phishing" element={<AntiPhishing />} />
          <Route path="/modules/sandbox" element={<Sandbox />} />
          <Route path="/modules/scanner" element={<Scanner />} />
          <Route path="/modules/simulator" element={<SimulateurAttaque />} />
          <Route path="/modules/ids-ips" element={<IdsIps />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </div>

      {/* Dropdown Modules — rendu en Portal pour échapper au overflow:hidden de .nav-menu */}
        {showModuleDropdown && !isCollapsed && createPortal(
        <div
            className="nav-module-dropdown"
            style={{ top: dropdownPos.top, left: dropdownPos.left }}
            onMouseEnter={() => setShowModuleDropdown(true)}
            onMouseLeave={() => setShowModuleDropdown(false)}
        >
            {MODULES.slice()
            .sort((a, b) => a.name.localeCompare(b.name))
            .map((mod, idx) =>
                mod.dispo ? (
                <Link
                    key={idx}
                    to={mod.link}
                    className="nav-module-dropdown-item"
                    onClick={() => setShowModuleDropdown(false)}
                >
                    <span className="nav-module-dropdown-icon">{mod.emoji}</span>
                    <span className="nav-module-dropdown-name">{mod.name}</span>
                    <span className="nav-module-dropdown-status active">🟢</span>
                </Link>
                ) : (
                <div key={idx} className="nav-module-dropdown-item nav-module-dropdown-item-locked">
                    <span className="nav-module-dropdown-icon">{mod.emoji}</span>
                    <span className="nav-module-dropdown-name">{mod.name}</span>
                    <span className="nav-module-dropdown-status inactive">🔴</span>
                </div>
                )
            )}
        </div>,
        document.body
    )}

      {/* Module Modal */}
      <ModulePageModal
        isOpen={showModuleModal}
        onClose={() => setShowModuleModal(false)}
      />
    </div>
  );
}

export default Naviguation;
