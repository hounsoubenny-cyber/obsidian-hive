import "./home.css";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  ShieldCheck,
  Radar,
  ClipboardList,
  FileBarChart,
  Bot,
  ArrowRight,
  Sparkles,
  ArrowLeft,
} from "lucide-react";
import { toTitleCaseWithUnderscore } from "./utils/to_lower_case";
import { AppConfig, getConfig } from "@/hooks/get_config";
import { isLogin } from "@/hooks/get_token";

const FEATURES = [
  {
    icon: Radar,
    title: "Scan continu des assets",
    text: "Surveillez en permanence votre surface d'attaque et détectez les changements dès qu'ils surviennent.",
  },
  {
    icon: ClipboardList,
    title: "Jobs orchestrés",
    text: "Planifiez, lancez et suivez vos jobs de sécurité depuis un tableau de bord unique et clair.",
  },
  {
    icon: FileBarChart,
    title: "Rapports exploitables",
    text: "Générez des rapports détaillés et priorisés, prêts à être partagés avec vos équipes.",
  },
  {
    icon: Bot,
    title: "Coralie, votre copilote IA",
    text: "Posez vos questions, obtenez des synthèses et accélérez vos investigations avec l'assistant intégré.",
  },
];

const STATS = [
  { value: "24/7", label: "Surveillance active" },
  { value: "100%", label: "Traçabilité des scans" },
  { value: "< 5 min", label: "Pour lancer un job" },
];

function Home() {
  const [isVisible, setIsVisible] = useState(true);
  const [conf, setConf] = useState<AppConfig | null>(null);
  useEffect(() => {
      async function load() {
          const cfg: AppConfig = await getConfig();
          setConf(cfg);
      }
      load();
  }, []);
  
  useEffect(() => {
    setIsVisible(true);
  }, []);
  const productName = conf?.productName ? toTitleCaseWithUnderscore(conf.productName) : "Obsidian Hive";

  return (
    <div className="home-wrapper">
      {/* Hero Section */}
      <section className={`hero-section ${isVisible ? 'fade-in' : ''}`}>
        <div className="hero-content">
          <div className="hero-badge">
            <Sparkles size={14} />
            {conf?.productName ? toTitleCaseWithUnderscore(conf.productName) : "Obsidian Hive"} Platform
          </div>
          <h1 className="hero-title">
            Votre sécurité,<br />
            toujours <span className="hero-highlight">en éveil</span>
          </h1>
          <p className="hero-subtitle">
            {productName} centralise le scan de vos assets, l'orchestration de vos jobs
            et vos rapports de sécurité, avec Coralie à vos côtés pour accélérer chaque investigation.
          </p>
          <div className="hero-buttons">
            <Link to={!isLogin() ? "/login" : "/logout"} className="btn-primary-hero">
              <ShieldCheck size={18} />
              {!isLogin() ? "Se connecter" : "Se deconnecter"}
              {!isLogin() ? <ArrowRight size={16} /> : <ArrowLeft size={16} />}
            </Link>
            {
              isLogin() && (
                 <Link to="/dashboard" className="btn-secondary-hero">
                  Voir le dashboard
                </Link>
              )
            }
          </div>
        </div>

        {/* Signature : radar de surveillance pulsé */}
        <div className="hero-radar" aria-hidden="true">
          <div className="hero-radar__ring hero-radar__ring--1" />
          <div className="hero-radar__ring hero-radar__ring--2" />
          <div className="hero-radar__ring hero-radar__ring--3" />
          <div className="hero-radar__core">
            <ShieldCheck size={26} />
          </div>
          <span className="hero-radar__blip hero-radar__blip--1" />
          <span className="hero-radar__blip hero-radar__blip--2" />
        </div>
      </section>

      {/* Stats */}
      <section className="home-stats">
        {STATS.map((stat) => (
          <div className="home-stat" key={stat.label}>
            <span className="home-stat__value">{stat.value}</span>
            <span className="home-stat__label">{stat.label}</span>
          </div>
        ))}
      </section>

      {/* Features */}
      <section className="home-features">
        <div className="home-features__header">
          <h2>Une plateforme, toute la chaîne de sécurité</h2>
          <p>De la détection au rapport final, sans changer d'outil.</p>
        </div>
        <div className="home-features__grid">
          {FEATURES.map((feature) => {
            const Icon = feature.icon;
            return (
              <div className="feature-card" key={feature.title}>
                <div className="feature-card__icon">
                  <Icon size={22} />
                </div>
                <h3 className="feature-card__title">{feature.title}</h3>
                <p className="feature-card__text">{feature.text}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Footer */}
      <footer className="home-footer">
        {
            `© ${new Date().getFullYear()} ${toTitleCaseWithUnderscore(productName)} — Tous droits réservés`
        }
      </footer>
    </div>
  );
}

export default Home;
