import "./add_asset_modal.css";
import { logError } from "@/hooks/error_utils";
import { useEffect, useState } from "react";
import { HelpersListResponse } from "@/types/scanner/types";
import { 
  AddAssetResult, 
  AssetType, 
  NetworkAssetModel, 
  PRIORITY_MAPPING, 
  WebAssetModel,
  ServerAssetModel
} from "@/types/assets/types";
import { 
  createNetworkAssetAction, 
  createWebAssetAction, 
  getIdsIpsDefaultConfig, 
  getScannerDefaultConfig, 
  getScannerSupportedVulns, 
  listScannerHelper 
} from "./utils";
import { AddNetworkAsset, AddWebAsset, AddServerAsset } from "./add_asset_modal_utils";
import { Copy, Check, Terminal } from "lucide-react";
import toast from "react-hot-toast";
import { createServerAssetAction } from "./utils";

// ============================================================================
// COMPOSANT PRINCIPAL : ADD ASSET MODAL
// ============================================================================

function AddAssetModal({ 
  setShowModal, 
  onAssetCreated, 
  naviguate 
}: { 
  setShowModal: (val: boolean) => void; 
  onAssetCreated: () => void; 
  naviguate: (val: any) => void;
}) {

  // ===== ÉTATS PRINCIPAUX =====
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [assetType, setAssetType] = useState<AssetType | null>(null);
  const [formData, setFormData] = useState<WebAssetModel | NetworkAssetModel | ServerAssetModel | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>("");
  const [createdResult, setCreatedResult] = useState<AddAssetResult | null>(null);
  const [copiedCmd, setCopiedCmd] = useState<boolean>(false);

  // ===== CONFIGS =====
  const [scannerDefaultConfig, setScannerDefaultConfig] = useState<Record<string, any> | null>(null);
  const [scannerSupportedVulns, setScannerSupportedVulns] = useState<string[] | null>(null);
  const [idsIpsDefaultConfig, setIdsIpsDefaultConfig] = useState<Record<string, any> | null>(null);
  const [scannerHelperList, setScannerHelperList] = useState<HelpersListResponse | null>(null);

  // ===== CHARGEMENT INITIAL =====
  useEffect(() => {
    getScannerDefaultConfig(setScannerDefaultConfig, () => {}, null, naviguate);
    getIdsIpsDefaultConfig(setIdsIpsDefaultConfig, () => {}, null, naviguate);
    listScannerHelper(setScannerHelperList, () => {}, null, naviguate);
    getScannerSupportedVulns(setScannerSupportedVulns, () => {}, null, naviguate);
  }, [naviguate]);

  // ===== FERMETURE =====
  const close = () => {
    setShowModal(false);
    setCurrentStep(1);
    setAssetType(null);
    setFormData(null);
    setCreatedResult(null);
    setError("");
  };

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
    };
    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, []);

  // ===== NAVIGATION =====
  const nextStep = () => {
    if (currentStep === 1 && !assetType) {
      setError("Veuillez sélectionner un type d'actif.");
      return;
    }
    if (currentStep === 2 && !formData) {
      setError("Veuillez valider la configuration d'abord.");
      return;
    }
    setError("");
    setCurrentStep((prev) => prev + 1);
  };

  const prevStep = () => {
    setError("");
    setCurrentStep((prev) => prev - 1);
  };

  // ===== SOUMISSION =====
  const handleSubmit = async () => {
    if (!formData) return;
    setLoading(true);
    setError("");

    try {
      let result: AddAssetResult | null = null;
      if (assetType === "web_site" || assetType === "web_app") {
        result = await createWebAssetAction(formData as WebAssetModel, setError, setLoading, naviguate);
      } else if (assetType === "network") {
        result = await createNetworkAssetAction(formData as NetworkAssetModel, setError, setLoading, naviguate);
      } else if (assetType === "server") {
        result = await createServerAssetAction(formData as ServerAssetModel, setError, setLoading, naviguate);
      }

      if (result && (result.status === "ok" || result.status === "success")) {
        setCreatedResult(result);
        onAssetCreated();
        if (assetType !== "server") {
          toast.success("✅ Actif créé avec succès !");
          setTimeout(() => close(), 600);
        } else {
          toast.success("🎉 Serveur créé ! Copiez la commande d'installation.");
        }
      } else {
        const errMsg = result?.error || "Erreur lors de la création de l'actif";
        setError(errMsg);
        toast.error(`Erreur: ${errMsg}`);
      }
    } catch (err) {
      const msg = logError(err);
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleCopyInstallCmd = async () => {
    if (createdResult?.install_command) {
      await navigator.clipboard.writeText(createdResult.install_command);
      setCopiedCmd(true);
      toast.success("Commande copiée !");
      setTimeout(() => setCopiedCmd(false), 1500);
    }
  };

  // ===== RENDU DES ÉTAPES =====
  const renderStep = () => {
    switch (currentStep) {
      case 1: return renderTypeSelection();
      case 2: return renderConfiguration();
      case 3: return renderValidation();
      default: return null;
    }
  };

  // ── ÉTAPE 1 : CHOIX DU TYPE (4 TYPES) ──
  const renderTypeSelection = () => {
    const types = [
      { type: "web_site" as AssetType, icon: "🌐", label: "Site web", desc: "Site web statique ou dynamique" },
      { type: "web_app" as AssetType, icon: "🧩", label: "Application web", desc: "SPA, PWA, application frontend" },
      { type: "network" as AssetType, icon: "📡", label: "Réseau", desc: "Surveillance IDS/IPS, Gateway, Bridge" },
      { type: "server" as AssetType, icon: "🖥️", label: "Serveur distant", desc: "Agent autonome léger (audit, logs, tools)" },
    ];

    return (
      <div className="jam_step_type">
        <h3 className="jam_step_title">📋 Choisis le type d'actif</h3>
        <p className="jam_step_subtitle">Sélectionne le type d'actif que tu veux ajouter :</p>
        <div className="jam_type_grid">
          {types.map((t) => (
            <div 
              key={t.type} 
              className={`jam_type_card ${assetType === t.type ? "selected" : ""}`} 
              onClick={() => { setAssetType(t.type); setError(""); }}
            >
              <div className="jam_type_icon">{t.icon}</div>
              <div className="jam_type_label">{t.label}</div>
              <div className="jam_type_desc">{t.desc}</div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // ── ÉTAPE 2 : CONFIGURATION SELON LE TYPE ──
  const renderConfiguration = () => {
    const isWeb = assetType === "web_site" || assetType === "web_app";

    return (
      <div className="jam_step_config">
        <h3 className="jam_step_title">
          {isWeb 
            ? "🌐 Configuration de l'actif web" 
            : assetType === "network" 
            ? "📡 Configuration de l'actif réseau" 
            : "🖥️ Configuration du serveur distant"}
        </h3>

        {isWeb ? (
          <AddWebAsset
            scannerDefaultConfig={scannerDefaultConfig || {}}
            scannerHelperList={scannerHelperList || { helpers: [], total: 0, usage: "" }}
            supportedScannerVulns={scannerSupportedVulns || []}
            isSpa={assetType === "web_app"}
            desc_limit={100}
            show_module={false}
            onValidate={(data) => {
              setFormData(data); 
              toast.success("Configuration validée !");
            }}
            naviguate={naviguate}
          />
        ) : assetType === "network" ? (
          <AddNetworkAsset
            idsIpsDefaultConfig={idsIpsDefaultConfig || {}}
            desc_limit={100}
            show_module={false}
            onValidate={(data) => {
              setFormData(data); 
              toast.success("Configuration validée !");
            }}
            naviguate={naviguate}
          />
        ) : (
          <AddServerAsset
            onValidate={(data) => {
              setFormData(data);
              toast.success("Configuration serveur prête !");
            }}
          />
        )}
      </div>
    );
  };

  // ── ÉTAPE 3 : VÉRIFICATION ET RÉSULTAT (COMMANDE D'INSTALLATION) ──
  const renderValidation = () => {
    const isWeb = assetType === "web_site" || assetType === "web_app";
    const typeLabel = isWeb 
      ? (assetType === "web_site" ? "Site web" : "Application web") 
      : assetType === "network" 
      ? "Réseau" 
      : "Serveur distant";

    return (
      <div className="jam_step_validation">
        <h3 className="jam_step_title">✅ Vérification</h3>
        <p className="jam_step_subtitle">Confirmez les informations avant de créer :</p>

        {/* Si le serveur a été créé et renvoie la commande d'installation */}
        {createdResult?.install_command ? (
          <div style={{ background: "var(--bg-surface)", padding: 24, borderRadius: "var(--radius-lg)", border: "1px solid var(--accent)", display: "flex", flexDirection: "column", gap: 14 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, color: "var(--accent-strong)", fontWeight: 700 }}>
              <Terminal size={20} /> Commande d'installation de l'Agent Serveur
            </div>
            <p style={{ margin: 0, fontSize: "0.86rem", color: "var(--text-secondary)" }}>
              Exécutez cette commande en <strong>root (sudo)</strong> sur la machine cible. L'agent sera téléchargé et configuré automatiquement en tant que service systemd.
            </p>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <pre style={{ margin: 0, flex: 1, padding: "12px 14px", background: "#07090e", borderRadius: "var(--radius-md)", color: "#38bdf8", fontFamily: "var(--font-mono)", fontSize: "0.82rem", overflowX: "auto" }}>
                <code>{createdResult.install_command}</code>
              </pre>
              <button type="button" className="oh-btn oh-btn--primary" onClick={handleCopyInstallCmd}>
                {copiedCmd ? <Check size={14} /> : <Copy size={14} />} {copiedCmd ? "Copié !" : "Copier"}
              </button>
            </div>
          </div>
        ) : (
          <div className="jam_summary">
            <div className="jam_summary_row"><span className="jam_summary_label">Type</span><span className="jam_summary_value">{typeLabel}</span></div>
            <div className="jam_summary_row"><span className="jam_summary_label">Nom</span><span className="jam_summary_value">{formData?.name || "Non défini"}</span></div>
            <div className="jam_summary_row"><span className="jam_summary_label">Priorité</span><span className="jam_summary_value">{PRIORITY_MAPPING[formData?.priority || 1]}</span></div>
            
            {isWeb && (
              <>
                <div className="jam_summary_row"><span className="jam_summary_label">URL</span><span className="jam_summary_value">{(formData as WebAssetModel)?.url || "Non définie"}</span></div>
                <div className="jam_summary_row"><span className="jam_summary_label">SPA</span><span className="jam_summary_value">{(formData as WebAssetModel)?.type === "web_app" ? "✅ Oui" : "❌ Non"}</span></div>
                <div className="jam_summary_row"><span className="jam_summary_label">Fix autorisé</span><span className="jam_summary_value">{(formData as WebAssetModel)?.fix_allowed ? "✅ Oui" : "❌ Non"}</span></div>
                <div className="jam_summary_row"><span className="jam_summary_label">Helpers</span><span className="jam_summary_value">{((formData as WebAssetModel)?.scan_args?.helpers || []).length > 0 ? (formData as WebAssetModel)?.scan_args?.helpers.map(h => h.name).join(", ") : "Aucun"}</span></div>
              </>
            )}

            {assetType === "network" && (
              <div className="jam_summary_row"><span className="jam_summary_label">Mode de déploiement</span><span className="jam_summary_value">{(formData as NetworkAssetModel)?.deployment_mode || "Non défini"}</span></div>
            )}

            {assetType === "server" && (
              <div className="jam_summary_row"><span className="jam_summary_label">Mode de connexion</span><span className="jam_summary_value">Agent autonome sécurisé (WebSocket)</span></div>
            )}

            <div className="jam_summary_row"><span className="jam_summary_label">Tags</span><span className="jam_summary_value">{formData?.tags?.join(", ") || "—"}</span></div>
          </div>
        )}

        {error && <div className="jam_error">{error}</div>}
      </div>
    );
  };

  const RenderStepBtn = () => {
    const prevBtn = (
      <button type="button" className="jam_btn jam_btn_secondary" onClick={prevStep} disabled={loading}>
        ← Précédent
      </button>
    );

    let nextBtn = null;
    if (currentStep === 1) {
      nextBtn = (
        <button type="button" className="jam_btn jam_btn_primary" onClick={nextStep} disabled={assetType === null || loading}>
          Suivant →
        </button>
      );
    } else if (currentStep === 2) {
      nextBtn = (
        <button type="button" className="jam_btn jam_btn_primary" onClick={nextStep} disabled={!formData || loading}>
          Suivant →
        </button>
      );
    } else if (currentStep === 3) {
      if (createdResult?.install_command) {
        nextBtn = (
          <button type="button" className="jam_btn jam_btn_primary" onClick={close}>
            Terminer & Fermer
          </button>
        );
      } else {
        nextBtn = (
          <button type="button" className="jam_btn jam_btn_primary" onClick={handleSubmit} disabled={loading}>
            {loading ? "⏳ Création en cours..." : "✅ Créer l'actif"}
          </button>
        );
      }
    }

    return (
      <div className="jam_modal_footer">
        {currentStep > 1 && !createdResult && prevBtn}
        {nextBtn}
      </div>
    );
  };

  return (
    <div className="jam_modal_overlay" onClick={close}>
      <div className="jam_modal_container" onClick={(e) => e.stopPropagation()}>
        <div className="jam_modal_header">
          <h2>➕ Ajouter un actif</h2>
          <button type="button" className="jam_modal_close" onClick={close}>✕</button>
        </div>

        <div className="jam_modal_steps">
          <span className={`jam_step ${currentStep >= 1 ? "active" : ""}`}>1. Type</span>
          <span className="jam_step_sep">—</span>
          <span className={`jam_step ${currentStep >= 2 ? "active" : ""}`}>2. Configuration</span>
          <span className="jam_step_sep">—</span>
          <span className={`jam_step ${currentStep >= 3 ? "active" : ""}`}>3. Validation</span>
        </div>

        <div className="jam_modal_body">{renderStep()}</div>

        <div>
          <RenderStepBtn />
        </div>
      </div>
    </div>
  );
}

export default AddAssetModal;