import { useState, useEffect } from "react";
import { 
  Asset, 
  AssetStatusMapping, 
  AssetTypeMapping, 
  PRIORITY_MAPPING, 
  Priority, 
  AssetStatus,
  ServerAsset,
  AgentStatusMapping,
  AgentCapabilitiesMapping,
  AgentCapabilities,
  ServerToolInfo
} from "@/types/assets/types";
import { 
  assetTypeIcon, 
  statusDotClass,
  rotateServerSecretAction,
  revokeServerAssetAction,
  reactivateServerAssetAction,
  getServerToolsList,
  toggleServerTool,
  toggleServerCapability
} from "./utils";
import JSON5 from "json5";
import JsonEditor from "@/components/utils/json_editor/json_editor";
import { useNavigate } from "react-router-dom";
import { 
  Pause, 
  Play, 
  Trash2, 
  Loader2, 
  FolderOpen, 
  ChevronDown, 
  X, 
  Edit3, 
  Save, 
  RotateCcw, 
  TriangleAlert, 
  Plus,
  KeyRound,
  Ban,
  Terminal,
  Cpu,
  Server,
  Copy,
  Check
} from "lucide-react";
import toast from "react-hot-toast";

// ============================================================================
// COMPOSANT : ASSET PREVIEW (CARTE DANS LA LISTE)
// ============================================================================

export function AssetPreview({
  asset,
  selected,
  onSelect,
  onPause,
  onResume,
  onDelete,
  isActionLoading,
}: {
  asset: Asset;
  selected: boolean;
  onSelect: () => void;
  onPause: (id: string) => void;
  onResume: (id: string) => void;
  onDelete: (id: string) => void;
  isActionLoading: (id: string) => boolean;
}) {
  const assetId = asset.id || "";
  const isLoading = isActionLoading(assetId);
  const isServer = asset.type === "server";

  return (
    <div
      id={`asset_preview_${assetId}`}
      className={`asset_preview_card ${selected ? "asset_preview_selected" : ""}`}
      onClick={onSelect}
    >
      <div className="asset_preview_header">
        <span className="asset_preview_icon">{assetTypeIcon[asset.type]}</span>
        <span className="asset_preview_name">{asset.name || "Actif sans nom"}</span>
      </div>

      <div className="asset_preview_meta">
        <span className="asset_preview_type_badge">{AssetTypeMapping[asset.type]}</span>
        
        {isServer ? (
          <span className="asset_preview_status">
            <span className={`status_dot ${asset.agent_status === "connected" ? "status_dot_active" : "status_dot_inactive"}`}></span>
            {AgentStatusMapping[asset.agent_status || "pending_install"]}
          </span>
        ) : (
          <span className="asset_preview_status">
            <span className={`status_dot ${statusDotClass[asset.status]}`}></span>
            {AssetStatusMapping[asset.status]}
          </span>
        )}

        <span className="asset_preview_priority">
          <TriangleAlert size={11} />
          {PRIORITY_MAPPING[asset.priority]}
        </span>
      </div>

      {asset.tags && asset.tags.length > 0 && (
        <div className="asset_preview_tags">
          {asset.tags.map((tag, i) => (
            <span key={i} className="asset_preview_tag">
              #{tag}
            </span>
          ))}
        </div>
      )}

      <div className="asset_preview_actions" onClick={(e) => e.stopPropagation()}>
        {!isServer && (
          asset.status === "active" ? (
            <button
              type="button"
              className="btn_action_preview btn_pause"
              onClick={() => onPause(assetId)}
              disabled={isLoading || !assetId}
              title="Mettre en pause"
            >
              {isLoading ? <Loader2 size={14} className="spin" /> : <Pause size={14} />}
            </button>
          ) : (
            <button
              type="button"
              className="btn_action_preview btn_resume"
              onClick={() => onResume(assetId)}
              disabled={isLoading || !assetId}
              title="Reprendre"
            >
              {isLoading ? <Loader2 size={14} className="spin" /> : <Play size={14} />}
            </button>
          )
        )}
        <button
          type="button"
          className="btn_action_preview btn_delete"
          onClick={() => onDelete(assetId)}
          disabled={isLoading || !assetId}
          title="Supprimer"
        >
          {isLoading ? <Loader2 size={14} className="spin" /> : <Trash2 size={14} />}
        </button>
      </div>
    </div>
  );
}

// ============================================================================
// COMPOSANT : ASSET DETAIL (PANNEAU DE DÉTAIL + MODE ÉDITION COMPLET)
// ============================================================================

export function AssetDetail({
  asset,
  onPause,
  onResume,
  onDelete,
  onDeselect,
  onUpdateAsset,
  isActionLoading,
}: {
  asset: Asset | null;
  onPause: (id: string) => void;
  onResume: (id: string) => void;
  onDelete: (id: string) => void;
  onDeselect: () => void;
  onUpdateAsset: (assetId: string, attrs: Record<string, any>, restartWorkflow?: boolean) => Promise<boolean>;
  isActionLoading: (id: string) => boolean;
}) {
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [showMoreDetails, setShowMoreDetails] = useState<boolean>(false);
  const [saving, setSaving] = useState<boolean>(false);

  // Formulaire d'édition standard
  const [editName, setEditName] = useState<string>("");
  const [editPriority, setEditPriority] = useState<Priority>(1);
  const [editStatus, setEditStatus] = useState<AssetStatus>("active");
  const [editTags, setEditTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState<string>("");
  const [editFixAllowed, setEditFixAllowed] = useState<boolean>(false);
  const [editRestartWorkflow, setEditRestartWorkflow] = useState<boolean>(false);

  // Configurations JSON éditables
  const [editInitConfig, setEditInitConfig] = useState<any>(null);
  const [editRunConfig, setEditRunConfig] = useState<any>(null);
  const [editConfContent, setEditConfContent] = useState<any>(null);

  // États Spécifiques ServerAsset
  const [catalogTools, setCatalogTools] = useState<ServerToolInfo[]>([]);
  const [reactivationCmd, setReactivationCmd] = useState<string | null>(null);
  const [copiedCmd, setCopiedCmd] = useState<boolean>(false);

  const assetId = asset?.id || "";
  const isLoading = isActionLoading(assetId);
  const isServer = asset?.type === "server";
  const isWebAsset = asset?.type === "web_site" || asset?.type === "web_app";

  useEffect(() => {
    if (isServer) {
      getServerToolsList((tools) => setCatalogTools(tools || []), () => {}, navigate);
    }
  }, [isServer, navigate]);

  if (!asset) {
    return (
      <div id="asset_detail_empty" className="asset_detail_empty">
        <FolderOpen size={30} className="asset_detail_empty_icon" />
        <p>Sélectionne un actif dans la liste pour voir ses détails ici.</p>
      </div>
    );
  }

  // Fonction originelle de formatage
  const formatConfigValue = (value: unknown): string => {
    if (value === null || value === undefined) return "—";
    if (typeof value === "string") return value;
    if (typeof value === "boolean") return value ? "✅ Oui" : "❌ Non";
    if (typeof value === "object") {
      try {
        return JSON.stringify(value, null, 2);
      } catch {
        return "[Objet non sérialisable]";
      }
    }
    return String(value);
  };

  // Basculer en mode édition
  const startEditing = () => {
    setEditName(asset.name || "");
    setEditPriority(asset.priority);
    setEditStatus(asset.status);
    setEditTags([...(asset.tags || [])]);
    setEditFixAllowed(Boolean((asset as any).fix_allowed));
    setEditRestartWorkflow(false);

    setEditInitConfig((asset as any).init_config || {});
    setEditRunConfig((asset as any).run_config || {});
    
    try {
      setEditConfContent(asset.conf_content ? JSON5.parse(asset.conf_content) : {});
    } catch {
      setEditConfContent({});
    }

    setIsEditing(true);
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !editTags.includes(tagInput.trim())) {
      setEditTags([...editTags, tagInput.trim()]);
      setTagInput("");
    }
  };

  const handleRemoveTag = (index: number) => {
    setEditTags(editTags.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    if (!assetId) return;
    setSaving(true);
    const attrs: Record<string, any> = {
      name: editName,
      priority: editPriority,
      status: editStatus,
      tags: editTags,
    };

    if (isWebAsset) {
      attrs.fix_allowed = editFixAllowed;
      if (editInitConfig) attrs.init_config = editInitConfig;
      if (editRunConfig) attrs.run_config = editRunConfig;
    }

    if (editConfContent) {
      attrs.conf_content = typeof editConfContent === "string" ? editConfContent : JSON5.stringify(editConfContent);
    }

    const ok = await onUpdateAsset(assetId, attrs, editRestartWorkflow);
    setSaving(false);
    if (ok) {
      setIsEditing(false);
      toast.success("✅ Actif mis à jour avec succès !");
    }
  };

  // ── Actions Spécifiques ServerAsset ────────────────────────────────────────
  const handleRotateSecret = async () => {
    const res = await rotateServerSecretAction(assetId, () => {}, null, navigate);
    if (res?.status === "success") {
      toast.success("🔑 Secret de l'agent renouvelé !");
    }
  };

  const handleRevoke = async () => {
    if (!confirm("Révoquer cet agent serveur ? Il sera immédiatement déconnecté.")) return;
    const ok = await revokeServerAssetAction(assetId, () => {}, null, navigate);
    if (ok) toast.success("⛔ Agent révoqué");
  };

  const handleReactivate = async () => {
    const res = await reactivateServerAssetAction(assetId, () => {}, null, navigate);
    if (res?.status === "success" && res.install_command) {
      setReactivationCmd(res.install_command);
      toast.success("Nouvelle commande de ré-enregistrement générée !");
    }
  };

  const handleCopyCmd = async () => {
    if (!reactivationCmd) return;
    await navigator.clipboard.writeText(reactivationCmd);
    setCopiedCmd(true);
    toast.success("Commande copiée !");
    setTimeout(() => setCopiedCmd(false), 1500);
  };

  const handleToggleTool = async (toolName: string, currentlyAllowed: boolean) => {
    const ok = await toggleServerTool(assetId, toolName, !currentlyAllowed, () => {}, navigate);
    if (ok) {
      toast.success(`Outil ${toolName} ${!currentlyAllowed ? "autorisé" : "révoqué"}`);
    }
  };

  const handleToggleCap = async (cap: AgentCapabilities, currentlyActive: boolean) => {
    const ok = await toggleServerCapability(assetId, cap, !currentlyActive, () => {}, navigate);
    if (ok) {
      toast.success(`Capacité ${cap} ${!currentlyActive ? "activée" : "désactivée"}`);
    }
  };

  return (
    <div id={`asset_detail_${assetId}`} className="asset_detail_panel">
      {/* ===== HEADER ===== */}
      <div className="asset_detail_header">
        <span className="asset_detail_icon">{assetTypeIcon[asset.type]}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <h2 className="asset_detail_name">{asset.name || "Actif sans nom"}</h2>
          <span style={{ fontSize: "0.72rem", color: "var(--text-tertiary)", fontFamily: "var(--font-mono)" }}>
            ID : {asset.id}
          </span>
        </div>
        
        {!isEditing ? (
          <button type="button" className="oh-btn oh-btn--ghost" style={{ padding: "5px 12px", fontSize: "0.8rem", marginLeft: "auto" }} onClick={startEditing}>
            <Edit3 size={13} /> Éditer l'actif
          </button>
        ) : (
          <button type="button" className="oh-btn oh-btn--ghost" style={{ padding: "5px 12px", fontSize: "0.8rem", marginLeft: "auto" }} onClick={() => setIsEditing(false)}>
            <RotateCcw size={13} /> Annuler
          </button>
        )}
      </div>

      {/* ===== CORPS : MODE ÉDITION VS MODE LECTURE ===== */}
      {isEditing ? (
        <div className="asset-edit-form">
          <div className="asset_detail_row">
            <span className="asset_detail_label">📛 Nom de l'actif</span>
            <input
              type="text"
              className="jam_input"
              style={{ maxWidth: "260px" }}
              value={editName}
              onChange={(e) => setEditName(e.target.value)}
              placeholder="Ex: Site Vitrine, Serveur Prod-01..."
            />
          </div>

          <div className="asset_detail_row">
            <span className="asset_detail_label">🔺 Priorité</span>
            <select
              className="jam_select"
              style={{ maxWidth: "260px" }}
              value={editPriority}
              onChange={(e) => setEditPriority(Number(e.target.value) as Priority)}
            >
              {Object.entries(PRIORITY_MAPPING).map(([key, val]) => (
                <option key={key} value={key}>{val} ({key})</option>
              ))}
            </select>
          </div>

          <div className="asset_detail_row">
            <span className="asset_detail_label">📶 Statut</span>
            <select
              className="jam_select"
              style={{ maxWidth: "260px" }}
              value={editStatus}
              onChange={(e) => setEditStatus(e.target.value as AssetStatus)}
            >
              {Object.entries(AssetStatusMapping).map(([key, val]) => (
                <option key={key} value={key}>{val}</option>
              ))}
            </select>
          </div>

          {isWebAsset && (
            <div className="asset_detail_row">
              <span className="asset_detail_label">🔧 Fix autorisé</span>
              <label className="scl-checkbox-item">
                <input
                  type="checkbox"
                  checked={editFixAllowed}
                  onChange={(e) => setEditFixAllowed(e.target.checked)}
                />
                <span>Autoriser Alex à corriger</span>
              </label>
            </div>
          )}

          {/* Édition des tags */}
          <div className="asset_detail_tags_block">
            <span className="asset_detail_label">🏷️ Tags</span>
            <div className="asset_detail_tags">
              {editTags.map((tag, idx) => (
                <span key={idx} className="asset_preview_tag" style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
                  #{tag}
                  <button type="button" className="jam_tag_remove" onClick={() => handleRemoveTag(idx)}>✕</button>
                </span>
              ))}
            </div>
            <div className="jam_tag_input" style={{ marginTop: 6 }}>
              <input
                type="text"
                className="jam_input"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleAddTag()}
                placeholder="Ajouter un tag..."
              />
              <button type="button" className="jam_btn jam_btn_small" onClick={handleAddTag}>
                <Plus size={12} />
              </button>
            </div>
          </div>

          {!isServer && (
            <div className="asset_detail_row" style={{ background: "var(--bg-surface-2)", padding: "10px 14px", borderRadius: "var(--radius-md)" }}>
              <span className="asset_detail_label">⚡ Redémarrage</span>
              <label className="scl-checkbox-item">
                <input
                  type="checkbox"
                  checked={editRestartWorkflow}
                  onChange={(e) => setEditRestartWorkflow(e.target.checked)}
                />
                <span>Redémarrer le workflow après sauvegarde</span>
              </label>
            </div>
          )}

          {/* JsonEditors spécifiques pour les configurations */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16, marginTop: 8 }}>
            {isWebAsset && (
              <>
                <JsonEditor
                  title="⚙️ Init Config (Instanciation Scanner)"
                  json={editInitConfig}
                  onSave={setEditInitConfig}
                  readOnly={false}
                  saveLabel="Enregistrer Init Config"
                />

                <JsonEditor
                  title="⚙️ Run Config (Options de Scan)"
                  json={editRunConfig}
                  onSave={setEditRunConfig}
                  readOnly={false}
                  saveLabel="Enregistrer Run Config"
                />
              </>
            )}

            {!isServer && (
              <JsonEditor
                title="⚙️ Config Brut (conf_content)"
                json={editConfContent}
                onSave={setEditConfContent}
                readOnly={false}
                saveLabel="Enregistrer Config Brut"
              />
            )}
          </div>

          <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
            <button type="button" className="oh-btn oh-btn--primary" style={{ flex: 1 }} onClick={handleSave} disabled={saving}>
              <Save size={14} /> {saving ? "Sauvegarde en cours..." : "Enregistrer les modifications"}
            </button>
            <button type="button" className="oh-btn oh-btn--ghost" onClick={() => setIsEditing(false)}>
              Annuler
            </button>
          </div>
        </div>
      ) : (
        /* ===== MODE LECTURE (100% COMPLET & ADAPTÉ AUX 3 TYPES) ===== */
        <>
          {/* ── SECTION SPÉCIFIQUE SERVEUR DISTANT ── */}
          {isServer ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {/* Statut Agent */}
              <div style={{ background: "var(--bg-surface-2)", padding: "12px 16px", borderRadius: "var(--radius-md)", border: "1px solid var(--border)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <span style={{ fontSize: "0.72rem", color: "var(--text-tertiary)", textTransform: "uppercase", fontWeight: 700, display: "block" }}>
                    État Agent
                  </span>
                  <span style={{ fontSize: "0.95rem", fontWeight: 700, color: (asset as ServerAsset).agent_status === "connected" ? "var(--success)" : "var(--warning)" }}>
                    {AgentStatusMapping[(asset as ServerAsset).agent_status || "pending_install"]}
                  </span>
                </div>
                {(asset as ServerAsset).last_heartbeat && (
                  <span style={{ fontSize: "0.74rem", color: "var(--text-tertiary)" }}>
                    Ping : {new Date((asset as ServerAsset).last_heartbeat!).toLocaleTimeString("fr-FR")}
                  </span>
                )}
              </div>

              {/* Commande de réactivation si disponible */}
              {reactivationCmd && (
                <div style={{ background: "var(--bg-surface-2)", padding: 12, borderRadius: "var(--radius-md)", border: "1px solid var(--accent)", display: "flex", flexDirection: "column", gap: 6 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontSize: "0.78rem", fontWeight: 700, color: "var(--accent-strong)" }}>
                      🔄 Commande de ré-enregistrement :
                    </span>
                    <button type="button" className="scl-btn-inline" onClick={handleCopyCmd}>
                      {copiedCmd ? <Check size={12} /> : <Copy size={12} />} {copiedCmd ? "Copié !" : "Copier"}
                    </button>
                  </div>
                  <pre style={{ margin: 0, padding: "8px 10px", background: "#07090e", borderRadius: 4, color: "#38bdf8", fontFamily: "var(--font-mono)", fontSize: "0.75rem", overflowX: "auto" }}>
                    <code>{reactivationCmd}</code>
                  </pre>
                </div>
              )}

              {/* Actions Rapides Serveur */}
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <button type="button" className="oh-btn oh-btn--ghost" style={{ padding: "6px 12px", fontSize: "0.78rem" }} onClick={handleRotateSecret}>
                  <KeyRound size={13} /> Rotation Secret
                </button>
                <button type="button" className="oh-btn oh-btn--ghost" style={{ padding: "6px 12px", fontSize: "0.78rem" }} onClick={handleReactivate}>
                  <RotateCcw size={13} /> Réenregistrer
                </button>
                <button type="button" className="oh-btn oh-btn--ghost" style={{ padding: "6px 12px", fontSize: "0.78rem", color: "var(--danger)" }} onClick={handleRevoke}>
                  <Ban size={13} /> Révoquer
                </button>
              </div>

              {/* Spécifications Système Hôte */}
              {(asset as ServerAsset).system_info && Object.keys((asset as ServerAsset).system_info).length > 0 && (
                <div style={{ background: "var(--bg-surface-2)", padding: 14, borderRadius: "var(--radius-md)", border: "1px solid var(--border)", display: "flex", flexDirection: "column", gap: 6 }}>
                  <span style={{ fontSize: "0.75rem", fontWeight: 700, color: "var(--text-tertiary)", textTransform: "uppercase" }}>
                    🖥️ Spécifications Machine
                  </span>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, fontSize: "0.8rem" }}>
                    <div>OS : <strong>{(asset as ServerAsset).system_info?.os} {(asset as ServerAsset).system_info?.os_release}</strong></div>
                    <div>Arch : <strong>{(asset as ServerAsset).system_info?.architecture}</strong></div>
                    <div>Hostname : <strong>{(asset as ServerAsset).system_info?.hostname}</strong></div>
                    <div>Python : <strong>{(asset as ServerAsset).system_info?.python_version}</strong></div>
                  </div>
                </div>
              )}

              {/* Outils Autorisés */}
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                <span style={{ fontSize: "0.75rem", fontWeight: 700, color: "var(--text-tertiary)", textTransform: "uppercase" }}>
                  🛠️ Outils Autorisés ({((asset as ServerAsset).allowed_tools || []).length})
                </span>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {catalogTools.map((tool) => {
                    const isAllowed = ((asset as ServerAsset).allowed_tools || []).includes(tool.name);
                    return (
                      <button
                        key={tool.name}
                        type="button"
                        className={`jam_vuln_chip ${isAllowed ? "active" : ""}`}
                        onClick={() => handleToggleTool(tool.name, isAllowed)}
                        title={tool.description}
                      >
                        {tool.name}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Capabilities */}
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                <span style={{ fontSize: "0.75rem", fontWeight: 700, color: "var(--text-tertiary)", textTransform: "uppercase" }}>
                  📦 Capacités & Modules
                </span>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {(["scanner_web", "anti_phishing", "sandbox", "ids_ips", "simulator"] as AgentCapabilities[]).map((cap) => {
                    const isCapActive = ((asset as ServerAsset).capabilities || []).includes(cap);
                    return (
                      <button
                        key={cap}
                        type="button"
                        className={`jam_vuln_chip ${isCapActive ? "active" : ""}`}
                        onClick={() => handleToggleCap(cap, isCapActive)}
                      >
                        {AgentCapabilitiesMapping[cap]}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            /* ── SECTIONS STANDARDS WEB & RÉSEAU ── */
            <>
              <div className="asset_detail_row">
                <span className="asset_detail_label">🆔 Identifiant</span>
                <span className="asset_detail_value asset_detail_mono">{asset.id}</span>
              </div>
              <div className="asset_detail_row">
                <span className="asset_detail_label">🏷️ Type</span>
                <span className="asset_detail_value">{AssetTypeMapping[asset.type]}</span>
              </div>
              <div className="asset_detail_row">
                <span className="asset_detail_label">📶 Statut</span>
                <span className="asset_detail_value">
                  <span className={`status_dot ${statusDotClass[asset.status]}`}></span>
                  {AssetStatusMapping[asset.status]}
                </span>
              </div>
              <div className="asset_detail_row">
                <span className="asset_detail_label">🔺 Priorité</span>
                <span className="asset_detail_value">{PRIORITY_MAPPING[asset.priority]}</span>
              </div>

              {isWebAsset ? (
                <>
                  <div className="asset_detail_row">
                    <span className="asset_detail_label">🔗 URL cible</span>
                    <span className="asset_detail_value asset_detail_mono">{asset.url}</span>
                  </div>
                  <div className="asset_detail_row">
                    <span className="asset_detail_label">📂 Code source</span>
                    <span className="asset_detail_value asset_detail_mono">
                      {asset.source_code_dir || "—"}
                    </span>
                  </div>
                  <div className="asset_detail_row">
                    <span className="asset_detail_label">🔧 Fix autorisé</span>
                    <span className="asset_detail_value">
                      {asset.fix_allowed ? "✅ Oui" : "❌ Non"}
                    </span>
                  </div>
                </>
              ) : (
                <>
                  <div className="asset_detail_row">
                    <span className="asset_detail_label">🛰️ Mode de déploiement</span>
                    <span className="asset_detail_value">{asset.deployment_mode}</span>
                  </div>
                  <div className="asset_detail_row">
                    <span className="asset_detail_label">📄 Fichier de config</span>
                    <span className="asset_detail_value asset_detail_mono">{asset.config_path}</span>
                  </div>
                </>
              )}
            </>
          )}

          {/* ===== TAGS ===== */}
          {asset.tags && asset.tags.length > 0 && (
            <div className="asset_detail_tags_block">
              <span className="asset_detail_label">🏷️ Tags</span>
              <div className="asset_detail_tags">
                {asset.tags.map((tag, i) => (
                  <span key={i} className="asset_preview_tag">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* ===== ACCORDÉON CONFIGURATIONS AVEC JSON EDITOR (NON SERVEUR) ===== */}
          {!isServer && (
            <>
              <div className="asset_detail_more_toggle">
                <button
                  type="button"
                  className={`btn_more_details ${showMoreDetails ? "is-open" : ""}`}
                  onClick={() => setShowMoreDetails(!showMoreDetails)}
                >
                  {showMoreDetails ? "Masquer les détails" : "Voir plus de détails"}
                  <ChevronDown size={14} className="btn_more_details_chevron" />
                </button>
              </div>

              {showMoreDetails && (
                <div className="asset_detail_more_panel" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                  <h4 className="asset_detail_more_title">📋 Configuration complète</h4>

                  {isWebAsset ? (
                    <>
                      <div>
                        <span className="asset_detail_label" style={{ display: "block", marginBottom: 6 }}>⚙️ Init Config</span>
                        <JsonEditor
                          title="⚙️ Init Config"
                          json={asset.init_config}
                          readOnly={true}
                          fileName="init_config.json"
                        />
                      </div>

                      <div>
                        <span className="asset_detail_label" style={{ display: "block", marginBottom: 6 }}>⚙️ Run Config</span>
                        <JsonEditor
                          title="⚙️ Run Config"
                          json={asset.run_config}
                          readOnly={true}
                          fileName="run_config.json"
                        />
                      </div>
                    </>
                  ) : (
                    <div className="asset_detail_row">
                      <span className="asset_detail_label">⚙️ Configuration</span>
                      <span className="asset_detail_value asset_detail_mono config_json">
                        {formatConfigValue(asset.config_path)}
                      </span>
                    </div>
                  )}

                  {asset?.conf_content && (
                    <div>
                      <span className="asset_detail_label" style={{ display: "block", marginBottom: 6 }}>⚙️ Config Brut</span>
                      <JsonEditor
                        title="⚙️ Config Brut"
                        json={(() => {
                          try { return JSON5.parse(asset.conf_content); }
                          catch { return { content: asset.conf_content }; }
                        })()}
                        readOnly={true}
                        fileName="conf_content.json"
                      />
                    </div>
                  )}
                </div>
              )}
            </>
          )}

          {/* ===== ACTIONS ===== */}
          <div className="asset_detail_actions">
            {!isServer && (
              asset.status === "active" ? (
                <button
                  type="button"
                  className="btn_action_detail btn_pause"
                  onClick={() => onPause(assetId)}
                  disabled={isLoading}
                >
                  {isLoading ? <Loader2 size={15} className="spin" /> : <Pause size={15} />}
                  Mettre en pause
                </button>
              ) : (
                <button
                  type="button"
                  className="btn_action_detail btn_resume"
                  onClick={() => onResume(assetId)}
                  disabled={isLoading}
                >
                  {isLoading ? <Loader2 size={15} className="spin" /> : <Play size={15} />}
                  Reprendre
                </button>
              )
            )}
            <button
              type="button"
              className="btn_action_detail btn_delete"
              onClick={() => onDelete(assetId)}
              disabled={isLoading}
            >
              {isLoading ? <Loader2 size={15} className="spin" /> : <Trash2 size={15} />}
              Supprimer
            </button>
            <button
              type="button"
              className="btn_action_detail btn_deselect"
              onClick={onDeselect}
              disabled={isLoading}
            >
              <X size={15} />
              Désélectionner
            </button>
          </div>

          {/* ===== MÉTADONNÉES ===== */}
          <div className="asset_detail_row">
            <span className="asset_detail_label">📅 Création</span>
            <span className="asset_detail_value">
              {asset.created_at ? new Date(asset.created_at).toLocaleString("fr-FR") : "—"}
            </span>
          </div>
          <div className="asset_detail_row">
            <span className="asset_detail_label">🔄 Dernière mise à jour</span>
            <span className="asset_detail_value">
              {asset.updated_at ? new Date(asset.updated_at).toLocaleString("fr-FR") : "—"}
            </span>
          </div>
          {asset.timestamp && (
            <div className="asset_detail_row">
              <span className="asset_detail_label">⏱️ Timestamp</span>
              <span className="asset_detail_value">{asset.timestamp}</span>
            </div>
          )}
        </>
      )}
    </div>
  );
}