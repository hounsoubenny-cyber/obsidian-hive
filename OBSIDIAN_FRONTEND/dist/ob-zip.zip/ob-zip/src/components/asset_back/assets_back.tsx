import "./assets.css";
import { useEffect, useState, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import {
  Asset,
  AssetStatus,
  AssetStatusMapping,
  AssetType,
  AssetTypeMapping,
  Priority,
  PRIORITY_MAPPING,
} from "@/types/assets/types";
import {
  pauseAsset as _pauseAsset,
  resumeAsset as _resumeAsset,
  deleteAsset as _deleteAsset,
} from "@/hooks/fetch_functions";
import { 
  listAsset,
  searchAsset,
  filterAsset as _filterAsset,
  capitalize,
  updateAssetAction,
  pauseAllAssetsAction,
  resumeAllAssetsAction
} from "./utils";
import { isLogin, getToken } from "@/hooks/get_token";
import { Link, useNavigate } from "react-router-dom";
import { logError } from "@/hooks/error_utils";
import AddAssetModal from "../add_asset_modal/add_asset_modal";
import { AssetDetail, AssetPreview } from "./asset_componant_utils";
import toast from "react-hot-toast";
import {
  Plus,
  RefreshCw,
  Search,
  SlidersHorizontal,
  ListFilter,
  FileText,
  Lock,
  Zap,
  Pause,
  Play,
  X as XIcon,
  TriangleAlert,
} from "lucide-react";

export function AssetPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const assetIdFromUrl = searchParams.get("asset_id");
  const [assets, setAssets] = useState<Asset[] | null>(null);
  const [assetsCopy, setAssetsCopy] = useState<Asset[] | null>(null);
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [error, setError] = useState<string>("");
  const [actionLoading, setActionLoading] = useState<Record<string, boolean>>({});
  const [bulkLoading, setBulkLoading] = useState<boolean>(false);
  const navigate = useNavigate();

  // Filtres
  const [priorityFilter, setPriorityFilter] = useState<Priority | null>(null);
  const [tagsFilter, setTagsFilter] = useState<string[]>([]);
  const [tagFilterInput, setTagFilterInput] = useState<string>("");
  const [typeFilter, setTypeFilter] = useState<AssetType | null>(null);
  const [statusFilter, setStatusFilter] = useState<AssetStatus | null>(null);
  const [autoFilter, setAutoFilter] = useState<boolean>(false);

  // Limites d'affichage
  const [listLimit, setListLimit] = useState<number>(5);
  const [searchLimit, setSearchLimit] = useState<number>(3);
  const [listShowAll, setListShowAll] = useState<boolean>(false);
  const [searchShowAll, setSearchShowAll] = useState<boolean>(false);
  const [localListLimit, setLocalListLimit] = useState<number>(listLimit);
  const [localSearchLimit, setLocalSearchLimit] = useState<number>(searchLimit);

  // Masquer / Afficher les sections
  const [showSearchBar, setShowSearchBar] = useState<boolean>(true);
  const [showFilters, setShowFilters] = useState<boolean>(true);
  const [showList, setShowList] = useState<boolean>(true);
  const [showDetail, setShowDetail] = useState<boolean>(true);

  // Recherche
  const [searchAssetInput, setSearchAssetInput] = useState<string>("");
  const [searchAssetResult, setSearchAssetResult] = useState<Asset[] | null>(null);
  const [searchError, setSearchError] = useState<string>("");
  const [searchLoading, setSearchLoading] = useState<boolean>(false);
  const [includeNameForResearch, setIncludeNameForResearch] = useState<boolean>(false);
  const [caseSensitiveForResearch, setCaseSensitiveForResearch] = useState<boolean>(false);
  const [partialForResearch, setPartialForResearch] = useState<boolean>(true);
  const [firstOnlyForResearch, setFirstOnlyForResearch] = useState<boolean>(false);
  const [limitForResearch, setLimitForResearch] = useState<number>(50);

  const [isReloading, setIsReloading] = useState<boolean>(false);
  const [showAddAssetModal, setShowAddAssetModal] = useState<boolean>(false);

  // Chargement initial
  useEffect(() => {
    listAsset([setAssets, setAssetsCopy], setError, null, navigate);
  }, [navigate]);

  useEffect(() => {
    if (assets && assetIdFromUrl) {
      const found = assets.find((a) => a.id === assetIdFromUrl);
      if (found) setSelectedAsset(found);
    }
  }, [assets, assetIdFromUrl]);

  const reload = async () => {
    setIsReloading(true);
    await listAsset([setAssets, setAssetsCopy], setError, null, navigate);
    setIsReloading(false);
  };

  // Gestion des Filtres
  const addTag = (tag: string) => {
    if (tag.trim()) setTagsFilter((prev) => [...prev, tag.trim()]);
    setTagFilterInput("");
  };

  const removeTag = (tag: string) => {
    setTagsFilter((prev) => prev.filter((t) => t !== tag));
  };

  const filterAsset = () => {
    const filtered = _filterAsset(assetsCopy || [], statusFilter, priorityFilter, tagsFilter, typeFilter);
    setAssets(filtered);
  };

  const resetFilters = () => {
    setPriorityFilter(null);
    setTypeFilter(null);
    setStatusFilter(null);
    setTagsFilter([]);
    setAssets(assetsCopy ? [...assetsCopy] : []);
  };

  useEffect(() => {
    if (autoFilter) filterAsset();
  }, [autoFilter, statusFilter, priorityFilter, typeFilter]);

  // Recherche
  const handleSearch = async () => {
    await searchAsset(
      searchAssetInput,
      includeNameForResearch,
      caseSensitiveForResearch,
      partialForResearch,
      firstOnlyForResearch,
      limitForResearch,
      setSearchAssetResult,
      setSearchError,
      setSearchLoading,
      navigate
    );
  };

  // Actions Unitaires
  const handlePause = async (id: string) => {
    setActionLoading((prev) => ({ ...prev, [id]: true }));
    try {
      const result = await _pauseAsset({ asset_id: id }, getToken());
      if (result.ok) {
        reload();
        toast.success("Actif mis en pause");
      } else {
        setError(`Erreur lors de la pause : ${result.error}`);
      }
    } catch (err) {
      setError(`Erreur lors de la pause : ${logError(err)}`);
    } finally {
      setActionLoading((prev) => ({ ...prev, [id]: false }));
    }
  };

  const handleResume = async (id: string) => {
    setActionLoading((prev) => ({ ...prev, [id]: true }));
    try {
      const result = await _resumeAsset({ asset_id: id }, getToken());
      if (result.ok) {
        reload();
        toast.success("Actif repris");
      } else {
        setError(`Erreur lors de la reprise : ${result.error}`);
      }
    } catch (err) {
      setError(`Erreur lors de la reprise : ${logError(err)}`);
    } finally {
      setActionLoading((prev) => ({ ...prev, [id]: false }));
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Supprimer définitivement cet actif ? Cette action est irréversible.")) return;

    setActionLoading((prev) => ({ ...prev, [id]: true }));
    try {
      const result = await _deleteAsset({ asset_id: id }, getToken());
      if (result.ok) {
        reload();
        if (selectedAsset?.id === id) setSelectedAsset(null);
        if (searchAssetResult) {
          setSearchAssetResult(searchAssetResult.filter((a) => a.id !== id));
        }
        toast.success("Actif supprimé");
      } else {
        setError(`Erreur lors de la suppression : ${result.error}`);
      }
    } catch (err) {
      setError(`Erreur lors de la suppression : ${logError(err)}`);
    } finally {
      setActionLoading((prev) => ({ ...prev, [id]: false }));
    }
  };

  const handleUpdateAsset = async (assetId: string, attrs: Record<string, any>, restartWorkflow = false): Promise<boolean> => {
    try {
      const res = await updateAssetAction({ asset_id: assetId, attrs, restart_workflow: restartWorkflow }, setError, null, navigate);
      if (res && res.status === "ok") {
        await reload();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  // ── Actions Collectives (Pause All / Resume All) ─────────────────────────
  const handlePauseAll = async () => {
    if (!confirm("Mettre en pause TOUS les actifs actifs du système ?")) return;
    setBulkLoading(true);
    const res = await pauseAllAssetsAction({}, setError, null, navigate);
    setBulkLoading(false);
    if (res && res.status === "success") {
      toast.success("⏸️ Tous les actifs ont été mis en pause");
      reload();
    }
  };

  const handleResumeAll = async () => {
    if (!confirm("Reprendre TOUS les actifs en pause du système ?")) return;
    setBulkLoading(true);
    const res = await resumeAllAssetsAction({}, setError, null, navigate);
    setBulkLoading(false);
    if (res && res.status === "success") {
      toast.success("▶️ Tous les actifs ont été repris");
      reload();
    }
  };

  const handleSelectAsset = (asset: Asset) => {
    setSelectedAsset(asset);
    setSearchParams((prev) => {
      prev.set("asset_id", asset.id!);
      return prev;
    }, { replace: true });
  };

  const handleDeselect = () => {
    setSelectedAsset(null);
    setSearchParams((prev) => {
      prev.delete("asset_id");
      return prev;
    }, { replace: true });
  };

  // Calcul des colonnes dynamiques
  const gridLayoutClass = useMemo(() => {
    const activeCount = [showFilters, showList, showDetail].filter(Boolean).length;
    if (activeCount === 3) return "asset-layout--3-cols";
    if (activeCount === 2) {
      if (showFilters && showList) return "asset-layout--filters-list";
      if (showList && showDetail) return "asset-layout--list-detail";
      if (showFilters && showDetail) return "asset-layout--filters-detail";
    }
    return "asset-layout--1-col";
  }, [showFilters, showList, showDetail]);

  if (!isLogin()) {
    return (
      <div id="asset_page_locked" className="asset_page_locked">
        <div className="grid-dots"></div>
        <div className="not-authenticated">
          <Lock size={26} className="not-authenticated-icon" />
          <h2>Accès restreint</h2>
          <p>Veuillez d'abord vous connecter à la <Link to="/login">page de connexion</Link>.</p>
        </div>
      </div>
    );
  }

  const totalAssets = assets?.length || 0;
  const totalSearchResults = searchAssetResult?.length || 0;

  return (
    <div id="asset_page" className="asset_page">
      {/* Toolbar Supérieure avec Actions Collectives */}
      <div className="asset_toolbar">
        <div className="asset_toolbar_title">
          <h1>Gestionnaire d'Actifs</h1>
          <span className="asset_toolbar_count">{totalAssets}</span>
        </div>

        <div className="asset_toolbar_actions">
          {/* Boutons d'Action Collective */}
          <button
            type="button"
            className="oh-btn oh-btn--ghost"
            style={{ color: "var(--warning)" }}
            onClick={handlePauseAll}
            disabled={bulkLoading || totalAssets === 0}
            title="Mettre en pause tous les actifs du système"
          >
            <Pause size={15} /> Tout suspendre
          </button>

          <button
            type="button"
            className="oh-btn oh-btn--ghost"
            style={{ color: "var(--success)" }}
            onClick={handleResumeAll}
            disabled={bulkLoading || totalAssets === 0}
            title="Reprendre tous les actifs du système"
          >
            <Play size={15} /> Tout reprendre
          </button>

          <button type="button" className="oh-btn oh-btn--primary" onClick={() => setShowAddAssetModal(true)}>
            <Plus size={16} /> Ajouter un actif
          </button>

          <button type="button" className="oh-btn oh-btn--ghost" onClick={reload} disabled={isReloading}>
            <RefreshCw size={15} className={isReloading ? "oh-spin" : ""} /> Actualiser
          </button>
        </div>
      </div>

      {/* Toggles de Sections */}
      <div className="section_toggles">
        <button
          type="button"
          className={`btn_toggle_section ${showSearchBar ? "is-active" : ""}`}
          onClick={() => setShowSearchBar(!showSearchBar)}
        >
          <Search size={14} /> Recherche
        </button>
        <button
          type="button"
          className={`btn_toggle_section ${showFilters ? "is-active" : ""}`}
          onClick={() => setShowFilters(!showFilters)}
        >
          <SlidersHorizontal size={14} /> Filtres
        </button>
        <button
          type="button"
          className={`btn_toggle_section ${showList ? "is-active" : ""}`}
          onClick={() => setShowList(!showList)}
        >
          <ListFilter size={14} /> Liste ({totalAssets})
        </button>
        <button
          type="button"
          className={`btn_toggle_section ${showDetail ? "is-active" : ""}`}
          onClick={() => setShowDetail(!showDetail)}
        >
          <FileText size={14} /> Détails
        </button>
      </div>

      {/* Barre de Recherche Complète */}
      {showSearchBar && (
        <div className="asset_search_bar">
          <div className="search_input_group">
            <label>Identifiant ou nom</label>
            <input
              className="search_asset_input"
              value={searchAssetInput}
              onChange={(e) => setSearchAssetInput(e.target.value)}
              placeholder="ex : sh_as-123, site vitrine, prod..."
              type="text"
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              disabled={searchLoading}
            />
          </div>

          <div className="search_toggle_group">
            <label>Chercher par nom</label>
            <button
              type="button"
              className={`btn_toggle ${includeNameForResearch ? "is-on" : ""}`}
              onClick={() => setIncludeNameForResearch(!includeNameForResearch)}
              disabled={searchLoading}
            >
              <span className="btn_toggle_knob" />
            </button>
          </div>

          <div className="search_toggle_group">
            <label>Sensible à la casse</label>
            <button
              type="button"
              className={`btn_toggle ${caseSensitiveForResearch ? "is-on" : ""}`}
              onClick={() => setCaseSensitiveForResearch(!caseSensitiveForResearch)}
              disabled={searchLoading}
            >
              <span className="btn_toggle_knob" />
            </button>
          </div>

          <div className="search_toggle_group">
            <label>Recherche partielle</label>
            <button
              type="button"
              className={`btn_toggle ${partialForResearch ? "is-on" : ""}`}
              onClick={() => setPartialForResearch(!partialForResearch)}
              disabled={searchLoading}
            >
              <span className="btn_toggle_knob" />
            </button>
          </div>

          <div className="search_toggle_group">
            <label>Un seul résultat</label>
            <button
              type="button"
              className={`btn_toggle ${firstOnlyForResearch ? "is-on" : ""}`}
              onClick={() => setFirstOnlyForResearch(!firstOnlyForResearch)}
              disabled={searchLoading}
            >
              <span className="btn_toggle_knob" />
            </button>
          </div>

          {!firstOnlyForResearch && (
            <div className="search_limit_group">
              <label>Max résultats</label>
              <input
                type="number"
                min="1"
                max="500"
                value={limitForResearch}
                onChange={(e) => {
                  const val = parseInt(e.target.value);
                  if (!isNaN(val) && val > 0 && val <= 500) setLimitForResearch(val);
                }}
                disabled={searchLoading}
              />
            </div>
          )}

          <button type="button" className="btn_search_asset" onClick={handleSearch} disabled={searchLoading}>
            <Search size={15} />
            {searchLoading ? "Recherche..." : "Rechercher"}
          </button>

          {searchError && <p className="search_error_text"><TriangleAlert size={13} /> {searchError}</p>}

          {/* Résultats de recherche */}
          {searchAssetResult !== null && (
            <div className="asset_search_results">
              <div className="search_results_header">
                <span className="search_results_count">
                  {totalSearchResults} résultat{totalSearchResults > 1 ? "s" : ""} trouvé{totalSearchResults > 1 ? "s" : ""}
                </span>
                <button type="button" className="scl-btn-inline" onClick={() => setSearchAssetResult(null)}>
                  ✕ Fermer recherche
                </button>
              </div>

              {searchAssetResult.length === 0 ? (
                <div className="asset_empty_state">Aucun résultat trouvé</div>
              ) : (
                <>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 12 }}>
                    {(searchShowAll ? searchAssetResult : searchAssetResult.slice(0, searchLimit)).map((asset, index) => (
                      <AssetPreview
                        key={`${asset.id}-${index}`}
                        asset={asset}
                        selected={selectedAsset?.id === asset.id}
                        onSelect={() => handleSelectAsset(asset)}
                        onPause={handlePause}
                        onResume={handleResume}
                        onDelete={handleDelete}
                        isActionLoading={(id) => Boolean(actionLoading[id])}
                      />
                    ))}
                  </div>

                  {totalSearchResults > searchLimit && (
                    <div className="see_more_controls">
                      <button type="button" onClick={() => setSearchShowAll(!searchShowAll)} className="btn_see_more">
                        {searchShowAll ? "Voir moins" : `Voir tout (${totalSearchResults})`}
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      )}

      {/* ── CORPS ADAPTATIF RÉARRANGÉ AUTOMATIQUEMENT ── */}
      <div className={`asset_main_content ${gridLayoutClass}`}>
        {/* Colonne 1 : Filtres */}
        {showFilters && (
          <aside className="asset_filters_panel">
            <h3><SlidersHorizontal size={15} /> Filtres</h3>

            <div className="filter_group auto_filter_group">
              <label><Zap size={13} /> Auto-filtre</label>
              <button
                type="button"
                className={`btn_toggle ${autoFilter ? "is-on" : ""}`}
                onClick={() => setAutoFilter(!autoFilter)}
              >
                <span className="btn_toggle_knob" />
              </button>
            </div>

            <div className="filter_group">
              <label>Priorité</label>
              <select
                className="jam_select"
                value={priorityFilter ?? ""}
                onChange={(e) => setPriorityFilter(e.target.value ? (parseInt(e.target.value) as Priority) : null)}
              >
                <option value="">Toutes</option>
                {Object.entries(PRIORITY_MAPPING).map(([key, value]) => (
                  <option key={key} value={key}>{capitalize(value)} ({key})</option>
                ))}
              </select>
            </div>

            <div className="filter_group">
              <label>Type</label>
              <select
                className="jam_select"
                value={typeFilter ?? ""}
                onChange={(e) => setTypeFilter(e.target.value ? (e.target.value as AssetType) : null)}
              >
                <option value="">Tous</option>
                {Object.entries(AssetTypeMapping).map(([key, value]) => (
                  <option key={key} value={key}>{value}</option>
                ))}
              </select>
            </div>

            <div className="filter_group">
              <label>Statut</label>
              <select
                className="jam_select"
                value={statusFilter ?? ""}
                onChange={(e) => setStatusFilter(e.target.value ? (e.target.value as AssetStatus) : null)}
              >
                <option value="">Tous</option>
                {Object.entries(AssetStatusMapping).map(([key, value]) => (
                  <option key={key} value={key}>{value}</option>
                ))}
              </select>
            </div>

            {/* Tags */}
            <div className="filter_group">
              <label>Tags</label>
              {tagsFilter.length > 0 && (
                <div className="active_tags_list">
                  {tagsFilter.map((value) => (
                    <span key={value} className="active_tag" onClick={() => removeTag(value)}>
                      #{value} <XIcon size={11} />
                    </span>
                  ))}
                </div>
              )}
              <div className="tag_input_row">
                <input
                  value={tagFilterInput}
                  onChange={(e) => setTagFilterInput(e.target.value)}
                  placeholder="ex : production"
                  type="text"
                  onKeyDown={(e) => e.key === "Enter" && addTag(tagFilterInput)}
                />
                <button type="button" onClick={() => addTag(tagFilterInput)}><Plus size={15} /></button>
              </div>
            </div>

            <div className="filter_actions">
              <button type="button" className="btn_apply_filters" onClick={filterAsset}>
                Filtrer
              </button>
              <button type="button" className="btn_reset_filters" onClick={resetFilters}>
                <RefreshCw size={13} /> Réinitialiser
              </button>
            </div>
          </aside>
        )}

        {/* Colonne 2 : Liste des Actifs */}
        {showList && (
          <section className="asset_list_panel">
            {error && <p className="asset_list_error"><TriangleAlert size={13} /> {error}</p>}
            <div className="list_header">
              <span className="list_count">{totalAssets} actif(s) au total</span>
            </div>

            {totalAssets === 0 ? (
              <div className="asset_empty_state">Aucun actif à afficher</div>
            ) : (
              <>
                <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                  {(listShowAll ? assets || [] : (assets || []).slice(0, listLimit)).map((asset, index) => (
                    <AssetPreview
                      key={`${asset.id}-${index}`}
                      asset={asset}
                      selected={selectedAsset?.id === asset.id}
                      onSelect={() => handleSelectAsset(asset)}
                      onPause={handlePause}
                      onResume={handleResume}
                      onDelete={handleDelete}
                      isActionLoading={(id) => Boolean(actionLoading[id])}
                    />
                  ))}
                </div>

                {totalAssets > listLimit && (
                  <div className="see_more_controls">
                    <button type="button" onClick={() => setListShowAll(!listShowAll)} className="btn_see_more">
                      {listShowAll ? "Voir moins" : `Voir tout (${totalAssets})`}
                    </button>
                  </div>
                )}
              </>
            )}
          </section>
        )}

        {/* Colonne 3 : Panneau Détail & Édition */}
        {showDetail && (
          <section className="asset_detail_panel_wrapper">
            <AssetDetail
              asset={selectedAsset}
              onPause={handlePause}
              onResume={handleResume}
              onDelete={handleDelete}
              onDeselect={handleDeselect}
              onUpdateAsset={handleUpdateAsset}
              isActionLoading={(id) => Boolean(actionLoading[id])}
            />
          </section>
        )}
      </div>

      {/* Modal d'ajout d'actif */}
      {showAddAssetModal && (
        <AddAssetModal
          setShowModal={setShowAddAssetModal}
          onAssetCreated={() => {
            reload();
            setShowAddAssetModal(false);
          }}
          naviguate={navigate}
        />
      )}
    </div>
  );
}

export default AssetPage;