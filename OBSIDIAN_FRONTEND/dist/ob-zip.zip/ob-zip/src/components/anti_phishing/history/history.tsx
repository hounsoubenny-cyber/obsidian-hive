import { useEffect, useState } from "react";
import "./history.css";
import { 
    HistoryUrlResponse, 
    HistoryMailResponse,
    HistoryItemUrl,
    HistoryItemMail 
} from "@/types/anti_phishing/types";
import { getHistoryUrl, getHistoryMails } from "../utils";
import { useNavigate } from "react-router-dom";
import { 
    History, 
    Globe, 
    Mail, 
    RefreshCw, 
    Search, 
    Copy, 
    Calendar, 
    Filter,
    AlertTriangle,
    ChevronLeft,
    ChevronRight,
    ChevronsLeft,
    ChevronsRight,
    ListFilter
} from "lucide-react";
import toast from "react-hot-toast";

type HistoryType = "url" | "mail";

function ApHistoryComponent({ navigate }: { navigate?: ReturnType<typeof useNavigate> }) {
    const defaultNavigate = useNavigate();
    const nav = navigate || defaultNavigate;

    // Onglet actif : URLs ou Emails
    const [historyType, setHistoryType] = useState<HistoryType>("url");

    // Données d'historique issues de utils
    const [urlHistory, setUrlHistory] = useState<HistoryUrlResponse | null>(null);
    const [mailHistory, setMailHistory] = useState<HistoryMailResponse | null>(null);

    // États de chargement et erreurs
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    // Filtres locaux
    const [searchFilter, setSearchFilter] = useState<string>("");
    const [decisionFilter, setDecisionFilter] = useState<string>("all");

    // 🔢 États de la pagination
    const [currentPage, setCurrentPage] = useState<number>(1);
    const [itemsPerPage, setItemsPerPage] = useState<number>(10);

    // Chargement initial des deux historiques
    useEffect(() => {
        getHistoryUrl("json", setUrlHistory, setError, setLoading, nav);
        getHistoryMails("json", setMailHistory, setError, setLoading, nav);
    }, []);

    // Rechargement manuel ou au changement d'onglet
    const loadHistory = () => {
        if (historyType === "url") {
            getHistoryUrl("json", setUrlHistory, setError, setLoading, nav);
        } else {
            getHistoryMails("json", setMailHistory, setError, setLoading, nav);
        }
    };

    // 🔄 Réinitialiser la page à 1 lors d'un changement de filtre, d'onglet ou de taille de page
    useEffect(() => {
        setCurrentPage(1);
    }, [historyType, searchFilter, decisionFilter, itemsPerPage]);

    // 🛡️ Extraction sécurisée des listes
    const rawUrls: HistoryItemUrl[] = Array.isArray(urlHistory?.json)
        ? urlHistory.json
        : Array.isArray(urlHistory)
        ? (urlHistory as unknown as HistoryItemUrl[])
        : [];

    const rawMails: HistoryItemMail[] = Array.isArray(mailHistory?.json)
        ? mailHistory.json
        : Array.isArray(mailHistory)
        ? (mailHistory as unknown as HistoryItemMail[])
        : [];

    // Filtrage des URLs
    const filteredUrls: HistoryItemUrl[] = rawUrls.filter((item) => {
        if (!item || typeof item !== "object") return false;
        const urlStr = (item.url || "").toLowerCase();
        const sourceStr = (item.source || "").toLowerCase();
        const search = searchFilter.toLowerCase();
        
        const matchesSearch = urlStr.includes(search) || sourceStr.includes(search);
        const matchesDecision = decisionFilter === "all" || item.final_decision === decisionFilter;
        return matchesSearch && matchesDecision;
    });

    // Filtrage des Emails
    const filteredMails: HistoryItemMail[] = rawMails.filter((item) => {
        if (!item || typeof item !== "object") return false;
        const subjectStr = (item.subject || "").toLowerCase();
        const senderStr = (item.sender || "").toLowerCase();
        const search = searchFilter.toLowerCase();

        const matchesSearch = subjectStr.includes(search) || senderStr.includes(search);
        const matchesDecision = decisionFilter === "all" || item.final_decision === decisionFilter;
        return matchesSearch && matchesDecision;
    });

    // 📄 Calculs de pagination pour l'onglet actif
    const totalItems = historyType === "url" ? filteredUrls.length : filteredMails.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;

    // Découpage des éléments de la page courante
    const paginatedUrls = filteredUrls.slice(startIndex, endIndex);
    const paginatedMails = filteredMails.slice(startIndex, endIndex);

    const handleCopyJson = (data: any) => {
        navigator.clipboard.writeText(JSON.stringify(data, null, 2));
        toast.success("📋 Données copiées dans le presse-papier !");
    };

    return (
        <div id="aph-container" className="aph-container">
            {/* Header */}
            <div className="aph-header">
                <div className="aph-header__left">
                    <h2 className="aph-header__title">
                        <History size={24} /> 📜 Historique des Analyses
                    </h2>
                    <p className="aph-header__subtitle">
                        Consultez l'ensemble des diagnostics passés réalisés sur vos liens et courriers électroniques.
                    </p>
                </div>

                <div className="aph-header__right">
                    <button 
                        id="aph-btn-refresh"
                        className="aph-btn"
                        type="button" 
                        onClick={loadHistory} 
                        disabled={loading}
                    >
                        <RefreshCw size={16} className={loading ? "aph-loading__icon" : ""} />
                        {loading ? "⏳ Chargement..." : "🔄 Actualiser"}
                    </button>
                </div>
            </div>

            {/* Sélecteur de type d'historique */}
            <div className="aph-type-selector">
                <button
                    id="aph-type-url"
                    type="button"
                    className={`aph-type-btn ${historyType === "url" ? "aph-type-btn--active" : ""}`}
                    onClick={() => {
                        setHistoryType("url");
                        setSearchFilter("");
                    }}
                    disabled={historyType === "url"}
                >
                    <Globe size={18} /> Analyses d'URLs
                    <span className="aph-type-btn__count">{rawUrls.length}</span>
                </button>

                <button
                    id="aph-type-mail"
                    type="button"
                    className={`aph-type-btn ${historyType === "mail" ? "aph-type-btn--active" : ""}`}
                    onClick={() => {
                        setHistoryType("mail");
                        setSearchFilter("");
                    }}
                    disabled={historyType === "mail"}
                >
                    <Mail size={18} /> Analyses d'Emails
                    <span className="aph-type-btn__count">{rawMails.length}</span>
                </button>
            </div>

            {/* Filtres & Recherche */}
            <div className="aph-filters">
                <div className="aph-filters__group">
                    <Search size={16} className="aph-filters__icon" />
                    <input
                        id="aph-search-input"
                        className="aph-filters__input"
                        type="text"
                        placeholder={historyType === "url" ? "Filtrer par URL ou source..." : "Filtrer par sujet ou expéditeur..."}
                        value={searchFilter}
                        onChange={(e) => setSearchFilter(e.target.value)}
                    />
                </div>

                <div className="aph-filters__verdicts">
                    <button 
                        type="button" 
                        className={`aph-filter-btn ${decisionFilter === "all" ? "aph-filter-btn--active" : ""}`}
                        onClick={() => setDecisionFilter("all")}
                    >
                        Tous
                    </button>
                    <button 
                        type="button" 
                        className={`aph-filter-btn ${decisionFilter === "phishing" ? "aph-filter-btn--active" : ""}`}
                        onClick={() => setDecisionFilter("phishing")}
                    >
                        🔴 Phishing
                    </button>
                    <button 
                        type="button" 
                        className={`aph-filter-btn ${decisionFilter === "suspicious" ? "aph-filter-btn--active" : ""}`}
                        onClick={() => setDecisionFilter("suspicious")}
                    >
                        🟡 Suspect
                    </button>
                    <button 
                        type="button" 
                        className={`aph-filter-btn ${decisionFilter === "safe" ? "aph-filter-btn--active" : ""}`}
                        onClick={() => setDecisionFilter("safe")}
                    >
                        🟢 Sûr
                    </button>
                </div>
            </div>

            {/* Message d'erreur */}
            {error && (
                <div id="aph-error" className="aph-error">
                    <AlertTriangle size={20} className="aph-error__icon" />
                    <div className="aph-error__content">
                        <span className="aph-error__title">❌ Erreur lors de la récupération de l'historique</span>
                        <p className="aph-error__text">{error}</p>
                    </div>
                </div>
            )}

            {/* Tableau URLs */}
            {historyType === "url" && (
                <div className="aph-table-wrapper">
                    {filteredUrls.length === 0 ? (
                        <div className="aph-empty">
                            📭 Aucun enregistrement d'analyse d'URL ne correspond à vos critères.
                        </div>
                    ) : (
                        <table className="aph-table">
                            <thead>
                                <tr>
                                    <th>Date & Heure</th>
                                    <th>URL Analysée</th>
                                    <th>Verdict Final</th>
                                    <th>Confiance</th>
                                    <th>Source</th>
                                    <th>Durée</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {paginatedUrls.map((item, idx) => {
                                    let verdictClass = "aph-table__verdict--unknown";
                                    if (item.final_decision === "safe") verdictClass = "aph-table__verdict--safe";
                                    else if (item.final_decision === "suspicious") verdictClass = "aph-table__verdict--suspicious";
                                    else if (item.final_decision === "phishing") verdictClass = "aph-table__verdict--phishing";

                                    return (
                                        <tr key={idx}>
                                            <td>{item.date}</td>
                                            <td className="aph-table__url">{item.url}</td>
                                            <td>
                                                <span className={`aph-table__verdict ${verdictClass}`}>
                                                    {item.final_decision === "safe" && "🟢 SÛR"}
                                                    {item.final_decision === "suspicious" && "🟡 SUSPECT"}
                                                    {item.final_decision === "phishing" && "🔴 PHISHING"}
                                                    {item.final_decision !== "safe" && item.final_decision !== "suspicious" && item.final_decision !== "phishing" && "⚪ INCONNU"}
                                                </span>
                                            </td>
                                            <td className="aph-table__confidence">{Math.round((item.confidence || 0) * 100)}%</td>
                                            <td>
                                                <div className="aph-table__source">
                                                    🔍 {item.source}
                                                </div>
                                            </td>
                                            <td>⏱️ {item.elapsed}s</td>
                                            <td>
                                                <button 
                                                    className="aph-table__btn"
                                                    type="button" 
                                                    onClick={() => handleCopyJson(item)} 
                                                    title="Copier les détails JSON"
                                                >
                                                    <Copy size={12} /> JSON
                                                </button>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    )}
                </div>
            )}

            {/* Tableau Emails */}
            {historyType === "mail" && (
                <div className="aph-table-wrapper">
                    {filteredMails.length === 0 ? (
                        <div className="aph-empty">
                            📭 Aucun enregistrement d'analyse d'email ne correspond à vos critères.
                        </div>
                    ) : (
                        <table className="aph-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Expéditeur</th>
                                    <th>Sujet</th>
                                    <th>Verdict</th>
                                    <th>Confiance</th>
                                    <th>SPF / DKIM</th>
                                    <th>Liens Phishing</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {paginatedMails.map((item, idx) => {
                                    let verdictClass = "aph-table__verdict--unknown";
                                    if (item.final_decision === "safe") verdictClass = "aph-table__verdict--safe";
                                    else if (item.final_decision === "suspicious") verdictClass = "aph-table__verdict--suspicious";
                                    else if (item.final_decision === "phishing") verdictClass = "aph-table__verdict--phishing";

                                    return (
                                        <tr key={idx}>
                                            <td>{item.date}</td>
                                            <td className="aph-table__url">{item.sender || "(Inconnu)"}</td>
                                            <td>{item.subject || "(Sans objet)"}</td>
                                            <td>
                                                <span className={`aph-table__verdict ${verdictClass}`}>
                                                    {item.final_decision === "safe" && "🟢 SÛR"}
                                                    {item.final_decision === "suspicious" && "🟡 SUSPECT"}
                                                    {item.final_decision === "phishing" && "🔴 PHISHING"}
                                                    {item.final_decision !== "safe" && item.final_decision !== "suspicious" && item.final_decision !== "phishing" && "⚪ INCONNU"}
                                                </span>
                                            </td>
                                            <td className="aph-table__confidence">{Math.round((item.confidence || 0) * 100)}%</td>
                                            <td>{item.spf} / {item.dkim}</td>
                                            <td>
                                                {item.nb_urls_phishing > 0 ? (
                                                    <span className="aph-table__link-phishing aph-table__link-phishing--danger">
                                                        🚨 {item.nb_urls_phishing} / {item.nb_urls_total}
                                                    </span>
                                                ) : (
                                                    <span className="aph-table__link-phishing aph-table__link-phishing--safe">
                                                        ✅ 0 / {item.nb_urls_total}
                                                    </span>
                                                )}
                                            </td>
                                            <td>
                                                <button 
                                                    className="aph-table__btn"
                                                    type="button" 
                                                    onClick={() => handleCopyJson(item)} 
                                                    title="Copier les détails JSON"
                                                >
                                                    <Copy size={12} /> JSON
                                                </button>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    )}
                </div>
            )}

            {/* 🔢 BARRE DE PAGINATION & SÉLECTEUR D'ÉLÉMENTS PAR PAGE */}
            {totalItems > 0 && (
                <div className="aph-pagination">
                    {/* Sélecteur du nombre d'items par page */}
                    <div className="aph-pagination__size">
                        <ListFilter size={14} />
                        <label htmlFor="aph-page-size">Lignes par page :</label>
                        <select
                            id="aph-page-size"
                            className="aph-pagination__select"
                            value={itemsPerPage}
                            onChange={(e) => setItemsPerPage(Number(e.target.value))}
                        >
                            <option value={5}>5</option>
                            <option value={10}>10</option>
                            <option value={20}>20</option>
                            <option value={50}>50</option>
                            <option value={100}>100</option>
                        </select>
                    </div>

                    {/* Informations sur la page */}
                    <div className="aph-pagination__info">
                        Page <strong>{currentPage}</strong> sur <strong>{totalPages}</strong> ({totalItems} résultat{totalItems > 1 ? "s" : ""})
                    </div>

                    {/* Boutons de navigation */}
                    <div className="aph-pagination__controls">
                        <button
                            type="button"
                            className="aph-pagination__btn"
                            disabled={currentPage === 1}
                            onClick={() => setCurrentPage(1)}
                            title="Première page"
                        >
                            <ChevronsLeft size={16} />
                        </button>

                        <button
                            type="button"
                            className="aph-pagination__btn"
                            disabled={currentPage === 1}
                            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                            title="Page précédente"
                        >
                            <ChevronLeft size={16} /> Précédent
                        </button>

                        <button
                            type="button"
                            className="aph-pagination__btn"
                            disabled={currentPage === totalPages}
                            onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                            title="Page suivante"
                        >
                            Suivant <ChevronRight size={16} />
                        </button>

                        <button
                            type="button"
                            className="aph-pagination__btn"
                            disabled={currentPage === totalPages}
                            onClick={() => setCurrentPage(totalPages)}
                            title="Dernière page"
                        >
                            <ChevronsRight size={16} />
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
}

export default ApHistoryComponent;