import { useEffect, useState } from "react";
import "./anti_phishing.css";
import ApAnalyzeComponent from "./analyze/analyze";
import ApHealthComponent from "./health/health";
import ApSettingsComponent from "./settings/settings";
import ApHistoryComponent from "./history/history";
import { HealthResponse } from "@/types/anti_phishing/types";
import { getApHealth } from "./utils";
import { Link, useNavigate } from "react-router-dom";
import { 
    Shield, 
    Search, 
    History, 
    Activity, 
    Settings, 
    XCircle, 
    CheckCircle2, 
    AlertTriangle, 
    Pin, 
    Sparkles,
    RefreshCw,
    Lock
} from "lucide-react";
import toast from "react-hot-toast";
import { isLogin } from "@/hooks/get_token";

export type TabType = "analyze" | "history" | "health" | "settings";

function AntiPhishing() {
    const navigate = useNavigate();

    // 1. Récupération de l'onglet par défaut (localStorage)
    const [defaultTab, setDefaultTab] = useState<TabType>(() => {
        const saved = localStorage.getItem("ap_default_tab");
        return (saved as TabType) || "analyze";
    });

    // 2. Onglet actif (initialisé avec l'onglet par défaut)
    const [activeTab, setActiveTab] = useState<TabType | null>(() => {
        const saved = localStorage.getItem("ap_default_tab");
        return (saved as TabType) || "analyze";
    });

    // 3. Santé backend (Pulse en direct)
    const [health, setHealth] = useState<HealthResponse | null>(null);
    const [healthLoading, setHealthLoading] = useState<boolean>(false);
    const [healthError, setHealthError] = useState<string | null>(null);

    const checkHealth = () => {
        getApHealth(setHealth, setHealthError, setHealthLoading, navigate);
    };

    useEffect(() => {
        checkHealth();
        const interval = setInterval(checkHealth, 30000); // Polling toutes les 30s
        return () => clearInterval(interval);
    }, []);

    const handleSetDefaultTab = (tab: TabType) => {
        setDefaultTab(tab);
        localStorage.setItem("ap_default_tab", tab);
        toast.success(`📌 Onglet par défaut : ${getTabLabel(tab)}`);
    };

    function getTabLabel(tab: TabType): string {
        switch (tab) {
            case "analyze": return "🔍 Analyse";
            case "history": return "📜 Historique";
            case "health": return "🩺 Santé";
            case "settings": return "⚙️ Paramètres";
            default: return "";
        }
    }

    const isHealthy = health?.status === "healthy" && !healthError;

    let pulseClass = "ap-health-pulse--loading";
    if (!healthLoading) {
        pulseClass = isHealthy ? "ap-health-pulse--healthy" : "ap-health-pulse--unhealthy";
    }

    if (!isLogin()) {
        return (
            <div id="ap-locked-screen" className="simatk-module">
                <div className="simatk-auth-locked">
                    <Lock size={36} style={{ color: "var(--accent)" }} />
                    <h2>Accès Restreint au Système de détection de Phishing</h2>
                    <p>
                        Une session authentifiée est requise pour analyser des urls et emails.
                    </p>
                    <Link to="/login" className="oh-btn oh-btn--primary" style={{ marginTop: 12 }}>
                        Se Connecter
                    </Link>
                </div>
            </div>
        );
    }
    
    return (
        <div id="ap-module" className="ap-module">
            {/* Header Fixe */}
            <header id="ap-header" className="ap-header">
                <div className="ap-header__top">
                    {/* Logo & Titre */}
                    <div className="ap-header__left">
                        <div className="ap-header__logo">
                            <Shield size={28} className="ap-header__logo-icon" />
                            <h1 className="ap-header__title">Anti-Phishing</h1>
                            <span className="ap-header__version">v2.0</span>
                        </div>
                    </div>

                    {/* Zone Droite : Onglet par défaut & Pulse Santé */}
                    <div className="ap-header__right">
                        <div className="ap-default-selector">
                            <span className="ap-default-selector__label">
                                <Pin size={13} /> Défaut :
                            </span>
                            <select
                                id="ap-default-select"
                                className="ap-default-selector__select"
                                value={defaultTab}
                                onChange={(e) => handleSetDefaultTab(e.target.value as TabType)}
                            >
                                <option value="analyze">🔍 Analyse</option>
                                <option value="history">📜 Historique</option>
                                <option value="health">🩺 Santé</option>
                                <option value="settings">⚙️ Paramètres</option>
                            </select>
                        </div>

                        {/* Pastille Pulse */}
                        <div id="ap-health-pulse" className={`ap-health-pulse ${pulseClass}`}>
                            <span className={`ap-health-pulse__dot ${isHealthy ? "ap-health-pulse__dot--healthy" : "ap-health-pulse__dot--unhealthy"}`} />
                            {healthLoading ? (
                                <span><RefreshCw size={14} className="oh-spin" /> Vérification...</span>
                            ) : isHealthy ? (
                                <span>🟢 En ligne {health?.ml_available ? "(IA Active)" : "(Passif)"}</span>
                            ) : (
                                <span>🔴 Hors ligne</span>
                            )}
                        </div>
                    </div>
                </div>

                {/* Navigation des Onglets */}
                <nav id="ap-nav" className="ap-nav">
                    <button
                        id="ap-nav-analyze"
                        type="button"
                        className={`ap-nav__btn ${activeTab === "analyze" ? "ap-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("analyze")}
                    >
                        <Search size={16} /> 🔍 Analyse
                    </button>

                    <button
                        id="ap-nav-history"
                        type="button"
                        className={`ap-nav__btn ${activeTab === "history" ? "ap-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("history")}
                    >
                        <History size={16} /> 📜 Historique
                    </button>

                    <button
                        id="ap-nav-health"
                        type="button"
                        className={`ap-nav__btn ${activeTab === "health" ? "ap-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("health")}
                    >
                        <Activity size={16} /> 🩺 Santé
                    </button>

                    <button
                        id="ap-nav-settings"
                        type="button"
                        className={`ap-nav__btn ${activeTab === "settings" ? "ap-nav__btn--active" : ""}`}
                        onClick={() => setActiveTab("settings")}
                    >
                        <Settings size={16} /> ⚙️ Paramètres
                    </button>

                    {activeTab !== null && (
                        <button
                            id="ap-nav-close"
                            type="button"
                            className="ap-nav__btn ap-nav__btn--close"
                            onClick={() => setActiveTab(null)}
                            title="Fermer la vue active"
                        >
                            ✖️ Fermer
                        </button>
                    )}
                </nav>
            </header>

            <hr id="ap-divider" className="ap-divider" />

            {/* Contenu Principal : CONSERVÉ EN MÉMOIRE via display: none */}
            <main id="ap-content" className="ap-content">
                {/* 1. Onglet Analyse */}
                <section style={{ display: activeTab === "analyze" ? "block" : "none" }}>
                    <ApAnalyzeComponent navigate={navigate} />
                </section>

                {/* 2. Onglet Historique */}
                <section style={{ display: activeTab === "history" ? "block" : "none" }}>
                    <ApHistoryComponent navigate={navigate} />
                </section>

                {/* 3. Onglet Santé & Métriques */}
                <section style={{ display: activeTab === "health" ? "block" : "none" }}>
                    <ApHealthComponent navigate={navigate} />
                </section>

                {/* 4. Onglet Paramètres */}
                <section style={{ display: activeTab === "settings" ? "block" : "none" }}>
                    <ApSettingsComponent navigate={navigate} />
                </section>

                {/* 5. État Désélectionné (Si activeTab === null) */}
                {activeTab === null && (
                    <div id="ap-empty" className="ap-empty">
                        <Sparkles size={40} style={{ color: 'var(--accent)' }} />
                        <h2 className="ap-empty__title">🛡️ Module Anti-Phishing</h2>
                        <p className="ap-empty__text">
                            Aucun outil n'est actif. Sélectionnez un module ci-dessus ou choisissez une action rapide :
                        </p>

                        <div className="ap-empty__actions">
                            <button className="ap-empty__btn" type="button" onClick={() => setActiveTab("analyze")}>
                                <Search size={16} /> 🔍 Lancer une Analyse d'URL ou d'Email
                            </button>
                            <button className="ap-empty__btn" type="button" onClick={() => setActiveTab("history")}>
                                <History size={16} /> 📜 Consulter l'Historique
                            </button>
                            <button className="ap-empty__btn" type="button" onClick={() => setActiveTab("health")}>
                                <Activity size={16} /> 🩺 Examiner la Santé Système
                            </button>
                            <button className="ap-empty__btn" type="button" onClick={() => setActiveTab("settings")}>
                                <Settings size={16} /> ⚙️ Configurer les Paramètres
                            </button>
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
}

export default AntiPhishing;