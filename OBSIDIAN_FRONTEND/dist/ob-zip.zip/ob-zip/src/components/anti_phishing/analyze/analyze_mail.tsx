import "./analyze_mail.css"
import React, { useState } from "react";
import { 
    AnalyzeMailFormDataRequest, 
    AnalyzeMailResponse,
    AnalyzeMailItemResult,
    DecisionEnum 
} from "@/types/anti_phishing/types";
import toast from "react-hot-toast";
import { analyzeMails } from "../utils";
import { useNavigate } from "react-router-dom";
import { 
    Mail, 
    FileText, 
    UploadCloud, 
    PlusCircle, 
    Trash2, 
    Copy, 
    Search, 
    RotateCcw, 
    ShieldCheck, 
    ShieldAlert, 
    ShieldX, 
    Info, 
    Link,
    AlertTriangle,
    CheckCircle2,
    XCircle,
    FileCheck
} from "lucide-react";
import { toTitleCaseWithUnderscore } from "@/components/utils/to_lower_case";

// ============================================================================
// SOUS-COMPOSANT : Affichage des Résultats de l'Analyse d'Emails
// ============================================================================

function ShowAnalyzeMailResponse({
    response,
    onClear,
}: {
    response: AnalyzeMailResponse;
    onClear: () => void;
}) {
    if (!response || !response.results) return null;

    const handleCopy = () => {
        navigator.clipboard.writeText(JSON.stringify(response, null, 2));
        toast.success("📋 Rapport d'analyse email copié !");
    };

    return (
        <div id="apm-results" className="apm-results">
            {/* Header */}
            <div className="apm-results__header">
                <div className="apm-results__title">
                    📊 Synthèse Globale du Lot ({response.total} email{response.total > 1 ? "s" : ""})
                </div>
                <div className="apm-results__stats">
                    <span className="apm-results__stat apm-results__stat--phishing">
                        🔴 {response.phishing_count}
                    </span>
                    <span className="apm-results__stat apm-results__stat--suspicious">
                        🟡 {response.suspicious_count}
                    </span>
                    <span className="apm-results__stat apm-results__stat--safe">
                        🟢 {response.safe_count}
                    </span>
                </div>
                <div className="apu-result__actions">
                    <button className="apu-result__btn" onClick={handleCopy}>
                        <Copy size={14} /> Copier
                    </button>
                    <button className="apu-result__btn" onClick={onClear}>
                        <Trash2 size={14} /> Effacer
                    </button>
                </div>
            </div>

            {/* Liste des emails */}
            <div id="apm-mail-list">
                {response.results.map((mailResult: AnalyzeMailItemResult, index: number) => {
                    const isSafe = mailResult.final_decision === DecisionEnum.SAFE;
                    const isPhishing = mailResult.final_decision === DecisionEnum.PHISHING;
                    const isSuspicious = mailResult.final_decision === DecisionEnum.SUSPICIOUS;

                    let verdictClass = "apm-mail-card__verdict--unknown";
                    if (isSafe) verdictClass = "apm-mail-card__verdict--safe";
                    else if (isSuspicious) verdictClass = "apm-mail-card__verdict--suspicious";
                    else if (isPhishing) verdictClass = "apm-mail-card__verdict--phishing";

                    return (
                        <div key={index} className="apm-mail-card">
                            {/* Header */}
                            <div className="apm-mail-card__header">
                                <div className="apm-mail-card__left">
                                    <div className="apm-mail-card__icon">
                                        {isSafe && <ShieldCheck size={24} />}
                                        {isSuspicious && <ShieldAlert size={24} />}
                                        {isPhishing && <ShieldX size={24} />}
                                        {!isSafe && !isSuspicious && !isPhishing && <AlertTriangle size={24} />}
                                    </div>
                                    <div className="apm-mail-card__info">
                                        <div className="apm-mail-card__subject">
                                            Email #{index + 1} : {mailResult.subject || "(Sans objet)"}
                                        </div>
                                        <div className="apm-mail-card__sender">
                                            👤 Expéditeur : <strong>{mailResult.sender || "Inconnu"}</strong>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <span className={`apm-mail-card__verdict ${verdictClass}`}>
                                        {isSafe && "🟢 SÛR"}
                                        {isSuspicious && "🟡 SUSPECT"}
                                        {isPhishing && "🔴 PHISHING"}
                                        {!isSafe && !isSuspicious && !isPhishing && "⚪ ERREUR"}
                                    </span>
                                    <span className="apm-mail-card__confidence">
                                        (Confiance : {Math.round((mailResult.confidence || 0) * 100)}%)
                                    </span>
                                </div>
                            </div>

                            {/* Métadonnées */}
                            <div className="apm-mail-meta">
                                <div className="apm-mail-meta__item">
                                    <span className="apm-mail-meta__label">🛡️ SPF :</span>
                                    <span className={`apm-mail-meta__value ${mailResult.spf === "pass" ? "apm-mail-meta__value--pass" : mailResult.spf === "fail" ? "apm-mail-meta__value--fail" : ""}`}>
                                        {mailResult.spf === "pass" ? "✅ Pass" : mailResult.spf === "fail" ? "❌ Fail" : `⚠️ ${mailResult.spf}`}
                                    </span>
                                </div>
                                <div className="apm-mail-meta__item">
                                    <span className="apm-mail-meta__label">🔑 DKIM :</span>
                                    <span className="apm-mail-meta__value">
                                        {mailResult.dkim === "present" ? "✅ Présente" : "❌ Absente"}
                                    </span>
                                </div>
                                <div className="apm-mail-meta__item">
                                    <span className="apm-mail-meta__label">🔍 Source :</span>
                                    <span className="apm-mail-meta__value">{toTitleCaseWithUnderscore(mailResult.source)}</span>
                                </div>
                                <div className="apm-mail-meta__item">
                                    <span className="apm-mail-meta__label">⏱️ Durée :</span>
                                    <span className="apm-mail-meta__value">{mailResult.elapsed}s ({mailResult.date})</span>
                                </div>
                            </div>

                            {/* Advice */}
                            {mailResult.advice && (
                                <div className="apm-mail-advice">
                                    <Info size={18} className="apm-mail-advice__icon" />
                                    <p className="apm-mail-advice__text">
                                        <strong>💡 Recommandation :</strong> {mailResult.advice}
                                    </p>
                                </div>
                            )}

                            {/* URLs */}
                            <div>
                                <div className="apu-breakdown__title" style={{ marginBottom: '8px' }}>
                                    🔗 URLs Détectées ({mailResult.nb_urls_total} total | {mailResult.nb_urls_phishing} dangereuse{mailResult.nb_urls_phishing > 1 ? "s" : ""})
                                </div>

                                {mailResult.breakdown?.urls_summary && mailResult.breakdown.urls_summary.length > 0 ? (
                                    <table className="apm-url-table">
                                        <thead>
                                            <tr>
                                                <th>Lien extrait</th>
                                                <th>Verdict</th>
                                                <th>Confiance</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {mailResult.breakdown.urls_summary.map((urlItem, uIdx) => {
                                                let decisionClass = "";
                                                if (urlItem.decision === "phishing") decisionClass = "apm-url-table__decision--phishing";
                                                else if (urlItem.decision === "suspicious") decisionClass = "apm-url-table__decision--suspicious";
                                                else if (urlItem.decision === "safe") decisionClass = "apm-url-table__decision--safe";

                                                let decisionLabel = "⚪ Inconnu";
                                                if (urlItem.decision === "phishing") decisionLabel = "🔴 Phishing";
                                                else if (urlItem.decision === "suspicious") decisionLabel = "🟡 Suspect";
                                                else if (urlItem.decision === "safe") decisionLabel = "🟢 Sûr";

                                                return (
                                                    <tr key={uIdx}>
                                                        <td>
                                                            <div className="apm-url-table__url">
                                                                <Link size={14} /> {urlItem.url}
                                                            </div>
                                                        </td>
                                                        <td className={`apm-url-table__decision ${decisionClass}`}>
                                                            {decisionLabel}
                                                        </td>
                                                        <td>{Math.round((urlItem.confidence || 0) * 100)}%</td>
                                                    </tr>
                                                );
                                            })}
                                        </tbody>
                                    </table>
                                ) : (
                                    <div className="apm-url-table__empty">
                                        ℹ️ Aucun lien HTTP/HTTPS n'a été détecté dans le corps de cet email.
                                    </div>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
}

// ============================================================================
// COMPOSANT PRINCIPAL : Analyse d'Emails
// ============================================================================

function AnalyzeMailComponent({ navigate }: { navigate?: ReturnType<typeof useNavigate> }) {

    const [inputMode, setInputMode] = useState<"file" | "text">("file");
    const [filesQueue, setFilesQueue] = useState<File[]>([]);
    const [textsQueue, setTextsQueue] = useState<string[]>([]);
    const [currentText, setCurrentText] = useState<string>("");
    const [checkBlacklist, setCheckBlacklist] = useState<boolean>(true);
    const [analyzeResponse, setAnalyzeResponse] = useState<AnalyzeMailResponse | null>(null);
    const [analyzeLoading, setAnalyzeLoading] = useState<boolean>(false);
    const [analyzeError, setAnalyzeError] = useState<string | null>(null);

    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            const uploadedFiles = Array.from(e.target.files);
            setFilesQueue((prev) => [...prev, ...uploadedFiles]);
            toast.success(`📁 ${uploadedFiles.length} fichier(s) ajouté(s) à la file d'analyse !`);
            e.target.value = "";
        }
    };

    const handleAddTextMail = () => {
        const trimmed = currentText.trim();
        if (!trimmed) {
            toast.error("⚠️ Veuillez coller le texte d'un email avant de l'ajouter !");
            return;
        }
        setTextsQueue((prev) => [...prev, trimmed]);
        setCurrentText("");
        toast.success("📝 Email texte ajouté à la file d'analyse !");
    };

    const handleRemoveFile = (index: number) => {
        setFilesQueue((prev) => prev.filter((_, i) => i !== index));
    };

    const handleRemoveText = (index: number) => {
        setTextsQueue((prev) => prev.filter((_, i) => i !== index));
    };

    const handleClearAll = () => {
        setFilesQueue([]);
        setTextsQueue([]);
        setCurrentText("");
        setAnalyzeResponse(null);
        setAnalyzeError(null);
        toast("🧹 File d'analyse réinitialisée !");
    };

    const handleAnalyze = async () => {
        let finalTexts = [...textsQueue];
        if (currentText.trim()) {
            finalTexts.push(currentText.trim());
            setTextsQueue(finalTexts);
            setCurrentText("");
        }

        const totalItems = filesQueue.length + finalTexts.length;
        if (totalItems === 0) {
            toast.error("⚠️ Veuillez ajouter au moins un fichier .eml ou un texte d'email à analyser !");
            return;
        }

        const data: AnalyzeMailFormDataRequest = {
            files: filesQueue.length > 0 ? filesQueue : null,
            mails: finalTexts.length > 0 ? finalTexts : null,
            check_blacklist: checkBlacklist,
        };

        const result = await analyzeMails(
            data,
            setAnalyzeResponse,
            setAnalyzeError,
            setAnalyzeLoading,
            navigate
        );

        if (result) {
            toast.success(`⚡ Analyse de ${result.total} email(s) terminée avec succès !`);
        }
    };

    const totalQueued = filesQueue.length + textsQueue.length + (currentText.trim() ? 1 : 0);

    return (
        <div id="apm-container" className="apm-container">
            {/* Header */}
            <div className="apm-header">
                <div className="apm-header__title">📧 Anti-Phishing pour Emails</div>
                <p className="apm-header__subtitle">
                    Détectez les arnaques, faux expéditeurs (SPF/DKIM) et liens piégés dans vos emails ⚡
                </p>
            </div>

            {/* Input Zone */}
            <div id="apm-input-zone" className="apm-input-zone">
                <div className="apm-input-zone__header">
                    <div className="apm-input-zone__title">📥 Mode d'ajout d'email</div>
                    <span className="apm-input-zone__hint">Alterner librement entre fichiers et texte</span>
                </div>

                <div className="apm-mode-toggle">
                    <button
                        id="apm-mode-file"
                        type="button"
                        className={`apm-mode-btn ${inputMode === "file" ? "apm-mode-btn--active" : ""}`}
                        onClick={() => setInputMode("file")}
                        disabled={inputMode === "file"}
                    >
                        <UploadCloud size={16} /> Fichiers .eml
                    </button>

                    <button
                        id="apm-mode-text"
                        type="button"
                        className={`apm-mode-btn ${inputMode === "text" ? "apm-mode-btn--active" : ""}`}
                        onClick={() => setInputMode("text")}
                        disabled={inputMode === "text"}
                    >
                        <FileText size={16} /> Texte Brut
                    </button>
                </div>

                {inputMode === "file" ? (
                    <label id="apm-upload-area" className="apm-upload-area">
                        <div className="apm-upload-area__icon">
                            <UploadCloud size={32} />
                        </div>
                        <div className="apm-upload-area__text">
                            📂 Cliquez pour sélectionner des fichiers <strong>.eml</strong> ou <strong>.msg</strong>
                            <br />(Sélection multiple possible)
                        </div>
                        <input
                            id="apm-file-input"
                            className="apm-upload-area__input"
                            type="file"
                            multiple
                            accept=".eml,.msg,.txt"
                            onChange={handleFileUpload}
                        />
                    </label>
                ) : (
                    <div className="apm-textarea-group">
                        <label htmlFor="apm-text-input" className="apu-form__label">
                            ✍️ Collez ici le contenu brut complet de l'email
                        </label>
                        <textarea
                            id="apm-text-input"
                            className="apm-textarea"
                            rows={8}
                            placeholder={`From: support@paypal-verify.tk\nSubject: URGENT: Compte bloqué\n\nCliquez ici pour vérifier votre identité : http://fake-bank.tk/login`}
                            value={currentText}
                            onChange={(e) => setCurrentText(e.target.value)}
                        />
                        <div className="apm-textarea-actions">
                            <button
                                id="apm-btn-add-text"
                                className="apm-btn apm-btn--success"
                                type="button"
                                onClick={handleAddTextMail}
                                disabled={!currentText.trim()}
                            >
                                <PlusCircle size={16} /> Ajouter ce texte
                            </button>
                        </div>
                    </div>
                )}
            </div>

            {/* Queue */}
            <div id="apm-queue" className="apm-queue">
                <div className="apm-queue__header">
                    <div className="apm-queue__title">
                        📬 File d'attente
                        <span className="apm-queue__count">({totalQueued} élément{totalQueued > 1 ? "s" : ""})</span>
                    </div>
                    {totalQueued > 0 && (
                        <button
                            id="apm-btn-clear-all"
                            className="apm-btn apm-btn--danger"
                            type="button"
                            onClick={handleClearAll}
                        >
                            <RotateCcw size={14} /> Tout vider
                        </button>
                    )}
                </div>

                {totalQueued === 0 ? (
                    <div className="apm-queue__empty">
                        📭 Aucun email dans la file d'attente.
                    </div>
                ) : (
                    <div className="apm-queue__list">
                        {/* Fichiers */}
                        {filesQueue.map((file, idx) => (
                            <div key={`file-${idx}`} className="apm-queue__item">
                                <div className="apm-queue__item-left">
                                    <FileCheck size={16} className="apm-queue__item-icon" />
                                    <span className="apm-queue__item-name">{file.name}</span>
                                    <span className="apm-queue__item-size">({(file.size / 1024).toFixed(1)} Ko)</span>
                                </div>
                                <button
                                    className="apm-queue__item-remove"
                                    type="button"
                                    onClick={() => handleRemoveFile(idx)}
                                >
                                    <Trash2 size={14} />
                                </button>
                            </div>
                        ))}

                        {/* Textes */}
                        {textsQueue.map((txt, idx) => (
                            <div key={`text-${idx}`} className="apm-queue__item">
                                <div className="apm-queue__item-left">
                                    <FileText size={16} className="apm-queue__item-icon" />
                                    <span className="apm-queue__item-name">
                                        Email #{idx + 1} : "{txt.slice(0, 60)}..."
                                    </span>
                                    <span className="apm-queue__item-size">({txt.length} car.)</span>
                                </div>
                                <button
                                    className="apm-queue__item-remove"
                                    type="button"
                                    onClick={() => handleRemoveText(idx)}
                                >
                                    <Trash2 size={14} />
                                </button>
                            </div>
                        ))}

                        {/* Brouillon */}
                        {currentText.trim() && (
                            <div className="apm-queue__item" style={{ opacity: 0.6, borderStyle: 'dashed' }}>
                                <div className="apm-queue__item-left">
                                    <FileText size={16} className="apm-queue__item-icon" />
                                    <span className="apm-queue__item-name">
                                        <em>En cours de saisie...</em> : "{currentText.slice(0, 60)}..."
                                    </span>
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </div>

            {/* Actions */}
            <div className="apm-actions">
                <div className="apm-actions__left">
                    <input
                        id="apm-check-blacklist"
                        className="apm-actions__checkbox"
                        type="checkbox"
                        checked={checkBlacklist}
                        onChange={(e) => setCheckBlacklist(e.target.checked)}
                    />
                    <label htmlFor="apm-check-blacklist" className="apm-actions__label">
                        🛡️ Vérifier les liens auprès des blacklists (PhishDestroy)
                    </label>
                </div>
                <div className="apm-actions__right">
                    <button
                        id="apm-btn-analyze"
                        className="apm-btn apm-btn--primary"
                        type="button"
                        disabled={analyzeLoading || totalQueued === 0}
                        onClick={handleAnalyze}
                    >
                        {analyzeLoading ? (
                            <>⏳ Analyse en cours...</>
                        ) : (
                            <>
                                <Search size={18} /> Analyser ({totalQueued} email{totalQueued > 1 ? "s" : ""})
                            </>
                        )}
                    </button>
                </div>
            </div>

            {/* Erreur */}
            {analyzeError && (
                <div id="apm-error" className="apu-error">
                    <AlertTriangle size={20} className="apu-error__icon" />
                    <div className="apu-error__content">
                        <span className="apu-error__title">❌ Erreur lors de l'analyse</span>
                        <p className="apu-error__text">{analyzeError}</p>
                    </div>
                </div>
            )}

            {/* Résultats */}
            {analyzeResponse && (
                <ShowAnalyzeMailResponse
                    response={analyzeResponse}
                    onClear={() => setAnalyzeResponse(null)}
                />
            )}
        </div>
    );
}

export default AnalyzeMailComponent;