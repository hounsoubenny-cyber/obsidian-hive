import "./analyze.css";
import { useState } from "react";;
import AnalyzeUrlComponent from "./analyze_url";
import AnalyzeMailComponent from "./analyze_mail";
import { Globe, Mail, Sparkles, CheckCircle2 } from "lucide-react";
import { useNavigate } from "react-router-dom";

type AnalyzeMode = "url" | "mail";

function ApAnalyzeComponent({ navigate }: { navigate?: ReturnType<typeof useNavigate> }) {
    const [activeMode, setActiveMode] = useState<AnalyzeMode>("url");

    return (
        <div id="ap-page" className="ap-page">
            {/* Header */}
            <header id="ap-header" className="ap-header">
                <div className="ap-header__top">
                    <h2 className="ap-header__title">
                        🛡️ Analyse Anti-Phishing
                    </h2>
                </div>
                <p className="ap-header__subtitle">
                    Choisissez le vecteur d'attaque à inspecter : inspectez une URL suspecte ou analysez un email complet avec vérification d'en-têtes et de liens.
                </p>
            </header>

            {/* Mode Selector */}
            <div id="ap-mode-selector" className="ap-mode-selector">
                {/* URL Card */}
                <button
                    id="ap-mode-url"
                    type="button"
                    className={`ap-mode-card ${activeMode === "url" ? "ap-mode-card--active" : ""}`}
                    onClick={() => setActiveMode("url")}
                    disabled={activeMode === "url"}
                >
                    <div className="ap-mode-card__header">
                        <div className="ap-mode-card__left">
                            <div className="ap-mode-card__icon">
                                <Globe size={24} />
                            </div>
                            <h4 className="ap-mode-card__name">🌐 Analyser d'URL & Nom de Domaine</h4>
                        </div>
                        {activeMode === "url" && (
                            <span className="ap-mode-card__badge">
                                <CheckCircle2 size={16} /> Actif
                            </span>
                        )}
                    </div>
                    <p className="ap-mode-card__description">
                        Analyse par IA (Stacking ML 33 features) + Heuristiques passives (WHOIS, Typosquatting, Punycode, Certificats SSL).
                    </p>
                </button>

                {/* Mail Card */}
                <button
                    id="ap-mode-mail"
                    type="button"
                    className={`ap-mode-card ${activeMode === "mail" ? "ap-mode-card--active" : ""}`}
                    onClick={() => setActiveMode("mail")}
                    disabled={activeMode === "mail"}
                >
                    <div className="ap-mode-card__header">
                        <div className="ap-mode-card__left">
                            <div className="ap-mode-card__icon">
                                <Mail size={24} />
                            </div>
                            <h4 className="ap-mode-card__name">📧 Scanner d'Emails (.eml & Texte)</h4>
                        </div>
                        {activeMode === "mail" && (
                            <span className="ap-mode-card__badge">
                                <CheckCircle2 size={16} /> Actif
                            </span>
                        )}
                    </div>
                    <p className="ap-mode-card__description">
                        Inspection NLP (Transformer / RoBERTa) + Extraction des liens + Vérification d'authenticité SPF & DKIM.
                    </p>
                </button>
            </div>

            <hr id="ap-divider" className="ap-divider" />

            {/* Content */}
            <div id="ap-content" className="ap-content">
                {activeMode === "url" && <AnalyzeUrlComponent navigate={navigate} />}
                {activeMode === "mail" && <AnalyzeMailComponent navigate={navigate} />}
            </div>
        </div>
    );
}

export default ApAnalyzeComponent;