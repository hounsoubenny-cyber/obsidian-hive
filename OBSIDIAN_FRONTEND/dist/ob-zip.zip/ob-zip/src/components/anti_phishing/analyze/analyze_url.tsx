import "./analyze_url.css"
import { useState } from "react";
import { 
    AnalyzeUrlRequest, 
    AnalyzeUrlResponse,
    DecisionEnum 
} from "@/types/anti_phishing/types";
import toast from "react-hot-toast";
import { analyzeUrl } from "../utils";
import { useNavigate } from "react-router-dom";
import { 
    ShieldCheck, 
    ShieldAlert, 
    ShieldX, 
    Copy, 
    Trash2, 
    Search, 
    RotateCcw, 
    Info, 
    ExternalLink,
    CheckCircle2,
    AlertTriangle,
    XCircle
} from "lucide-react";
import { toTitleCaseWithUnderscore } from "@/components/utils/to_lower_case";

// ============================================================================
// SOUS-COMPOSANT : Affichage du Résultat d'Analyse
// ============================================================================

function ShowAnalyzeResponse({
    response,
    explain,
    onClear,
}: {
    response: AnalyzeUrlResponse;
    explain: boolean;
    onClear: () => void;
}) {
    if (!response) return null;

    const handleCopy = () => {
        navigator.clipboard.writeText(JSON.stringify(response, null, 2));
        toast.success("📋 Résultat copié dans le presse-papier !");
    };

    const isSafe = response.final_decision === DecisionEnum.SAFE;
    const isPhishing = response.final_decision === DecisionEnum.PHISHING;
    const isSuspicious = response.final_decision === DecisionEnum.SUSPICIOUS;

    let verdictClass = "apu-verdict--unknown";
    if (isSafe) verdictClass = "apu-verdict--safe";
    else if (isSuspicious) verdictClass = "apu-verdict--suspicious";
    else if (isPhishing) verdictClass = "apu-verdict--phishing";

    return (
        <div id="apu-result" className="apu-result">
            {/* Header */}
            <div className="apu-result__header">
                <div className="apu-result__left">
                    <div className="apu-result__title">
                        📊 Résultat de l'évaluation
                    </div>
                    <span className="apu-result__meta">
                        📅 {response.date} (⏱️ {response.elapsed}s)
                    </span>
                </div>
                <div className="apu-result__actions">
                    <button className="apu-result__btn" onClick={handleCopy}>
                        <Copy size={14} /> Copier
                    </button>
                    <button className="apu-result__btn" onClick={onClear}>
                        <Trash2 size={14} /> Effacer
                    </button>
                </div>
            </div>

            {/* Verdict */}
            <div className={`apu-verdict ${verdictClass}`}>
                <div className="apu-verdict__icon">
                    {isSafe && <ShieldCheck size={32} />}
                    {isSuspicious && <ShieldAlert size={32} />}
                    {isPhishing && <ShieldX size={32} />}
                    {!isSafe && !isSuspicious && !isPhishing && <AlertTriangle size={32} />}
                </div>
                <div className="apu-verdict__content">
                    <div className="apu-verdict__decision">
                        {isSafe && "🟢 Site Sûr / Légitime"}
                        {isSuspicious && "🟡 Site Suspect (Prudence requise)"}
                        {isPhishing && "🔴 Menace Confirmée : Phishing"}
                        {!isSafe && !isSuspicious && !isPhishing && "⚪ Analyse Inconclue"}
                    </div>
                    <div className="apu-verdict__url">
                        🌐 <strong>{response.url}</strong>
                    </div>
                    <div className="apu-verdict__stats">
                        <div className="apu-verdict__stat">
                            <span className="apu-verdict__stat-label">Confiance</span>
                            <span className="apu-verdict__stat-value">{Math.round((response.confidence || 0) * 100)}%</span>
                        </div>
                        <div className="apu-verdict__stat">
                            <span className="apu-verdict__stat-label">Source</span>
                            <span className="apu-verdict__stat-value">🔍 {toTitleCaseWithUnderscore(response.source)}</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Advice */}
            {response.advice && (
                <div className="apu-advice">
                    <Info size={20} className="apu-advice__icon" />
                    <div className="apu-advice__content">
                        <span className="apu-advice__title">💡 Conseil de sécurité</span>
                        <p className="apu-advice__text">{response.advice}</p>
                    </div>
                </div>
            )}

            {/* Breakdown */}
            {explain && response?.breakdown && response?.breakdown?.ia_pred && response?.breakdown?.passive_analyze_level && (
                <div className="apu-breakdown">
                    <div className="apu-breakdown__title">🔬 Analyse Technique Approfondie</div>

                    {/* IA */}
                    {response.breakdown.ia_pred && <div className="apu-breakdown__section">
                        <div className="apu-breakdown__section-title">🧠 Intelligence Artificielle</div>
                        <ul className="apu-breakdown__list">
                            {response.breakdown.ia_pred && (
                                <li className="apu-breakdown__item">
                                    <span className="apu-breakdown__item-label">Verdict IA</span>
                                    <span className="apu-breakdown__item-value">{response.breakdown.ia_pred}</span>
                                </li>
                            )}
                            {response.breakdown.ia_pred_proba !== undefined && (
                                <li className="apu-breakdown__item">
                                    <span className="apu-breakdown__item-label">Probabilité Safe</span>
                                    <span className="apu-breakdown__item-value">{Math.round((response.breakdown.ia_pred_proba || 0) * 100)}%</span>
                                </li>
                            )}
                            {response.breakdown.ia_pred_proba_phishing !== undefined && (
                                <li className="apu-breakdown__item">
                                    <span className="apu-breakdown__item-label">Probabilité Phishing</span>
                                    <span className="apu-breakdown__item-value">{Math.round((response.breakdown.ia_pred_proba_phishing || 0) * 100)}%</span>
                                </li>
                            )}
                        </ul>
                    </div>}

                    {/* Heuristiques */}
                    {response?.breakdown?.passive_analyze_level && <div className="apu-breakdown__section">
                        <div className="apu-breakdown__section-title">🛡️ Heuristiques Passives</div>
                        <ul className="apu-breakdown__list">
                            {response.breakdown.passive_analyze_level && (
                                <li className="apu-breakdown__item">
                                    <span className="apu-breakdown__item-label">Niveau de Risque</span>
                                    <span className="apu-breakdown__item-value">{response.breakdown.passive_analyze_level}</span>
                                </li>
                            )}
                            {response.breakdown.passive_analyze_prob !== undefined && (
                                <li className="apu-breakdown__item">
                                    <span className="apu-breakdown__item-label">Score de Risque</span>
                                    <span className="apu-breakdown__item-value">{Math.round((response.breakdown.passive_analyze_prob || 0) * 100)}%</span>
                                </li>
                            )}
                        </ul>
                    </div>}

                    {/* Flags */}
                    {response?.passive_pred?.flags && response?.passive_pred?.flags?.length > 0 && (
                        <div className="apu-breakdown__section">
                            <div className="apu-breakdown__section-title">
                                🚩 Signaux Détectés ({response.passive_pred.flags.length})
                            </div>
                            <ul className="apu-breakdown__list">
                                {response.passive_pred.flags.map((flag, idx) => {
                                    const msg = Array.isArray(flag) ? flag[0] : flag.message;
                                    const pts = Array.isArray(flag) ? flag[1] : flag.points;
                                    return (
                                        <li key={idx} className="apu-breakdown__item">
                                            <span className="apu-breakdown__item-label">{msg}</span>
                                            <span className="apu-breakdown__item-value">{pts >= 0 ? `+${pts}` : pts} pts</span>
                                        </li>
                                    );
                                })}
                            </ul>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}

// ============================================================================
// COMPOSANT PRINCIPAL : Analyse d'URL
// ============================================================================

function AnalyzeUrlComponent({ navigate }: { navigate?: ReturnType<typeof useNavigate> }) {

    const [url, setUrl] = useState<string>("");
    const [checkBlacklist, setCheckBlacklist] = useState<boolean>(true);
    const [checkRightClick, setCheckRightClick] = useState<boolean>(false);
    const [explain, setExplain] = useState<boolean>(true);
    const [analyzeResponse, setAnalyzeResponse] = useState<AnalyzeUrlResponse | null>(null);
    const [analyzeLoading, setAnalyzeLoading] = useState<boolean>(false);
    const [analyzeError, setAnalyzeError] = useState<string | null>(null);

    const handleUrlBlur = () => {
        const val = url.trim();
        if (!val) return;
        if (!val.startsWith("http://") && !val.startsWith("https://")) {
            if (val.startsWith("://")) {
                setUrl("http" + val);
            } else {
                setUrl("http://" + val);
            }
        }
    };

    const handleAnalyze = async () => {
        const cleanUrl = url.trim();
        if (!cleanUrl) {
            toast.error("⚠️ Veuillez entrer une URL valide à analyser !");
            return;
        }

        const data: AnalyzeUrlRequest = {
            url: cleanUrl.startsWith("http://") || cleanUrl.startsWith("https://") 
                ? cleanUrl 
                : `https://${cleanUrl}`,
            explain: explain,
            check_blacklist: checkBlacklist,
            check_right_click: checkRightClick,
        };

        const result = await analyzeUrl(
            data,
            setAnalyzeResponse,
            setAnalyzeError,
            setAnalyzeLoading,
            navigate
        );

        if (result) {
            toast.success("⚡ Analyse complétée avec succès !");
        }
    };

    return (
        <div id="apu-container" className="apu-container">
            {/* Header */}
            <div className="apu-header">
                <div className="apu-header__title">🛡️ Anti-Phishing</div>
                <p className="apu-header__subtitle">
                    Analysez n'importe quelle URL suspecte en direct avec l'IA et 18 critères d'inspection passifs ⚡
                </p>
            </div>

            {/* Formulaire */}
            <div id="apu-form" className="apu-form">
                <div className="apu-form__group">
                    <label htmlFor="apu-url-input" className="apu-form__label">🔗 URL Cible à analyser</label>
                    <div className="apu-form__input-wrapper">
                        <input
                            id="apu-url-input"
                            className="apu-form__input"
                            type="text"
                            placeholder="Ex: http://paypal-secure-verify.tk/login ou google.com"
                            value={url}
                            onChange={(e) => setUrl(e.target.value)}
                            onBlur={handleUrlBlur}
                            onKeyDown={(e) => {
                                if (analyzeLoading || !url.trim()) return;
                                if (e.key === "Enter") handleAnalyze();
                            }}
                        />
                    </div>
                </div>

                {/* Actions */}
                <div className="apu-form__actions">
                    <button
                        id="apu-btn-reset"
                        className="apu-btn apu-btn--secondary"
                        type="button"
                        disabled={!url || analyzeLoading}
                        onClick={() => {
                            setUrl("");
                            setAnalyzeResponse(null);
                            setAnalyzeError(null);
                        }}
                    >
                        <RotateCcw size={16} /> Réinitialiser
                    </button>

                    <button
                        id="apu-btn-analyze"
                        className="apu-btn apu-btn--primary"
                        type="button"
                        disabled={analyzeLoading || !url.trim()}
                        onClick={handleAnalyze}
                    >
                        {analyzeLoading ? (
                            <>⏳ Analyse en cours...</>
                        ) : (
                            <>
                                <Search size={16} /> Analyser l'URL
                            </>
                        )}
                    </button>
                </div>

                {/* Options */}
                <div className="apu-options">
                    <div className="apu-options__title">⚙️ Options d'inspection</div>
                    
                    <label className="apu-options__group">
                        <input
                            type="checkbox"
                            className="apu-options__checkbox"
                            checked={checkBlacklist}
                            onChange={(e) => setCheckBlacklist(e.target.checked)}
                        />
                        <span className="apu-options__label">🛡️ Interroger les blacklists externes (PhishDestroy)</span>
                    </label>

                    <label className="apu-options__group">
                        <input
                            type="checkbox"
                            className="apu-options__checkbox"
                            checked={checkRightClick}
                            onChange={(e) => setCheckRightClick(e.target.checked)}
                        />
                        <span className="apu-options__label">🖱️ Détecter le blocage anti-inspection</span>
                    </label>

                    <label className="apu-options__group">
                        <input
                            type="checkbox"
                            className="apu-options__checkbox"
                            checked={explain}
                            onChange={(e) => setExplain(e.target.checked)}
                        />
                        <span className="apu-options__label">🔬 Explications techniques détaillées</span>
                    </label>
                </div>
            </div>

            {/* Erreur */}
            {analyzeError && (
                <div id="apu-error" className="apu-error">
                    <AlertTriangle size={20} className="apu-error__icon" />
                    <div className="apu-error__content">
                        <span className="apu-error__title">❌ Erreur lors de l'analyse</span>
                        <p className="apu-error__text">{analyzeError}</p>
                    </div>
                </div>
            )}

            {/* Empty State */}
            {!analyzeResponse && !analyzeLoading && !analyzeError && (
                <div id="apu-empty" className="apu-empty">
                    <div className="apu-empty__icon">🔍</div>
                    <p className="apu-empty__text">
                        Entrez une URL ci-dessus et cliquez sur <strong>Analyser</strong> pour obtenir un diagnostic complet.
                    </p>
                </div>
            )}

            {/* Résultat */}
            {analyzeResponse && (
                <ShowAnalyzeResponse
                    response={analyzeResponse}
                    explain={explain}
                    onClear={() => setAnalyzeResponse(null)}
                />
            )}
        </div>
    );
}

export default AnalyzeUrlComponent;