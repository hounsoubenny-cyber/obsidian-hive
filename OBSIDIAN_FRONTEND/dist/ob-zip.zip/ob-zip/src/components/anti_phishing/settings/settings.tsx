import { useEffect, useState } from "react";
import "./settings.css";
import { UserSettings, FullAppConfig, UpdateSettingsResponse } from "@/types/anti_phishing/types";
import { getApSettings, updateApSettings } from "../utils";
import { useNavigate } from "react-router-dom";
import { 
    Settings, 
    Sliders, 
    Save, 
    RotateCcw, 
    Shield, 
    Cpu, 
    Database, 
    Layers, 
    AlertTriangle,
    Info,
    RefreshCw
} from "lucide-react";
import toast from "react-hot-toast";

function ApSettingsComponent({ navigate }: { navigate?: ReturnType<typeof useNavigate> }) {
    const defaultNavigate = useNavigate();
    const nav = navigate || defaultNavigate;

    const [userSettings, setUserSettings] = useState<UserSettings>({
        check_blacklist: false,
        explain: true,
        check_right_click: false,
    });

    const [serverConfig, setServerConfig] = useState<FullAppConfig | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [saving, setSaving] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const fetchSettings = () => {
        getApSettings(
            (config: FullAppConfig) => {
                if (config) {
                    setServerConfig(config);
                    setUserSettings({
                        check_blacklist: config.check_blacklist ?? false,
                        explain: config.explain ?? true,
                        check_right_click: config.check_right_click ?? false,
                    });
                }
            },
            setError,
            setLoading,
            nav
        );
    };

    useEffect(() => {
        fetchSettings();
    }, []);

    const handleSave = async (e: React.FormEvent) => {
        e.preventDefault();
        const result = await updateApSettings(
            userSettings,
            (res: UpdateSettingsResponse) => {
                if (res?.settings) {
                    setUserSettings(res.settings);
                }
            },
            setError,
            setSaving,
            nav
        );

        if (result && result.status === "Succès") {
            toast.success("✅ Paramètres enregistrés avec succès !");
        }
    };

    return (
        <div id="aps-container" className="aps-container">
            {/* Header */}
            <div className="aps-header">
                <h2 className="aps-header__title">
                    <Settings size={24} /> ⚙️ Paramètres & Préférences Anti-Phishing
                </h2>
                <p className="aps-header__subtitle">
                    Configurez le comportement d'inspection par défaut et visualisez les caractéristiques du moteur IA.
                </p>
            </div>

            {/* Erreur */}
            {error && (
                <div id="aps-error" className="aps-error">
                    <AlertTriangle size={20} className="aps-error__icon" />
                    <div className="aps-error__content">
                        <span className="aps-error__title">❌ Erreur</span>
                        <p className="aps-error__text">{error}</p>
                    </div>
                </div>
            )}

            {/* Formulaire des Préférences */}
            <form id="aps-form" className="aps-form" onSubmit={handleSave}>
                <div className="aps-form__section">
                    <div className="aps-form__section-header">
                        <Sliders size={20} />
                        <h3 className="aps-form__section-title">🎛️ Options d'Analyse par Défaut</h3>
                    </div>
                    <span className="aps-form__section-desc">
                        Ces options seront présélectionnées lors de vos prochaines analyses.
                    </span>

                    {/* Option 1 : Blacklist */}
                    <label className="aps-option">
                        <input
                            id="aps-check-blacklist"
                            type="checkbox"
                            className="aps-option__checkbox"
                            checked={userSettings.check_blacklist}
                            onChange={(e) =>
                                setUserSettings({ ...userSettings, check_blacklist: e.target.checked })
                            }
                        />
                        <div className="aps-option__content">
                            <span className="aps-option__label">
                                🛡️ Vérification des Blacklists Externes (PhishDestroy)
                            </span>
                            <p className="aps-option__description">
                                Interroge les listes mondiales de menaces en temps réel pour une détection immédiate des domaines blacklistés.
                            </p>
                        </div>
                    </label>

                    {/* Option 2 : Clic Droit */}
                    <label className="aps-option">
                        <input
                            id="aps-check-right-click"
                            type="checkbox"
                            className="aps-option__checkbox"
                            checked={userSettings.check_right_click}
                            onChange={(e) =>
                                setUserSettings({ ...userSettings, check_right_click: e.target.checked })
                            }
                        />
                        <div className="aps-option__content">
                            <span className="aps-option__label">
                                🖱️ Détection de Blocage du Clic Droit
                            </span>
                            <p className="aps-option__description">
                                Vérifie si le site web désactive le menu contextuel (technique anti-inspection utilisée par les kits de phishing).
                            </p>
                        </div>
                    </label>

                    {/* Option 3 : Mode Explications */}
                    <label className="aps-option">
                        <input
                            id="aps-check-explain"
                            type="checkbox"
                            className="aps-option__checkbox"
                            checked={userSettings.explain}
                            onChange={(e) =>
                                setUserSettings({ ...userSettings, explain: e.target.checked })
                            }
                        />
                        <div className="aps-option__content">
                            <span className="aps-option__label">
                                🔬 Mode Explications & Diagnostics Détaillés
                            </span>
                            <p className="aps-option__description">
                                Retourne les scores précis de chaque modèle IA et la liste complète des drapeaux heuristiques levés.
                            </p>
                        </div>
                    </label>
                </div>

                {/* Boutons d'Action */}
                <div className="aps-actions">
                    <button 
                        id="aps-btn-reset"
                        type="button" 
                        className="aps-btn aps-btn--secondary" 
                        onClick={fetchSettings} 
                        disabled={loading || saving}
                    >
                        <RotateCcw size={16} /> Réinitialiser
                    </button>

                    <button 
                        id="aps-btn-save"
                        type="submit" 
                        className="aps-btn aps-btn--primary" 
                        disabled={saving}
                    >
                        <Save size={16} /> {saving ? "Enregistrement..." : "💾 Enregistrer les Préférences"}
                    </button>
                </div>
            </form>

            {/* Spécifications Moteur IA (Sans chemins ni infos sensibles) */}
            <div className="aps-specs">
                <div className="aps-specs__header">
                    <Cpu size={20} />
                    <h3 className="aps-specs__title">🧠 Spécifications du Moteur d'Intelligence Artificielle</h3>
                </div>
                <span className="aps-specs__subtitle">
                    Caractéristiques générales et paramètres d'apprentissage automatique du système.
                </span>

                {serverConfig ? (
                    <table className="aps-table">
                        <thead>
                            <tr>
                                <th>Composant IA</th>
                                <th>Configuration</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div className="aps-table__label">
                                        <Layers size={14} /> Moteur d'Analyse d'URLs
                                    </div>
                                </td>
                                <td><span className="aps-table__value">Pipeline Stacking Multi-Modèles</span></td>
                                <td>Combinaison XGBoost + ExtraTrees + Réseau de neurones (MLP)</td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="aps-table__label">
                                        <Cpu size={14} /> Moteur d'Analyse d'Emails
                                    </div>
                                </td>
                                <td><span className="aps-table__value">Modèle Transformer (NLP)</span></td>
                                <td>Architecture XLM-RoBERTa avec encodeur contrastif supervisé</td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="aps-table__label">
                                        <Database size={14} /> Vecteur de Caractéristiques
                                    </div>
                                </td>
                                <td><span className="aps-table__value">{serverConfig.n_features} features analysées</span></td>
                                <td>Entropie de Shannon, Punycode, typosquatting, sous-domaines, ports...</td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="aps-table__label">
                                        <RotateCcw size={14} /> Cycle de Réentraînement
                                    </div>
                                </td>
                                <td><span className="aps-table__value">{serverConfig.refit_time?.toLocaleString()} requêtes</span></td>
                                <td>Volume de nouvelles analyses pour déclencher une réévaluation du modèle</td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="aps-table__label">
                                        <Shield size={14} /> Seuil de Validation IA
                                    </div>
                                </td>
                                <td><span className="aps-table__value">+{Math.round((serverConfig.comparison_threshold || 0) * 100)}% de précision</span></td>
                                <td>Gain minimal requis pour valider une mise à jour du modèle</td>
                            </tr>
                        </tbody>
                    </table>
                ) : (
                    <div className="aps-loading">
                        <RefreshCw size={16} className="aps-loading__icon" />
                        <span>Chargement des spécifications techniques du moteur...</span>
                    </div>
                )}
            </div>
        </div>
    );
}

export default ApSettingsComponent;