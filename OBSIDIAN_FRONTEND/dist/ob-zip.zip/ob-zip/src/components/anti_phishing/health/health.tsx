import { useEffect, useState } from "react";
import "./health.css";
import { HealthResponse } from "@/types/anti_phishing/types";
import { useNavigate } from "react-router-dom";
import { getApHealth } from "../utils";
import { 
    Activity, 
    Cpu, 
    ShieldCheck, 
    RefreshCw, 
    Clock, 
    AlertTriangle, 
    CheckCircle2, 
    Server, 
    Zap,
    Globe,
    Calendar,
    Hash
} from "lucide-react";

function ApHealthComponent({ navigate }: { navigate?: ReturnType<typeof useNavigate> }) {
    const defaultNavigate = useNavigate();
    const nav = navigate || defaultNavigate;

    const [health, setHealth] = useState<HealthResponse | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [lastRefresh, setLastRefresh] = useState<Date>(new Date());

    const fetchHealth = () => {
        getApHealth(setHealth, setError, setLoading, nav).then(() => {
            setLastRefresh(new Date());
        });
    };

    useEffect(() => {
        fetchHealth();
    }, []);

    const isHealthy = health?.status === "healthy" && !error;
    const mlReady = health?.ml_available;

    return (
        <div id="aphh-container" className="aphh-container">
            {/* Header */}
            <div className="aphh-header">
                <div className="aphh-header__left">
                    <h2 className="aphh-header__title">
                        <Activity size={24} /> 🩺 État de Santé & Monitoring Système
                    </h2>
                    <p className="aphh-header__subtitle">
                        Surveillez en direct la disponibilité des modèles IA, les compteurs d'analyses et les quotas de sécurité.
                    </p>
                </div>

                <div className="aphh-header__right">
                    <span className="aphh-header__last-refresh">
                        <Clock size={14} /> Dernier contrôle : {lastRefresh.toLocaleTimeString()}
                    </span>
                    <button 
                        id="aphh-btn-refresh"
                        className="aphh-btn"
                        type="button" 
                        onClick={fetchHealth} 
                        disabled={loading}
                        title="Actualiser les métriques"
                    >
                        <RefreshCw size={16} className={loading ? "aphh-loading__icon" : ""} />
                        {loading ? "⏳ Actualisation..." : "🔄 Actualiser"}
                    </button>
                </div>
            </div>

            {/* Erreur */}
            {error && (
                <div id="aphh-error" className="aphh-error">
                    <AlertTriangle size={24} className="aphh-error__icon" />
                    <div className="aphh-error__content">
                        <span className="aphh-error__title">❌ Impossible de joindre le serveur Anti-Phishing</span>
                        <p className="aphh-error__text">{error}</p>
                        <button type="button" className="aphh-error__btn" onClick={fetchHealth}>
                            🔁 Réessayer la connexion
                        </button>
                    </div>
                </div>
            )}

            {/* Bannière d'état général */}
            {health && (
                <div id="aphh-banner" className={`aphh-banner ${isHealthy ? "aphh-banner--healthy" : "aphh-banner--degraded"}`}>
                    <div className="aphh-banner__left">
                        <div className="aphh-banner__icon">
                            {isHealthy ? <CheckCircle2 size={32} /> : <AlertTriangle size={32} />}
                        </div>
                        <div className="aphh-banner__content">
                            <div className="aphh-banner__status">
                                {isHealthy ? "🟢 Système 100% Opérationnel" : "🟡 Système Dégradé"}
                            </div>
                            <span className="aphh-banner__detail">
                                API FastAPI en ligne • Horodatage serveur : {new Date(health.date).toLocaleString()}
                            </span>
                        </div>
                    </div>

                    <div className="aphh-banner__right">
                        <span className="aphh-banner__badge">
                            STATUT : {health.status.toUpperCase()}
                        </span>
                    </div>
                </div>
            )}

            {/* Grille de métriques */}
            {health && (
                <div id="aphh-grid" className="aphh-grid">
                    {/* Carte 1 : Moteur IA */}
                    <div className="aphh-card">
                        <div className="aphh-card__header">
                            <Cpu size={20} className="aphh-card__icon" />
                            <h4 className="aphh-card__title">Moteur d'IA</h4>
                        </div>
                        <div className={`aphh-card__value ${mlReady ? "aphh-card__value--ml-ready" : "aphh-card__value--ml-not-ready"}`}>
                            {mlReady ? "🟢 Prêt" : "🔴 Hors ligne"}
                        </div>
                        <p className="aphh-card__description">
                            {mlReady 
                                ? "XGBoost, StackingClassifier & XLM-RoBERTa chargés en RAM." 
                                : "Le moteur IA est indisponible. Seule l'analyse passive fonctionnera."}
                        </p>
                    </div>

                    {/* Carte 2 : Analyses Session */}
                    <div className="aphh-card">
                        <div className="aphh-card__header">
                            <Zap size={20} className="aphh-card__icon" />
                            <h4 className="aphh-card__title">Session Actuelle</h4>
                        </div>
                        <div className="aphh-card__value">
                            {health.current_request_number.toLocaleString()}
                        </div>
                        <p className="aphh-card__description">
                            Analyses traitées depuis le démarrage du serveur.
                        </p>
                    </div>

                    {/* Carte 3 : Analyses Mois */}
                    <div className="aphh-card">
                        <div className="aphh-card__header">
                            <Calendar size={20} className="aphh-card__icon" />
                            <h4 className="aphh-card__title">Analyses ce Mois</h4>
                        </div>
                        <div className="aphh-card__value">
                            {health.month_request_number.toLocaleString()}
                        </div>
                        <p className="aphh-card__description">
                            Total cumulé des analyses d'URLs et d'emails ce mois-ci.
                        </p>
                    </div>

                    {/* Carte 4 : Total Historique */}
                    <div className="aphh-card">
                        <div className="aphh-card__header">
                            <Hash size={20} className="aphh-card__icon" />
                            <h4 className="aphh-card__title">Total Historique</h4>
                        </div>
                        <div className="aphh-card__value">
                            {health.all_request_number.toLocaleString()}
                        </div>
                        <p className="aphh-card__description">
                            Volume total d'analyses effectuées depuis l'installation.
                        </p>
                    </div>

                    {/* Carte 5 : Rate Limiting */}
                    <div className="aphh-card">
                        <div className="aphh-card__header">
                            <ShieldCheck size={20} className="aphh-card__icon" />
                            <h4 className="aphh-card__title">Rate Limiting</h4>
                        </div>
                        <div className="aphh-card__value">
                            {health.rate_limit}/min
                        </div>
                        <p className="aphh-card__description">
                            Quota maximal de requêtes autorisé par adresse IP.
                        </p>
                    </div>

                    {/* Carte 6 : Interface Frontend */}
                    <div className="aphh-card">
                        <div className="aphh-card__header">
                            <Globe size={20} className="aphh-card__icon" />
                            <h4 className="aphh-card__title">Interface Web</h4>
                        </div>
                        <div className="aphh-card__value">
                            {health.react ? "🟢 Déployé" : "⚪ API Seule"}
                        </div>
                        <p className="aphh-card__description">
                            {health.react 
                                ? "Fichiers statiques React servis par FastAPI." 
                                : "Serveur en mode API REST autonome."}
                        </p>
                    </div>
                </div>
            )}

            {/* Tableau Technique */}
            {health && (
                <div id="aphh-tech" className="aphh-tech">
                    <div className="aphh-tech__title">🔬 Détails Techniques de l'Environnement</div>
                    <table className="aphh-table">
                        <thead>
                            <tr>
                                <th>Composant</th>
                                <th>Configuration Détectée</th>
                                <th>État</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div className="aphh-table__component">
                                        <Server size={14} /> Service Backend
                                    </div>
                                </td>
                                <td>FastAPI (uvicorn / async)</td>
                                <td><span className="aphh-table__status aphh-table__status--online">🟢 En ligne</span></td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="aphh-table__component">
                                        <Cpu size={14} /> Modèles IA (Stacking + Transformer)
                                    </div>
                                </td>
                                <td>{mlReady ? "Opérationnels en RAM" : "Non chargés"}</td>
                                <td>
                                    <span className={`aphh-table__status ${mlReady ? "aphh-table__status--active" : "aphh-table__status--inactive"}`}>
                                        {mlReady ? "✅ Prêt" : "❌ Indisponible"}
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="aphh-table__component">
                                        <ShieldCheck size={14} /> Quota Anti-Abus
                                    </div>
                                </td>
                                <td>{health.rate_limit} requêtes / minute</td>
                                <td><span className="aphh-table__status aphh-table__status--active">✅ Actif</span></td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="aphh-table__component">
                                        <Clock size={14} /> Horloge Serveur
                                    </div>
                                </td>
                                <td>{new Date(health.date).toISOString()}</td>
                                <td><span className="aphh-table__status aphh-table__status--online">✅ Synchronisée</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            )}

            {/* État de chargement initial */}
            {!health && loading && (
                <div className="aphh-loading">
                    <RefreshCw size={24} className="aphh-loading__icon" />
                    <span>⏳ Récupération des indicateurs de santé du système...</span>
                </div>
            )}
        </div>
    );
}

export default ApHealthComponent;