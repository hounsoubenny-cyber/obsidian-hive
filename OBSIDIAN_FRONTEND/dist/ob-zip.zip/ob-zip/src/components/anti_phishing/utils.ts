import { logError } from "@/hooks/error_utils";
import { getToken, refreshToken } from "@/hooks/get_token";
import { 
    AnalyzeMailFormDataRequest, 
    AnalyzeMailResponse, 
    AnalyzeUrlRequest, 
    AnalyzeUrlResponse,
    HealthResponse as ApHealthResponse, 
    HistoryMailResponse, 
    HistoryUrlResponse ,
    FullAppConfig as ApFullAppConfig,          
    UpdateSettingsRequest as ApUpdateSettingsRequest,
    UpdateSettingsResponse as ApUpdateSettingsResponse
} from "@/types/anti_phishing/types";
import { 
    apAnalyzeMails, 
    apAnalyzeUrl, 
    apHealth, 
    apHistoryMails, 
    apHistoryUrl,
    apGetSettings,
    apSetSettings 
} from "@/hooks/fetch_functions";
import { useNavigate } from "react-router-dom";

export async function analyzeUrl(
    data: AnalyzeUrlRequest,
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<AnalyzeUrlResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await apAnalyzeUrl(data, getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as AnalyzeUrlResponse;
            if (setResult) setResult(json_);
            return json;
        }
        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await analyzeUrl(data, setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error)
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans analyzeUrl : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function analyzeMails(
    data: AnalyzeMailFormDataRequest,
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<AnalyzeMailResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const formData = new FormData();
        if (data.files){
            for (let i of data.files)
                formData.append("files", i)
        }
        if (data.mails){
            for (let i of data.mails)
                formData.append("mails", i)
        }
        formData.append("check_blacklist", data.check_blacklist ? "true" : "false");

        const result = await apAnalyzeMails(formData, getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as AnalyzeMailResponse;
            if (setResult) setResult(json_);
            return json;
        }
        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await analyzeMails(data, setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error)
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans analyzeMails : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function getHistoryUrl(
    mode: "all" | "json" | "txt",
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<HistoryUrlResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await apHistoryUrl(mode, getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as HistoryUrlResponse;
            if (setResult) setResult(json_);
            return json;
        }
        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getHistoryUrl(mode, setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error)
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getHistoryUrl : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function getHistoryMails(
    mode: "all" | "json" | "txt",
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<HistoryMailResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await apHistoryMails(mode, getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as HistoryMailResponse;
            if (setResult) setResult(json_);
            return json;
        }
        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getHistoryMails(mode, setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error)
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getHistoryMails : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function getApHealth(
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<ApHealthResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await apHealth(getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as ApHealthResponse;
            if (setResult) setResult(json_);
            return json;
        }
        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getApHealth(setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error)
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getApHealth : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function getApSettings(
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<ApFullAppConfig | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await apGetSettings(getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as ApFullAppConfig;
            if (setResult) setResult(json_);
            return json;
        }
        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await getApSettings(setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans getApSettings : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}

export async function updateApSettings(
    data: ApUpdateSettingsRequest,
    setResult: Function | null,
    setError: Function,
    setLoading: Function | null = null,
    navigate: ReturnType<typeof useNavigate>
): Promise<ApUpdateSettingsResponse | null> {
    try {
        if (setLoading) setLoading(true);
        setError(null);
        const result = await apSetSettings(data, getToken());
        const json_ = result.response;
        if (result.ok) {
            const json = json_ as ApUpdateSettingsResponse;
            if (setResult) setResult(json_);
            return json;
        }
        const json = json_ as Record<string, string>;
        if (json?.detail === "TOKEN_EXPIRED") {
            const refreshed = await refreshToken(getToken(), navigate);
            if (refreshed) return await updateApSettings(data, setResult, setError, setLoading, navigate);
            throw new Error("Impossible de rafraîchir le token");
        }
        if (setResult) setResult(null);
        setError(result.error);
        return null;
    } catch (err) {
        const msg: string = logError(err);
        setError(msg);
        console.log("❌ Erreur dans updateApSettings : ", msg);
        return null;
    } finally {
        if (setLoading) setLoading(false);
    }
}