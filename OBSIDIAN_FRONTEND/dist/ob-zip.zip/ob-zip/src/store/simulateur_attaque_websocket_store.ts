import { create } from "zustand";
import { 
  WSSimMessage, 
  SimulationReport, 
  SimStatus, 
  SimMode, 
  ActionDetailInfo 
} from "@/types/simulateur_attaque/types";
import { getSimulationReport } from "@/components/simulateur_attaque/utils";

const STORAGE_KEYS = {
  SESSION_ID: "simatk_active_session_id",
  MODE: "simatk_active_mode",
  WS_URL: "simatk_active_ws_url",
};

// ── Normalisateur universel de clés MITRE (PascalCase <-> snake_case) ──
export function normalizeActionKey(action: string): string {
  if (!action) return "";
  const cleaned = action.trim().toLowerCase().replace(/[\s\-_|]/g, "");
  
  const map: Record<string, string> = {
    reconnaissance: "reconnaissance",
    networkservicediscover: "reconnaissance",
    initialaccess: "initial_access",
    sshbruteforce: "initial_access",
    ftpbruteforce: "initial_access",
    httpbruteforce: "initial_access",
    execution: "execution",
    commandexecution: "execution",
    pythonexecution: "execution",
    reverseshell: "execution",
    privilegeescalation: "privilege_escalation",
    privesc: "privilege_escalation",
    sudoexploit: "privilege_escalation",
    suidbinary: "privilege_escalation",
    credentialaccess: "credential_access",
    passwordfiledump: "credential_access",
    bashhistoryread: "credential_access",
    sshkeytheft: "credential_access",
    lateralmovement: "lateral_movement",
    sshlateralmovement: "lateral_movement",
    exfiltration: "exfiltration",
    exfiltrationhttp: "exfiltration",
    defenseevasion: "defense_evasion",
    logcleaner: "defense_evasion",
    timestomp: "defense_evasion",
    persistence: "persistence",
    sshkeybackdoor: "persistence",
    cronbackdoor: "persistence",
    startupscript: "persistence",
    report: "report",
  };

  return map[cleaned] || action.toLowerCase();
}

function formatLogMessage(data: WSSimMessage): string | null {
  const time = data.timestamp ? new Date(data.timestamp).toLocaleTimeString() : "";
  const prefix = time ? `[${time}] ` : "";

  if (data.type === "step_start") {
    return `${prefix}📡 [START] ${data.message || data.step}`;
  }
  if (data.type === "step_progress") {
    return `${prefix}  ↳ ${data.message}`;
  }
  if (data.type === "step_success" || data.type === "step_end" || data.type === "step_result") {
    if (data.step === "report") {
      return `${prefix}📊 [RAPPORT] Synthèse intermédiaire reçue.`;
    }
    return `${prefix}✅ [OK] ${data.message || data.step || "Étape terminée"}`;
  }
  if (data.type === "sim_status") {
    return data.message ? `${prefix}ℹ️ [STATUS] ${data.message}` : null;
  }
  if (data.type === "llm_suggest") {
    const text = typeof data.suggestion === "object" ? JSON.stringify(data.suggestion) : String(data.suggestion || "");
    return `${prefix}🤖 [IA Conseil] ${text}`;
  }
  if (data.type === "llm_review") {
    const text = typeof data.review === "object" ? JSON.stringify(data.review) : String(data.review || "");
    return `${prefix}🤖 [IA Avis : ${data.action || "Action"}] ${text}`;
  }
  if (data.type === "sim_finished" || data.type === "finish") {
    return `${prefix}🏁 [FIN] Simulation terminée. Rapport disponible.`;
  }
  if (data.type === "error" || data.type === "step_error") {
    return `${prefix}❌ [ERREUR] ${data.message || data.error}`;
  }
  if (data.message && typeof data.message === "string") {
    return `${prefix}${data.message}`;
  }
  return null;
}

interface SimulateurAttaqueWSStore {
  ws: WebSocket | null;
  isConnected: boolean;
  isSimulating: boolean;
  isWaitingUserAction: boolean;
  isReplaying: boolean;

  // État de session
  sessionId: string | null;
  mode: SimMode | null;
  status: SimStatus | null;
  targetIp: string | null;
  progress: number;
  currentStep: string | null;
  actionsDone: string[];
  actionsAvailable: string[];
  actionsDetails: Record<string, ActionDetailInfo> | null;
  stateSummary: Record<string, any> | null;

  // Copilote IA
  llmSuggestion: string | null;
  llmReview: string | null;
  llmLoading: boolean;

  // Flux de logs & Rapport
  logs: string[];
  report: SimulationReport | null;
  simError: string | null;

  // Méthodes
  connect: (url: string) => void;
  disconnect: () => void;
  executeAction: (action: string, params?: Record<string, any>) => void;
  requestLlmSuggest: () => void;
  requestLlmReview: (action: string) => void;
  finishInteractive: () => void;
  clearLogs: () => void;
  resetSimulation: () => void;
  restoreSession: () => boolean;
  fetchReportFallback: (sessionId: string) => Promise<void>;
}

let pingInterval: any = null;

function saveSession(sessionId: string | null, mode: string | null, wsUrl: string | null) {
  if (sessionId && wsUrl) {
    sessionStorage.setItem(STORAGE_KEYS.SESSION_ID, sessionId);
    sessionStorage.setItem(STORAGE_KEYS.MODE, mode || "auto");
    sessionStorage.setItem(STORAGE_KEYS.WS_URL, wsUrl);
  } else {
    sessionStorage.removeItem(STORAGE_KEYS.SESSION_ID);
    sessionStorage.removeItem(STORAGE_KEYS.MODE);
    sessionStorage.removeItem(STORAGE_KEYS.WS_URL);
  }
}

export const useSimulateurAttaqueWSStore = create<SimulateurAttaqueWSStore>((set, get) => ({
  ws: null,
  isConnected: false,
  isSimulating: Boolean(sessionStorage.getItem(STORAGE_KEYS.SESSION_ID)),
  isWaitingUserAction: false,
  isReplaying: false,

  sessionId: sessionStorage.getItem(STORAGE_KEYS.SESSION_ID),
  mode: (sessionStorage.getItem(STORAGE_KEYS.MODE) as SimMode) || null,
  status: null,
  targetIp: null,
  progress: 0,
  currentStep: null,
  actionsDone: [],
  actionsAvailable: [],
  actionsDetails: null,
  stateSummary: null,

  llmSuggestion: null,
  llmReview: null,
  llmLoading: false,

  logs: [],
  report: null,
  simError: null,

  connect: (url: string) => {
    const { ws, isConnected } = get();
    if (isConnected && ws && ws.readyState === WebSocket.OPEN) {
      return;
    }

    if (ws) {
      try {
        ws.onclose = null;
        ws.close();
      } catch (e) {}
    }

    const sessionIdMatch = url.match(/\/ws\/([^?]+)/);
    const sid = sessionIdMatch ? sessionIdMatch[1] : null;

    saveSession(sid, get().mode || "auto", url);

    set({
      isSimulating: true,
      simError: null,
      sessionId: sid,
      report: null,
    });

    const newWs = new WebSocket(url);

    newWs.onopen = () => {
      set({ isConnected: true, isSimulating: true });
      clearInterval(pingInterval);
      pingInterval = setInterval(() => {
        if (newWs.readyState === WebSocket.OPEN) {
          newWs.send(JSON.stringify({ type: "get_state" }));
        }
      }, 25000);
    };

    newWs.onmessage = async (event: MessageEvent) => {
      try {
        const data: WSSimMessage = JSON.parse(event.data);

        if (data.type === "pong") return;

        // 1. Replay Buffer
        if (data.type === "replay_start") {
          set({
            isReplaying: true,
            logs: [`🔄 [HISTORIQUE] Début de restauration de la session...`],
          });
          return;
        }

        if (data.type === "replay_end") {
          set((s) => ({
            isReplaying: false,
            logs: [...s.logs, `🔄 [HISTORIQUE] Session synchronisée.`],
          }));
          return;
        }

        const logLine = formatLogMessage(data);

        // 2. Connected
        if (data.type === "connected") {
          const rawDone = data.actions_done || [];
          const normalizedDone = rawDone.map(normalizeActionKey).filter((v, i, a) => a.indexOf(v) === i);
          set((s) => ({
            status: data.status || s.status,
            mode: (data.mode as SimMode) || s.mode,
            currentStep: data.current_step ? normalizeActionKey(data.current_step) : null,
            actionsDone: normalizedDone,
            progress: typeof data.progress === "number" ? (data.progress > 1 ? data.progress : data.progress * 100) : s.progress,
            logs: logLine ? [...s.logs, logLine] : s.logs,
          }));
        }

        // 3. Sim Ready (Interactif)
        else if (data.type === "sim_ready") {
          const rawDone = data.actions_done || [];
          const normalizedDone = rawDone.map(normalizeActionKey).filter((v, i, a) => a.indexOf(v) === i);
          const rawAvail = data.actions_available || [];
          const normalizedAvail = rawAvail.map(normalizeActionKey).filter((v, i, a) => a.indexOf(v) === i);

          set((s) => ({
            isWaitingUserAction: true,
            targetIp: data.ip || data.data?.ip || s.targetIp,
            actionsAvailable: normalizedAvail,
            actionsDetails: data.actions_available_with_details || data.actions_details || null,
            actionsDone: normalizedDone,
            stateSummary: data.state_summary || null,
            logs: logLine ? [...s.logs, logLine] : [...s.logs, `⚡ Cible prête : ${data.ip || data.data?.ip || "Hôte"} — En attente d'ordres`],
          }));
        }

        // 4. Step Start
        else if (data.type === "step_start") {
          const normalized = data.step ? normalizeActionKey(data.step) : null;
          set((s) => ({
            currentStep: normalized || s.currentStep,
            progress: typeof data.progress === "number" ? (data.progress > 1 ? data.progress : data.progress * 100) : s.progress,
            logs: logLine ? [...s.logs, logLine] : s.logs,
          }));
        }

        // 5. Step Progress
        else if (data.type === "step_progress") {
          set((s) => ({
            logs: logLine ? [...s.logs, logLine] : s.logs,
          }));
        }

        // 6. Step Success / Result / End
        else if (
          data.type === "step_success" || 
          data.type === "step_end" || 
          data.type === "step_result"
        ) {
          const normalized = data.step ? normalizeActionKey(data.step) : null;
          const currentDone = get().actionsDone;
          const updatedDone = normalized && !currentDone.includes(normalized) 
            ? [...currentDone, normalized] 
            : currentDone;

          const rawAvail = data.actions_available || [];
          const normalizedAvail = rawAvail.length > 0 
            ? rawAvail.map(normalizeActionKey).filter((v, i, a) => a.indexOf(v) === i) 
            : get().actionsAvailable;

          let updatedReport = get().report;
          if (normalized === "report" || data.step === "report") {
            const rawSnap = data.result?.result || data.result;
            if (rawSnap) {
              updatedReport = rawSnap;
            }
          }

          set((s) => ({
            currentStep: null,
            progress: typeof data.progress === "number" ? (data.progress > 1 ? data.progress : data.progress * 100) : s.progress,
            isWaitingUserAction: s.mode === "interactive",
            actionsAvailable: normalizedAvail,
            actionsDetails: data.actions_available_with_details || data.actions_details || s.actionsDetails,
            actionsDone: updatedDone,
            report: updatedReport,
            logs: logLine ? [...s.logs, logLine] : s.logs,
          }));
        }

        // 7. Copilote IA
        else if (data.type === "llm_suggest") {
          const text = typeof data.suggestion === "object" ? JSON.stringify(data.suggestion, null, 2) : String(data.suggestion || "");
          set((s) => ({
            llmSuggestion: text,
            llmLoading: false,
            logs: logLine ? [...s.logs, logLine] : s.logs,
          }));
        } else if (data.type === "llm_review") {
          const text = typeof data.review === "object" ? JSON.stringify(data.review, null, 2) : String(data.review || "");
          set((s) => ({
            llmReview: text,
            llmLoading: false,
            logs: logLine ? [...s.logs, logLine] : s.logs,
          }));
        }

        // 8. Statut Global
        else if (data.type === "sim_status") {
          if (data.status === "stopped" || data.status === "failed" || data.status === "completed") {
            set({ isSimulating: false, status: data.status });
          }
          if (logLine) {
            set((s) => ({ logs: [...s.logs, logLine] }));
          }
        }

        // 9. Fin de Simulation & Rapport Final
        else if (data.type === "sim_finished" || data.type === "finish") {
          saveSession(null, null, null);

          let extractedReport: any = data.report;
          if (extractedReport && typeof extractedReport === "object") {
            if (extractedReport.report && extractedReport.report.executive_summary) {
              extractedReport = extractedReport.report;
            }
          }

          set((s) => ({
            report: extractedReport || s.report,
            isSimulating: false,
            isWaitingUserAction: false,
            progress: 100,
            logs: logLine ? [...s.logs, logLine] : [...s.logs, "🏁 [FIN] Simulation terminée. Rapport disponible."],
          }));

          const sid = get().sessionId;
          if (!extractedReport?.executive_summary && sid) {
            await get().fetchReportFallback(sid);
          }

          get().disconnect();
        }

        // 10. Erreurs
        else if (data.type === "error" || data.type === "step_error") {
          const errText = data.message || data.error || "Erreur d'exécution";
          set((s) => ({
            simError: errText,
            llmLoading: false,
            logs: logLine ? [...s.logs, logLine] : s.logs,
          }));
        }

        else if (logLine) {
          set((s) => ({ logs: [...s.logs, logLine] }));
        }
      } catch (err) {
        if (typeof event.data === "string") {
          set((s) => ({ logs: [...s.logs, event.data] }));
        }
      }
    };

    newWs.onclose = () => {
      clearInterval(pingInterval);
      set({ isConnected: false, isSimulating: false });
    };

    set({ ws: newWs });
  },

  disconnect: () => {
    const { ws } = get();
    clearInterval(pingInterval);
    if (ws) {
      ws.onclose = null;
      ws.close();
    }
    set({ ws: null, isConnected: false, isSimulating: false, isWaitingUserAction: false, isReplaying: false });
  },

  executeAction: (action: string, params: Record<string, any> = {}) => {
    const { ws } = get();
    if (ws && ws.readyState === WebSocket.OPEN) {
      set({ isWaitingUserAction: false });
      ws.send(JSON.stringify({ type: "execute_action", action, params }));
    }
  },

  requestLlmSuggest: () => {
    const { ws } = get();
    if (ws && ws.readyState === WebSocket.OPEN) {
      set({ llmLoading: true, llmSuggestion: null });
      ws.send(JSON.stringify({ type: "request_llm_suggest" }));
    }
  },

  requestLlmReview: (action: string) => {
    const { ws } = get();
    if (ws && ws.readyState === WebSocket.OPEN) {
      set({ llmLoading: true, llmReview: null });
      ws.send(JSON.stringify({ type: "request_llm_review", action }));
    }
  },

  finishInteractive: () => {
    const { ws } = get();
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: "finish" }));
    }
  },

  clearLogs: () => set({ logs: [] }),

  resetSimulation: () => {
    const { disconnect } = get();
    disconnect();
    saveSession(null, null, null);
    set({
      logs: [],
      report: null,
      simError: null,
      sessionId: null,
      status: null,
      currentStep: null,
      progress: 0,
      actionsDone: [],
      actionsAvailable: [],
      actionsDetails: null,
      stateSummary: null,
      llmSuggestion: null,
      llmReview: null,
      isSimulating: false,
      isWaitingUserAction: false,
      isReplaying: false,
    });
  },

  restoreSession: () => {
    const activeUrl = sessionStorage.getItem(STORAGE_KEYS.WS_URL);
    const sid = sessionStorage.getItem(STORAGE_KEYS.SESSION_ID);
    if (activeUrl && sid) {
      get().connect(activeUrl);
      return true;
    }
    return false;
  },

  fetchReportFallback: async (sessionId: string) => {
    try {
      const res = await getSimulationReport(sessionId, null, () => {}, null, undefined);
      if (res) {
        let finalRep: any = res;
        if (res.report && res.report.executive_summary) {
          finalRep = res.report;
        }
        set({ report: finalRep });
      }
    } catch (e) {}
  },
}));