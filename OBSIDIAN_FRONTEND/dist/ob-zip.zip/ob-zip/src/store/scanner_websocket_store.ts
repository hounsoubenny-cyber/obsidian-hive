import { create } from "zustand";
import { ScanSummaryResult, WSScanMessage } from "@/types/scanner/types";

// Clés de stockage de session
const STORAGE_KEYS = {
  SCAN_ID: "sc_active_scan_id",
  PASS_PHRASE: "sc_active_pass_phrase",
  WS_URL: "sc_active_ws_url",
};

interface WSConnectOptions {
  onOpen?: () => void;
  onClose?: (event: CloseEvent) => void;
  onResult?: (result: ScanSummaryResult) => void;
  onError?: (error: string) => void;
  force?: boolean;
}

interface ScannerWSStore {
  ws: WebSocket | null;
  isConnected: boolean;
  isScanning: boolean;
  isReconnecting: boolean;

  // Données de session
  activeScanId: string | null;
  activePassPhrase: string | null;
  activeWsUrl: string | null;

  // Données de flux en direct
  logs: string[];
  scanInfos: string[];
  scanResult: ScanSummaryResult | null;
  scanError: string | null;

  // Actions
  connect: (url: string, options?: WSConnectOptions) => void;
  disconnect: () => void;
  sendMessage: (data: any) => void;
  clearLogs: () => void;
  resetScan: () => void;
  restoreSession: () => boolean;
}

let pingInterval: any = null;
let reconnectTimeout: any = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 3;
const RECONNECT_DELAY = 2000;

// Sauvegarde dans sessionStorage
function saveSession(scanId: string | null, passPhrase: string | null, wsUrl: string | null) {
  if (scanId && wsUrl) {
    sessionStorage.setItem(STORAGE_KEYS.SCAN_ID, scanId);
    sessionStorage.setItem(STORAGE_KEYS.PASS_PHRASE, passPhrase || "");
    sessionStorage.setItem(STORAGE_KEYS.WS_URL, wsUrl);
  } else {
    sessionStorage.removeItem(STORAGE_KEYS.SCAN_ID);
    sessionStorage.removeItem(STORAGE_KEYS.PASS_PHRASE);
    sessionStorage.removeItem(STORAGE_KEYS.WS_URL);
  }
}

// Extraction du scan_id depuis l'URL
function extractScanId(url: string): string | null {
  try {
    const parsed = new URL(url);
    return parsed.searchParams.get("scan_id");
  } catch {
    const match = url.match(/scan_id=([^&]+)/);
    return match ? match[1] : null;
  }
}

function extractPassPhrase(url: string): string | null {
  try {
    const parsed = new URL(url);
    return parsed.searchParams.get("pass_phrase");
  } catch {
    const match = url.match(/pass_phrase=([^&]+)/);
    return match ? decodeURIComponent(match[1]) : null;
  }
}

export const useScannerWSStore = create<ScannerWSStore>((set, get) => ({
  ws: null,
  isConnected: false,
  isScanning: Boolean(sessionStorage.getItem(STORAGE_KEYS.SCAN_ID)),
  isReconnecting: false,

  activeScanId: sessionStorage.getItem(STORAGE_KEYS.SCAN_ID),
  activePassPhrase: sessionStorage.getItem(STORAGE_KEYS.PASS_PHRASE),
  activeWsUrl: sessionStorage.getItem(STORAGE_KEYS.WS_URL),

  logs: [],
  scanInfos: [],
  scanResult: null,
  scanError: null,

  connect: (url: string, options?: WSConnectOptions) => {
    const { force = false, onOpen, onClose, onResult, onError } = options || {};
    const { ws, isConnected } = get();

    if (isConnected && !force) return;
    if ((ws?.readyState === WebSocket.OPEN || ws?.readyState === WebSocket.CONNECTING) && !force) return;

    // Fermeture propre de l'ancienne socket si force = true
    if (ws && force) {
      try {
        ws.onclose = null;
        ws.close();
      } catch {
        // Ignorer
      }
    }

    clearTimeout(reconnectTimeout);

    const scanId = extractScanId(url);
    const passPhrase = extractPassPhrase(url);

    // Enregistrement de la session active
    saveSession(scanId, passPhrase, url);

    set({
      isScanning: true,
      scanError: null,
      scanResult: null,
      activeScanId: scanId,
      activePassPhrase: passPhrase,
      activeWsUrl: url,
    });

    const newWs = new WebSocket(url);

    newWs.onopen = () => {
      console.log("✅ [Scanner WS] Connecté");
      reconnectAttempts = 0;
      set({ isConnected: true, isScanning: true, isReconnecting: false });
      onOpen?.();

      // Heartbeat ping toutes les 25s
      clearInterval(pingInterval);
      pingInterval = setInterval(() => {
        if (newWs.readyState === WebSocket.OPEN) {
          newWs.send("ping");
        }
      }, 25000);
    };

    newWs.onmessage = (event) => {
      try {
        const data: WSScanMessage = JSON.parse(event.data);

        // 🏓 1. Réponse Pong (on ignore immédiatement)
        if (data.type === "pong") {
          return;
        }

        // 2. Logs bruts du terminal
        if (data.type === "log" && typeof data.message === "string") {
          set((state) => ({ logs: [...state.logs, data.message as string] }));
        }
        // 3. Événements d'étapes de scan
        else if (data.type === "scan_info" && typeof data.message === "string") {
          set((state) => ({ 
            scanInfos: [...state.scanInfos, data.message as string],
            logs: [...state.logs, `ℹ️ ${data.message}`]
          }));
        }
        // 4. Résultat final complet
        else if (data.type === "scan_result") {
          const result = data.message as ScanSummaryResult;
          // Nettoyage de la session active car le scan est terminé
          saveSession(null, null, null);
          set({
            scanResult: result,
            isScanning: false,
            isReconnecting: false,
            activeScanId: null,
            activePassPhrase: null,
            activeWsUrl: null,
            logs: [...get().logs, "🏁 [SCAN] Résumé final reçu avec succès."]
          });
          onResult?.(result);
          const {disconnect} = get()
          disconnect();
        }
        // 5. Erreur critique pendant le scan
        else if (data.type === "scan_error") {
          const errorMsg = typeof data.message === "string" ? data.message : JSON.stringify(data.message);
          // Nettoyage de la session
          saveSession(null, null, null);
          set({
            scanError: errorMsg,
            isScanning: false,
            isReconnecting: false,
            activeScanId: null,
            activePassPhrase: null,
            activeWsUrl: null,
            logs: [...get().logs, `❌ [ERREUR SCAN] ${errorMsg}`]
          });
          onError?.(errorMsg);
          const {disconnect} = get()
          disconnect();
        }
      } catch {
        // Message texte brut non-JSON (et non 'pong')
        if (typeof event.data === "string" && event.data !== "pong") {
          set((state) => ({ logs: [...state.logs, event.data] }));
        }
      }
    };

    newWs.onclose = (event) => {
      console.log(`❌ [Scanner WS] Déconnecté (code=${event.code}, reason=${event.reason || "?"})`);
      clearInterval(pingInterval);

      const { isScanning, activeWsUrl } = get();

      // Si le scan était toujours en cours et qu'on n'a pas atteint la limite de reconnexions
      if (isScanning && activeWsUrl && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
        reconnectAttempts++;
        console.log(`🔄 [Scanner WS] Tentative de reconnexion ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS} dans ${RECONNECT_DELAY}ms...`);
        set({ isConnected: false, isReconnecting: true });

        reconnectTimeout = setTimeout(() => {
          get().connect(activeWsUrl, options);
        }, RECONNECT_DELAY);
      } else {
        // Déconnexion définitive ou fin de scan
        set({ isConnected: false, isReconnecting: false });
        const {disconnect} = get()
        disconnect();
        onClose?.(event);
      }
    };

    newWs.onerror = () => {
      console.error("⚠️ [Scanner WS] Erreur socket");
      clearInterval(pingInterval);
      set({ isConnected: false });
    };

    set({ ws: newWs });
  },

  disconnect: () => {
    const { ws } = get();
    clearInterval(pingInterval);
    clearTimeout(reconnectTimeout);
    reconnectAttempts = 0;
    saveSession(null, null, null);

    if (ws) {
      ws.onclose = null;
      ws.close();
    }

    set({ 
      ws: null, 
      isConnected: false, 
      isScanning: false, 
      isReconnecting: false,
      activeScanId: null,
      activePassPhrase: null,
      activeWsUrl: null,
    });
  },

  sendMessage: (data: any) => {
    const { ws } = get();
    if (ws?.readyState === WebSocket.OPEN) {
      ws.send(typeof data === "string" ? data : JSON.stringify(data));
    } else {
      console.warn("⚠️ [Scanner WS] Impossible d'envoyer : socket déconnectée");
    }
  },

  clearLogs: () => {
    set({ logs: [], scanInfos: [] });
  },

  resetScan: () => {
    const { disconnect } = get();
    disconnect();
    set({
      logs: [],
      scanInfos: [],
      scanResult: null,
      scanError: null,
      isScanning: false,
      isReconnecting: false,
      isConnected: false,
      activeWsUrl: null,
      ws: null, 
      activeScanId: null,
      activePassPhrase: null,
    });
  },

  // Restauration automatique au rechargement de page (F5)
  restoreSession: () => {
    const activeUrl = sessionStorage.getItem(STORAGE_KEYS.WS_URL);
    const activeId = sessionStorage.getItem(STORAGE_KEYS.SCAN_ID);
    if (activeUrl && activeId) {
      console.log(`♻️ [Scanner WS] Restauration de session pour scan_id: ${activeId}`);
      get().connect(activeUrl);
      return true;
    }
    else{
      const {disconnect} = get();
      disconnect();
    }
    return false;
  },
}));