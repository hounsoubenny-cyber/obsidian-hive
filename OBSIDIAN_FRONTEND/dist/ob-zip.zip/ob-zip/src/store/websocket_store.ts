import { create } from "zustand";

interface WSConnectOptions {
  /** Appelé quand la connexion s'ouvre avec succès — utile pour réinitialiser
   * un compteur de retry côté appelant. */
  onOpen?: () => void;
  /** Appelé à la fermeture, avec le CloseEvent complet (code, reason) —
   * c'est à l'appelant de décider quoi faire (retry, refresh du token,
   * redirection login...), le store reste agnostique de l'auth/router. */
  onClose?: (event: CloseEvent) => void;
  /** Force une reconnexion même si une connexion OPEN existe déjà
   * (ex: reconnexion avec un nouveau token après refresh). */
  force?: boolean;
}

interface WSStore {
  ws: WebSocket | null;
  isConnected: boolean;
  connect: (url: string, options?: WSConnectOptions) => void;
  disconnect: () => void;
  sendMessage: (data: any) => void;
}

export const useWSStore = create<WSStore>((set, get) => ({
  ws: null,
  isConnected: false,

  connect: (url: string, options?: WSConnectOptions) => {
    const { force = false, onOpen, onClose } = options || {};
    const { ws, isConnected } = get();
    console.log("state", ws?.readyState);
    if (isConnected && !force) return;
    if ((ws?.readyState === WebSocket.OPEN || ws?.readyState === WebSocket.CONNECTING) && !force) return;

    // Si on force une reconnexion (ex: nouveau token) alors qu'une socket
    // existe encore, on la ferme proprement avant d'en ouvrir une nouvelle
    // pour éviter de laisser une connexion fantôme en OPEN/CONNECTING.
    if (ws && force) {
      try {
        ws.onclose = null;
        ws.close();
      } catch {
        // pas critique
      }
    }

    const newWs = new WebSocket(url);

    newWs.onopen = () => {
      console.log("✅ WS connecté");
      set({ isConnected: true });
      onOpen?.();
    };

    newWs.onmessage = (event) => {
      console.log("📩 Message reçu:", event.data);
    };

    newWs.onclose = (event) => {
      console.log(`❌ WS déconnecté (code=${event.code}, reason=${event.reason || "?"})`);
      set({ isConnected: false });
      onClose?.(event);
    };

    newWs.onerror = () => {
      console.error("⚠️ WS erreur");
      set({ isConnected: false });
    };

    set({ ws: newWs });
  },

  disconnect: () => {
    const { ws } = get();
    if (ws) {
      ws.onclose = null;
      ws.close();
      set({ ws: null, isConnected: false });
    }
  },

  sendMessage: (data: any) => {
    const { ws } = get();
    if (ws?.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(data));
    } else {
      console.warn("⚠️ sendMessage ignoré : WebSocket non connecté");
    }
  },
}));