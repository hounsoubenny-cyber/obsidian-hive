import { useNavigate } from "react-router-dom";
import { refreshToken as _refreshToken } from "./fetch_functions";
import { RefreshTokenData } from "@/types/refresh_token/types";
import { logError } from "./error_utils";

function getToken(){
    return sessionStorage.getItem("token");
}

function setToken(token: string){
    return sessionStorage.setItem("token", token)
}

function getUsername(){
    return sessionStorage.getItem("username");
}

function setUsername(token: string){
    return sessionStorage.setItem("username", token)
}

function removeToken(){
    return sessionStorage.removeItem("token");
}


function removeUsername(){
    return sessionStorage.removeItem("username");
}

function isLogin(){
    return Boolean(sessionStorage.getItem("token"));
}

function logout(){
    removeToken();
    removeUsername();
}

const refreshToken = async (token: string, navigate: ReturnType<typeof useNavigate>) => {
    console.log("🔄 Refresh token enclenché !");
    try {
        let data: RefreshTokenData = {
            "token": token,
            "username": getUsername(),
        }
        let response = await _refreshToken(
            data
        );
        
        if ((!response.ok) || response.error){
            console.log("❌ Erreur dans refresh_token : ", response.error);
            sessionStorage.removeItem("token");
            if (navigate) navigate("/login");
            return false;
        }
        const json = response.response;
        setToken(json.access_token);
        console.log("✅ Token rafraîchi avec succès");
        return true;
    } catch (err) {
        let msg: string = logError(err);
        console.log("❌ Exception refreshToken : ", msg);
        alert("Erreur lors du rafraîchissement du token. Veuillez vous reconnecter.");
        sessionStorage.clear();
        if (navigate) navigate("/login");
        return false;
    }
}

export {getToken, setToken, setUsername, getUsername, isLogin, refreshToken, removeToken, removeUsername, logout};