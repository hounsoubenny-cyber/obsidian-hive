import { _FetchResult, _fetch_get, _fetch_post } from "./fetch_functions_bases";

import {
  createWebAssetRoute,
  createNetWorkAssetRoute,
  listAssetRoute,
  getAssetRoute,
  deleteAssetRoute,
  pauseAssetRoute,
  resumeAssetRoute,
  searchAssetRoute,
  apAnalyzeUrlRoute,
  apAnalyzeMailRoute,
  apHistoryUrlsRoute,
  apHistoryMailsRoute,
  apHealthRoute,
  apSetSettingsRoute,
  apGetSettingsRoute,
  sbAnalyzeCodeRoute,
  sbConfigRoute,
  sbContainersStatusRoute,
  sbEstimateRiskRoute,
  sbHealthRoute,
  sbLanguagesRoute,
  scCancelScanRoute,
  scReportsRoute,
  scStartScanRoute,
  scStatusRoute,
  scSupportedVulnsRoute,
  scValidateParamsDirRoute,
  simActionsRoute,
  simCloneStartRoute,
  simCloneStatusRoute,
  simCloneStopRoute,
  simContainersCreateRoute,
  simContainersExecRoute,
  simContainersListRoute,
  simContainersStopRoute,
  simHistoryRoute,
  simImagesListRoute,
  simListRoute,
  simNetworkConnectRoute,
  simNetworkCreateRoute,
  simNetworkDisconnectRoute,
  simNetworkListRoute,
  simNetworkMoveRoute,
  simNetworkRemoveRoute,
  simReportRoute,
  simServicesCaptureRoute,
  simServicesValidateRoute,
  simStartRoute,
  simStatusRoute,
  simStopRoute,
  idsAlertsRoute,
  idsBlockedRoute,
  idsBlockIpRoute,
  idsChangeModeRoute,
  idsConfigRoute,
  idsCreateNetworkAssetRoute,
  idsDefaultConfigRoute,
  idsGeoLocationRoute,
  idsGetModeRoute,
  idsGetPortRoute,
  idsHealthRoute,
  idsHelpRoute,
  idsListEndpointsRoute,
  idsManageIgnoredIpRoute,
  idsManageWhitelistRoute,
  idsStartRoute,
  idsStopRoute,
  idsUnlockRoute,
  idsUpdateConfigRoute,
  updateAssetRoute,
  pauseAllAssetsRoute,
  resumeAllAssetsRoute,
  addServerCapabilitiesRoute,
  allowServerToolsRoute,
  createServerAssetRoute,
  listServerCapabilitiesRoute,
  listServerToolsRoute,
  reactivateServerAssetRoute,
  removeServerCapabilitiesRoute,
  revokeServerAssetRoute,
  revokeServerToolsRoute,
  rotateServerSecretRoute,
} from "./backend_routes";

import {
  jobCatalogRoute,
  listJobsRoute,
  getJobRoute,
  createJobRoute,
  modifyJobRoute,
  pauseJobRoute,
  resumeJobRoute,
  pauseAllJobsRoute,
  resumeAllJobsRoute,
  removeAllJobsRoute,
  removeJobRoute,
} from "./backend_routes";

import {
  scannerDefaultConfigRoute,
  idsIpsDefaultConfigRoute,
  listScannerHelpersRoute,
  listScannerSupportedVulnsRoute,
  checkPathExitsRoute,
  validateScannerKnowParamDirRoute,
} from "./backend_routes";

import {
  getReportRoute,
  getLatestReportRoute,
  getFirstestReportRoute,
  listReportsByFilterRoute,
  listCriticalReportsRoute,
  getReportStatsRoute,
  updateReportSeverityRoute,
  deleteReportRoute,
  deleteOldReportsRoute,
} from "./backend_routes";

import {
  createConversationRoute,
  deleteConversationRoute,
  deleteMessageRoute,
  getConversationRoute,
  getLastMessageRoute,
  getMessagesRoute,
  listConversationsRoute,
  searchConversationsRoute,
  setArchivedRoute,
  setFavoriteRoute,
  updateConversationTitleRoute,
  updateMessageContentRoute,
} from "./backend_routes";

import { refreshTokenRoute } from "./backend_routes";

import { getConfig } from "./get_config";

import {
  AddAssetResult,
  BulkAssetActionResponse,
  GetAssetDataRequest,
  GetAssetResponse,
  ListAssetDataRequest,
  ListAssetResponse,
  ManageAssetDataRequest,
  ManageAssetResponse,
  NetworkAssetModel,
  PauseAssetDataRequest,
  PauseAssetsDataRequest,
  ReactivateServerAssetRequest,
  ReactivateServerAssetResponse,
  RemoveAssetDataRequest,
  RemoveAssetResponse,
  ResumeAssetDataRequest,
  ResumeAssetsDataRequest,
  RotateSecretRequest,
  RotateSecretResponse,
  SearchAssetDataRequest,
  SearchAssetResponse,
  ServerAgentRevokeRequest,
  ServerAssetModel,
  ServerCapabilitiesRequest,
  ServerToolInfo,
  ServerToolsRequest,
  UpdateAssetDataRequest,
  WebAssetModel,
} from "@/types/assets/types";

import { RefreshTokenData } from "@/types/refresh_token/types";

import {
  AddJobRequest,
  GetJobRequest,
  GetJobResponse,
  InMemoryFilter,
  Job,
  JobBulkOperationResponse,
  JobCatalogResponse,
  JobOperationResponse,
  ListJobsResponse,
  ManageAllJobsRequest,
  ManageJobRequest,
  ModifyJobRequest,
} from "@/types/jobs/types";

import { CancelScanRequest, CancelScanResponse, HelpersListResponse, ScannerStatusResponse, ScanReportsResponse, StartScanRequest, StartScanResponse, SupportedVulnsResponse, ValidateKnownParamDirResponse } from "@/types/scanner/types";

import {
  GetReportDataRequest,
  GetReportResponse,
  GetByAssetDataRequest,
  GetLatestReportResponse,
  GetFirstestReportResponse,
  ListReportsByFilterDataRequest,
  ListReportsByFilterResponse,
  ListCriticalReportsDataRequest,
  ListCriticalReportsResponse,
  ReportStatsDataRequest,
  ReportStatsResponse,
  UpdateReportSeverityDataRequest,
  UpdateReportSeverityResponse,
  ReportIdDataRequest,
  DeleteReportResponse,
  DeleteOldReportsDataRequest,
  DeleteOldReportsResponse,
} from "@/types/reports/types";

import {
  CreateConversationRequest,
  CreateConversationResponse,
  DeleteConversationRequest,
  DeleteConversationResponse,
  DeleteMessageRequest,
  DeleteMessageResponse,
  GetConversationRequest,
  GetConversationResponse,
  GetLastMessageRequest,
  GetLastMessageResponse,
  GetMessagesRequest,
  GetMessagesResponse,
  ListConversationsRequest,
  ListConversationsResponse,
  SearchConversationsRequest,
  SearchConversationsResponse,
  SetArchivedRequest,
  SetArchivedResponse,
  SetFavoriteRequest,
  SetFavoriteResponse,
  UpdateConversationTitleRequest,
  UpdateConversationTitleResponse,
  UpdateMessageContentRequest,
  UpdateMessageContentResponse,
} from "@/types/chat_coralie/types";

import { 
  AnalyzeUrlResponse as ApnalyzeUrlResponse,
  AnalyzeUrlRequest as ApAnalyzeUrlRequest,
  AnalyzeMailResponse as ApAnalyzeMailResponse,
  AnalyzeMailFormDataRequest as ApAnalyzeMailFormDataRequest,
  HistoryMailResponse as ApHistoryMailResponse,
  HistoryUrlResponse as ApHistoryUrlResponse,
  UpdateSettingsRequest as ApUpdateSettingsRequest,
  UpdateSettingsResponse as ApUpdateSettingsResponse,
  HealthResponse as ApHealthResponse,
  FullAppConfig as ApFullAppConfig,
} from "@/types/anti_phishing/types";
import { AnalyzeCodeResponse, EstimateRiskResponse, SupportedLanguagesResponse, SandboxDefaultConfigResponse, ContainerStatusResponse, SandboxHealthResponse } from "@/types/sandbox/types";
import { StartSimRequest, StartSimResponse, StopSimResponse, SimStatusResponse, SimulationReport, AvailableActionsResponse, DockerImageInfo, CloneRequest, CloneStatusResponse, ValidateServicesResponse, ContainerInfo, ContainerCreateRequest, ContainerExecRequest, ContainerExecResponse, NetworkInfo, NetworkCreateRequest, NetworkConnectRequest, NetworkMoveRequest } from "@/types/simulateur_attaque/types";
import { BlockedIpsResponseMap, BlockIpRequest, ChangeModeRequest, IdsActionResponse, IdsFullConfig, IdsGeoLocationResponse, IdsGraphPortResponse, IdsHealthResponse, IdsMode, LastAlertsResponse, ManageIgnoredIpRequest, ManageWhitelistRequest, NetworkEndpointsMap, UnlockIpRequest, UpdateConfigCategoryRequest } from "@/types/ids_ips/types";


type funcRetType = Promise<_FetchResult>;

export const refreshToken = async (data: RefreshTokenData): funcRetType => {
    return await _fetch_post(
        `${(await getConfig()).apiBaseUrl}/${refreshTokenRoute}`,
        data as Record<string, any>
    );
}

// Assets

export const createWebAsset = async (data: WebAssetModel, token: string): Promise<_FetchResult<AddAssetResult>> => {
    return await _fetch_post<AddAssetResult>(
        `${(await getConfig()).apiBaseUrl}/${createWebAssetRoute}`,
        data as Record<string, any>,
        token
    );
};

export const createNetworkAsset = async (data: NetworkAssetModel, token: string): Promise<_FetchResult<AddAssetResult>> => {
    return await _fetch_post<AddAssetResult>(
        `${(await getConfig()).apiBaseUrl}/${createNetWorkAssetRoute}`,
        data as Record<string, any>,
        token
    );
};

export const listAsset = async (data: ListAssetDataRequest, token: string): Promise<_FetchResult<ListAssetResponse>> => {
    return await _fetch_post<ListAssetResponse>(
        `${(await getConfig()).apiBaseUrl}/${listAssetRoute}`,
        data as Record<string, any>,
        token
    );
};

export const getAsset = async (data: GetAssetDataRequest, token: string): Promise<_FetchResult<GetAssetResponse>> => {
    return await _fetch_post<GetAssetResponse>(
        `${(await getConfig()).apiBaseUrl}/${getAssetRoute}`,
        data as Record<string, any>,
        token
    );
};

export const deleteAsset = async (data: RemoveAssetDataRequest, token: string): Promise<_FetchResult<RemoveAssetResponse>> => {
    return await _fetch_post<RemoveAssetResponse>(
        `${(await getConfig()).apiBaseUrl}/${deleteAssetRoute}`,
        data as Record<string, any>,
        token
    );
};

export const pauseAsset = async (data: PauseAssetDataRequest, token: string): Promise<_FetchResult<ManageAssetResponse>> => {
    return await _fetch_post<ManageAssetResponse>(
        `${(await getConfig()).apiBaseUrl}/${pauseAssetRoute}`,
        data as Record<string, any>,
        token
    );
};

export const resumeAsset = async (data: ResumeAssetDataRequest, token: string): Promise<_FetchResult<ManageAssetResponse>> => {
    return await _fetch_post<ManageAssetResponse>(
        `${(await getConfig()).apiBaseUrl}/${resumeAssetRoute}`,
        data as Record<string, any>,
        token
    );
};

export const searchAsset = async (
    data: SearchAssetDataRequest,
    token: string
): Promise<_FetchResult<SearchAssetResponse>> => {
    const config = await getConfig();
    return _fetch_post<SearchAssetResponse>(
        `${config.apiBaseUrl}/${searchAssetRoute}`,
        data as Record<string, any>,
        token
    );
};

export const updateAsset = async (
  data: UpdateAssetDataRequest,
  token: string
): Promise<_FetchResult<ManageAssetResponse>> => {
  const config = await getConfig();
  return _fetch_post<ManageAssetResponse>(
    `${config.apiBaseUrl}/${updateAssetRoute}`,
    data as Record<string, any>,
    token
  );
};

export const pauseAllAssets = async (
  data: PauseAssetsDataRequest,
  token: string
): Promise<_FetchResult<BulkAssetActionResponse>> => {
  const config = await getConfig();
  return _fetch_post<BulkAssetActionResponse>(
    `${config.apiBaseUrl}/${pauseAllAssetsRoute}`,
    data as Record<string, any>,
    token
  );
};

export const resumeAllAssets = async (
  data: ResumeAssetsDataRequest,
  token: string
): Promise<_FetchResult<BulkAssetActionResponse>> => {
  const config = await getConfig();
  return _fetch_post<BulkAssetActionResponse>(
    `${config.apiBaseUrl}/${resumeAllAssetsRoute}`,
    data as Record<string, any>,
    token
  );
};


export const createServerAsset = async (data: ServerAssetModel, token: string): Promise<_FetchResult<AddAssetResult>> => {
  const config = await getConfig();
  return _fetch_post<AddAssetResult>(`${config.apiBaseUrl}/${createServerAssetRoute}`, data as Record<string, any>, token);
};

export const revokeServerAsset = async (data: ServerAgentRevokeRequest, token: string): Promise<_FetchResult<any>> => {
  const config = await getConfig();
  return _fetch_post<any>(`${config.apiBaseUrl}/${revokeServerAssetRoute}`, data as Record<string, any>, token);
};

export const rotateServerSecret = async (data: RotateSecretRequest, token: string): Promise<_FetchResult<RotateSecretResponse>> => {
  const config = await getConfig();
  return _fetch_post<RotateSecretResponse>(`${config.apiBaseUrl}/${rotateServerSecretRoute}`, data as Record<string, any>, token);
};

export const reactivateServerAsset = async (data: ReactivateServerAssetRequest, token: string): Promise<_FetchResult<ReactivateServerAssetResponse>> => {
  const config = await getConfig();
  return _fetch_post<ReactivateServerAssetResponse>(`${config.apiBaseUrl}/${reactivateServerAssetRoute}`, data as Record<string, any>, token);
};

export const addServerCapabilities = async (data: ServerCapabilitiesRequest, token: string): Promise<_FetchResult<any>> => {
  const config = await getConfig();
  return _fetch_post<any>(`${config.apiBaseUrl}/${addServerCapabilitiesRoute}`, data as Record<string, any>, token);
};

export const removeServerCapabilities = async (data: ServerCapabilitiesRequest, token: string): Promise<_FetchResult<any>> => {
  const config = await getConfig();
  return _fetch_post<any>(`${config.apiBaseUrl}/${removeServerCapabilitiesRoute}`, data as Record<string, any>, token);
};

export const listServerCapabilities = async (token: string): Promise<_FetchResult<Record<string, string>>> => {
  const config = await getConfig();
  return _fetch_get<Record<string, string>>(`${config.apiBaseUrl}/${listServerCapabilitiesRoute}`, null, token);
};

export const allowServerTools = async (data: ServerToolsRequest, token: string): Promise<_FetchResult<any>> => {
  const config = await getConfig();
  return _fetch_post<any>(`${config.apiBaseUrl}/${allowServerToolsRoute}`, data as Record<string, any>, token);
};

export const revokeServerTools = async (data: ServerToolsRequest, token: string): Promise<_FetchResult<any>> => {
  const config = await getConfig();
  return _fetch_post<any>(`${config.apiBaseUrl}/${revokeServerToolsRoute}`, data as Record<string, any>, token);
};

export const listServerTools = async (token: string): Promise<_FetchResult<ServerToolInfo[]>> => {
  const config = await getConfig();
  return _fetch_get<ServerToolInfo[]>(`${config.apiBaseUrl}/${listServerToolsRoute}`, null, token);
};

// JOBS

export const jobCatalog = async (
    token: string
): Promise<_FetchResult<JobCatalogResponse>> => {
    return await _fetch_get<JobCatalogResponse>(
        `${(await getConfig()).apiBaseUrl}/${jobCatalogRoute}`,
        null,
        token
    );
}

export const listJob = async (
    data: InMemoryFilter,
    token: string
): Promise<_FetchResult<ListJobsResponse>> => {
    return await _fetch_post<ListJobsResponse>(
        `${(await getConfig()).apiBaseUrl}/${listJobsRoute}`,
        data as Record<string, any>,
        token
    );
}

export const getJob = async (
  data: GetJobRequest,
  token: string
): Promise<_FetchResult<GetJobResponse>> => {
  const config = await getConfig();
  return _fetch_post<GetJobResponse>(
    `${config.apiBaseUrl}/${getJobRoute}`,
    data as Record<string, any>,
    token
  );
};

export const getJobState = async (
  data: GetJobRequest,
  token: string
): Promise<_FetchResult<string | null>> => {
  const config = await getConfig();
  return _fetch_post<string | null>(
    `${config.apiBaseUrl}/${getJobState}`,
    data as Record<string, any>,
    token
  );
};

export const createJob = async (
  data: AddJobRequest,
  token: string
): Promise<_FetchResult<Job>> => {
  const config = await getConfig();
  return _fetch_post<Job>(
    `${config.apiBaseUrl}/${createJobRoute}`,
    data as Record<string, any>,
    token
  );
};

export const modifyJob = async (
  data: ModifyJobRequest,
  token: string
): Promise<_FetchResult<JobOperationResponse>> => {
  const config = await getConfig();
  return _fetch_post<JobOperationResponse>(
    `${config.apiBaseUrl}/${modifyJobRoute}`,
    data as Record<string, any>,
    token
  );
};

export const pauseJob = async (
  data: ManageJobRequest,
  token: string
): Promise<_FetchResult<JobOperationResponse>> => {
  const config = await getConfig();
  return _fetch_post<JobOperationResponse>(
    `${config.apiBaseUrl}/${pauseJobRoute}`,
    data as Record<string, any>,
    token
  );
};

export const resumeJob = async (
  data: ManageJobRequest,
  token: string
): Promise<_FetchResult<JobOperationResponse>> => {
  const config = await getConfig();
  return _fetch_post<JobOperationResponse>(
    `${config.apiBaseUrl}/${resumeJobRoute}`,
    data as Record<string, any>,
    token
  );
};

export const removeJob = async (
  data: ManageJobRequest,
  token: string
): Promise<_FetchResult<JobOperationResponse>> => {
  const config = await getConfig();
  return _fetch_post<JobOperationResponse>(
    `${config.apiBaseUrl}/${removeJobRoute}`,
    data as Record<string, any>,
    token
  );
};

export const pauseAllJobs = async (
  data: ManageAllJobsRequest,
  token: string
): Promise<_FetchResult<JobBulkOperationResponse>> => {
  const config = await getConfig();
  return _fetch_post<JobBulkOperationResponse>(
    `${config.apiBaseUrl}/${pauseAllJobsRoute}`,
    data as Record<string, any>,
    token
  );
};

export const resumeAllJobs = async (
  data: ManageAllJobsRequest,
  token: string
): Promise<_FetchResult<JobBulkOperationResponse>> => {
  const config = await getConfig();
  return _fetch_post<JobBulkOperationResponse>(
    `${config.apiBaseUrl}/${resumeAllJobsRoute}`,
    data as Record<string, any>,
    token
  );
};

export const removeAllJobs = async (
  data: ManageAllJobsRequest,
  token: string
): Promise<_FetchResult<JobBulkOperationResponse>> => {
  const config = await getConfig();
  return _fetch_post<JobBulkOperationResponse>(
    `${config.apiBaseUrl}/${removeAllJobsRoute}`,
    data as Record<string, any>,
    token
  );
};

// Default Config

export const getScannerDefaultConfig = async (
  token: string
): Promise<_FetchResult<Record<string, any>>> => {
  const config = await getConfig();
  return _fetch_get<Record<string, any>>(
    `${config.apiBaseUrl}/${scannerDefaultConfigRoute}`,
    null,
    token
  );
};

export const getIdsIpsDefaultConfig = async (
  token: string
): Promise<_FetchResult<Record<string, any>>> => {
  const config = await getConfig();
  return _fetch_get<Record<string, any>>(
    `${config.apiBaseUrl}/${idsIpsDefaultConfigRoute}`,
    null,
    token
  );
};

// Liste des helpers

export const listScannerHelper = async (
  token: string
): Promise<_FetchResult<HelpersListResponse>> => {
  const config = await getConfig();
  return _fetch_get<HelpersListResponse>(
    `${config.apiBaseUrl}/${listScannerHelpersRoute}`,
    null,
    token
  );
};

// Liste des vulns supporter par le scanner.

export const listScannerSupportedVulns = async (
  token: string
): Promise<_FetchResult<string[]>> => {
  const config = await getConfig();
  return _fetch_get<string[]>(
    `${config.apiBaseUrl}/${listScannerSupportedVulnsRoute}`,
    null,
    token
  );
};

export const checkPathExits = async (
    path: string,
    token: string
): Promise<_FetchResult<{exists: boolean}>> => {
  const config = await getConfig();
  return _fetch_get<{exists: boolean}>(
    `${config.apiBaseUrl}/${checkPathExitsRoute}`,
    `path=${encodeURIComponent(path)}`,
    token
  );
};

export const validateScannerKnowParamDir = async (
    path: string,
    token: string
): Promise<_FetchResult<{can: boolean, reason: string}>> => {
  const config = await getConfig();
  return _fetch_get<{can: boolean, reason: string}>(
    `${config.apiBaseUrl}/${validateScannerKnowParamDirRoute}`,
    `path=${encodeURIComponent(path)}`,
    token
  );
};

// ============================================================================
// REPORTS
// ============================================================================

export const getReport = async (
    data: GetReportDataRequest,
    token: string
): Promise<_FetchResult<GetReportResponse>> => {
    const config = await getConfig();
    return _fetch_post<GetReportResponse>(
        `${config.apiBaseUrl}/${getReportRoute}`,
        data as Record<string, any>,
        token
    );
};

export const getLatestReport = async (
    data: GetByAssetDataRequest,
    token: string
): Promise<_FetchResult<GetLatestReportResponse>> => {
    const config = await getConfig();
    return _fetch_post<GetLatestReportResponse>(
        `${config.apiBaseUrl}/${getLatestReportRoute}`,
        data as Record<string, any>,
        token
    );
};

export const getFirstestReport = async (
    data: GetByAssetDataRequest,
    token: string
): Promise<_FetchResult<GetFirstestReportResponse>> => {
    const config = await getConfig();
    return _fetch_post<GetFirstestReportResponse>(
        `${config.apiBaseUrl}/${getFirstestReportRoute}`,
        data as Record<string, any>,
        token
    );
};

export const listReportsByFilter = async (
    data: ListReportsByFilterDataRequest,
    token: string
): Promise<_FetchResult<ListReportsByFilterResponse>> => {
    const config = await getConfig();
    return _fetch_post<ListReportsByFilterResponse>(
        `${config.apiBaseUrl}/${listReportsByFilterRoute}`,
        data as Record<string, any>,
        token
    );
};

export const listCriticalReports = async (
    data: ListCriticalReportsDataRequest,
    token: string
): Promise<_FetchResult<ListCriticalReportsResponse>> => {
    const config = await getConfig();
    return _fetch_post<ListCriticalReportsResponse>(
        `${config.apiBaseUrl}/${listCriticalReportsRoute}`,
        data as Record<string, any>,
        token
    );
};

export const getReportStats = async (
    data: ReportStatsDataRequest,
    token: string
): Promise<_FetchResult<ReportStatsResponse>> => {
    const config = await getConfig();
    return _fetch_post<ReportStatsResponse>(
        `${config.apiBaseUrl}/${getReportStatsRoute}`,
        data as Record<string, any>,
        token
    );
};

export const updateReportSeverity = async (
    data: UpdateReportSeverityDataRequest,
    token: string
): Promise<_FetchResult<UpdateReportSeverityResponse>> => {
    const config = await getConfig();
    return _fetch_post<UpdateReportSeverityResponse>(
        `${config.apiBaseUrl}/${updateReportSeverityRoute}`,
        data as Record<string, any>,
        token
    );
};

export const deleteReport = async (
    data: ReportIdDataRequest,
    token: string
): Promise<_FetchResult<DeleteReportResponse>> => {
    const config = await getConfig();
    return _fetch_post<DeleteReportResponse>(
        `${config.apiBaseUrl}/${deleteReportRoute}`,
        data as Record<string, any>,
        token
    );
};

export const deleteOldReports = async (
    data: DeleteOldReportsDataRequest,
    token: string
): Promise<_FetchResult<DeleteOldReportsResponse>> => {
    const config = await getConfig();
    return _fetch_post<DeleteOldReportsResponse>(
        `${config.apiBaseUrl}/${deleteOldReportsRoute}`,
        data as Record<string, any>,
        token
    );
};

// ============================================================================
// CONVERSATION MANAGER — FETCH FUNCTIONS
// ============================================================================

// ---- CREATE CONVERSATION ----

export const createConversation = async (
  data: CreateConversationRequest,
  token: string
): Promise<_FetchResult<CreateConversationResponse>> => {
  const config = await getConfig();
  return _fetch_post<CreateConversationResponse>(
    `${config.apiBaseUrl}/${createConversationRoute}`,
    data as Record<string, any>,
    token
  );
};

// ---- LIST CONVERSATIONS ----

export const listConversations = async (
  data: ListConversationsRequest,
  token: string
): Promise<_FetchResult<ListConversationsResponse>> => {
  const config = await getConfig();
  return _fetch_post<ListConversationsResponse>(
    `${config.apiBaseUrl}/${listConversationsRoute}`,
    data as Record<string, any>,
    token
  );
};

// ---- GET CONVERSATION ----

export const getConversation = async (
  data: GetConversationRequest,
  token: string
): Promise<_FetchResult<GetConversationResponse>> => {
  const config = await getConfig();
  return _fetch_post<GetConversationResponse>(
    `${config.apiBaseUrl}/${getConversationRoute}`,
    data as Record<string, any>,
    token
  );
};

// ---- DELETE CONVERSATION ----

export const deleteConversation = async (
  data: DeleteConversationRequest,
  token: string
): Promise<_FetchResult<DeleteConversationResponse>> => {
  const config = await getConfig();
  return _fetch_post<DeleteConversationResponse>(
    `${config.apiBaseUrl}/${deleteConversationRoute}`,
    data as Record<string, any>,
    token
  );
};

// ---- UPDATE CONVERSATION TITLE ----

export const updateConversationTitle = async (
  data: UpdateConversationTitleRequest,
  token: string
): Promise<_FetchResult<UpdateConversationTitleResponse>> => {
  const config = await getConfig();
  return _fetch_post<UpdateConversationTitleResponse>(
    `${config.apiBaseUrl}/${updateConversationTitleRoute}`,
    data as Record<string, any>,
    token
  );
};

// ---- SET FAVORITE ----

export const setFavorite = async (
  data: SetFavoriteRequest,
  token: string
): Promise<_FetchResult<SetFavoriteResponse>> => {
  const config = await getConfig();
  return _fetch_post<SetFavoriteResponse>(
    `${config.apiBaseUrl}/${setFavoriteRoute}`,
    data as Record<string, any>,
    token
  );
};

// ---- SET ARCHIVED ----

export const setArchived = async (
  data: SetArchivedRequest,
  token: string
): Promise<_FetchResult<SetArchivedResponse>> => {
  const config = await getConfig();
  return _fetch_post<SetArchivedResponse>(
    `${config.apiBaseUrl}/${setArchivedRoute}`,
    data as Record<string, any>,
    token
  );
};

// ---- SEARCH CONVERSATIONS ----

export const searchConversations = async (
  data: SearchConversationsRequest,
  token: string
): Promise<_FetchResult<SearchConversationsResponse>> => {
  const config = await getConfig();
  return _fetch_post<SearchConversationsResponse>(
    `${config.apiBaseUrl}/${searchConversationsRoute}`,
    data as Record<string, any>,
    token
  );
};

// ---- GET MESSAGES ----

export const getMessages = async (
  data: GetMessagesRequest,
  token: string
): Promise<_FetchResult<GetMessagesResponse>> => {
  const config = await getConfig();
  return _fetch_post<GetMessagesResponse>(
    `${config.apiBaseUrl}/${getMessagesRoute}`,
    data as Record<string, any>,
    token
  );
};

// ---- GET LAST MESSAGE ----

export const getLastMessage = async (
  data: GetLastMessageRequest,
  token: string
): Promise<_FetchResult<GetLastMessageResponse>> => {
  const config = await getConfig();
  return _fetch_post<GetLastMessageResponse>(
    `${config.apiBaseUrl}/${getLastMessageRoute}`,
    data as Record<string, any>,
    token
  );
};

// ---- UPDATE MESSAGE CONTENT ----

export const updateMessageContent = async (
  data: UpdateMessageContentRequest,
  token: string
): Promise<_FetchResult<UpdateMessageContentResponse>> => {
  const config = await getConfig();
  return _fetch_post<UpdateMessageContentResponse>(
    `${config.apiBaseUrl}/${updateMessageContentRoute}`,
    data as Record<string, any>,
    token
  );
};

// ---- DELETE MESSAGE ----

export const deleteMessage = async (
  data: DeleteMessageRequest,
  token: string
): Promise<_FetchResult<DeleteMessageResponse>> => {
  const config = await getConfig();
  return _fetch_post<DeleteMessageResponse>(
    `${config.apiBaseUrl}/${deleteMessageRoute}`,
    data as Record<string, any>,
    token
  );
};


// Anti Phishing

export const apAnalyzeUrl = async (
  data: ApAnalyzeUrlRequest,
  token: string
): Promise<_FetchResult<ApnalyzeUrlResponse>> => {
  const config = await getConfig();
  return _fetch_post<ApnalyzeUrlResponse>(
    `${config.apiBaseUrl}/${apAnalyzeUrlRoute}`,
    data as Record<string, any>,
    token
  );
};

export const apAnalyzeMails = async (
  data: any,
  token: string
): Promise<_FetchResult<ApAnalyzeMailResponse>> => {
  const config = await getConfig();
  return _fetch_post<ApAnalyzeMailResponse>(
    `${config.apiBaseUrl}/${apAnalyzeMailRoute}`,
    data,
    token,
    true
  );
};

export const apHistoryUrl = async (
  mode: "all" | "json" | "txt",
  token: string
): Promise<_FetchResult<ApHistoryUrlResponse>> => {
  const config = await getConfig();
  return _fetch_get<ApHistoryUrlResponse>(
    `${config.apiBaseUrl}/${apHistoryUrlsRoute}`,
    `mode=${encodeURIComponent(mode)}`,
    token
  );
};

export const apHistoryMails = async (
  mode: "all" | "json" | "txt",
  token: string
): Promise<_FetchResult<ApHistoryMailResponse>> => {
  const config = await getConfig();
  return _fetch_get<ApHistoryMailResponse>(
    `${config.apiBaseUrl}/${apHistoryMailsRoute}`,
    `mode=${encodeURIComponent(mode)}`,
    token
  );
};

export const apHealth = async (
  token: string
): Promise<_FetchResult<ApHealthResponse>> => {
  const config = await getConfig();
  return _fetch_get<ApHealthResponse>(
    `${config.apiBaseUrl}/${apHealthRoute}`,
    null,
    token
  );
};

export const apSetSettings = async (
  data: ApUpdateSettingsRequest,
  token: string
): Promise<_FetchResult<ApUpdateSettingsResponse>> => {
  const config = await getConfig();
  return _fetch_post<ApUpdateSettingsResponse>(
    `${config.apiBaseUrl}/${apSetSettingsRoute}`,
    data as Record<string, any>,
    token
  );
};

export const apGetSettings = async (
  token: string
): Promise<_FetchResult<ApFullAppConfig>> => {
  const config = await getConfig();
  return _fetch_get<ApFullAppConfig>(
    `${config.apiBaseUrl}/${apGetSettingsRoute}`,
    null,
    token
  );
};

// ============================================================================
// Sandbox Base Fetch Functions
// ============================================================================

export const sbAnalyzeCode = async (
  data: FormData | any,
  token: string
): Promise<_FetchResult<AnalyzeCodeResponse>> => {
  const config = await getConfig();
  return _fetch_post<AnalyzeCodeResponse>(
    `${config.apiBaseUrl}/${sbAnalyzeCodeRoute}`,
    data,
    token,
    true // multipart/form-data
  );
};

export const sbEstimateRisk = async (
  data: FormData | any,
  token: string
): Promise<_FetchResult<EstimateRiskResponse>> => {
  const config = await getConfig();
  return _fetch_post<EstimateRiskResponse>(
    `${config.apiBaseUrl}/${sbEstimateRiskRoute}`,
    data,
    token,
    true // multipart/form-data
  );
};

export const sbLanguages = async (
  token: string
): Promise<_FetchResult<SupportedLanguagesResponse>> => {
  const config = await getConfig();
  return _fetch_get<SupportedLanguagesResponse>(
    `${config.apiBaseUrl}/${sbLanguagesRoute}`,
    null,
    token
  );
};

export const sbConfig = async (
  token: string
): Promise<_FetchResult<SandboxDefaultConfigResponse>> => {
  const config = await getConfig();
  return _fetch_get<SandboxDefaultConfigResponse>(
    `${config.apiBaseUrl}/${sbConfigRoute}`,
    null,
    token
  );
};

export const sbContainersStatus = async (
  token: string
): Promise<_FetchResult<ContainerStatusResponse>> => {
  const config = await getConfig();
  return _fetch_get<ContainerStatusResponse>(
    `${config.apiBaseUrl}/${sbContainersStatusRoute}`,
    null,
    token
  );
};

export const sbHealth = async (
  token: string
): Promise<_FetchResult<SandboxHealthResponse>> => {
  const config = await getConfig();
  return _fetch_get<SandboxHealthResponse>(
    `${config.apiBaseUrl}/${sbHealthRoute}`,
    null,
    token
  );
};

// Scanner Web Suite

export const scStartScan = async (
  data: StartScanRequest,
  token: string
): Promise<_FetchResult<StartScanResponse>> => {
  const config = await getConfig();
  return _fetch_post<StartScanResponse>(
    `${config.apiBaseUrl}/${scStartScanRoute}`,
    data as Record<string, any>,
    token
  );
};

export const scCancelScan = async (
  data: CancelScanRequest,
  token: string
): Promise<_FetchResult<CancelScanResponse>> => {
  const config = await getConfig();
  return _fetch_post<CancelScanResponse>(
    `${config.apiBaseUrl}/${scCancelScanRoute}`,
    data as Record<string, any>,
    token
  );
};

export const scGetStatus = async (
  token: string
): Promise<_FetchResult<ScannerStatusResponse>> => {
  const config = await getConfig();
  return _fetch_get<ScannerStatusResponse>(
    `${config.apiBaseUrl}/${scStatusRoute}`,
    null,
    token
  );
};

export const scGetReports = async (
  scan_id: string,
  token: string
): Promise<_FetchResult<ScanReportsResponse>> => {
  const config = await getConfig();
  return _fetch_get<ScanReportsResponse>(
    `${config.apiBaseUrl}/${scReportsRoute}/${encodeURIComponent(scan_id)}`,
    null,
    token
  );
};

export const scGetDefaultConfig = async (
  token: string
): Promise<_FetchResult<Record<string, any>>> => {
  return await getScannerDefaultConfig(token);
};

export const scGetSupportedVulns = async (
  token: string
): Promise<_FetchResult<SupportedVulnsResponse>> => {
  const config = await getConfig();
  return _fetch_get<SupportedVulnsResponse>(
    `${config.apiBaseUrl}/${scSupportedVulnsRoute}`,
    null,
    token
  );
};

export const scGetHelpers = async (
  token: string
): Promise<_FetchResult<HelpersListResponse>> => {
  return await listScannerHelper(token);
};

export const scValidateParamsDir = async (
  path: string,
  token: string
): Promise<_FetchResult<ValidateKnownParamDirResponse>> => {
  const config = await getConfig();
  return _fetch_get<ValidateKnownParamDirResponse>(
    `${config.apiBaseUrl}/${scValidateParamsDirRoute}`,
    `path=${encodeURIComponent(path)}`,
    token
  );
};


// ─── Simulations ─────────────────────────────────────────────────────────────

export const simStart = async (data: StartSimRequest, token: string) => {
  const config = await getConfig();
  return _fetch_post<StartSimResponse>(`${config.apiBaseUrl}/${simStartRoute}`, data, token);
};

export const simStop = async (sessionId: string, token: string) => {
  const config = await getConfig();
  return _fetch_post<StopSimResponse>(`${config.apiBaseUrl}/${simStopRoute}/${encodeURIComponent(sessionId)}/stop`, {}, token);
};

export const simGetStatus = async (sessionId: string, token: string) => {
  const config = await getConfig();
  return _fetch_get<SimStatusResponse>(`${config.apiBaseUrl}/${simStatusRoute}/${encodeURIComponent(sessionId)}/status`, null, token);
};

export const simListActive = async (token: string) => {
  const config = await getConfig();
  return _fetch_get<{ sims: SimStatusResponse[] }>(`${config.apiBaseUrl}/${simListRoute}`, null, token);
};

export const simGetReport = async (sessionId: string, token: string) => {
  const config = await getConfig();
  return _fetch_get<SimulationReport>(`${config.apiBaseUrl}/${simReportRoute}/${encodeURIComponent(sessionId)}/report`, null, token);
};

export const simGetActions = async (sessionId: string, token: string) => {
  const config = await getConfig();
  return _fetch_get<AvailableActionsResponse>(`${config.apiBaseUrl}/${simActionsRoute}/${encodeURIComponent(sessionId)}/actions`, null, token);
};

export const simGetHistory = async (token: string) => {
  const config = await getConfig();
  return _fetch_get<{ history: any[] }>(`${config.apiBaseUrl}/${simHistoryRoute}`, null, token);
};

// ─── Images Docker ───────────────────────────────────────────────────────────

export const simListImages = async (token: string) => {
  const config = await getConfig();
  return _fetch_get<{ images: DockerImageInfo[] }>(`${config.apiBaseUrl}/${simImagesListRoute}`, null, token);
};

// ─── Clonage & Services ──────────────────────────────────────────────────────

export const simStartClone = async (data: CloneRequest, token: string) => {
  const config = await getConfig();
  return _fetch_post<{ clone_id: string; status: string; message: string }>(`${config.apiBaseUrl}/${simCloneStartRoute}`, data, token);
};

export const simGetCloneStatus = async (cloneId: string, token: string) => {
  const config = await getConfig();
  return _fetch_get<CloneStatusResponse>(`${config.apiBaseUrl}/${simCloneStatusRoute}/${encodeURIComponent(cloneId)}/status`, null, token);
};

export const simStopClone = async (cloneId: string, token: string) => {
  const config = await getConfig();
  return _fetch_post<{ clone_id: string; status: string }>(`${config.apiBaseUrl}/${simCloneStopRoute}/${encodeURIComponent(cloneId)}/stop`, {}, token);
};

export const simCaptureServices = async (token: string) => {
  const config = await getConfig();
  return _fetch_get<{ services: Record<string, any> }>(`${config.apiBaseUrl}/${simServicesCaptureRoute}`, null, token);
};

export const simValidateServices = async (services: Record<string, any>, token: string) => {
  const config = await getConfig();
  return _fetch_post<ValidateServicesResponse>(`${config.apiBaseUrl}/${simServicesValidateRoute}`, { services }, token);
};

// ─── Conteneurs ──────────────────────────────────────────────────────────────

export const simListContainers = async (token: string, running?: boolean) => {
  const config = await getConfig();
  const query = running !== undefined ? `running=${running}` : "";
  return _fetch_get<{ total: number; containers: ContainerInfo[] }>(`${config.apiBaseUrl}/${simContainersListRoute}`, query, token);
};

export const simCreateContainer = async (data: ContainerCreateRequest, token: string) => {
  const config = await getConfig();
  return _fetch_post<{ success: boolean; container: any; message: string }>(`${config.apiBaseUrl}/${simContainersCreateRoute}`, data, token);
};

export const simStopContainer = async (name: string, token: string) => {
  const config = await getConfig();
  return _fetch_post<{ success: boolean; container: string; message: string }>(`${config.apiBaseUrl}/${simContainersStopRoute}/${encodeURIComponent(name)}/stop`, {}, token);
};

export const simExecContainer = async (name: string, data: ContainerExecRequest, token: string) => {
  const config = await getConfig();
  return _fetch_post<ContainerExecResponse>(`${config.apiBaseUrl}/${simContainersExecRoute}/${encodeURIComponent(name)}/exec`, data, token);
};

// ─── Réseaux Docker ──────────────────────────────────────────────────────────

export const simListNetworks = async (token: string, onlySimatk = false) => {
  const config = await getConfig();
  const query = onlySimatk ? "only_simatk=true" : "";
  return _fetch_get<{ total: number; networks: NetworkInfo[] }>(`${config.apiBaseUrl}/${simNetworkListRoute}`, query, token);
};

export const simCreateNetwork = async (data: NetworkCreateRequest, token: string) => {
  const config = await getConfig();
  return _fetch_post<{ success: boolean; network: any; message: string; error?: string }>(`${config.apiBaseUrl}/${simNetworkCreateRoute}`, data, token);
};

export const simRemoveNetwork = async (name: string, force = false, token: string) => {
  const config = await getConfig();
  const query = force ? "force=true" : "";
  return _fetch_post<{ success: boolean; network: string; message: string }>(`${config.apiBaseUrl}/${simNetworkRemoveRoute}/${encodeURIComponent(name)}/remove?${query}`, {}, token);
};

export const simConnectNetwork = async (name: string, data: NetworkConnectRequest, token: string) => {
  const config = await getConfig();
  return _fetch_post<{ success: boolean; container: string; network: string; ip?: string }>(`${config.apiBaseUrl}/${simNetworkConnectRoute}/${encodeURIComponent(name)}/connect`, data, token);
};

export const simDisconnectNetwork = async (name: string, containerName: string, force = false, token: string) => {
  const config = await getConfig();
  return _fetch_post<{ success: boolean; message: string }>(`${config.apiBaseUrl}/${simNetworkDisconnectRoute}/${encodeURIComponent(name)}/disconnect`, { container_name: containerName, force }, token);
};

export const simMoveNetwork = async (data: NetworkMoveRequest, token: string) => {
  const config = await getConfig();
  return _fetch_post<{ success: boolean; message: string; ip?: string }>(`${config.apiBaseUrl}/${simNetworkMoveRoute}`, data, token);
};

// ============================================================================
// 1. Routes Central (Core API — config.apiBaseUrl)
// ============================================================================

export const idsListEndpoints = async (token: string) => {
  const config = await getConfig();
  return _fetch_get<NetworkEndpointsMap>(
    `${config.apiBaseUrl}/${idsListEndpointsRoute}`, 
    null, 
    token
  );
};

export const idsCreateNetworkAsset = async (data: any, token: string) => {
  const config = await getConfig();
  return _fetch_post<any>(
    `${config.apiBaseUrl}/${idsCreateNetworkAssetRoute}`, 
    data, 
    token
  );
};

// ============================================================================
// 2. Routes directes Sonde IDS/IPS (probeUrl = "http://host:port/api")
// ============================================================================

export const idsStart = async (probeUrl: string, token: string) => {
  return _fetch_get<IdsActionResponse>(`${probeUrl}/${idsStartRoute}`, null, token);
};

export const idsStop = async (probeUrl: string, token: string) => {
  return _fetch_get<IdsActionResponse>(`${probeUrl}/${idsStopRoute}`, null, token);
};

export const idsGetHealth = async (probeUrl: string, token: string) => {
  return _fetch_get<IdsHealthResponse>(`${probeUrl}/${idsHealthRoute}`, null, token);
};

export const idsGetMode = async (probeUrl: string, token: string) => {
  return _fetch_get<{ mode: IdsMode }>(`${probeUrl}/${idsGetModeRoute}`, null, token);
};

export const idsChangeMode = async (probeUrl: string, data: ChangeModeRequest & { username: string; password?: string; token: string }, token: string) => {
  return _fetch_post<{ success: boolean }>(`${probeUrl}/${idsChangeModeRoute}`, data, token);
};

export const idsGetAlerts = async (probeUrl: string, n = 10, token: string) => {
  const query = `n=${encodeURIComponent(n)}`;
  return _fetch_get<LastAlertsResponse>(`${probeUrl}/${idsAlertsRoute}`, query, token);
};

export const idsGetGraphPort = async (probeUrl: string, token: string) => {
  return _fetch_get<IdsGraphPortResponse>(`${probeUrl}/${idsGetPortRoute}`, null, token);
};

export const idsGetBlockedIps = async (probeUrl: string, data: { username: string; token: string }, token: string) => {
  return _fetch_post<{ blocked: BlockedIpsResponseMap; message: string }>(`${probeUrl}/${idsBlockedRoute}`, data, token);
};

export const idsBlockIp = async (probeUrl: string, data: BlockIpRequest & { username: string; password?: string; token: string }, token: string) => {
  return _fetch_post<IdsActionResponse>(`${probeUrl}/${idsBlockIpRoute}`, data, token);
};

export const idsUnlockIp = async (probeUrl: string, data: UnlockIpRequest & { username: string; password?: string; token: string }, token: string) => {
  return _fetch_post<IdsActionResponse>(`${probeUrl}/${idsUnlockRoute}`, data, token);
};

export const idsManageWhitelist = async (probeUrl: string, data: ManageWhitelistRequest & { username: string; password?: string; token: string }, token: string) => {
  return _fetch_post<IdsActionResponse>(`${probeUrl}/${idsManageWhitelistRoute}`, data, token);
};

export const idsManageIgnoredIp = async (probeUrl: string, data: ManageIgnoredIpRequest & { username: string; password?: string; token: string }, token: string) => {
  return _fetch_post<IdsActionResponse>(`${probeUrl}/${idsManageIgnoredIpRoute}`, data, token);
};

export const idsGetGeoLocation = async (probeUrl: string, ip: string, token: string) => {
  const query = `ip=${encodeURIComponent(ip)}`;
  return _fetch_get<IdsGeoLocationResponse>(`${probeUrl}/${idsGeoLocationRoute}`, query, token);
};

export const idsGetConfig = async (probeUrl: string, data: { username: string; token: string }, token: string) => {
  return _fetch_post<{ "ids/ips_config": any; api_config: any; host: string; port: number }>(`${probeUrl}/${idsConfigRoute}`, data, token);
};

export const idsUpdateConfig = async (probeUrl: string, data: UpdateConfigCategoryRequest & { username: string; password?: string; token: string }, token: string) => {
  return _fetch_post<IdsActionResponse>(`${probeUrl}/${idsUpdateConfigRoute}`, data, token);
};

export const idsGetDefaultConfig = async (probeUrl: string, token: string) => {
  return _fetch_get<IdsFullConfig>(`${probeUrl}/${idsDefaultConfigRoute}`, null, token);
};

export const idsGetHelp = async (probeUrl: string, token: string) => {
  return _fetch_get<any>(`${probeUrl}/${idsHelpRoute}`, null, token);
};