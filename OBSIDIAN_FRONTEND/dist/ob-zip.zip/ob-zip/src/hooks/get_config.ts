export interface AppConfig {
    productName: string;
    apiBaseUrl: string;
    wsUrl: string;
    themes: string[];
    defaultTheme: string;
    defaultLanguage: string;
    redirectDelayAfterLogin: number;
    demoMode: boolean;
}

type cachedConfigType = AppConfig | null;
let cachedConfig: cachedConfigType = null;

async function getConfig(force: boolean = true): Promise<AppConfig> {
    if (!force && cachedConfig !== null) return cachedConfig;
    const data = await fetch("/config.json");
    const json: AppConfig = await data.json();
    cachedConfig = json;
    return cachedConfig;
}

export {getConfig};