export const loginRoute = "auth_routes/auth/login";
export const refreshTokenRoute = "auth_routes/token/refresh";

export const createWebAssetRoute = "core/asset/create/web_asset";
export const createNetWorkAssetRoute = "core/asset/create/network_asset";
export const listAssetRoute = "core/assets/list";
export const getAssetRoute = "core/assets/get_asset";
export const deleteAssetRoute = "core/assets/manage/delete";
export const pauseAssetRoute = "core/assets/manage/pause";
export const resumeAssetRoute = "core/assets/manage/resume";
export const updateAssetRoute = "core/assets/manage/update";
export const searchAssetRoute = "core/assets/search";
export const pauseAllAssetsRoute = "core/assets/pause";
export const resumeAllAssetsRoute = "core/assets/resume";
// ─── Server Assets (Agent) ───────────────────────────────────────────────────
export const createServerAssetRoute      = "core/asset/create/server_asset";
export const revokeServerAssetRoute      = "core/assets/server_asset/revoke";
export const rotateServerSecretRoute     = "core/assets/server_asset/rotate-secret";
export const reactivateServerAssetRoute  = "core/assets/server_asset/reactivate";

export const addServerCapabilitiesRoute    = "core/assets/server_asset/capabilities/add";
export const removeServerCapabilitiesRoute = "core/assets/server_asset/capabilities/remove";
export const listServerCapabilitiesRoute   = "core/assets/server_asset/capabilities/list";

export const allowServerToolsRoute         = "core/assets/server_asset/tools/allow";
export const revokeServerToolsRoute        = "core/assets/server_asset/tools/revoke";
export const listServerToolsRoute          = "core/assets/server_asset/tools/list";


export const scannerDefaultConfigRoute = "scanner/default_config";
export const idsIpsDefaultConfigRoute = "ids_ips/default_config";


export const listJobsRoute = "managers/jobs/list";
export const getJobRoute = "managers/jobs/get";
export const getJobStateRoute = "managers/jobs/state";
export const jobCatalogRoute = "managers/jobs/catalog";
export const createJobRoute = "managers/jobs/create";
export const modifyJobRoute = "managers/jobs/modify";
export const pauseJobRoute = "managers/jobs/pause";
export const resumeJobRoute = "managers/jobs/resume";
export const removeJobRoute = "managers/jobs/remove";
export const removeAllJobsRoute = "managers/jobs/remove_all";
export const pauseAllJobsRoute = "managers/jobs/pause_all";
export const resumeAllJobsRoute = "managers/jobs/resume_all";


export const listScannerHelpersRoute = "scanner/helpers"
export const listScannerSupportedVulnsRoute = "scanner/supported_vulns"
export const validateScannerKnowParamDirRoute = "scanner/validate_know_param_dir"
export const checkPathExitsRoute = "utils/path_exists"

export const getReportRoute = "managers/reports/get";
export const getLatestReportRoute = "managers/reports/get_latest";
export const getFirstestReportRoute = "managers/reports/get_firstest";
export const listReportsByFilterRoute = "managers/reports/list_by_filter";
export const listCriticalReportsRoute = "managers/reports/list_critical";
export const getReportStatsRoute = "managers/reports/stats";
export const updateReportSeverityRoute = "managers/reports/update_severity";
export const deleteReportRoute = "managers/reports/delete";
export const deleteOldReportsRoute = "managers/reports/delete_older_than";

// ============================================================================
// ConversationManager — routes
// ============================================================================

export const createConversationRoute = "managers/conversations/create";
export const listConversationsRoute = "managers/conversations/list";
export const getConversationRoute = "managers/conversations/get";
export const deleteConversationRoute = "managers/conversations/delete";
export const updateConversationTitleRoute = "managers/conversations/update_title";
export const setFavoriteRoute = "managers/conversations/set_favorite";
export const setArchivedRoute = "managers/conversations/set_archived";
export const searchConversationsRoute = "managers/conversations/search";
export const getMessagesRoute = "managers/conversations/messages";
export const getLastMessageRoute = "managers/conversations/last_message";
export const updateMessageContentRoute = "managers/conversations/update_message";
export const deleteMessageRoute = "managers/conversations/delete_message";

// Anti phishing

export const apAnalyzeUrlRoute = "anti_phishing/analyze";
export const apAnalyzeMailRoute = "anti_phishing/analyze_mail";
export const apHistoryUrlsRoute = "anti_phishing/history";
export const apHistoryMailsRoute = "anti_phishing/history_mail";
export const apHealthRoute = "anti_phishing/health";
export const apGetSettingsRoute = "anti_phishing/get_settings";
export const apSetSettingsRoute = "anti_phishing/settings";

// Sandbox

export const sbAnalyzeCodeRoute = "sandbox/analyse_code";
export const sbEstimateRiskRoute = "sandbox/estimate_risk";
export const sbLanguagesRoute = "sandbox/languages";
export const sbConfigRoute = "sandbox/config";
export const sbContainersStatusRoute = "sandbox/status/containers";
export const sbHealthRoute = "sandbox/status/health";


// Scanner Web Suite

export const scStartScanRoute = "scanner/start_scan";
export const scCancelScanRoute = "scanner/cancel_scan";
export const scStatusRoute = "scanner/status";
export const scWsScanStatusRoute = "scanner/ws_scan_status";
export const scSupportedVulnsRoute = "scanner/supported_vulns";
export const scValidateParamsDirRoute = "scanner/validate_know_param_dir";
export const scReportsRoute = "scanner/reports"; // Usage: `${scReportsRoute}/${scan_id}`
export const scReportDirRoute = "scanner_reports"


// Simulateur d'Attaque IA — Routes API & WebSocket (Préfixe : simulator/)

// Simulations (Cycle de vie & Tâches)
export const simStartRoute        = "simulator/sim/start";
export const simStopRoute         = "simulator/sim";               // Usage: `${simStopRoute}/${session_id}/stop`
export const simStatusRoute       = "simulator/sim";               // Usage: `${simStatusRoute}/${session_id}/status`
export const simListRoute         = "simulator/sim/list";
export const simReportRoute       = "simulator/sim";               // Usage: `${simReportRoute}/${session_id}/report`
export const simActionsRoute      = "simulator/sim";               // Usage: `${simActionsRoute}/${session_id}/actions`
export const simHistoryRoute      = "simulator/sim/history";       // Usage: `${simHistoryRoute}` ou `${simHistoryRoute}/${sim_id}`

// WebSocket
export const simWsRoute           = "simulator/ws";                // Usage: `${simWsRoute}/${session_id}`

// Images Docker locales
export const simImagesListRoute   = "simulator/images/list";

// Clonage de système
export const simCloneStartRoute   = "simulator/clone/start";
export const simCloneStatusRoute  = "simulator/clone";             // Usage: `${simCloneStatusRoute}/${clone_id}/status`
export const simCloneStopRoute    = "simulator/clone";             // Usage: `${simCloneStopRoute}/${clone_id}/stop`

// Services Host & Validation
export const simServicesCaptureRoute  = "simulator/services/capture";
export const simServicesValidateRoute = "simulator/services/validate";

// Gestion des Conteneurs Docker
export const simContainersListRoute     = "simulator/containers/list";
export const simContainersListOwnRoute  = "simulator/containers/list_my_own";
export const simContainersCreateRoute   = "simulator/containers/create";
export const simContainersStopRoute     = "simulator/containers";  // Usage: `${simContainersStopRoute}/${name}/stop`
export const simContainersExecRoute     = "simulator/containers";  // Usage: `${simContainersExecRoute}/${name}/exec`
export const simContainersCacheRoute    = "simulator/containers/cache";

// Gestion des Réseaux Docker (Lab)
export const simNetworkListRoute        = "simulator/network/list";
export const simNetworkCreateRoute      = "simulator/network/create";
export const simNetworkContainersRoute  = "simulator/network";     // Usage: `${simNetworkContainersRoute}/${name}/containers`
export const simNetworkRemoveRoute      = "simulator/network";     // Usage: `${simNetworkRemoveRoute}/${name}/remove`
export const simNetworkRemoveAllRoute   = "simulator/network/remove_all";
export const simNetworkConnectRoute     = "simulator/network";     // Usage: `${simNetworkConnectRoute}/${name}/connect`
export const simNetworkDisconnectRoute  = "simulator/network";     // Usage: `${simNetworkDisconnectRoute}/${name}/disconnect`
export const simNetworkMoveRoute        = "simulator/network/move";

// ============================================================================
// IDS / IPS & Sondes Réseau — Routes API (Préfixes : core/ et sonde IDS directe)
// ============================================================================

// ─── 1. Découverte & Gestion des Sondes (Core API) ───────────────────────────
export const idsListEndpointsRoute    = "core/assets/list_network_endpoints"; // Découverte dynamique de tous les IDS actifs (host, port, is_open)
export const idsCreateNetworkAssetRoute = "core/asset/create/network_asset";  // Création d'un nouvel asset réseau (gateway, span, bridge)

// ─── 2. Contrôle & Cycle de vie de l'IDS/IPS (Direct Sonde) ──────────────────
export const idsStartRoute            = "start";               // Démarrage du moteur de capture & détection
export const idsStopRoute             = "stop";                // Arrêt propre du moteur et libération des interfaces
export const idsHealthRoute           = "health";              // État de santé (detector_ready, graph_port, timestamp)
export const idsGetModeRoute          = "get_mode";            // Récupération du mode actif ("ids" ou "ips")
export const idsChangeModeRoute       = "change_mode";         // Bascule à chaud du mode ("ids" <-> "ips")

// ─── 3. Alertes & Flux en Direct ─────────────────────────────────────────────
export const idsAlertsRoute           = "alerts";              // Dernières alertes Suricata/ML (Usage: `${idsAlertsRoute}?n=20`)
export const idsGetPortRoute          = "get_port";            // Port du serveur Bokeh interactif pour les graphiques temps réel

// ─── 4. Blocages, Filtrage & NFTables ────────────────────────────────────────
export const idsBlockedRoute          = "blocked";             // Liste de toutes les IPs avec scores (0-300) et état NFTables
export const idsBlockIpRoute          = "block_ip";            // Blocage manuel (drop, rate_limit, rate_limit_data)
export const idsUnlockRoute           = "unlock";              // Déblocage d'une IP et réinitialisation de son score
export const idsManageWhitelistRoute  = "manage_whitelist";    // Ajout/Retrait d'une IP ou CIDR de la whitelist NFTables
export const idsManageIgnoredIpRoute  = "manage_ignored_ip";   // Ignorer une IP en capture (src ou dst)
export const idsGeoLocationRoute      = "geo_location";        // Géolocalisation rapide d'une IP (Usage: `${idsGeoLocationRoute}?ip=x.x.x.x`)

// ─── 5. Configuration & Métadonnées ──────────────────────────────────────────
export const idsConfigRoute           = "config";              // Lecture de la configuration active complète
export const idsUpdateConfigRoute     = "update_config";       // Mise à jour d'une catégorie (SEUIL, SCORING_CONFIG, etc.)
export const idsDefaultConfigRoute    = "default_config";      // Configuration JSON par défaut pour l'éditeur
export const idsHelpRoute             = "help";                // Documentation intégrée de l'API IDS