#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jun  7 18:09:24 2026

@author: hounsousamuel
"""

import hashlib
import os

def save(data: bytes, path: str):
    data = data if isinstance(data, bytes) else data.encode()
    checksum = hashlib.sha256(data).hexdigest()
    dirname = os.path.dirname(path)
    sha_name = f".sha256_{os.path.basename(path)}"
    checksum_path = os.path.join(dirname, sha_name)
    with open(checksum_path, "w") as f:
        f.write(checksum)
    
    with open(path, "wb") as f:
        f.write(data)
    
    return checksum

def load(path: str):
    try:
        dirname = os.path.dirname(path)
        sha_name = f".sha256_{os.path.basename(path)}"
        checksum_path = os.path.join(dirname, sha_name)
        with open(checksum_path) as f:
            expected = f.read().strip()
        
        with open(path, "rb") as f:
            data = f.read()
        
        checksum = hashlib.sha256(data).hexdigest()
        if expected != checksum:
            raise RuntimeError("Fichier invalide !")
        
        return data
    
    except RuntimeError:
        raise
        
    except Exception as e:
        raise RuntimeError(str(e))
        
    
    