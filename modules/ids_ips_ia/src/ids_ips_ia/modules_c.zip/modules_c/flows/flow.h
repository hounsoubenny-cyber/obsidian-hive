#ifndef FLOW_H
#define FLOW_H
#include "../parser/parser.h"
#include "../dict/dict.h"
#include "../utils/utils.h"
#include <stdint.h>
#include <stdint.h>

enum FlowKeyType{
    FlowKeyIpv4Type,
    FlowKeyIpv6Type,
};

enum FlowVerdict{
    UNKNOW = 0,
    BLOCK = 1,
    LIMIT_REACHED = 2,
};

typedef enum FlowVerdict FlowVerdict;
typedef enum FlowKeyType FlowKeyType;

struct FlowKeyIpv4{
    FlowKeyType key;
    uint8_t ip_min[L_IPV4];
    uint8_t ip_max[L_IPV4];
    uint8_t port_min[L_PORT];
    uint8_t port_max[L_PORT];
    uint8_t proto;
};

struct FlowKeyIpv6{
    FlowKeyType key;
    uint8_t ip_min[L_IPV6];
    uint8_t ip_max[L_IPV6];
    uint8_t port_min[L_PORT];
    uint8_t port_max[L_PORT];
    uint8_t proto;
};

struct Ipv4EntryData{
    uint8_t initiator_ip[L_IPV4];
    uint8_t initiator_port[L_PORT];
    uint8_t receiver_ip[L_IPV4];
    uint8_t receiver_port[L_PORT];
};

struct Ipv6EntryData{
    uint8_t initiator_ip[L_IPV6];
    uint8_t initiator_port[L_PORT];
    uint8_t receiver_ip[L_IPV6];
    uint8_t receiver_port[L_PORT];
};

struct _FlagSeens{
    uint32_t rst;
    uint32_t syn;
    uint32_t ack;
    uint32_t fin;
    uint32_t urg;
    uint32_t cwr;
    uint32_t ece;
    uint32_t psh;
};

// ltr = left to rigth; rtl = rigth to left
struct FlowData{
    uint8_t v4;
    union{
        struct Ipv4EntryData ipv4_headers;
        struct Ipv6EntryData ipv6_headers;
    } header;
    uint64_t start_time;
    uint64_t end_time;
    struct _FlagSeens flag_count;
    uint32_t n_pkt_ltr;
    uint32_t n_pkt_rtl;
    uint32_t octets_data_ltr;
    uint32_t octets_data_rtl;
    uint8_t proto;
    FlowVerdict verdict;
};
typedef struct FlowData FlowData;

struct FlowEntry{
    void *key;
    FlowData* data;
    /* liens pour la liste LRU */
    struct FlowEntry *lru_prev;
    struct FlowEntry *lru_next;
    uint32_t dcl_pos;
};
typedef struct FlowEntry FlowEntry;
typedef struct FlowKeyIpv4 FlowKeyIpv4;
typedef struct FlowKeyIpv6 FlowKeyIpv6;

int build_flow_key(void *key, uint8_t *src_ip, uint8_t *dst_ip, uint8_t *src_port, uint8_t *dst_port, uint8_t proto, int v4);
int build_flow_entry(void *entry, ParserResult *pr, void *key, int v4);
int entry_update(FlowEntry *entry, ParserResult *pr);
int flow_hash(const void *key);
int flow_key_compare(const void *key1, const void *key2);
void *flow_key_dup(const void *key);
void  flow_key_free(void *key);
void *flow_value_dup(const void *value);
void  flow_value_free(void *value);
Dict* create_ft_dict(uint32_t size);

#endif
