#include "flow_table.h"
#include "flow.h"
#include "../utils/utils.h"
#include <stdlib.h>
#include <string.h>

static void *port_key_dup(const void *key){
    struct PortPerIpKey *copy = malloc(sizeof(struct PortPerIpKey));
    if (copy) *copy = *(const struct PortPerIpKey *)key;
    return copy;
}

static void port_key_free(void *key){
    free(key);
}

static int port_key_compare(const void *a, const void *b){
    return memcmp(a, b, sizeof(struct PortPerIpKey));
}

static int port_key_hash(const void *key){
    const struct PortPerIpKey *k = (const struct PortPerIpKey *)key;
    uint32_t h = 2166136261u;
    h = fnv1a_update(h, k -> ip,  k -> v4 == 0 ? L_IPV4 : L_IPV6);
    h ^= k->v4; h *= 16777619u;
    h = fmix32(h);
    return (int)(h & 0x7FFFFFFF);
}


static void _flow_entry_get_ip_key(const FlowEntry *e, struct PortPerIpKey *out){
    if (e == NULL || e->data == NULL) return;
    memset(out, 0, sizeof(*out));
    if (e->data->v4 == 0){
        out->v4 = 0;
        memcpy(out->ip, e->data->header.ipv4_headers.initiator_ip, L_IPV4);
    } else {
        out->v4 = 1;
        memcpy(out->ip, e->data->header.ipv6_headers.initiator_ip, L_IPV6);
    }
}

int ft_port_per_ip_visit(FlowTable *ft, ParserResult *pr){
    if (ft == NULL || pr == NULL) return -1;
    if (pr -> code != (uint8_t)SUCCES) return -1;

    struct PortPerIpKey key;
    memset(&key, 0, sizeof(key));

    uint16_t port = 0;

    if (pr -> type == IPV4){
        key.v4 = 0;
        memcpy(key.ip, pr -> ip_data.ipv4.src_ip, L_IPV4);

        if (pr -> ip_data.ipv4.proto == (uint8_t)TCP){
            port = port_to_u16(pr -> data.tcp.dst_port);
        } else if (pr -> ip_data.ipv4.proto == (uint8_t)UDP){
            port = port_to_u16(pr -> data.udp.dst_port);
        } else {
            return 0;   /* ICMP et autres : pas de port */
        }
    } else if (pr -> type == IPV6){
        key.v4 = 1;
        memcpy(key.ip, pr -> ip_data.ipv6.src_ip, L_IPV6);

        if (pr -> ip_data.ipv6.next_header == (uint8_t)TCP){
            port = port_to_u16(pr -> data.tcp.dst_port);
        } else if (pr -> ip_data.ipv6.next_header == (uint8_t)UDP){
            port = port_to_u16(pr -> data.udp.dst_port);
        } else {
            return 0;
        }
    } else {
        return 0;   /* ni v4 ni v6 */
    }

    struct PortMap *pm = (struct PortMap *)dict_getitem(ft -> port_per_ip, &key);
    if (pm == NULL){
        pm = (struct PortMap *)calloc(1, sizeof(struct PortMap));
        if (pm == NULL) return -1;
        portmap_init(pm);
        dict_setitem(ft -> port_per_ip, &key, pm);
    }

    portmap_add(pm, port);
    return 0;
}

/* appelée à la création d'un flux */
static int _port_per_ip_add(FlowTable *ft, const struct PortPerIpKey *key){
    struct PortMap *pme = dict_getitem(ft->port_per_ip, key);
    if (pme == NULL){
        pme = calloc(1, sizeof(struct PortMap));
        if (pme == NULL) return -1;
        portmap_init(pme);
        pme->refcount = 0;
        dict_setitem(ft->port_per_ip, key, pme);
    }
    pme->refcount++;
    return 0;
}

/* appelée à l'éviction d'un flux */
static void _port_per_ip_release(FlowTable *ft, const struct PortPerIpKey *key){
    struct PortMap *pme = dict_getitem(ft->port_per_ip, key);
    if (pme == NULL) return;
    if (pme->refcount > 0) pme->refcount--;
    if (pme->refcount == 0){
        dict_delitem(ft->port_per_ip, key);
    }
}

FlowTable *ft_create(uint32_t size){
    if (size <= 0) return NULL;
    Dict *flow_dict = create_ft_dict(size);
    if (flow_dict == NULL) {
        return NULL;
    }
    Dict *port_per_ip = create_dict(
        size, port_key_hash, port_key_compare, port_key_dup,  
        port_key_free, NULL, free
    );
    //Dict *port_per_ip = create_dict_int((uint32_t)(size / 4));
    if (port_per_ip == NULL) {
        free(flow_dict);
        return NULL;
    }
    DChainedList *flow_dcl = create_dcl(size);
    if (flow_dcl == NULL) {
        free(flow_dict); free(port_per_ip);
        return NULL;
    }
    FlowTable *ft = calloc(1, sizeof(FlowTable));
    if (ft == NULL){
        free(flow_dict); free(port_per_ip); free(flow_dcl);
        return NULL;
    }
    ft -> flow_dcl = flow_dcl; ft -> flow_dict = flow_dict;
    ft -> port_per_ip = port_per_ip; ft -> size = size;
    ft -> nbr_elements = 0; ft -> n_evicted = 0;
    return ft;
}

static void _ft_evict(FlowTable *ft, FlowEntry *entry){
    if (ft == NULL || entry == NULL) return;
    if (ft -> flow_dcl == NULL || ft -> flow_dict == NULL) return;

    struct PortPerIpKey ip_key;
    _flow_entry_get_ip_key(entry, &ip_key);
    _port_per_ip_release(ft, &ip_key);
    dict_delitem(ft -> flow_dict, entry -> key);
    if (entry -> data != NULL) free(entry -> data);
    if (entry -> key != NULL) flow_key_free(entry -> key);
    ft -> n_evicted += 1;
    ft -> nbr_elements -= 1;
    int entry_is_top = entry == ft -> flow_dcl -> head;
    delete_from_top(ft -> flow_dcl);
    if (entry_is_top == 0) flow_value_free(entry);
    return;
}

static int _is_v4(const void *key){
    FlowKeyType *fk = (FlowKeyType *)key;
    return *fk == FlowKeyIpv4Type ? 0 : 1;
}

void ft_destroy(FlowTable *ptr){
    if (ptr == NULL) return;
    while (ptr -> nbr_elements > 0) {
        ft_evict_oldest(ptr);
    }
    if (ptr -> flow_dict != NULL) dict_clear(ptr -> flow_dict);
    if (ptr -> flow_dcl != NULL) free(ptr -> flow_dcl);
    if (ptr -> port_per_ip != NULL) dict_clear(ptr -> port_per_ip);
    free(ptr);
    return;
}

void ft_evict_oldest(FlowTable *ft){
    if (ft == NULL) return;
    if (ft -> flow_dcl == NULL || ft -> flow_dict == NULL) return;
    FlowEntry *oldest = ft -> flow_dcl -> head;
    return _ft_evict(ft, oldest);
}

FlowEntry *ft_get(FlowTable *ft, const void *key){
    if (ft == NULL || key == NULL) return NULL;
    return (FlowEntry *)dict_getitem(ft -> flow_dict, key);
}

int ft_contains(FlowTable *ft, const void *key){
    if (ft == NULL) return -1;
    return ft_get(ft, key) == NULL ?  -1 : 0;
}

int ft_can_add(FlowTable *ft){
    if (ft == NULL) return -1;
    return (ft -> size < (ft -> nbr_elements + 1)) == 1 ? -1 : 0;
}

int ft_add(FlowTable *ft, const void *key, const FlowEntry *entry){
    if (ft == NULL || key == NULL || entry == NULL) return -1;

    while (ft_can_add(ft) == -1){
        ft_evict_oldest(ft);
    }
    if (ft_contains(ft, key) != 0){
        int r1 = dict_setitem(ft -> flow_dict, key, (FlowEntry *)entry);
        int r2 = add_to_end(ft -> flow_dcl, (FlowEntry *)entry, 0);
        ft -> nbr_elements += 1;
        return (r1 == 0 && r2 == 0) == 1 ? 0 : -1;
    }
    // déja présent
    int r1 = move_to_end(ft -> flow_dcl, (FlowEntry *)entry);
    int r2 = dict_setitem(ft -> flow_dict, key, (FlowEntry *)entry);
    return (r1 == 0 && r2 == 0) == 1 ? 0 : -1;
}

int ft_process(FlowTable *ft, ParserResult *pr){
    if (ft == NULL || pr == NULL) return -1;
    if (pr->code != (uint8_t)SUCCES) return -1;

    /* 1. Version IP (convention de flow.c : 0 = IPv4, 1 = IPv6) */
    int v4;
    if (pr->type == IPV4)      v4 = 0;
    else if (pr->type == IPV6) v4 = 1;
    else return -1;

    uint8_t *src_ip, *dst_ip, proto;
    if (v4 == 0){
        src_ip = pr->ip_data.ipv4.src_ip;
        dst_ip = pr->ip_data.ipv4.dst_ip;
        proto  = pr->ip_data.ipv4.proto;
    } else {
        src_ip = pr->ip_data.ipv6.src_ip;
        dst_ip = pr->ip_data.ipv6.dst_ip;
        proto  = pr->ip_data.ipv6.next_header;
    }

    /* 2. Ports (à 0 pour ICMP et les autres protocoles) */
    uint8_t zero_port[L_PORT] = {0, 0};
    uint8_t *src_port = zero_port, *dst_port = zero_port;
    if (proto == (uint8_t)TCP){
        src_port = pr->data.tcp.src_port;
        dst_port = pr->data.tcp.dst_port;
    } else if (proto == (uint8_t)UDP){
        src_port = pr->data.udp.src_port;
        dst_port = pr->data.udp.dst_port;
    }

    /* 3. Construire la clé : une boîte assez grande pour une clé v4 OU v6 */
    union { FlowKeyIpv4 k4; FlowKeyIpv6 k6; } key;
    memset(&key, 0, sizeof key);
    if (build_flow_key(&key, src_ip, dst_ip, src_port, dst_port, proto, v4) != 0)
        return -1;

    /* 4. Existe déjà ? */
    FlowEntry *existing = ft_get(ft, &key);
    if (existing != NULL){
        if (entry_update(existing, pr) != 0) return -1;
        move_to_end(ft->flow_dcl, existing);
        return 0;
    }

    /* 5. Nouveau flux */
    FlowEntry *new_entry = (FlowEntry *)calloc(1, sizeof(FlowEntry));
    if (new_entry == NULL) return -1;

    union { FlowKeyIpv4 *k4; FlowKeyIpv6 *k6; } key_copy;
    if (v4 == 0){
        FlowKeyIpv4 *key_copy_ = flow_key_dup(&key);
        if (key_copy_ == NULL){ free(new_entry); return -1; }
        key_copy.k4 = key_copy_;
    }else {
        FlowKeyIpv6 *key_copy_ = flow_key_dup(&key);
        if (key_copy_ == NULL){ free(new_entry); return -1; }
        key_copy.k6 = key_copy_;
    }

    int br;
    if (v4 == 0){
        br = build_flow_entry(new_entry, pr, key_copy.k4, v4);
    }else{
        br = build_flow_entry(new_entry, pr, key_copy.k6, v4);
    }
    if (br != 0){
        if (v4 == 0) flow_key_free(key_copy.k4);
        else flow_key_free(key_copy.k6);
        free(new_entry);
        return -1;
    }

    /* ft_add gère l'éviction, l'insertion dans le dict et la DCL */
    int ftar;
    if (v4 == 0){
        ftar = ft_add(ft, key_copy.k4, new_entry);
    }else{
        ftar = ft_add(ft, key_copy.k6, new_entry);
    }
    if (ftar != 0){
        free(new_entry->data);
        if (v4 == 0) flow_key_free(key_copy.k4);
        else flow_key_free(key_copy.k6);
        free(new_entry);
        return -1;
    }

    /* seulement après le succès : le compteur d'IP et le port visité */
    struct PortPerIpKey ip_key;
    _flow_entry_get_ip_key(new_entry, &ip_key);
    _port_per_ip_add(ft, &ip_key);
    ft_port_per_ip_visit(ft, pr);
    return 0;
}