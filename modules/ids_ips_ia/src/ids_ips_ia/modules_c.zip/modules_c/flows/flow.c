#include "flow.h"
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include <stdio.h>
#include "flow.h"

void FlowKey_print(const void *k){
    if (k == NULL){
        printf("FlowKeyType: NULL\n");
        return;
    }

    /* Le premier champ de chaque struct est l'enum "key".
     * On lit son int pour savoir quoi caster. */
    FlowKeyType tag = *(const FlowKeyType *)k;

    if (tag == FlowKeyIpv4Type){
        const FlowKeyIpv4 *v4 = (const FlowKeyIpv4 *)k;
        printf("FlowKeyType{ipv4, proto=%u,\n", v4->proto);
        printf("  ip_min  = %u.%u.%u.%u\n",
               v4->ip_min[0], v4->ip_min[1], v4->ip_min[2], v4->ip_min[3]);
        printf("  ip_max  = %u.%u.%u.%u\n",
               v4->ip_max[0], v4->ip_max[1], v4->ip_max[2], v4->ip_max[3]);
        printf("  port_min = %u, port_max = %u}\n",
               ((uint16_t)v4->port_min[0] << 8) | v4->port_min[1],
               ((uint16_t)v4->port_max[0] << 8) | v4->port_max[1]);
    }
    else if (tag == FlowKeyIpv6Type){
        const FlowKeyIpv6 *v6 = (const FlowKeyIpv6 *)k;
        printf("FlowKeyType{ipv6, proto=%u,\n", v6->proto);
        printf("  ip_min  = %02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x\n",
               v6->ip_min[0], v6->ip_min[1], v6->ip_min[2],  v6->ip_min[3],
               v6->ip_min[4], v6->ip_min[5], v6->ip_min[6],  v6->ip_min[7],
               v6->ip_min[8], v6->ip_min[9], v6->ip_min[10], v6->ip_min[11],
               v6->ip_min[12], v6->ip_min[13], v6->ip_min[14], v6->ip_min[15]);
        printf("  ip_max  = %02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x\n",
               v6->ip_max[0], v6->ip_max[1], v6->ip_max[2],  v6->ip_max[3],
               v6->ip_max[4], v6->ip_max[5], v6->ip_max[6],  v6->ip_max[7],
               v6->ip_max[8], v6->ip_max[9], v6->ip_max[10], v6->ip_max[11],
               v6->ip_max[12], v6->ip_max[13], v6->ip_max[14], v6->ip_max[15]);
        printf("  port_min = %u, port_max = %u}\n",
               ((uint16_t)v6->port_min[0] << 8) | v6->port_min[1],
               ((uint16_t)v6->port_max[0] << 8) | v6->port_max[1]);
    }
    else {
        printf("FlowKeyType{tag inconnu = %d}\n", (int)tag);
    }
}

int build_flow_key(void *key, uint8_t *src_ip, uint8_t *dst_ip, uint8_t *src_port, uint8_t *dst_port, uint8_t proto, int v4){
    if ((v4 != 0 && v4 != 1) || key == NULL){
        return -1;
    }
    uint8_t len = v4 == 0 ? L_IPV4 : L_IPV6;
    uint8_t ip_min[len], ip_max[len], port_min[L_PORT], port_max[L_PORT];
    /*ip_min = (uint8_t *)malloc(L_IPV4 * sizeof(uint8_t));
    ip_max = (uint8_t *)malloc(L_IPV4 * sizeof(uint8_t));
    port_min = (uint8_t *)malloc(L_PORT * sizeof(uint8_t));
    port_max = (uint8_t *)malloc(L_PORT * sizeof(uint8_t));*/
    //int r = cmp_and_assign(src_ip, dst_ip, ip_min, ip_max, len);
    //cmp_and_assign(src_port, dst_port, port_min, port_max, L_PORT);
    int r = memcmp(src_ip, dst_ip, len);
    if (r == 0){   // identiques
        memcpy(ip_min, src_ip, len); // ip min -> scr
        memcpy(ip_max, dst_ip, len);   // ip max -> dst, arbitraire
        int r = memcmp(src_port, dst_port, L_PORT); // Comparer alors les ports
        if (r == 0){
            memcpy(port_min, src_port, L_PORT);
            memcpy(port_max, dst_port, L_PORT);
        }else{
            if (r < 0){
                memcpy(port_min, src_port, L_PORT);
                memcpy(port_max, dst_port, L_PORT);
            }else{
                memcpy(port_min, dst_port, L_PORT);
                memcpy(port_max, src_port, L_PORT);
            }
        }
    }else{
        if (r < 0){
            memcpy(ip_min, src_ip, len);
            memcpy(port_min, src_port, L_PORT);
            memcpy(ip_max, dst_ip, len);
            memcpy(port_max, dst_port, L_PORT);
        }else{
            memcpy(ip_min, dst_ip, len);
            memcpy(port_min, dst_port, L_PORT);
            memcpy(ip_max, src_ip, len);
            memcpy(port_max, src_port, L_PORT);
        }
    }
    if (v4 == 0){
        FlowKeyIpv4 *ptr = key;
        memset(ptr, 0, sizeof(FlowKeyIpv4));
        ptr -> key = FlowKeyIpv4Type;
        memcpy(ptr -> ip_max, ip_max, len);
        memcpy(ptr -> ip_min, ip_min, len);
        memcpy(ptr -> port_max, port_max, L_PORT);
        memcpy(ptr -> port_min, port_min, L_PORT);
        ptr -> proto = proto;
    }
    else{
        FlowKeyIpv6 *ptr = key;
        memset(ptr, 0, sizeof(FlowKeyIpv6));
        ptr -> key = FlowKeyIpv6Type;
        memcpy(ptr -> ip_max, ip_max, len);
        memcpy(ptr -> ip_min, ip_min, len);
        memcpy(ptr -> port_max, port_max, L_PORT);
        memcpy(ptr -> port_min, port_min, L_PORT);
        ptr -> proto = proto;
    }
    //FlowKey_print(key);
    return 0;
}

int build_flow_entry(void *entry, ParserResult *pr, void *key, int v4){
    if (entry == NULL || pr == NULL){
        return -1;
    }
    if (pr -> code != (uint8_t)SUCCES){
        return -1;
    }
    if (v4 != 0 && v4 != 1){
        return -1;
    }
    if (v4 == 0 && pr -> version != 4){
        return -1;
    }
    if (v4 == 1 && pr -> version != 6){
        return -1;
    }

    FlowEntry *e = (FlowEntry *)entry;
    e -> data = (FlowData *)calloc(1, sizeof(FlowData));
    if (e -> data == NULL){
        return -1;
    }

    ((FlowEntry *)entry) -> key = key;
    FlowData *d = e -> data;
    d -> v4 = (uint8_t)v4;
    d -> verdict = UNKNOW;
    d -> n_pkt_ltr = 1;
    d -> n_pkt_rtl = 0;
    d -> octets_data_ltr = 0;
    d -> octets_data_rtl = 0;
    d -> start_time = monotonic_ms();
    d -> end_time = 0;

    if (v4 == 0){
        memcpy(d -> header.ipv4_headers.initiator_ip, pr -> ip_data.ipv4.src_ip, L_IPV4);
        memcpy(d -> header.ipv4_headers.receiver_ip,  pr -> ip_data.ipv4.dst_ip, L_IPV4);
        d -> proto = pr -> ip_data.ipv4.proto;

        if (pr -> ip_data.ipv4.proto == (uint8_t)TCP){
            memcpy(d -> header.ipv4_headers.initiator_port, pr -> data.tcp.src_port, L_PORT);
            memcpy(d -> header.ipv4_headers.receiver_port,  pr -> data.tcp.dst_port, L_PORT);
            d -> flag_count.syn += (pr -> data.tcp.flags & SYN) ? 1 : 0;
            d -> flag_count.ack += (pr -> data.tcp.flags & ACK) ? 1 : 0;
            d -> flag_count.fin += (pr -> data.tcp.flags & FIN) ? 1 : 0;
            d -> flag_count.rst += (pr -> data.tcp.flags & RST) ? 1 : 0;
            d -> flag_count.psh += (pr -> data.tcp.flags & PSH) ? 1 : 0;
            d -> flag_count.urg += (pr -> data.tcp.flags & URG) ? 1 : 0;
            d -> flag_count.ece += (pr -> data.tcp.flags & ECE) ? 1 : 0;
            d -> flag_count.cwr += (pr -> data.tcp.flags & CWR) ? 1 : 0;
        } else if (pr -> ip_data.ipv4.proto == (uint8_t)UDP){
            memcpy(d -> header.ipv4_headers.initiator_port, pr -> data.udp.src_port, L_PORT);
            memcpy(d -> header.ipv4_headers.receiver_port,  pr -> data.udp.dst_port, L_PORT);
        }
    } else {
        memcpy(d -> header.ipv6_headers.initiator_ip, pr -> ip_data.ipv6.src_ip, L_IPV6);
        memcpy(d -> header.ipv6_headers.receiver_ip,  pr -> ip_data.ipv6.dst_ip, L_IPV6);
        d -> proto = pr -> ip_data.ipv6.next_header;

        if (pr -> ip_data.ipv6.next_header == (uint8_t)TCP){
            memcpy(d -> header.ipv6_headers.initiator_port, pr -> data.tcp.src_port, L_PORT);
            memcpy(d -> header.ipv6_headers.receiver_port,  pr -> data.tcp.dst_port, L_PORT);
            d -> flag_count.syn += (pr -> data.tcp.flags & SYN) ? 1 : 0;
            d -> flag_count.ack += (pr -> data.tcp.flags & ACK) ? 1 : 0;
            d -> flag_count.fin += (pr -> data.tcp.flags & FIN) ? 1 : 0;
            d -> flag_count.rst += (pr -> data.tcp.flags & RST) ? 1 : 0;
            d -> flag_count.psh += (pr -> data.tcp.flags & PSH) ? 1 : 0;
            d -> flag_count.urg += (pr -> data.tcp.flags & URG) ? 1 : 0;
            d -> flag_count.ece += (pr -> data.tcp.flags & ECE) ? 1 : 0;
            d -> flag_count.cwr += (pr -> data.tcp.flags & CWR) ? 1 : 0;
        } else if (pr -> ip_data.ipv6.next_header == (uint8_t)UDP){
            memcpy(d -> header.ipv6_headers.initiator_port, pr -> data.udp.src_port, L_PORT);
            memcpy(d -> header.ipv6_headers.receiver_port,  pr -> data.udp.dst_port, L_PORT);
        }
    }

    return 0;
}

static int _cmp(void *ptr1, void *ptr2, int len){
    return memcmp(ptr1, ptr2, len);
}

static int _int_cmp(int a, int b){
    return (a > b) - (a < b);
}

static int _flow_key_compare(const void *key1, const void *key2, int v4){
    if (v4 != 0 && v4 != 1){
        return 1;
    }
    if (v4 == 0){
        FlowKeyIpv4 *ptr1 = (FlowKeyIpv4 *)key1;
        FlowKeyIpv4 *ptr2 = (FlowKeyIpv4 *)key2;
        return (int)(
            _cmp(ptr1 -> ip_max, ptr2 -> ip_max, L_IPV4) == 0 &&
            _cmp(ptr1 -> ip_min, ptr2 -> ip_min, L_IPV4) == 0 &&
            _cmp(ptr1 -> port_max, ptr2 -> port_max, L_PORT) == 0 &&
            _cmp(ptr1 -> port_min, ptr2 -> port_min, L_PORT) == 0 &&
            _int_cmp(ptr1 -> proto, ptr2 -> proto) == 0
        ) == 1 ? 0 : 1;
    }
    FlowKeyIpv6 *ptr1 = (FlowKeyIpv6 *)key1;
    FlowKeyIpv6 *ptr2 = (FlowKeyIpv6 *)key2;
    return (int)(
        _cmp(ptr1 -> ip_max, ptr2 -> ip_max, L_IPV6) == 0 &&
        _cmp(ptr1 -> ip_min, ptr2 -> ip_min, L_IPV6) == 0 &&
        _cmp(ptr1 -> port_max, ptr2 -> port_max, L_PORT) == 0 &&
        _cmp(ptr1 -> port_min, ptr2 -> port_min, L_PORT) == 0 &&
        _int_cmp(ptr1 -> proto, ptr2 -> proto) == 0
    ) == 1 ? 0 : 1;
}

int flow_key_compare(const void *key1, const void *key2){
    FlowKeyType ptr1 = *(FlowKeyType *)key1;
    FlowKeyType ptr2 = *(FlowKeyType *)key2;
    if (
        (ptr1 == FlowKeyIpv4Type && ptr2 == FlowKeyIpv6Type) ||
        (ptr1 == FlowKeyIpv6Type && ptr2 == FlowKeyIpv4Type)
    ) return 1;
    return _flow_key_compare(
        key1, key2, ptr1 == FlowKeyIpv4Type ? 0 : 1
    );
}

static void _free(void *ptr){
    if (ptr == NULL) return;
    return free(ptr);
}

void flow_key_free(void *key){
    return _free(key);
}

void flow_value_free(void *value){
    return _free(value);
}

void *flow_key_dup(const void *key){
    if (key == NULL) return NULL;
    FlowKeyType ptr = *(FlowKeyType *)key;
    if (ptr != FlowKeyIpv4Type && ptr != FlowKeyIpv6Type) return NULL;
    if (ptr == FlowKeyIpv4Type){
        FlowKeyIpv4 *ptr = (FlowKeyIpv4 *)calloc(1, sizeof(FlowKeyIpv4));
        if (ptr == NULL) return NULL;
        *ptr = *(FlowKeyIpv4 *)key;
        return ptr;
    }else{
        FlowKeyIpv6 *ptr = (FlowKeyIpv6 *)calloc(1, sizeof(FlowKeyIpv6));
        if (ptr == NULL) return NULL;
        *ptr = *(FlowKeyIpv6 *)key;
        return ptr;
    }
}

void *flow_value_dup(const void *value){
    if (value == NULL) return NULL;
    const FlowEntry *src = (const FlowEntry *)value;
    FlowEntry *ptr = (FlowEntry *)calloc(1, sizeof(FlowEntry));
    if (ptr == NULL) return NULL;
    *ptr = *src;
    return  ptr;
}


int flow_hash(const void *key){
    if (key == NULL) return -1;

    const FlowKeyType *tag = (const FlowKeyType *)key;
    uint32_t h = 2166136261u;

    if (*tag == FlowKeyIpv4Type){
        const FlowKeyIpv4 *v = (const FlowKeyIpv4 *)key;
        h = fnv1a_update(h, v->ip_min,   L_IPV4);
        h = fnv1a_update(h, v->ip_max,   L_IPV4);
        h = fnv1a_update(h, v->port_min, L_PORT);
        h = fnv1a_update(h, v->port_max, L_PORT);
        h ^= v->proto;
        h *= 16777619u;
    } else if (*tag == FlowKeyIpv6Type){
        const FlowKeyIpv6 *v = (const FlowKeyIpv6 *)key;
        h = fnv1a_update(h, v->ip_min,   L_IPV6);   /* ← 16, pas 4 */
        h = fnv1a_update(h, v->ip_max,   L_IPV6);   /* ← 16, pas 4 */
        h = fnv1a_update(h, v->port_min, L_PORT);
        h = fnv1a_update(h, v->port_max, L_PORT);
        h ^= v->proto;
        h *= 16777619u;
    } else {
        return -1;
    }

    h = fmix32(h);
    return (int)(h & 0x7FFFFFFF);
}


Dict* create_ft_dict(uint32_t size){
    if (size <= 0){
        return NULL;
    }
    Dict *dict = create_dict(
        size, flow_hash, flow_key_compare, flow_key_dup, flow_key_free, 
        NULL, NULL
    );
    return dict;
}


int entry_update(FlowEntry *entry, ParserResult *pr){
    if (entry == NULL || pr == NULL){
        return -1;
    }
    if (pr -> code != (uint8_t)SUCCES){
        return -1;
    }
    if (entry->key == NULL) return -1;
    FlowData *d = entry -> data;
    if (d == NULL){
        return -1;
    }

    uint8_t src_ip[L_IPV6];
    uint8_t dst_ip[L_IPV6];
    uint8_t src_port[L_PORT];
    uint8_t dst_port[L_PORT];

    /* 1. Récupérer src/dst et les ports depuis le ParserResult */
    if (d -> v4 == 0){
        memcpy(src_ip, pr -> ip_data.ipv4.src_ip, L_IPV4);
        memcpy(dst_ip, pr -> ip_data.ipv4.dst_ip, L_IPV4);

        if (pr -> ip_data.ipv4.proto == (uint8_t)TCP){
            memcpy(src_port, pr -> data.tcp.src_port, L_PORT);
            memcpy(dst_port, pr -> data.tcp.dst_port, L_PORT);
        } else if (pr -> ip_data.ipv4.proto == (uint8_t)UDP){
            memcpy(src_port, pr -> data.udp.src_port, L_PORT);
            memcpy(dst_port, pr -> data.udp.dst_port, L_PORT);
        } else {
            memset(src_port, 0, L_PORT);
            memset(dst_port, 0, L_PORT);
        }
    } else {
        memcpy(src_ip, pr -> ip_data.ipv6.src_ip, L_IPV6);
        memcpy(dst_ip, pr -> ip_data.ipv6.dst_ip, L_IPV6);

        if (pr -> ip_data.ipv6.next_header == (uint8_t)TCP){
            memcpy(src_port, pr -> data.tcp.src_port, L_PORT);
            memcpy(dst_port, pr -> data.tcp.dst_port, L_PORT);
        } else if (pr -> ip_data.ipv6.next_header == (uint8_t)UDP){
            memcpy(src_port, pr -> data.udp.src_port, L_PORT);
            memcpy(dst_port, pr -> data.udp.dst_port, L_PORT);
        } else {
            memset(src_port, 0, L_PORT);
            memset(dst_port, 0, L_PORT);
        }
    }

    /* 2. Déterminer le sens : ltr ou rtl.
     *    L'initiator du flux est stocké dans data->header.*_headers.initiator_*.
     *    Si le paquet vient de l'initiator → ltr. Sinon → rtl. */
    int ltr = 0;
    if (d -> v4 == 0){
        if (memcmp(src_ip, d -> header.ipv4_headers.initiator_ip, L_IPV4) == 0 &&
            memcmp(src_port, d -> header.ipv4_headers.initiator_port, L_PORT) == 0){
            ltr = 1;
        }
    } else {
        if (memcmp(src_ip, d -> header.ipv6_headers.initiator_ip, L_IPV6) == 0 &&
            memcmp(src_port, d -> header.ipv6_headers.initiator_port, L_PORT) == 0){
            ltr = 1;
        }
    }

    /* 3. Mettre à jour les compteurs selon le sens */
    if (ltr){
        d -> n_pkt_ltr += 1;
    } else {
        d -> n_pkt_rtl += 1;
    }

    /* 4. Compter les flags TCP (peu importe le sens) */
    if (d -> proto == (uint8_t)TCP){
        uint8_t f = pr -> data.tcp.flags;
        d -> flag_count.syn += (f & SYN) ? 1 : 0;
        d -> flag_count.ack += (f & ACK) ? 1 : 0;
        d -> flag_count.fin += (f & FIN) ? 1 : 0;
        d -> flag_count.rst += (f & RST) ? 1 : 0;
        d -> flag_count.psh += (f & PSH) ? 1 : 0;
        d -> flag_count.urg += (f & URG) ? 1 : 0;
        d -> flag_count.ece += (f & ECE) ? 1 : 0;
        d -> flag_count.cwr += (f & CWR) ? 1 : 0;
    }

    return 0;
}