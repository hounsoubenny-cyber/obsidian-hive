#ifndef FLOW_TABLE_H
#define FLOW_TABLE_H
#include <stdint.h>
#include "../dict/dict.h"
#include "../dchained_list/dchained_list.h"
#include "../portmap/portmap.h"

struct FlowTable{
    uint32_t size;
    uint32_t nbr_elements;
    Dict *flow_dict;
    DChainedList *flow_dcl;
    Dict *port_per_ip;
    uint32_t n_evicted;
};
struct PortPerIpKey {
    uint8_t ip[16];
    uint8_t v4;
    uint8_t pad[3];
};

typedef struct FlowTable FlowTable;

FlowTable *ft_create(uint32_t size);
void ft_destroy(FlowTable *ptr);
FlowEntry *ft_get(FlowTable *ft, const void *key);              // NULL si absent
FlowEntry *ft_get_or_create(FlowTable *ft, const void *key);    // crée si absent
int ft_contains(FlowTable *ft, const void *key);              // 0 présent, -1 absent
int ft_add(FlowTable *ft, const void *key, const FlowEntry *entry);              // 0 succèss, -1 échec
int ft_can_add(FlowTable *ft);
void ft_evict_oldest(FlowTable *ft);
int ft_process(FlowTable *ft, ParserResult *pr);
#endif