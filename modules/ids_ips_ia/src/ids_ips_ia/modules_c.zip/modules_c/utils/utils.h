#ifndef UTILS_H
#define UTILS_H
#include <stdint.h>
#include <time.h>


uint32_t ipv4_to_u32(const uint8_t ip[4]);
uint16_t port_to_u16(const uint8_t p[2]);
uint64_t monotonic_ms();
uint32_t fnv1a(const void *data, size_t len);
uint32_t fnv1a_update(uint32_t h, const uint8_t *p, size_t n);
uint32_t fmix32(uint32_t h);

#endif