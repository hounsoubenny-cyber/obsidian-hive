#ifndef DCHAINED_LIST_H
#define DCHAINED_LIST_H
#include <stdint.h>
#include <stdint.h>
#include "../flows/flow.h"

struct DChainedList{
    uint32_t max_element;         // 0 = infini
    uint32_t n_elements;
    FlowEntry *head;
    FlowEntry *tail;
    FlowEntry *current_element;
};
typedef struct DChainedList DChainedList;

DChainedList *create_dcl(uint32_t max_element);
int add_to_end(DChainedList *dcl, FlowEntry *entry, int del);   // si plein supprimé le premier
int add_to_top(DChainedList *dcl, FlowEntry *entry, int del);   // si plein supprimé le dernier
int move_to_top(DChainedList *dcl, FlowEntry *entry);
int move_to_end(DChainedList *dcl, FlowEntry *entry);
int delete_from_end(DChainedList *dcl);
int delete_from_top(DChainedList *dcl);
#endif