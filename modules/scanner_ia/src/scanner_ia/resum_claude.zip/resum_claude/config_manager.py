#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 26 11:51:49 2026

@author: hounsousamuel
"""

import os, sys
sys.path.insert(1, os.path.dirname(os.path.abspath(os.path.join(__file__, ".."))))
import json5
import hashlib
from scanner_ia.core.fetcher import Config as FetcherConfig
from scanner_ia.core.parser import Config as ParserConfig
from scanner_ia.core.crawler import Config as CrawlerConfig
from scanner_ia.core.analyzer_helper import Config as AnalyzerHelperConfig

DICT = {
    "fetcher": FetcherConfig,
    "crawler": CrawlerConfig,
    "parser": ParserConfig,
    "analyzer_helper": AnalyzerHelperConfig,
}

DEFAULT_CONFIG_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), ".", "shieldai_scanner.config.json5"))

class ConfigManager:
    
    DICT = DICT
    
    def configure(self, path: str = DEFAULT_CONFIG_PATH):
        if not os.path.exists(path):
            raise FileNotFoundError()
        
        config = None
        with open(path, "r") as f:
            config = json5.load(f)
        
        if config:
            to_return = {}
            for k, v in DICT.items():
                if k in config:
                    to_return[k] = {}
                    conf_k = config[k]
                    for i, j in conf_k.items():
                        if hasattr(v, i):
                            if getattr(v, i, None) != j:
                                print("Attribut", i, "de", type(v()).__name__, "mis à jour :", getattr(v, i, None), "-->", j, "\n")
                            setattr(v, i, j)
                            to_return[k][i] = j
                            
            return hashlib.md5(json5.dumps(to_return, indent=2, ensure_ascii=False, default=str).encode()).hexdigest()
    
        return ""

if __name__ == "__main__":
    confM = ConfigManager()
    path = "/home/hounsousamuel/PROJET/ShieldIA_v2/scanner_ia/shieldai_scanner.config.json5"
    print(confM.configure(path))
        
        
            
        
    