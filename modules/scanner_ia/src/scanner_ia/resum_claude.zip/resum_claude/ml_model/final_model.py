#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 26 11:48:04 2026

@author: hounsousamuel
"""



class FinalAI:
    def __init__(self):
        pass